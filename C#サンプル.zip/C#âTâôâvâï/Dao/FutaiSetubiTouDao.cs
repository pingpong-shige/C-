﻿using Dapper;
using Suisitu.Common;
using Suisitu.Entity;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Suisitu.Dao
{
    public class FutaiSetubiTouDao
    {
        /// <summary>
        /// 選択対象キーに該当する付帯設備等情報を取得します。
        /// </summary>
        /// <param name="key">選択対象キー</param>
        /// <returns>付帯設備等情報</returns>
        public static IEnumerable<FutaiSetubiTouEntity> SelectList(FutaiSetubiTouEntity key)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            IEnumerable<FutaiSetubiTouEntity> list = null;

            string sql = @"SELECT * FROM SDTFUTAISETUBI WHERE NENDO = @Nendo AND KANRINO = @KanriNo ORDER BY TORIMATOMEFLAG DESC, CONVERT(INT, TSNO), CONVERT(INT, FSNO)";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    list = conn.Query<FutaiSetubiTouEntity>(sql, key);
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);

            return list;
        }

        /// <summary>
        /// 選択対象キーに該当する付帯設備等情報を取得します。
        /// </summary>
        /// <param name="key">選択対象キー</param>
        /// <returns>付帯設備等情報</returns>
        public static FutaiSetubiTouEntity Select(FutaiSetubiTouEntity key)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            FutaiSetubiTouEntity entity = null;

            string sql = @"SELECT * FROM SDTFUTAISETUBI WHERE NENDO = @Nendo AND KANRINO = @KanriNo AND FSNO = @FsNo";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    entity = conn.QueryFirstOrDefault<FutaiSetubiTouEntity>(sql, key);
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);

            return entity;
        }

        /// <summary>
        /// 選択対象キーに該当する付帯設備等番号の最大値＋1を取得します。
        /// 該当データが存在しない場合は、"001"を返します。
        /// </summary>
        /// <param name="key">選択対象キー</param>
        /// <returns>新付帯設備等番号</returns>
        public static string GetNewFsNo(FutaiSetubiTouEntity key)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            dynamic entity = null;

            string sql = @"SELECT MAX(CONVERT(INT, FSNO)) + 1 AS MAXFSNO FROM SDTFUTAISETUBI WHERE NENDO = @Nendo AND KANRINO = @KanriNo";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    entity = conn.QueryFirstOrDefault(sql, key);
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);

            return entity.MAXFSNO == null ? "001" : String.Format("{0:000}", (int)entity.MAXFSNO);
        }

        /// <summary>
        /// 付帯設備等情報を登録します。
        /// </summary>
        /// <param name="entity">登録データ</param>
        public static void Insert(FutaiSetubiTouEntity entity)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            string sql = @"
INSERT INTO SDTFUTAISETUBI(
       NENDO
      ,KANRINO
      ,FSNO
      ,TORIMATOMEFLAG
      ,TORIMATOMEMEMO
      ,TSNO
      ,SISETUNAMEN
      ,SETUBIUMUFLAG1
      ,KOZOKIJUNFLAG1
      ,TEIKITENKENUMUFLAG1
      ,SETUBIUMUFLAG2
      ,KOZOKIJUNFLAG2
      ,TEIKITENKENUMUFLAG2
      ,SETUBIUMUFLAG3
      ,KOZOKIJUNFLAG3
      ,TEIKITENKENUMUFLAG3
      ,SETUBIUMUFLAG4
      ,KOZOKIJUNFLAG4
      ,TEIKITENKENUMUFLAG4
      ,SETUBIUMUFLAG5
      ,KOZOKIJUNFLAG5
      ,TEIKITENKENUMUFLAG5
      ,SETUBIUMUFLAG6
      ,KOZOKIJUNFLAG6
      ,TEIKITENKENUMUFLAG6
      ,SETUBIUMUFLAG7
      ,KOZOKIJUNFLAG7
      ,TEIKITENKENUMUFLAG7
      ,BIKO
      ,TOROKUDATE
      ,UPDDATE
      ,REV
     )
     VALUES (
      @Nendo
     ,@KanriNo
     ,@FsNo
     ,@TorimatomeFlag
     ,@TorimatomeMemo
     ,@TsNo
     ,@SisetuNameN
     ,@SetubiUmuFlag1
     ,@KozoKijunFlag1
     ,@TeikiTenkenUmuFlag1
     ,@SetubiUmuFlag2
     ,@KozoKijunFlag2
     ,@TeikiTenkenUmuFlag2
     ,@SetubiUmuFlag3
     ,@KozoKijunFlag3
     ,@TeikiTenkenUmuFlag3
     ,@SetubiUmuFlag4
     ,@KozoKijunFlag4
     ,@TeikiTenkenUmuFlag4
     ,@SetubiUmuFlag5
     ,@KozoKijunFlag5
     ,@TeikiTenkenUmuFlag5
     ,@SetubiUmuFlag6
     ,@KozoKijunFlag6
     ,@TeikiTenkenUmuFlag6
     ,@SetubiUmuFlag7
     ,@KozoKijunFlag7
     ,@TeikiTenkenUmuFlag7
     ,@Biko
     ,@TorokuDate
     ,@UpdDate
     ,@Rev
      )
";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    conn.Open();

                    using (var tran = conn.BeginTransaction())
                    {
                        try
                        {
                            conn.Execute(sql, entity, tran);
                            tran.Commit();
                        }
                        catch (Exception ex)
                        {
                            tran.Rollback();
                            throw ex;
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);
        }

        /// <summary>
        /// 付帯設備等情報を更新します。
        /// </summary>
        /// <param name="entity">更新データ</param>
        public static void Update(FutaiSetubiTouEntity entity)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            string sql = @"
UPDATE SDTFUTAISETUBI
   SET NENDO = @Nendo
      ,KANRINO = @KanriNo
      ,FSNO = @FsNo
      ,TORIMATOMEFLAG = @TorimatomeFlag
      ,TORIMATOMEMEMO = @TorimatomeMemo
      ,TSNO = @TsNo
      ,SISETUNAMEN = @SisetuNameN
      ,SETUBIUMUFLAG1 = @SetubiUmuFlag1
      ,KOZOKIJUNFLAG1 = @KozokijunFlag1
      ,TEIKITENKENUMUFLAG1 = @TeikiTenkenUmuFlag1
      ,SETUBIUMUFLAG2 = @SetubiUmuFlag2
      ,KOZOKIJUNFLAG2 = @KozokijunFlag2
      ,TEIKITENKENUMUFLAG2 = @TeikiTenkenUmuFlag2
      ,SETUBIUMUFLAG3 = @SetubiUmuFlag3
      ,KOZOKIJUNFLAG3 = @KozokijunFlag3
      ,TEIKITENKENUMUFLAG3 = @TeikiTenkenUmuFlag3
      ,SETUBIUMUFLAG4 = @SetubiUmuFlag4
      ,KOZOKIJUNFLAG4 = @KozokijunFlag4
      ,TEIKITENKENUMUFLAG4 = @TeikiTenkenUmuFlag4
      ,SETUBIUMUFLAG5 = @SetubiUmuFlag5
      ,KOZOKIJUNFLAG5 = @KozokijunFlag5
      ,TEIKITENKENUMUFLAG5 = @TeikiTenkenUmuFlag5
      ,SETUBIUMUFLAG6 = @SetubiUmuFlag6
      ,KOZOKIJUNFLAG6 = @KozokijunFlag6
      ,TEIKITENKENUMUFLAG6 = @TeikiTenkenUmuFlag6
      ,SETUBIUMUFLAG7 = @SetubiUmuFlag7
      ,KOZOKIJUNFLAG7 = @KozokijunFlag7
      ,TEIKITENKENUMUFLAG7 = @TeikiTenkenUmuFlag7
      ,BIKO = @Biko
      ,UPDDATE = @UpdDate
      ,REV = REV + @Rev
 WHERE NENDO = @Nendo
   AND KANRINO = @KanriNo
   AND FSNO = @FsNo
";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    conn.Open();

                    using (var tran = conn.BeginTransaction())
                    {
                        try
                        {
                            conn.Execute(sql, entity, tran);
                            tran.Commit();
                        }
                        catch (Exception ex)
                        {
                            tran.Rollback();
                            throw ex;
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);
        }

        /// <summary>
        /// 年度、管理番号に該当する付帯設備等情報を削除します。
        /// </summary>
        /// <param name="nendo">年度</param>
        /// <param name="kanriNo">管理番号</param>
        public static void Delete(int nendo, int kanriNo)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            string sql = @"DELETE FROM SDTFUTAISETUBI WHERE NENDO = @Nendo AND KANRINO = @KanriNo";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    conn.Open();

                    using (var tran = conn.BeginTransaction())
                    {
                        try
                        {
                            conn.Execute(sql, new { Nendo = nendo, KanriNo = kanriNo }, tran);
                            tran.Commit();
                        }
                        catch (Exception ex)
                        {
                            tran.Rollback();
                            throw ex;
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);
        }

        /// <summary>
        /// 削除対象キーに該当する付帯設備等情報を削除します。
        /// </summary>
        /// <param name="key">削除対象キー</param>
        public static void Delete(FutaiSetubiTouEntity key)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            string sql = @"DELETE FROM SDTFUTAISETUBI WHERE NENDO = @Nendo AND KANRINO = @KanriNo AND FSNO = @FsNo";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    conn.Open();

                    using (var tran = conn.BeginTransaction())
                    {
                        try
                        {
                            conn.Execute(sql, key, tran);
                            tran.Commit();
                        }
                        catch (Exception ex)
                        {
                            tran.Rollback();
                            throw ex;
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);
        }


    }
}
