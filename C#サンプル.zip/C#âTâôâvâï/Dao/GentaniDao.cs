﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using Dapper;
using Suisitu.Common;
using Suisitu.Entity;

namespace Suisitu.Dao
{
    /// <summary>
    /// 原単位Daoクラス
    /// </summary>
    public class GentaniDao
    {
        #region パブリックメソッド

        /// <summary>
        /// 原単位情報を取得します。
        /// </summary>
        /// <returns>原単位情報</returns>
        public static IEnumerable<GentaniEntity> SelectAll()
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            IEnumerable<GentaniEntity> list = null;

            string sql = @"SELECT * FROM SDCGENTANI ORDER BY SANGYOBC";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    list = conn.Query<GentaniEntity>(sql);
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);

            return list;
        }

        /// <summary>
        /// 選択対象キーに該当する原単位情報を取得します。
        /// </summary>
        /// <param name="key">選択対象キー</param>
        /// <returns>原単位情報</returns>
        public static GentaniEntity Select(GentaniEntity key)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            GentaniEntity entity = null;

            string sql = @"SELECT * FROM SDCGENTANI WHERE SANGYOBC = @Sangyobc";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    entity = conn.QueryFirstOrDefault<GentaniEntity>(sql, key);
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);

            return entity;
        }

        /// <summary>
        /// 産業分類（中分類）を取得します。（コンボボックス設定用）
        /// </summary>
        /// <returns>届出区分情報</returns>
        public static IEnumerable<MasterEntity> GetMasterData()
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            IEnumerable<MasterEntity> list = null;

            string sql = @"
SELECT SANGYOBC AS VALUE, SANGYOBCNAMEN AS NAME
  FROM SDCSANGYOBC
 ORDER BY SANGYOBC";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    list = conn.Query<MasterEntity>(sql, new GentaniEntity { });
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);

            return list;
        }

        /// <summary>
        /// 原単位情報を登録します。
        /// </summary>
        /// <param name="entity">登録データ</param>
        public static void Insert(GentaniEntity entity)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            string sql = @"
INSERT INTO SDCGENTANI( 
    SANGYOBC
   ,BOD
   ,COD
   ,TN
   ,TP
   ,UPDDATE
   ,REV
)
VALUES ( 
    @Sangyobc
   ,@Bod
   ,@Cod
   ,@Tn
   ,@Tp
   ,@UpdDate
   ,@Rev
)
";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    conn.Open();

                    using (var tran = conn.BeginTransaction())
                    {
                        try
                        {
                            conn.Execute(sql, entity, tran);
                            tran.Commit();
                        }
                        catch (Exception ex)
                        {
                            tran.Rollback();
                            throw ex;
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);
        }

        /// <summary>
        /// 原単位情報を更新します。
        /// </summary>
        /// <param name="entity">更新データ</param>
        public static void Update(GentaniEntity entity)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            string sql = @"
UPDATE SDCGENTANI
   SET BOD = @Bod
      ,COD = @Cod
      ,Tn = @Tn
      ,Tp = @Tp
      ,UPDDATE = @UpdDate
      ,REV = REV + @Rev
WHERE SANGYOBC = @Sangyobc
";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    conn.Open();

                    using (var tran = conn.BeginTransaction())
                    {
                        try
                        {
                            conn.Execute(sql, entity, tran);
                            tran.Commit();
                        }
                        catch (Exception ex)
                        {
                            tran.Rollback();
                            throw ex;
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);
        }

        /// <summary>
        /// 削除対象キーに該当する原単位情報を削除します。
        /// </summary>
        /// <param name="key">削除対象キー</param>
        public static void Delete(GentaniEntity key)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            string sql = @"DELETE FROM SDCGENTANI WHERE SANGYOBC = @Sangyobc";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    conn.Open();

                    using (var tran = conn.BeginTransaction())
                    {
                        try
                        {
                            conn.Execute(sql, key, tran);
                            tran.Commit();
                        }
                        catch (Exception ex)
                        {
                            tran.Rollback();
                            throw ex;
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);
        }

        #endregion
    }
}
