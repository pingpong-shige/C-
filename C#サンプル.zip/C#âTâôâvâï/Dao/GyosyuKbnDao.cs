﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using Dapper;
using Suisitu.Common;
using Suisitu.Entity;

namespace Suisitu.Dao
{
    /// <summary>
    /// 業種区分表Daoクラス
    /// </summary>
    class GyosyuKbnDao
    {
        #region パブリックメソッド

        /// <summary>
        /// 業種区分情報を取得します。
        /// </summary>
        /// <returns>業種区分情報</returns>
        public static IEnumerable<GyosyuKbnEntity> SelectAll()
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            IEnumerable<GyosyuKbnEntity> list = null;

            string sql = @"SELECT * FROM SDCGYOSYUKBN ORDER BY GYOSYUKBN";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    list = conn.Query<GyosyuKbnEntity>(sql);
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);

            return list;
        }

        /// <summary>
        /// 選択対象キーに該当する業種区分情報を取得します。
        /// </summary>
        /// <param name="key">選択対象キー</param>
        /// <returns>業種区分情報</returns>
        public static GyosyuKbnEntity Select(GyosyuKbnEntity key)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            GyosyuKbnEntity entity = null;

            string sql = @"SELECT * FROM SDCGYOSYUKBN WHERE GYOSYUKBN = @GyosyuKbn";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    entity = conn.QueryFirstOrDefault<GyosyuKbnEntity>(sql, key);
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);

            return entity;
        }

        /// <summary>
        /// 業種区分情報を登録します。
        /// </summary>
        /// <param name="entity">登録データ</param>
        public static void Insert(GyosyuKbnEntity entity)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            string sql = @"
INSERT INTO SDCGYOSYUKBN( 
    GYOSYUKBN
   ,GYOSYUKBNNAMEN
   ,UPDDATE
   ,REV
)
VALUES ( 
    @GyosyuKbn
   ,@GyosyuKbnNameN
   ,@UpdDate
   ,@Rev
)
";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    conn.Open();

                    using (var tran = conn.BeginTransaction())
                    {
                        try
                        {
                            conn.Execute(sql, entity, tran);
                            tran.Commit();
                        }
                        catch (Exception ex)
                        {
                            tran.Rollback();
                            throw ex;
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);
        }

        /// <summary>
        /// 業種区分情報を更新します。
        /// </summary>
        /// <param name="entity">更新データ</param>
        public static void Update(GyosyuKbnEntity entity)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            string sql = @"
UPDATE SDCGYOSYUKBN
   SET GYOSYUKBN = @GyosyuKbn
      ,GYOSYUKBNNAMEN = @GyosyuKbnNameN
      ,UPDDATE = @UpdDate
      ,REV = REV + @Rev
WHERE GYOSYUKBN = @GYOSYUKBN
";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    conn.Open();

                    using (var tran = conn.BeginTransaction())
                    {
                        try
                        {
                            conn.Execute(sql, entity, tran);
                            tran.Commit();
                        }
                        catch (Exception ex)
                        {
                            tran.Rollback();
                            throw ex;
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);
        }

        /// <summary>
        /// 業種区分キーに該当する業種区分情報を削除します。
        /// </summary>
        /// <param name="key">削除対象キー</param>
        public static void Delete(GyosyuKbnEntity key)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            string sql = @"DELETE FROM SDCGYOSYUKBN WHERE GyosyuKbn = @GyosyuKbn";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    conn.Open();

                    using (var tran = conn.BeginTransaction())
                    {
                        try
                        {
                            conn.Execute(sql, key, tran);
                            tran.Commit();
                        }
                        catch (Exception ex)
                        {
                            tran.Rollback();
                            throw ex;
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_START);
        }

        /// <summary>
        /// 業種区分情報を取得します。（コンボボックス設定用）
        /// </summary>
        /// <returns>業種区分情報</returns>
        public static IEnumerable<MasterEntity> GetMasterData()
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            IEnumerable<MasterEntity> list = null;

            string sql = @"
SELECT GYOSYUKBN AS VALUE, GYOSYUKBNNAMEN AS NAME
  FROM SDCGYOSYUKBN
 ORDER BY GYOSYUKBN";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    list = conn.Query<MasterEntity>(sql);
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);

            return list;
        }

        #endregion
    }
}
