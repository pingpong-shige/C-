﻿using Dapper;
using log4net;
using Suisitu.Common;
using Suisitu.Entity;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Reflection;

namespace Suisitu.Dao
{
    /// <summary>
    /// 排水口Daoクラス
    /// </summary>
    public class HaisuikoDao
    {
        private static readonly ILog logger = LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);

        #region パブリックメソッド

        /// <summary>
        /// 選択対象キーに該当する一般事項を取得します。
        /// </summary>
        /// <param name="key">選択対象キー</param>
        /// <returns>一般事項</returns>
        public static HaisuikoEntity Select(HaisuikoEntity key)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            HaisuikoEntity entity = null;

            string sql = @"SELECT * FROM SDTHAISUIKO WHERE NENDO = @Nendo AND KANRINO = @KanriNo AND HAISUIKONO = @HaisuikoNo";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    entity = conn.QueryFirstOrDefault<HaisuikoEntity>(sql, key);
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);

            return entity;
        }

        /// <summary>
        /// 年度、管理番号に該当する排水口情報一覧を取得します。
        /// </summary>
        /// <param name="nendo">年度</param>
        /// <param name="kanriNo">管理番号</param>
        /// <returns>排水口情報一覧</returns>
        public static IEnumerable<HaisuikoEntity> SelectList(int nendo, int kanriNo)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            IEnumerable<HaisuikoEntity> list = null;

            string sql = @"SELECT * FROM SDTHAISUIKO WHERE NENDO = @Nendo AND KANRINO = @KanriNo AND HAISIFLAG != '*'";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    list = conn.Query<HaisuikoEntity>(sql, new { Nendo = nendo, KanriNo = kanriNo });
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);

            return list;
        }

        /// <summary>
        /// 選択対象キーに該当する排水口番号の最大値＋1を取得します。
        /// 該当データが存在しない場合は、"01"を返します。
        /// </summary>
        /// <param name="key">選択対象キー</param>
        /// <returns>新排水口番号</returns>
        public static string GetNewHaisuikoNo(HaisuikoEntity key)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            dynamic entity = null;

            string sql = @"SELECT MAX(CONVERT(INT, HAISUIKONO)) + 1 AS MAXNO FROM SDTHAISUIKO WHERE NENDO = @Nendo AND KANRINO = @KanriNo";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    entity = conn.QueryFirstOrDefault(sql, key);
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);

            return entity.MAXNO == null ? "01" : String.Format("{0:00}", (int)entity.MAXNO);
        }

        /// <summary>
        /// 排水口情報を登録します。
        /// </summary>
        /// <param name="entity">登録データ</param>
        public static void Insert(HaisuikoEntity entity)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            string sql = @"
INSERT INTO SDTHAISUIKO(
       NENDO
      ,KANRINO
      ,HAISUIKONO
      ,SETIDATE
      ,HAISIDATE
      ,TDKDHSAVE
      ,TDKDHSMAX
      ,BIKO
      ,TOROKUDATE
      ,HAISIFLAG
      ,UPDDATE
      ,REV
     )
     VALUES (
      @Nendo
     ,@KanriNo
     ,@HaisuikoNo
     ,@SetiDate
     ,@HaisiDate
     ,@TdkdHsAve
     ,@TdkdHsMax
     ,@Biko
     ,@TorokuDate
     ,@HaisiFlag
     ,@UpdDate
     ,@Rev
      )
";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    conn.Open();

                    using (var tran = conn.BeginTransaction())
                    {
                        try
                        {
                            conn.Execute(sql, entity, tran);
                            tran.Commit();
                        }
                        catch (Exception ex)
                        {
                            tran.Rollback();
                            throw ex;
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);
        }

        /// <summary>
        /// 排水口情報を更新します。
        /// </summary>
        /// <param name="entity">更新データ</param>
        public static void Update(HaisuikoEntity entity)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            string sql = @"
UPDATE SDTHAISUIKO
   SET NENDO = @Nendo
      ,KANRINO = @KanriNo
      ,HAISUIKONO = @HaisuikoNo
      ,SETIDATE = @SetiDate
      ,HAISIDATE = @HaisiDate
      ,TDKDHSAVE = @TdkdHsAve
      ,TDKDHSMAX = @TdkdHsMax
      ,BIKO = @Biko
      ,UPDDATE = @UpdDate
      ,REV = REV + @Rev
 WHERE NENDO = @Nendo
   AND KANRINO = @KanriNo
   AND HAISUIKONO = @HaisuikoNo
";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    conn.Open();

                    using (var tran = conn.BeginTransaction())
                    {
                        try
                        {
                            conn.Execute(sql, entity, tran);
                            tran.Commit();
                        }
                        catch (Exception ex)
                        {
                            tran.Rollback();
                            throw ex;
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);
        }

        /// <summary>
        /// 削除対象キーに該当する排水口情報を削除します。
        /// </summary>
        /// <param name="key">削除対象キー</param>
        public static void Delete(HaisuikoEntity key)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            string sql = @"DELETE FROM SDTHAISUIKO WHERE NENDO = @Nendo AND KANRINO = @KanriNo AND HAISUIKONO = @HaisuikoNo";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    conn.Open();

                    using (var tran = conn.BeginTransaction())
                    {
                        try
                        {
                            conn.Execute(sql, key, tran);
                            tran.Commit();
                        }
                        catch (Exception ex)
                        {
                            tran.Rollback();
                            throw ex;
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);
        }

        /// <summary>
        /// 年度、管理番号に該当する排水口情報を削除します。
        /// </summary>
        /// <param name="nendo">年度</param>
        /// <param name="kanriNo">管理番号</param>
        public static void Delete(int nendo, int kanriNo)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            string sql = @"DELETE FROM SDTHAISUIKO WHERE NENDO = @Nendo AND KANRINO = @KanriNo";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    conn.Open();

                    using (var tran = conn.BeginTransaction())
                    {
                        try
                        {
                            conn.Execute(sql, new { Nendo = nendo, KanriNo = kanriNo }, tran);
                            tran.Commit();
                        }
                        catch (Exception ex)
                        {
                            tran.Rollback();
                            throw ex;
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);
        }

        #endregion
    }
}
