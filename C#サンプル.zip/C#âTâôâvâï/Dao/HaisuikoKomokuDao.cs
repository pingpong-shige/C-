﻿using Dapper;
using log4net;
using Suisitu.Common;
using Suisitu.Entity;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Reflection;

namespace Suisitu.Dao
{
    /// <summary>
    /// 排水口項目Daoクラス
    /// </summary>
    public class HaisuikoKomokuDao
    {
        private static readonly ILog logger = LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);

        #region パブリックメソッド

        /// <summary>
        /// 選択対象キーに該当する排水口項目情報を取得します。
        /// </summary>
        /// <param name="key">選択対象キー</param>
        /// <returns>排水口項目情報</returns>
        public static HaisuikoKomokuItiranEntity Select(HaisuikoKomokuItiranEntity key)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            HaisuikoKomokuItiranEntity entity = null;

            string sql = @"
SELECT * FROM SDTHAISUIKOKOMOKU
 WHERE NENDO = @Nendo
   AND KANRINO = @KanriNo
   AND HAISUIKONO = @HaisuikoNo
   AND KOMOKUCODE = @KomokuCode";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    entity = conn.QueryFirstOrDefault<HaisuikoKomokuItiranEntity>(sql, key);
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);

            return entity;
        }

        /// <summary>
        /// 年度、管理番号、排水口番号、採水項目フラグ「1」に該当する排水口目情報を取得します。
        /// </summary>
        /// <returns>項目名称</returns>
        public static IEnumerable<HaisuikoKomokuItiranEntity> SelectList(HaisuikoKomokuItiranEntity key)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            IEnumerable<HaisuikoKomokuItiranEntity> list = null;

            string sql = @"SELECT * FROM SDTHAISUIKOKOMOKU WHERE NENDO = @Nendo AND KANRINO = @KanriNo AND HAISUIKONO = @HaisuikoNo AND SAISUIKOMOKUFLAG = 1";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    list = conn.Query<HaisuikoKomokuItiranEntity>(sql, key);
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);

            return list;
        }

        /// <summary>
        /// 排水口項目情報を登録します。
        /// </summary>
        /// <param name="entity">登録データ</param>
        public static void Insert(HaisuikoKomokuItiranEntity entity)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            string sql = @"
INSERT INTO SDTHAISUIKOKOMOKU(
       NENDO
      ,KANRINO
      ,HAISUIKONO
      ,KOMOKUCODE
      ,TDKDAVE
      ,TDKDMAX
      ,SAISUIKOMOKUFLAG
      ,TOROKUDATE
      ,UPDDATE
      ,REV
     )
     VALUES (
      @Nendo
     ,@KanriNo
     ,@HaisuikoNo
     ,@KomokuCode
     ,@TdkdAve
     ,@TdkdMax
     ,@SaisuiKomokuFlag
     ,@TorokuDate
     ,@UpdDate
     ,@Rev
      )
";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    conn.Open();

                    using (var tran = conn.BeginTransaction())
                    {
                        try
                        {
                            conn.Execute(sql, entity, tran);
                            tran.Commit();
                        }
                        catch (Exception ex)
                        {
                            tran.Rollback();
                            throw ex;
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);
        }

        /// <summary>
        /// 排水口項目情報を更新します。
        /// </summary>
        /// <param name="entity">更新データ</param>
        public static void Update(HaisuikoKomokuItiranEntity entity)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            string sql = @"
UPDATE SDTHAISUIKOKOMOKU
   SET NENDO = @Nendo
      ,KANRINO = @KanriNo
      ,HAISUIKONO = @HaisuikoNo
      ,KOMOKUCODE = @KomokuCode
      ,TDKDAVE = @TdkdAve
      ,TDKDMAX = @TdkdMax
      ,SAISUIKOMOKUFLAG = @SaisuiKomokuFlag
      ,UPDDATE = @UpdDate
      ,REV = REV + @Rev
 WHERE NENDO = @Nendo
   AND KANRINO = @KanriNo
   AND HAISUIKONO = @HaisuikoNo
   AND KOMOKUCODE = @KomokuCode
";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    conn.Open();

                    using (var tran = conn.BeginTransaction())
                    {
                        try
                        {
                            conn.Execute(sql, entity, tran);
                            tran.Commit();
                        }
                        catch (Exception ex)
                        {
                            tran.Rollback();
                            throw ex;
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);
        }

        /// <summary>
        /// 削除対象キーに該当する排水口項目情報を削除します。
        /// </summary>
        /// <param name="key">削除対象キー</param>
        public static void Delete(HaisuikoKomokuItiranEntity key)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            string sql = @"
DELETE FROM SDTHAISUIKOKOMOKU
 WHERE NENDO = @Nendo
   AND KANRINO = @KanriNo
   AND HAISUIKONO = @HaisuikoNo
   AND KOMOKUCODE = @KomokuCode";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    conn.Open();

                    using (var tran = conn.BeginTransaction())
                    {
                        try
                        {
                            conn.Execute(sql, new { Nendo = key.Nendo, KanriNo = key.KanriNo, HaisuikoNo = key.HaisuikoNo, KomokuCode = key.KomokuCode }, tran);
                            tran.Commit();
                        }
                        catch (Exception ex)
                        {
                            tran.Rollback();
                            throw ex;
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);
        }

        /// <summary>
        /// 年度、管理番号に該当する排水口項目情報を削除します。
        /// </summary>
        /// <param name="nendo">年度</param>
        /// <param name="kanriNo">管理番号</param>
        public static void Delete(int nendo, int kanriNo)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            string sql = @"DELETE FROM SDTHAISUIKOKOMOKU WHERE NENDO = @Nendo AND KANRINO = @KanriNo";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    conn.Open();

                    using (var tran = conn.BeginTransaction())
                    {
                        try
                        {
                            conn.Execute(sql, new { Nendo = nendo, KanriNo = kanriNo }, tran);
                            tran.Commit();
                        }
                        catch (Exception ex)
                        {
                            tran.Rollback();
                            throw ex;
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);
        }

        #endregion
    }
}
