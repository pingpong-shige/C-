﻿using Dapper;
using log4net;
using Suisitu.Common;
using Suisitu.Entity;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Reflection;

namespace Suisitu.Dao
{
    /// <summary>
    /// 排水口項目一覧Daoクラス
    /// </summary>
    public class HaisuikoKomokuItiranDao
    {
        private static readonly ILog logger = LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);

        #region パブリックメソッド

        /// <summary>
        /// 選択対象キーに該当する排水口項目一覧を取得します。
        /// </summary>
        /// <param name="key">選択対象キー</param>
        /// <returns>排水口項目一覧</returns>
        public static List<HaisuikoKomokuItiranEntity> Select(HaisuikoKomokuItiranEntity key)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            List<HaisuikoKomokuItiranEntity> list = null;

            string sql = @"
SELECT * FROM SDVHAISUIKOKOMOKUITIRAN
 WHERE NENDO = @Nendo
   AND KANRINO = @KanriNo
   AND HAISUIKONO = @HaisuikoNo
 ORDER BY WRTSEQNO, KOMOKUCODE";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    list = conn.Query<HaisuikoKomokuItiranEntity>(sql, key).AsList<HaisuikoKomokuItiranEntity>();
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);

            return list;
        }

        #endregion
    }
}
