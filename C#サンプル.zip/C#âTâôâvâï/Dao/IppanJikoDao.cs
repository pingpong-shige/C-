﻿using Dapper;
using log4net;
using Suisitu.Common;
using Suisitu.Entity;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Reflection;

namespace Suisitu.Dao
{
    /// <summary>
    /// 一般事項表Daoクラス
    /// </summary>
    public class IppanJikoDao
    {
        private static readonly ILog logger = LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);

        #region パブリックメソッド

        /// <summary>
        /// 一般事項を取得します。
        /// </summary>
        /// <returns>一般事項</returns>
        public static IEnumerable<IppanJikoEntity> SelectAll()
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            IEnumerable<IppanJikoEntity> list = null;

            string sql = @"SELECT * FROM SDMIPPANJIKO ORDER BY JITITAICODE";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    list = conn.Query<IppanJikoEntity>(sql);
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);

            return list;
        }

        /// <summary>
        /// 選択対象キーに該当する一般事項を取得します。
        /// </summary>
        /// <param name="key">選択対象キー</param>
        /// <returns>一般事項</returns>
        public static IppanJikoEntity Select(IppanJikoEntity key)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            IppanJikoEntity entity = null;

            string sql = @"SELECT * FROM SDMIPPANJIKO WHERE JITITAICODE = @JititaiCode";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    entity = conn.QueryFirstOrDefault<IppanJikoEntity>(sql, key);
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);

            return entity;
        }

        /// <summary>
        /// 一般事項を登録します。
        /// </summary>
        /// <param name="entity">登録データ</param>
        public static void Insert(IppanJikoEntity entity)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            string sql = @"
INSERT INTO SDMIPPANJIKO( 
    JITITAICODE
   ,TANTOKANAMEN
   ,TELNO
   ,FAXNO
   ,EMAIL
   ,UPDDATE
   ,REV
)
VALUES ( 
    @JititaiCode
   ,@TantoKaNameN
   ,@TelNo
   ,@FaxNo
   ,@EMail
   ,@UpdDate
   ,@Rev
)
";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    conn.Open();

                    using (var tran = conn.BeginTransaction())
                    {
                        try
                        {
                            conn.Execute(sql, entity, tran);
                            tran.Commit();
                        }
                        catch (Exception ex)
                        {
                            tran.Rollback();
                            throw ex;
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);
        }

        /// <summary>
        /// 一般事項を更新します。
        /// </summary>
        /// <param name="entity">更新データ</param>
        public static void Update(IppanJikoEntity entity)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            string sql = @"
UPDATE SDMIPPANJIKO
   SET JITITAICODE = @JititaiCode
      ,TANTOKANAMEN = @TantoKaNameN
      ,TELNO = @TelNo
      ,FAXNO = @FaxNo
      ,EMAIL = @EMail
      ,UPDDATE = @UpdDate
      ,REV = REV + @Rev
WHERE JITITAICODE = @JititaiCode
";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    conn.Open();

                    using (var tran = conn.BeginTransaction())
                    {
                        try
                        {
                            conn.Execute(sql, entity, tran);
                            tran.Commit();
                        }
                        catch (Exception ex)
                        {
                            tran.Rollback();
                            throw ex;
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);
        }

        /// <summary>
        /// 削除対象キーに該当する一般事項を削除します。
        /// </summary>
        /// <param name="key">削除対象キー</param>
        public static void Delete(IppanJikoEntity key)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            string sql = @"DELETE FROM SDMIPPANJIKO WHERE JITITAICODE = @JititaiCode";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    conn.Open();

                    using (var tran = conn.BeginTransaction())
                    {
                        try
                        {
                            conn.Execute(sql, key, tran);
                            tran.Commit();
                        }
                        catch (Exception ex)
                        {
                            tran.Rollback();
                            throw ex;
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);
        }

        #endregion
    }
}
