﻿using Dapper;
using Suisitu.Common;
using Suisitu.Entity;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace Suisitu.Dao
{
    public class JigyojoItiranDao
    {
        /// <summary>
        /// すべての事業場一覧を取得します。
        /// </summary>
        /// <returns>事業場一覧</returns>
        public static IEnumerable<JigyojoItiranEntity> SelectAll()
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            IEnumerable<JigyojoItiranEntity> list = null;

            string sql = @"SELECT * FROM SDVJIGYOJOITIRAN WHERE ORDER BY NENDO, KANRINO";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    list = conn.Query<JigyojoItiranEntity>(sql);
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);

            return list;
        }

        /// <summary>
        /// 選択対象キーに該当する事業場一覧を取得します。
        /// </summary>
        /// <param name="key">選択対象キー</param>
        /// <returns>事業場一覧</returns>
        public static IEnumerable<JigyojoItiranEntity> SelectList(JigyojoItiranEntity key)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            IEnumerable<JigyojoItiranEntity> list = null;

            string sql = @" SELECT * FROM SDVJIGYOJOITIRAN";
            string where = @" WHERE NENDO = @Nendo";
            string order = @" ORDER BY NENDO, KANRINO";

            if (key.KanriNo > 0)
                where += @" AND KANRINO = @KanriNo";

            if (!string.IsNullOrEmpty(key.SeiriNo))
                where += @" AND (SEIRINO LIKE @SeiriNo OR dbo.FNC_GetFindSeiriNo(SEIRINO) LIKE @SeiriNo)";

            if (!string.IsNullOrEmpty(key.JigyosyoNameN))
                where += @" AND JIGYOSYONAMEN LIKE @JigyosyoNameN";

            if (!string.IsNullOrEmpty(key.JigyosyoNameK))
                where += @" AND JIGYOSYONAMEK LIKE @JigyosyoNameK";

            if (!string.IsNullOrEmpty(key.SyozaiJyusyo))
                where += @" AND SYOZAIJYUSYO LIKE @SyozaiJyusyo";

            if (!string.IsNullOrEmpty(key.SinseiCopName))
                where += @" AND SINSEICOPNAME LIKE @SinseiCopName";

            sql = sql + where + order;

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    list = conn.Query<JigyojoItiranEntity>(sql, key);
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);

            return list;
        }

        /// <summary>
        /// 事業場一覧情報を取得します。
        /// </summary>
        /// <returns>事業場一覧情報</returns>
        //public static IEnumerable<TokuteiSisetuTouEntity> SelectList(TokuteiSisetuTouEntity param = null)
        public static IEnumerable<JigyojoItiranEntity> SelectList(string key)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            IEnumerable<JigyojoItiranEntity> list = null;

            string sql = @"SELECT * FROM SDVJIGYOJOITIRAN TS WHERE SUBSTRING(SEIRINO,1,3) = '{0}' ORDER BY NENDO, KANRINO, SEIRINO";
            sql = string.Format(sql, key);

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                conn.Open();
                list = conn.Query<JigyojoItiranEntity>(sql);
                conn.Close();
            }

            //logger.Debug(Constant.LOG_METHOD_END);

            return list;
        }

        /// <summary>
        /// 選択対象キーに該当する事業場情報を取得します。
        /// </summary>
        /// <param name="key">選択対象キー</param>
        /// <returns>事業場情報</returns>
        public static JigyojoItiranEntity Select(JigyojoItiranEntity key)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            JigyojoItiranEntity entity = null;

            string sql = @"SELECT * FROM SDVJIGYOJOITIRAN WHERE NENDO = @Nendo AND KANRINO = @KanriNo ORDER BY NENDO, KANRINO";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    entity = conn.QueryFirstOrDefault<JigyojoItiranEntity>(sql, key);
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);

            return entity;
        }

        /// <summary>
        /// 年度リストを取得します。
        /// </summary>
        /// <returns>年度リスト</returns>
        public static IEnumerable<dynamic> GetNendoList()
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            IEnumerable<dynamic> list = null;

            string sql = @"SELECT NENDO FROM SDVJIGYOJOITIRAN GROUP BY NENDO ORDER BY NENDO";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    list = conn.Query(sql);
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);

            return list;
        }
    }
}
