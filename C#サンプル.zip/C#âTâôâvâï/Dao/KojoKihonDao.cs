﻿using System;
using System.Collections.Generic;
using log4net;
using System.Data.SqlClient;
using Dapper;
using Suisitu.Common;
using System.Reflection;
using Suisitu.Entity;

namespace Suisitu.Dao
{
    /// <summary>
    /// 工場事業場基本Daoクラス
    /// </summary>
    public class KojoKihonDao
    {
        private static readonly ILog logger = LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);

        #region パブリックメソッド

        /// <summary>
        /// 選択対象キーに該当する工場事業場基本情報を取得します。
        /// </summary>
        /// <param name="key">選択対象キー</param>
        /// <returns>工場事業場基本情報</returns>
        public static KojoKihonEntity Select(KojoKihonEntity key)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            KojoKihonEntity entity = null;

            string sql = @"SELECT * FROM SDVKOJYOKIHON WHERE Nendo = @Nendo AND KanriNo = @KanriNo";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    entity = conn.QueryFirstOrDefault<KojoKihonEntity>(sql, key);
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);

            return entity;
        }

        /// <summary>
        /// 削除対象キーに該当する工場事業場基本情報を削除します。
        /// </summary>
        /// <param name="key">削除対象キー</param>
        public static void Delete(KojoKihonEntity key)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            string sql = @"DELETE FROM SDTKOJYOKIHON WHERE Nendo = @Nendo AND KanriNo = @KanriNo";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    conn.Open();

                    using (var tran = conn.BeginTransaction())
                    {
                        try
                        {
                            conn.Execute(sql, key, tran);
                            tran.Commit();
                        }
                        catch (Exception ex)
                        {
                            tran.Rollback();
                            throw ex;
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);
        }

        ///// <summary>
        ///// 年度リストを降順で取得します。
        ///// </summary>
        ///// <returns>年度リスト</returns>
        public static IEnumerable<dynamic> GetNendoList()
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            IEnumerable<dynamic> list = null;

            string sql = @"SELECT NENDO FROM SDTKOJYOKIHON GROUP BY NENDO ORDER BY NENDO DESC";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    list = conn.Query(sql);
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);

            return list;
        }


        /// <summary>
        /// 工場事業場基本情報を登録します。
        /// </summary>
        /// <param name="entity">登録データ</param>
        public static void Insert(KojoKihonEntity entity)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            string sql = @"
INSERT INTO SDTKOJYOKIHON(
       NENDO
      ,KANRINO
      ,KYOTEIFLAG
      ,GESUIKBN
      ,KOSYOSITEIFLAG
      ,KANKYOSYOCODE
      ,JIGYOSYONAMEN
      ,JIGYOSYONAMEK
      ,KTANTONAMEN
      ,SYOZAIYUBINNO
      ,SYOZAIJYUSYO
      ,TELNO
      ,BIKO1
      ,SINSEIYUBINNO
      ,SINSEIJYUSYO
      ,SINSEICOPNAME
      ,SINSEINAMEN
      ,SINSEITELNO
      ,BIKO2
      ,SANGYOBC
      ,SANGYOBS
      ,SORYOKISEINO
      ,HOKBNCODE
      ,SIKIBETUCODE
      ,RYUIKICODE
      ,BIKO3
      ,ODAKUYUBINNO
      ,ODAKUJYUSYO
      ,ODAKUCOPNAME
      ,ODAKUNAMEN
      ,BIKO4
      ,SAISUINAMEN
      ,SAISUIFAXNO
      ,BIKO5
      ,YUGAIUM
      ,YOKAKUNINFLAG
      ,TOROKUDATE
      ,UPDDATE
      ,REV
     )
     VALUES (
      @Nendo
     ,@KanriNo
     ,@KyoteiFlag
     ,@GesuiKbn
     ,@KosyoSiteiFlag
     ,@KankyosyoCode
     ,@JigyosyoNameN
     ,@JigyosyoNameK
     ,@KTantoNameN
     ,@SyozaiYubinNo
     ,@SyozaiJyusyo
     ,@TelNo
     ,@Biko1
     ,@SinseiYubinNo
     ,@SinseiJyusyo
     ,@SinseiCopName
     ,@SinseiNameN
     ,@SinseiTelNo
     ,@Biko2
     ,@SangyoBC
     ,@SangyoBS
     ,@SoryoKiseiNo
     ,@HokbnCode
     ,@SikibetuCode
     ,@RyuikiCode
     ,@Biko3
     ,@OdakuYubinNo
     ,@OdakuJyusyo
     ,@OdakuCopName
     ,@OdakuNameN
     ,@Biko4
     ,@SaisuiNameN
     ,@SaisuiFaxNo
     ,@Biko5
     ,@YugaiUm
     ,@YokakuninFlag
     ,@TorokuDate
     ,@UpdDate
     ,@Rev
      )
";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    conn.Open();

                    using (var tran = conn.BeginTransaction())
                    {
                        try
                        {
                            conn.Execute(sql, entity, tran);
                            tran.Commit();
                        }
                        catch (Exception ex)
                        {
                            tran.Rollback();
                            throw ex;
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);
        }

        /// <summary>
        /// 工場事業場基本情報を更新します。
        /// </summary>
        /// <param name="entity">更新データ</param>
        public static void Update(KojoKihonEntity entity)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            string sql = @"
UPDATE SDTKOJYOKIHON
   SET  KYOTEIFLAG = @KyoteiFlag
       ,GESUIKBN = @GesuiKbn
       ,KOSYOSITEIFLAG = @KosyoSiteiFlag
       ,KANKYOSYOCODE = @KankyosyoCode
       ,JIGYOSYONAMEN = @JigyosyoNameN
       ,JIGYOSYONAMEK = @JigyosyoNameK
       ,KTANTONAMEN = @KTantoNameN
       ,SYOZAIYUBINNO = @SyozaiYubinNo
       ,SYOZAIJYUSYO = @SyozaiJyusyo
       ,TELNO = @TelNo
       ,BIKO1 = @Biko1
       ,SINSEIYUBINNO = @SinseiYubinNo
       ,SINSEIJYUSYO = @SinseiJyusyo
       ,SINSEICOPNAME = @SinseiCopName
       ,SINSEINAMEN = @SinseiNameN
       ,SINSEITELNO = @SinseiTelNo
       ,BIKO2 = @Biko2
       ,SANGYOBC = @SangyoBC
       ,SANGYOBS = @SangyoBS
       ,SORYOKISEINO = @SoryoKiseiNo
       ,HOKBNCODE = @HokbnCode
       ,SIKIBETUCODE = @SikibetuCode
       ,RYUIKICODE = @RyuikiCode
       ,BIKO3 = @Biko3
       ,ODAKUYUBINNO = @OdakuYubinNo
       ,ODAKUJYUSYO = @OdakuJyusyo
       ,ODAKUCOPNAME = @OdakuCopName
       ,ODAKUNAMEN = @OdakuCopName
       ,BIKO4 = @Biko4
       ,SAISUINAMEN = @SaisuiNameN
       ,SAISUIFAXNO = @SaisuiFaxNo
       ,BIKO5 = @Biko5
       ,YUGAIUM = @YugaiUm
       ,YOKAKUNINFLAG = @YokakuninFlag
       ,UPDDATE = @UpdDate
       ,REV = REV + @Rev
 WHERE NENDO = @Nendo
   AND KANRINO = @KanriNo
";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    conn.Open();

                    using (var tran = conn.BeginTransaction())
                    {
                        try
                        {
                            conn.Execute(sql, entity, tran);
                            tran.Commit();
                        }
                        catch (Exception ex)
                        {
                            tran.Rollback();
                            throw ex;
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);
        }

        /// <summary>
        /// 年度に該当する管理番号の最大値＋1を取得します。
        /// 該当データが存在しない場合は、1 を返します。
        /// </summary>
        /// <param name="key">選択対象キー</param>
        /// <returns>新処理施設管理番号</returns>
        public static int GetNewKanriNo(int nendo)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            dynamic entity = null;

            string sql = @"SELECT MAX(CONVERT(INT, KANRINO)) + 1 AS MAXKANRINO FROM SDTKOJYOKIHON WHERE NENDO = @Nendo";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    entity = conn.QueryFirstOrDefault(sql, new { Nendo = nendo });
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);

            return entity.MAXKANRINO == null ? 1 : (int)entity.MAXKANRINO;
        }

        #endregion
    }
}
