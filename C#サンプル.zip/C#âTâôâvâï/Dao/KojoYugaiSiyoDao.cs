﻿using System;
using System.Collections.Generic;
using log4net;
using System.Data.SqlClient;
using Dapper;
using Suisitu.Common;
using System.Reflection;
using Suisitu.Entity;

namespace Suisitu.Dao
{
    /// <summary>
    /// 有害物質使用状況Daoクラス
    /// </summary>
    public class KojoYugaiSiyoDao
    {
        private static readonly ILog logger = LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);

        #region パブリックメソッド

        /// <summary>
        /// 選択対象キーに該当する有害物質使用状況を取得します。
        /// </summary>
        /// <param name="key">選択対象キー</param>
        /// <returns>有害物質使用状況</returns>
        public static KojoYugaiSiyoEntity Select(KojoYugaiSiyoEntity key)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            KojoYugaiSiyoEntity entity = null;

            string sql = @"SELECT * FROM SDTKOJYOYUGAISIYO WHERE NENDO = @Nendo AND KANRINO = @KanriNo AND KANRINO = @KanriNo AND KOMOKUCODE = @KomokuCode";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    entity = conn.QueryFirstOrDefault<KojoYugaiSiyoEntity>(sql, key);
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);

            return entity;
        }

        /// <summary>
        /// すべての有害物質使用状況を取得します。
        /// </summary>
        /// <param name="nendo">年度</param>
        /// <param name="kanriNo">管理番号</param>
        /// <returns>有害物質使用状況</returns>
        public static IEnumerable<KojoYugaiSiyoEntity> Select(int nendo, int kanriNo)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            IEnumerable<KojoYugaiSiyoEntity> list = null;

            string sql = @"SELECT ROW_NUMBER() OVER(ORDER BY WRTSEQNO) AS No, * FROM SDVKOJYOYUGAISIYO WHERE NENDO = @Nendo AND KANRINO = @KanriNo";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    list = conn.Query<KojoYugaiSiyoEntity>(sql, new { Nendo = nendo, KanriNo = kanriNo });
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);

            return list;
        }

        /// <summary>
        /// 有害物質使用状況を登録します。
        /// </summary>
        /// <param name="entity">登録データ</param>
        public static void Insert(KojoYugaiSiyoEntity entity)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            string sql = @"
INSERT INTO SDTKOJYOYUGAISIYO(
       NENDO
      ,KANRINO
      ,KOMOKUCODE
      ,YUGAISIYOFLAG
      ,TOROKUDATE
      ,UPDDATE
      ,REV
     )
     VALUES (
      @Nendo
     ,@KanriNo
     ,@KomokuCode
     ,@YugaiSiyoFlag
     ,@TorokuDate
     ,@UpdDate
     ,@Rev
      )
";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    conn.Open();

                    using (var tran = conn.BeginTransaction())
                    {
                        try
                        {
                            conn.Execute(sql, entity, tran);
                            tran.Commit();
                        }
                        catch (Exception ex)
                        {
                            tran.Rollback();
                            throw ex;
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);
        }

        /// <summary>
        /// 有害物質使用状況を更新します。
        /// </summary>
        /// <param name="entity">更新データ</param>
        public static void Update(KojoYugaiSiyoEntity entity)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            string sql = @"
UPDATE SDTKOJYOYUGAISIYO
   SET NENDO = @Nendo
      ,KANRINO = @KanriNo
      ,KOMOKUCODE = @KomokuCode
      ,YUGAISIYOFLAG = @YugaiSiyoFlag
      ,UPDDATE = @UpdDate
      ,REV = REV + @Rev
 WHERE NENDO = @Nendo
   AND KANRINO = @KanriNo
   AND KOMOKUCODE = @KomokuCode
";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    conn.Open();

                    using (var tran = conn.BeginTransaction())
                    {
                        try
                        {
                            conn.Execute(sql, entity, tran);
                            tran.Commit();
                        }
                        catch (Exception ex)
                        {
                            tran.Rollback();
                            throw ex;
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);
        }

        #endregion
    }
}
