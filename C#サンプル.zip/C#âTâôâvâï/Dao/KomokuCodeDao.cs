﻿using Dapper;
using log4net;
using Suisitu.Common;
using Suisitu.Entity;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Reflection;

namespace Suisitu.Dao
{
    /// <summary>
    /// 項目コードDaoクラス
    /// </summary>
    public class KomokuCodeDao
    {

        private static readonly ILog logger = LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);

        #region パブリックメソッド

        /// <summary>
        /// すべての項目コードを取得します。
        /// </summary>
        /// <returns>項目コード</returns>
        public static List<KomokuCodeEntity> SelectAll()
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            List<KomokuCodeEntity> list = null;

            string sql = @"SELECT * FROM SDCKOMOKUCODE ORDER BY WRTSEQNO, KOMOKUCODE";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    list = conn.Query<KomokuCodeEntity>(sql).AsList<KomokuCodeEntity>();
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);

            return list;
        }

        /// <summary>
        /// 項目フラグが「4：その他」以外の項目名称と項目コードを取得します。
        /// </summary>
        /// <returns>項目名称</returns>
        public static IEnumerable<KomokuCodeEntity> GetKomokuNameNAndKomokuCodeOfNotSonota()
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            IEnumerable<KomokuCodeEntity> list = null;

            string sql = @"SELECT KOMOKUNAMEN, KOMOKUCODE FROM SDCKOMOKUCODE WHERE KOMOKUFLAG != '4' ORDER BY WRTSEQNO, KOMOKUCODE";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    list = conn.Query<KomokuCodeEntity>(sql);
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);

            return list;
        }

        #endregion

    }
}
