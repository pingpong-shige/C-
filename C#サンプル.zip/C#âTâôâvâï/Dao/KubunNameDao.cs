﻿using Dapper;
using log4net;
using Suisitu.Common;
using Suisitu.Entity;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Reflection;

namespace Suisitu.Dao
{
    /// <summary>
    /// 区分名称Daoクラス
    /// </summary>
    public class KubunNameDao
    {
        private static readonly ILog logger = LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);

        #region パブリックメソッド

        /// <summary>
        /// 識別IDに該当する区分名称を取得します。（コンボボックス設定用）
        /// </summary>
        /// <param name="id">識別ID</param>
        /// <returns>区分名称</returns>
        public static IEnumerable<MasterEntity> GetMasterData(string id)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            IEnumerable<MasterEntity> list = null;

            string sql = @"
SELECT KUBUN AS VALUE, KUBUNNAMEN AS NAME
  FROM SDCKUBUNNAME
 WHERE ID = @Id
 ORDER BY WRTSEQNO, KUBUN";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    list = conn.Query<MasterEntity>(sql, new KubunNameEntity { Id = id });
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);

            return list;
        }

        #endregion
    }
}
