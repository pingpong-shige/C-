﻿using Dapper;
using log4net;
using Suisitu.Common;
using Suisitu.Entity;
using System;
using System.Data.SqlClient;
using System.Reflection;

namespace Suisitu.Dao
{
    /// <summary>
    /// 汚濁負荷量Daoクラス
    /// </summary>
    public class OdakuFukaryoDao
    {
        private static readonly ILog logger = LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);

        #region パブリックメソッド

        /// <summary>
        /// 選択対象キーに該当する工場事業場基本情報を取得します。
        /// </summary>
        /// <param name="key">選択対象キー</param>
        /// <returns>工場事業場基本情報</returns>
        public static OdakuFukaryoEntity Select(OdakuFukaryoEntity key)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            OdakuFukaryoEntity entity = null;

            string sql = @"SELECT * FROM SDVODAKUFUKARYO WHERE Nendo = @Nendo AND KanriNo = @KanriNo";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    entity = conn.QueryFirstOrDefault<OdakuFukaryoEntity>(sql, key);
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);

            return entity;
        }

        /// <summary>
        /// 年度、管理番号に該当する汚濁負荷量情報を削除します。
        /// </summary>
        /// <param name="nendo">年度</param>
        /// <param name="kanriNo">管理番号</param>
        public static void Delete(int nendo, int kanriNo)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            string sql = @"DELETE FROM SDTODAKUFUKARYO WHERE NENDO = @Nendo AND KANRINO = @KanriNo";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    conn.Open();

                    using (var tran = conn.BeginTransaction())
                    {
                        try
                        {
                            conn.Execute(sql, new { Nendo = nendo, KanriNo = kanriNo }, tran);
                            tran.Commit();
                        }
                        catch (Exception ex)
                        {
                            tran.Rollback();
                            throw ex;
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);
        }

        /// <summary>
        /// 年度に該当する管理番号の最大値＋1を取得します。
        /// 該当データが存在しない場合は、1 を返します。
        /// </summary>
        /// <param name="key">選択対象キー</param>
        /// <returns>新処理施設管理番号</returns>
        public static int GetNewKanriNo(int nendo)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            dynamic entity = null;

            string sql = @"SELECT MAX(CONVERT(INT, KANRINO)) + 1 AS MAXKANRINO FROM SDTKOJYOKIHON WHERE NENDO = @Nendo";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    entity = conn.QueryFirstOrDefault(sql, new { Nendo = nendo });
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);

            return entity.MAXKANRINO == null ? 1 : (int)entity.MAXKANRINO;
        }

        /// <summary>
        /// 汚濁負荷量情報を登録します。
        /// </summary>
        /// <param name="entity">登録データ</param>
        public static void Insert(OdakuFukaryoEntity entity)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            string sql = @"
INSERT INTO SDTODAKUFUKARYO(
       NENDO
      ,KANRINO
      ,CODKYOYOFUKARYO
      ,CODTDKDFUKARYO
      ,TNKYOYOFUKARYO
      ,TNTDKDFUKARYO
      ,TPKYOYOFUKARYO
      ,TPTDKDFUKARYO
      ,SONOTAKYOYOFUKARYO
      ,SONOTATDKDFUKARYO
      ,BIKO
      ,TOROKUDATE
      ,UPDDATE
      ,REV
     )
     VALUES (
      @Nendo
     ,@KanriNo
     ,@CodKyoyoFukaryo
     ,@CodTdkdFukaryo
     ,@TnKyoyoFukaryo
     ,@TnTdkdFukaryo
     ,@TpKyoyoFukaryo
     ,@TpTdkdFukaryo
     ,@SonotaKyoyoFukaryo
     ,@SonotaTdkdFukaryo
     ,@Biko
     ,@TorokuDate
     ,@UpdDate
     ,@Rev
      )
";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    conn.Open();

                    using (var tran = conn.BeginTransaction())
                    {
                        try
                        {
                            conn.Execute(sql, entity, tran);
                            tran.Commit();
                        }
                        catch (Exception ex)
                        {
                            tran.Rollback();
                            throw ex;
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);
        }

        /// <summary>
        /// 汚濁負荷量情報を更新します。
        /// </summary>
        /// <param name="entity">更新データ</param>
        public static void Update(OdakuFukaryoEntity entity)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            string sql = @"
UPDATE SDTODAKUFUKARYO
   SET  NENDO = @Nendo
       ,KANRINO = @KanriNo
       ,CODKYOYOFUKARYO = @CodKyoyoFukaryo
       ,CODTDKDFUKARYO = @CodTdkdFukaryo
       ,TNKYOYOFUKARYO = @TnKyoyoFukaryo
       ,TNTDKDFUKARYO = @TnTdkdFukaryo
       ,TPKYOYOFUKARYO = @TpKyoyoFukaryo
       ,TPTDKDFUKARYO = @TpTdkdFukaryo
       ,SONOTAKYOYOFUKARYO = @SonotaKyoyoFukaryo
       ,SONOTATDKDFUKARYO = @SonotaTdkdFukaryo
       ,BIKO = @Biko
       ,UPDDATE = @UpdDate
       ,REV = REV + @Rev
 WHERE NENDO = @Nendo
   AND KANRINO = @KanriNo
";
            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    conn.Open();

                    using (var tran = conn.BeginTransaction())
                    {
                        try
                        {
                            conn.Execute(sql, entity, tran);
                            tran.Commit();
                        }
                        catch (Exception ex)
                        {
                            tran.Rollback();
                            throw ex;
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);
        }
        #endregion
    }
}
