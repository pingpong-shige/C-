﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using Dapper;
using Suisitu.Common;
using Suisitu.Entity;

namespace Suisitu.Dao
{
    /// <summary>
    /// 流域コードDaoクラス
    /// </summary>
    public class RyuikiCodeDao
    {
        #region パブリックメソッド

        /// <summary>
        /// 流域コード情報を取得します。
        /// </summary>
        /// <returns>流域コード情報</returns>
        public static IEnumerable<RyuikiCodeEntity> SelectAll()
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            IEnumerable<RyuikiCodeEntity> list = null;

            string sql = @"SELECT * FROM SDCRYUIKICODE ORDER BY RYUIKICODE";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    list = conn.Query<RyuikiCodeEntity>(sql);
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);

            return list;
        }

        /// <summary>
        /// 選択対象キーに該当する流域コード情報を取得します。
        /// </summary>
        /// <param name="key">選択対象キー</param>
        /// <returns>流域コード情報</returns>
        public static RyuikiCodeEntity Select(RyuikiCodeEntity key)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            RyuikiCodeEntity entity = null;

            string sql = @"SELECT * FROM SDCRYUIKICODE WHERE RYUIKICODE = @RyuikiCode";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    entity = conn.QueryFirstOrDefault<RyuikiCodeEntity>(sql, key);
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);

            return entity;
        }

        /// <summary>
        /// 流域コード情報を登録します。
        /// </summary>
        /// <param name="entity">登録データ</param>
        public static void Insert(RyuikiCodeEntity entity)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            string sql = @"
INSERT INTO SDCRYUIKICODE( 
    RYUIKICODE
   ,KIJUNTENCODE
   ,RYUIKINAMEN
   ,ABKISEITEKIYOFLAG
   ,UPDDATE
   ,REV
)
VALUES ( 
    @RyuikiCode
   ,@KijuntenCode
   ,@RyuikiNameN
   ,@AbKiseiTekiyoFlag
   ,@UpdDate
   ,@Rev
)
";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    conn.Open();

                    using (var tran = conn.BeginTransaction())
                    {
                        try
                        {
                            conn.Execute(sql, entity, tran);
                            tran.Commit();
                        }
                        catch (Exception ex)
                        {
                            tran.Rollback();
                            throw ex;
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);
        }

        /// <summary>
        /// 流域コード情報を更新します。
        /// </summary>
        /// <param name="entity">更新データ</param>
        public static void Update(RyuikiCodeEntity entity)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            string sql = @"
UPDATE SDCRYUIKICODE
   SET RYUIKICODE = @RyuikiCode
      ,KIJUNTENCODE = @KijuntenCode
      ,RYUIKINAMEN = @RyuikiNameN
      ,ABKISEITEKIYOFLAG = @AbKiseiTekiyoFlag
      ,UPDDATE = @UpdDate
      ,REV = REV + @Rev
WHERE RYUIKICODE = @RyuikiCode
";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    conn.Open();

                    using (var tran = conn.BeginTransaction())
                    {
                        try
                        {
                            conn.Execute(sql, entity, tran);
                            tran.Commit();
                        }
                        catch (Exception ex)
                        {
                            tran.Rollback();
                            throw ex;
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);
        }

        /// <summary>
        /// 削除対象キーに該当する流域コード情報を削除します。
        /// </summary>
        /// <param name="key">削除対象キー</param>
        public static void Delete(RyuikiCodeEntity key)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            string sql = @"DELETE FROM SDCRYUIKICODE WHERE RYUIKICODE = @RyuikiCode";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    conn.Open();

                    using (var tran = conn.BeginTransaction())
                    {
                        try
                        {
                            conn.Execute(sql, key, tran);
                            tran.Commit();
                        }
                        catch (Exception ex)
                        {
                            tran.Rollback();
                            throw ex;
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);
        }

        /// <summary>
        /// 流域コード情報を取得します。（コンボボックス設定用）
        /// </summary>
        /// <returns>流域コード情報</returns>
        public static IEnumerable<MasterEntity> GetMasterData()
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            IEnumerable<MasterEntity> list = null;

            string sql = @"
SELECT RYUIKICODE AS VALUE, RYUIKINAMEN AS NAME
  FROM SDCRYUIKICODE
 ORDER BY RYUIKICODE";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    list = conn.Query<MasterEntity>(sql);
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);

            return list;
        }

        #endregion
    }
}
