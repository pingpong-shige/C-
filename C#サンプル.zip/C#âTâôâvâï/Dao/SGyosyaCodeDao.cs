﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using Dapper;
using Suisitu.Common;
using Suisitu.Entity;

namespace Suisitu.Dao
{
    /// <summary>
    /// 採水業者コードDaoクラス
    /// </summary>
    public class SGyosyaCodeDao
    {
        #region パブリックメソッド

        /// <summary>
        /// 採水業者コード情報を取得します。
        /// </summary>
        /// <returns>採水業者コード情報</returns>
        public static IEnumerable<SGyosyaCodeEntity> SelectAll()
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            IEnumerable<SGyosyaCodeEntity> list = null;

            string sql = @"SELECT * FROM SDCSGYOSYACODE ORDER BY GYOSYACODE";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    list = conn.Query<SGyosyaCodeEntity>(sql);
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);

            return list;
        }

        /// <summary>
        /// 選択対象キーに該当する採水業者コード情報を取得します。
        /// </summary>
        /// <param name="key">選択対象キー</param>
        /// <returns>選択対象キーに該当する採水業者コード情報</returns>
        public static SGyosyaCodeEntity Select(SGyosyaCodeEntity key)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            SGyosyaCodeEntity entity = null;

            string sql = @"SELECT * FROM SDCSGYOSYACODE WHERE GYOSYACODE = @GyosyaCode";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    entity = conn.QueryFirstOrDefault<SGyosyaCodeEntity>(sql, key);
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);

            return entity;
        }

        /// <summary>
        /// 採水業者コード情報を登録します。
        /// </summary>
        /// <param name="entity">登録データ</param>
        public static void Insert(SGyosyaCodeEntity entity)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            string sql = @"
INSERT INTO SDCSGYOSYACODE( 
    GYOSYACODE
   ,GYOSYANAMEN
   ,TANTONAMEN
   ,UPDDATE
   ,REV
)
VALUES ( 
    @GyosyaCode
   ,@GyosyaNameN
   ,@TantoNameN
   ,@UpdDate
   ,@Rev
)
";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    conn.Open();

                    using (var tran = conn.BeginTransaction())
                    {
                        try
                        {
                            conn.Execute(sql, entity, tran);
                            tran.Commit();
                        }
                        catch (Exception ex)
                        {
                            tran.Rollback();
                            throw ex;
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);
        }

        /// <summary>
        /// 採水業者コード情報を更新します。
        /// </summary>
        /// <param name="entity">更新データ</param>
        public static void Update(SGyosyaCodeEntity entity)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            string sql = @"
UPDATE SDCSGYOSYACODE
   SET GYOSYANAMEN = @GyosyaNameN
      ,TANTONAMEN = @TantoNameN
      ,UPDDATE = @UpdDate
      ,REV = REV + @Rev
WHERE GYOSYACODE = @GyosyaCode
";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    conn.Open();

                    using (var tran = conn.BeginTransaction())
                    {
                        try
                        {
                            conn.Execute(sql, entity, tran);
                            tran.Commit();
                        }
                        catch (Exception ex)
                        {
                            tran.Rollback();
                            throw ex;
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);
        }

        /// <summary>
        /// 削除対象キーに該当する採水業者コード情報を削除します。
        /// </summary>
        /// <param name="key">削除対象キー</param>
        public static void Delete(SGyosyaCodeEntity key)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            string sql = @"DELETE FROM SDCSGYOSYACODE WHERE GYOSYACODE = @GyosyaCode";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    conn.Open();

                    using (var tran = conn.BeginTransaction())
                    {
                        try
                        {
                            conn.Execute(sql, key, tran);
                            tran.Commit();
                        }
                        catch (Exception ex)
                        {
                            tran.Rollback();
                            throw ex;
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);
        }

        /// <summary>
        /// 採水業者を取得します。（コンボボックス設定用）
        /// </summary>
        /// <returns>採水業者</returns>
        public static IEnumerable<MasterEntity> GetMasterData()
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            IEnumerable<MasterEntity> list = null;

            string sql = @"
SELECT GYOSYACODE AS VALUE, GYOSYANAMEN AS NAME
  FROM SDCSGYOSYACODE
 ORDER BY GYOSYACODE";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    list = conn.Query<MasterEntity>(sql);
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);

            return list;
        }

        #endregion
    }
}
