﻿using Dapper;
using log4net;
using Suisitu.Common;
using Suisitu.Entity;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Reflection;

namespace Suisitu.Dao
{
    /// <summary>
    /// 採水計画Daoクラス
    /// </summary>
    public class SaisuiKeikakuDao
    {
        private static readonly ILog logger = LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);

        #region パブリックメソッド

        /// <summary>
        /// 年度、管理番号に該当する採水計画情報を削除します。
        /// </summary>
        /// <param name="nendo">年度</param>
        /// <param name="kanriNo">管理番号</param>
        public static void Delete(int nendo, int kanriNo)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            string sql = @"DELETE FROM SDTSAISUIKEIKAKU WHERE NENDO = @Nendo AND KANRINO = @KanriNo";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    conn.Open();

                    using (var tran = conn.BeginTransaction())
                    {
                        try
                        {
                            conn.Execute(sql, new { Nendo = nendo, KanriNo = kanriNo }, tran);
                            tran.Commit();
                        }
                        catch (Exception ex)
                        {
                            tran.Rollback();
                            throw ex;
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);
        }

        /// <summary>
        /// 選択対象キーに該当する採水計画一覧を取得します。
        /// </summary>
        /// <param name="key">選択対象キー</param>
        /// <returns>採水計画一覧</returns>
        public static IEnumerable<SaisuiKeikakuItiranEntity> SelectList(SaisuiKeikakuItiranEntity key)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            IEnumerable<SaisuiKeikakuItiranEntity> list = null;

            string sql = @" SELECT 
                            NENDO
                          , SAISUIKAI
                          , (SELECT COUNT(*) AS KENTAISUU FROM (SELECT KANRINO,HAISUIKONO FROM SDTSAISUIKEIKAKU WHERE SAISUIKAI = SK.SAISUIKAI GROUP BY KANRINO,HAISUIKONO) AS GR ) AS KENTAISU
                          , SAISUIDATE
                          , STATUS
                          , KN.KUBUNNAMEN AS STATUSKUBUNNAMEN
                          , SHEETDATE 
                          , MAX(SK.REV) AS REV
                            FROM SDTSAISUIKEIKAKU SK
                            LEFT JOIN SDCKUBUNNAME KN ON KN.ID = 'STATUS' AND KN.KUBUN = SK.STATUS";
            string where = @" WHERE NENDO = @Nendo";
            string group = @" GROUP BY
                            NENDO
                          , SAISUIKAI
                          , SAISUIDATE
                          , STATUS
                          , SHEETDATE
                          , KN.KUBUNNAMEN";
            string order = @" ORDER BY
                            SAISUIKAI DESC
                          , SAISUIDATE DESC
                          , STATUS DESC
                          , SHEETDATE DESC";

            if (!string.IsNullOrEmpty(key.SaisuiDateFrom))
                where += @" AND SAISUIDATE >= @SaisuiDateFrom";

            if (!string.IsNullOrEmpty(key.SaisuiDateTo))
                where += @" AND SAISUIDATE <= @SaisuiDateTo";

            sql = sql + where + group + order;

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    list = conn.Query<SaisuiKeikakuItiranEntity>(sql, key);
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);

            return list;
        }

        /// <summary>
        /// 選択対象キーに該当する採水計画情報を取得します。
        /// </summary>
        /// <param name="key">選択対象キー</param>
        /// <returns>採水計画情報</returns>
        public static SaisuiKeikakuEntity Select(string key)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            SaisuiKeikakuEntity list = null;

            string sql = @" SELECT * , KN.KUBUNNAMEN as STATUSKUBUNNAMEN FROM SDTSAISUIKEIKAKU SK
                            LEFT JOIN SDCKUBUNNAME KN ON KN.ID = 'STATUS' and KN.KUBUN = SK.STATUS";
            string where = @" WHERE SAISUIKAI = @SaisuiKai";

            sql = sql + where;

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    list = conn.QueryFirstOrDefault<SaisuiKeikakuEntity>(sql, new { SaisuiKai = key });
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);

            return list;
        }

        /// <summary>
        /// 選択対象キーに該当する採水計画情報を取得します。
        /// </summary>
        /// <param name="key">選択対象キー</param>
        /// <returns>採水計画情報</returns>
        public static SaisuiKeikakuEntity GetKentaisu(string key)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            SaisuiKeikakuEntity list = null;

            string sql = @" SELECT * , KN.KUBUNNAMEN as STATUSKUBUNNAMEN FROM SDTSAISUIKEIKAKU SK
                            LEFT JOIN SDCKUBUNNAME KN ON KN.ID = 'STATUS' and KN.KUBUN = SK.STATUS";
            string where = @" WHERE SAISUIKAI = @SaisuiKai";

            sql = sql + where;

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    list = conn.QueryFirstOrDefault<SaisuiKeikakuEntity>(sql, new { SaisuiKai = key });
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);

            return list;
        }

        /// <summary>
        /// 年度、採水年月回に該当する採水計画情報を削除します。
        /// </summary>
        /// <param name="nendo">年度</param>
        /// <param name="kanriNo">管理番号</param>
        public static void Delete(int nendo, string saisuiKai)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            string sql = @"DELETE FROM SDTSAISUIKEIKAKU WHERE NENDO = @Nendo AND SAISUIKAI = @SaisuiKai";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    conn.Open();

                    using (var tran = conn.BeginTransaction())
                    {
                        try
                        {
                            conn.Execute(sql, new { Nendo = nendo, SaisuiKai = saisuiKai }, tran);
                            tran.Commit();
                        }
                        catch (Exception ex)
                        {
                            tran.Rollback();
                            throw ex;
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);
        }

        /// <summary>
        /// 年度、採水年月回に該当する採水計画情報を中止にします。
        /// </summary>
        /// <param name="nendo">年度</param>
        /// <param name="kanriNo">管理番号</param>
        public static void Stop(SaisuiKeikakuItiranEntity key)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            string sql = @"
UPDATE SDTSAISUIKEIKAKU
   SET STATUS = 9
      ,UPDDATE = @UpdDate
      ,REV = @Rev
 WHERE NENDO = @Nendo 
   AND SAISUIKAI = @SaisuiKai
";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    conn.Open();

                    using (var tran = conn.BeginTransaction())
                    {
                        try
                        {
                            conn.Execute(sql, key, tran);
                            tran.Commit();
                        }
                        catch (Exception ex)
                        {
                            tran.Rollback();
                            throw ex;
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);
        }

        /// <summary>
        /// 採水年月回に該当する採水計画一覧を取得します。
        /// </summary>
        /// <param name="key">選択対象キー</param>
        /// <returns>採水計画一覧</returns>
        public static IEnumerable<SaisuiKeikakuEntity> SelectSaisuiKaiList(string saisuiKai)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            IEnumerable<SaisuiKeikakuEntity> list = null;

            string sql = @" SELECT SAISUIKAI, SK.KANRINO, JIGYOSYONAMEN, HAISUIKONO, TATIIRIKANRINO FROM SDTSAISUIKEIKAKU SK
                            LEFT JOIN SDTKOJYOKIHON KK ON KK.KANRINO = SK.KANRINO";
            string where = @" WHERE SAISUIKAI = @SaisuiKai";
            string group = @" GROUP BY 
                            SAISUIKAI
                          , SK.KANRINO
                          , HAISUIKONO
                          , TATIIRIKANRINO
                          , JIGYOSYONAMEN";
            string order = @" ORDER BY
                            SK.KANRINO
                          , HAISUIKONO
                          , TATIIRIKANRINO";

            sql = sql + where + group + order;

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    list = conn.Query<SaisuiKeikakuEntity>(sql, new { SaisuiKai = saisuiKai });
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);

            return list;
        }

        /// <summary>
        /// 採水年月回、管理番号、排水口番号に該当する項目コードを取得します。
        /// </summary>
        /// <param name="key">選択対象キー</param>
        /// <returns>項目コード一覧</returns>
        public static IEnumerable<SaisuiKeikakuEntity> SelectSaisuiKaiKomokuList(SaisuiKeikakuEntity saisui )
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            IEnumerable<SaisuiKeikakuEntity> list = null;

            string sql = @" SELECT KOMOKUCODE FROM SDTSAISUIKEIKAKU ";
            string where = @" WHERE SAISUIKAI = @SaisuiKai AND KANRINO = @KanriNo AND HAISUIKONO = @HaisuikoNo";
            string order = @" ORDER BY
                            KOMOKUCODE";

            sql = sql + where + order;

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    list = conn.Query<SaisuiKeikakuEntity>(sql, saisui);
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);

            return list;
        }

        /// <summary>
        /// 採水年月回に該当する採水計画情報を削除します。
        /// </summary>
        /// <param name="saisuikai">採水年月回</param>
        public static void Delete(string saisuikai)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            string sql = @"DELETE FROM SDTSAISUIKEIKAKU WHERE SAISUIKAI = @Saisuikai";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    conn.Open();

                    using (var tran = conn.BeginTransaction())
                    {
                        try
                        {
                            conn.Execute(sql, new { Saisuikai = saisuikai}, tran);
                            tran.Commit();
                        }
                        catch (Exception ex)
                        {
                            tran.Rollback();
                            throw ex;
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);
        }

        /// <summary>
        /// 採水計画情報を登録します。
        /// </summary>
        /// <param name="entity">登録データ</param>
        public static void Insert(SaisuiKeikakuEntity entity)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            string sql = @"
INSERT 
INTO [dbo].SDTSAISUIKEIKAKU( 
    NENDO
  , KANRINO
  , HAISUIKONO
  , SAISUIKAI
  , KOMOKUCODE
  , TATIIRIKANRINO
  , SAISUIDATE
  , STATUS
  , GYOSYACODE
  , SAISUISYANAMEN
  , SHEETDATE
  , TOROKUDATE
  , HAISIFLAG
  , UPDDATE
  , REV
) 
VALUES ( 
    @NENDO
  , @KANRINO
  , @HAISUIKONO
  , @SAISUIKAI
  , @KOMOKUCODE
  , @TATIIRIKANRINO
  , @SAISUIDATE
  , @STATUS
  , @GYOSYACODE
  , @SAISUISYANAMEN
  , @SHEETDATE
  , @TOROKUDATE
  , @HAISIFLAG
  , @UPDDATE
  , @REV
) 

";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    conn.Open();

                    using (var tran = conn.BeginTransaction())
                    {
                        try
                        {
                            conn.Execute(sql, entity, tran);
                            tran.Commit();
                        }
                        catch (Exception ex)
                        {
                            tran.Rollback();
                            throw ex;
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);
        }
        #endregion
    }
}
