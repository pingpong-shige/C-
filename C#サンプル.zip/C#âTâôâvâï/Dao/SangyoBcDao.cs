﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using Dapper;
using Suisitu.Common;
using Suisitu.Entity;

namespace Suisitu.Dao
{
    /// <summary>
    /// 産業分類（中分類）Daoクラス
    /// </summary>
    public class SangyoBcDao
    {
        #region パブリックメソッド

        /// <summary>
        /// 産業分類（中分類）を取得します。
        /// </summary>
        /// <returns> 産業分類（中分類）</returns>
        public static IEnumerable<SangyoBcEntity> SelectAll()
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            IEnumerable<SangyoBcEntity> list = null;

            string sql = @"SELECT * FROM SDCSANGYOBC ORDER BY SANGYOBC";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    list = conn.Query<SangyoBcEntity>(sql, new SangyoBcEntity { });
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);

            return list;
        }

        /// <summary>
        /// 選択対象キーに該当する産業分類（中分類）を取得します。
        /// </summary>
        /// <param name="key">選択対象キー</param>
        /// <returns>産業分類（中分類）</returns>
        public static SangyoBcEntity Select(SangyoBcEntity key)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            SangyoBcEntity entity = null;

            string sql = @"SELECT * FROM SDCSANGYOBC WHERE SANGYOBC = @Sangyobc";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    entity = conn.QueryFirstOrDefault<SangyoBcEntity>(sql, key);
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);

            return entity;
        }

        /// <summary>
        /// 産業分類（中分類）を登録します。
        /// </summary>
        /// <param name="entity">登録データ</param>
        public static void Insert(SangyoBcEntity entity)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            string sql = @"
INSERT INTO SDCSangyoBc( 
    SANGYOBC
   ,SANGYOBCNAMEN
   ,UPDDATE
   ,REV
)
VALUES ( 
    @Sangyobc
   ,@SangyobcNameN
   ,@UpdDate
   ,@Rev
)
";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    conn.Open();

                    using (var tran = conn.BeginTransaction())
                    {
                        try
                        {
                            conn.Execute(sql, entity, tran);
                            tran.Commit();
                        }
                        catch (Exception ex)
                        {
                            tran.Rollback();
                            throw ex;
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);
        }

        /// <summary>
        /// 産業分類（中分類）を更新します。
        /// </summary>
        /// <param name="entity">更新データ</param>
        public static void Update(SangyoBcEntity entity)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            string sql = @"
UPDATE SDCSangyoBc
   SET SANGYOBCNAMEN = @SangyobcNameN
      ,UPDDATE = @UpdDate
      ,REV = REV + @Rev
WHERE SANGYOBC = @Sangyobc
";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    conn.Open();

                    using (var tran = conn.BeginTransaction())
                    {
                        try
                        {
                            conn.Execute(sql, entity, tran);
                            tran.Commit();
                        }
                        catch (Exception ex)
                        {
                            tran.Rollback();
                            throw ex;
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);
        }

        /// <summary>
        /// 削除対象キーに該当する産業分類（中分類）を削除します。
        /// </summary>
        /// <param name="key">削除対象キー</param>
        public static void Delete(SangyoBcEntity key)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            string sql = @"DELETE FROM SDCSANGYOBC WHERE SANGYOBC = @Sangyobc";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    conn.Open();

                    using (var tran = conn.BeginTransaction())
                    {
                        try
                        {
                            conn.Execute(sql, key, tran);
                            tran.Commit();
                        }
                        catch (Exception ex)
                        {
                            tran.Rollback();
                            throw ex;
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);
        }

        /// <summary>
        /// 産業分類（中分類）を取得します。（コンボボックス設定用）
        /// </summary>
        /// <returns>産業分類(中分類)</returns>
        public static IEnumerable<MasterEntity> GetMasterData()
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            IEnumerable<MasterEntity> list = null;

            string sql = @"
SELECT SANGYOBC AS VALUE, SANGYOBCNAMEN AS NAME
  FROM SDCSANGYOBC
 ORDER BY SANGYOBC";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    list = conn.Query<MasterEntity>(sql);
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);

            return list;
        }

        #endregion
    }
}
