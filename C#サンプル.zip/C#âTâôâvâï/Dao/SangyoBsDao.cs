﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using Dapper;
using Suisitu.Common;
using Suisitu.Entity;

namespace Suisitu.Dao
{
    /// <summary>
    /// 産業分類（細分類）Daoクラス
    /// </summary>
    public class SangyoBsDao
    {
        #region パブリックメソッド

        /// <summary>
        /// 産業分類（中分類）に紐付く産業分類（細分類）を取得します。
        /// </summary>
        /// <param name="parent">産業分類（中分類）</param>
        /// <returns>産業分類（細分類）</returns>
        public static IEnumerable<MasterEntity> GetMasterData(string parent)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            IEnumerable<MasterEntity> list = null;

            string sql = @"
SELECT SUBSTRING(SANGYOBS, 3, 2) AS VALUE, SANGYOBSNAMEN AS NAME
  FROM SDCSANGYOBS
 WHERE PARENT = @Parent
 ORDER BY SANGYOBS";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    list = conn.Query<MasterEntity>(sql, new { Parent = parent });
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);

            return list;
        }

        /// <summary>
        /// 産業分類（細分類）情報を登録します。
        /// </summary>
        /// <param name="entity">登録データ</param>
        public static void Insert(SangyoBsEntity entity)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            string sql = @"
INSERT INTO SDCSANGYOBS( 
    SANGYOBS
   ,SANGYOBSNAMEN
   ,PARENT
   ,UPDDATE
   ,REV
)
VALUES ( 
    @Sangyobs
   ,@SangyobsNameN
   ,@Parent
   ,@UpdDate
   ,@Rev
)
";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    conn.Open();

                    using (var tran = conn.BeginTransaction())
                    {
                        try
                        {
                            conn.Execute(sql, entity, tran);
                            tran.Commit();
                        }
                        catch (Exception ex)
                        {
                            tran.Rollback();
                            throw ex;
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);
        }

        /// <summary>
        /// 産業分類（細分類）情報を更新します。
        /// </summary>
        /// <param name="entity">更新データ</param>
        public static void Update(SangyoBsEntity entity)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            string sql = @"
UPDATE SDCSANGYOBS
   SET SANGYOBSNAMEN = @SangyobsNameN
      ,UPDDATE = @UpdDate
      ,REV = REV + @Rev
WHERE SANGYOBS = @Sangyobs
  AND PARENT = @Parent
";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    conn.Open();

                    using (var tran = conn.BeginTransaction())
                    {
                        try
                        {
                            conn.Execute(sql, entity, tran);
                            tran.Commit();
                        }
                        catch (Exception ex)
                        {
                            tran.Rollback();
                            throw ex;
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);
        }

        /// <summary>
        /// 削除対象キーに該当する産業分類（細分類）情報を削除します。
        /// </summary>
        /// <param name="key">削除対象キー</param>
        public static void Delete(SangyoBsEntity key)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            string sql = @"DELETE FROM SDCSANGYOBS WHERE SANGYOBS = @Sangyobs";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    conn.Open();

                    using (var tran = conn.BeginTransaction())
                    {
                        try
                        {
                            conn.Execute(sql, key, tran);
                            tran.Commit();
                        }
                        catch (Exception ex)
                        {
                            tran.Rollback();
                            throw ex;
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);
        }

        /// <summary>
        /// 産業分類（中分類）に該当する産業分類（細分類）情報を取得します。
        /// </summary>
        /// <param name="parent">産業分類（中分類）</param>
        /// <returns>産業分類（中分類）に該当する産業分類（細分類）情報</returns>
        public static IEnumerable<SangyoBsEntity> SelectByParent(SangyoBcEntity key)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            IEnumerable<SangyoBsEntity> list = null;

            string sql = @"SELECT * FROM SDCSANGYOBS WHERE PARENT = @SangyoBc ORDER BY SANGYOBS";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    list = conn.Query<SangyoBsEntity>(sql, key);
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);

            return list;
        }

        /// <summary>
        /// 産業分類（中分類）、産業分類（細区分）に該当する産業分類（細分類）情報を取得します。
        /// </summary>
        /// <param name="key">選択対象キー</param>
        /// <returns>産業分類（細分類）情報</returns>
        public static SangyoBsEntity SelectBySangyoBs(SangyoBsEntity key)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            SangyoBsEntity entity = null;

            string sql = @"SELECT * FROM SDCSANGYOBS WHERE SANGYOBS = @SangyoBs";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    entity = conn.QueryFirstOrDefault<SangyoBsEntity>(sql, key);
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);

            return entity;
        }

        #endregion
    }
}
