﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using Dapper;
using Suisitu.Common;
using Suisitu.Entity;

namespace Suisitu.Dao
{
    /// <summary>
    /// 識別コード表Daoクラス
    /// </summary>
    class SikibetuCodeDao
    {
        #region パブリックメソッド

        /// <summary>
        /// 識別コード情報を取得します。
        /// </summary>
        /// <returns>識別コード情報</returns>
        public static IEnumerable<SikibetuCodeEntity> SelectAll()
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            IEnumerable<SikibetuCodeEntity> list = null;

            string sql = @"SELECT * FROM SDCSIKIBETUCODE ORDER BY SIKIBETUCODE";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    list = conn.Query<SikibetuCodeEntity>(sql);
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);

            return list;
        }

        /// <summary>
        /// 選択対象キーに該当する識別コード情報を取得します。
        /// </summary>
        /// <param name="key">選択対象キー</param>
        /// <returns>識別コード情報</returns>
        public static SikibetuCodeEntity Select(SikibetuCodeEntity key)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            SikibetuCodeEntity entity = null;

            string sql = @"SELECT * FROM SDCSIKIBETUCODE WHERE SIKIBETUCODE = @SikibetuCode";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    entity = conn.QueryFirstOrDefault<SikibetuCodeEntity>(sql, key);
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);

            return entity;
        }

        /// <summary>
        /// 識別コード情報を登録します。
        /// </summary>
        /// <param name="entity">登録データ</param>
        public static void Insert(SikibetuCodeEntity entity)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            string sql = @"
INSERT INTO SDCSIKIBETUCODE( 
    SIKIBETUCODE
   ,SIKIBETUNAMEN
   ,UPDDATE
   ,REV
)
VALUES ( 
    @SikibetuCode
   ,@SikibetuNameN
   ,@UpdDate
   ,@Rev
)
";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    conn.Open();

                    using (var tran = conn.BeginTransaction())
                    {
                        try
                        {
                            conn.Execute(sql, entity, tran);
                            tran.Commit();
                        }
                        catch (Exception ex)
                        {
                            tran.Rollback();
                            throw ex;
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);
        }

        /// <summary>
        /// 識別コード情報を更新します。
        /// </summary>
        /// <param name="entity">更新データ</param>
        public static void Update(SikibetuCodeEntity entity)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            string sql = @"
UPDATE SDCSIKIBETUCODE
   SET SIKIBETUCODE = @SikibetuCode
      ,SIKIBETUNAMEN = @SikibetuNameN
      ,UPDDATE = @UpdDate
      ,REV = REV + @Rev
WHERE SIKIBETUCODE = @SIKIBETUCODE
";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    conn.Open();

                    using (var tran = conn.BeginTransaction())
                    {
                        try
                        {
                            conn.Execute(sql, entity, tran);
                            tran.Commit();
                        }
                        catch (Exception ex)
                        {
                            tran.Rollback();
                            throw ex;
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);
        }

        /// <summary>
        /// 削除対象キーに該当する識別コード情報を削除します。
        /// </summary>
        /// <param name="key">削除対象キー</param>
        public static void Delete(SikibetuCodeEntity key)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            string sql = @"DELETE FROM SDCSIKIBETUCODE WHERE SikibetuCode = @SikibetuCode";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    conn.Open();

                    using (var tran = conn.BeginTransaction())
                    {
                        try
                        {
                            conn.Execute(sql, key, tran);
                            tran.Commit();
                        }
                        catch (Exception ex)
                        {
                            tran.Rollback();
                            throw ex;
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_START);
        }

        /// <summary>
        /// 識別コード情報を取得します。（コンボボックス設定用）
        /// </summary>
        /// <returns>識別コード情報</returns>
        public static IEnumerable<MasterEntity> GetMasterData()
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            IEnumerable<MasterEntity> list = null;

            string sql = @"
SELECT SIKIBETUCODE AS VALUE, SIKIBETUNAMEN AS NAME
  FROM SDCSIKIBETUCODE
 ORDER BY SIKIBETUCODE";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    list = conn.Query<MasterEntity>(sql);
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);

            return list;
        }

        #endregion
    }
}
