﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using Dapper;
using Suisitu.Common;
using Suisitu.Entity;

namespace Suisitu.Dao
{
    /// <summary>
    /// その他区分Daoクラス
    /// </summary>
    class SonotaKbnDao
    {
        #region パブリックメソッド

        /// <summary>
        /// 区分名称表を取得します。
        /// </summary>
        /// <returns>区分名称表</returns>
        public static IEnumerable<SonotaKbnEntity> SelectAll(SonotaKbnEntity key)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            IEnumerable<SonotaKbnEntity> list = null;

            string sql = @"SELECT * FROM SDCKUBUNNAME WHERE ID = @Id ORDER BY KUBUN";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    list = conn.Query<SonotaKbnEntity>(sql, key);
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);

            return list;
        }

        /// <summary>
        /// 選択対象キーに該当する区分名称を取得します。
        /// </summary>
        /// <param name="key">選択対象キー</param>
        /// <returns>区分名称</returns>
        public static SonotaKbnEntity Select(SonotaKbnEntity key)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            SonotaKbnEntity entity = null;

            string sql = @"SELECT * FROM SDCKUBUNNAME WHERE ID = @Id AND KUBUN = @Kubun";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    entity = conn.QueryFirstOrDefault<SonotaKbnEntity>(sql, key);
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);

            return entity;
        }

        /// <summary>
        /// 区分名称を登録します。
        /// </summary>
        /// <param name="entity">登録データ</param>
        public static void Insert(SonotaKbnEntity entity)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            string sql = @"
INSERT INTO SDCKUBUNNAME( 
    ID
   ,KUBUN
   ,KUBUNNAMEN
   ,PARENT
   ,WRTSEQNO
   ,UPDDATE
   ,REV
)
VALUES ( 
    @Id
   ,@Kubun
   ,@KubunNameN
   ,@Parent
   ,@WrtSeqNo
   ,@UpdDate
   ,@Rev
)
";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    conn.Open();

                    using (var tran = conn.BeginTransaction())
                    {
                        try
                        {
                            conn.Execute(sql, entity, tran);
                            tran.Commit();
                        }
                        catch (Exception ex)
                        {
                            tran.Rollback();
                            throw ex;
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);
        }

        /// <summary>
        /// 区分名称を更新します。
        /// </summary>
        /// <param name="entity">更新データ</param>
        public static void Update(SonotaKbnEntity entity)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            string sql = @"
UPDATE SDCKUBUNNAME
   SET KUBUN = @Kubun
      ,KUBUNNAMEN = @KubunNameN
      ,PARENT = @PARENT
      ,WRTSEQNO = @WrtSeqNo
      ,UPDDATE = @UpdDate
      ,REV = REV + @Rev
WHERE ID = @Id
  AND KUBUN = @Kubun
";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    conn.Open();

                    using (var tran = conn.BeginTransaction())
                    {
                        try
                        {
                            conn.Execute(sql, entity, tran);
                            tran.Commit();
                        }
                        catch (Exception ex)
                        {
                            tran.Rollback();
                            throw ex;
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);
        }

        /// <summary>
        /// 削除対象キーに該当する区分名称を削除します。
        /// </summary>
        /// <param name="key">削除対象キー</param>
        public static void Delete(SonotaKbnEntity key)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            string sql = @"
DELETE FROM SDCKUBUNNAME
WHERE ID = @Id
  AND KUBUN = @Kubun
";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    conn.Open();

                    using (var tran = conn.BeginTransaction())
                    {
                        try
                        {
                            conn.Execute(sql, key, tran);
                            tran.Commit();
                        }
                        catch (Exception ex)
                        {
                            tran.Rollback();
                            throw ex;
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_START);
        }

        #endregion
    }
}
