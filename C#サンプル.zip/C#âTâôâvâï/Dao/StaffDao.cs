﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using Dapper;
using Suisitu.Common;
using Suisitu.Entity;

namespace Suisitu.Dao
{
    /// <summary>
    /// 職員マスタDaoクラス
    /// </summary>
    class StaffDao
    {
        #region パブリックメソッド

        /// <summary>
        /// 職員情報を取得します。
        /// </summary>
        /// <returns>職員情報</returns>
        public static IEnumerable<StaffEntity> SelectAll()
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            IEnumerable<StaffEntity> list = null;

            string sql = @"SELECT * FROM SDMSTAFF WHERE STAFFID <> 'administrator' ORDER BY STAFFID";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    list = conn.Query<StaffEntity>(sql);
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);

            return list;
        }

        /// <summary>
        /// 選択対象キーに該当する職員情報を取得します。
        /// </summary>
        /// <param name="key">選択対象キー</param>
        /// <returns>職員情報</returns>
        public static StaffEntity Select(StaffEntity key)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            StaffEntity entity = null;

            string sql = @"SELECT * FROM SDMSTAFF WHERE STAFFID = @StaffID";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    entity = conn.QueryFirstOrDefault<StaffEntity>(sql, key);
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);

            return entity;
        }

        /// <summary>
        /// 職員情報を登録します。
        /// </summary>
        /// <param name="entity">登録データ</param>
        public static void Insert(StaffEntity entity)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            string sql = @"
INSERT INTO SDMSTAFF( 
    STAFFID
   ,STAFFNAMEN
   ,PASSWORD
   ,KANRISYAFLAG
   ,UPDDATE
   ,REV
)
VALUES ( 
    @StaffID
   ,@StaffNameN
   ,@PassWord
   ,@KanrisyaFlag
   ,@UpdDate
   ,@Rev
)
";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    conn.Open();

                    using (var tran = conn.BeginTransaction())
                    {
                        try
                        {
                            conn.Execute(sql, entity, tran);
                            tran.Commit();
                        }
                        catch (Exception ex)
                        {
                            tran.Rollback();
                            throw ex;
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);
        }

        /// <summary>
        /// 職員情報を更新します。
        /// </summary>
        /// <param name="entity">更新データ</param>
        public static void Update(StaffEntity entity)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            string sql = @"
UPDATE SDMSTAFF
   SET STAFFID = @StaffID
      ,STAFFNAMEN = @StaffNameN
      ,PASSWORD = @PassWord
      ,KANRISYAFLAG = @KanrisyaFlag
      ,UPDDATE = @UpdDate
      ,REV = REV + @Rev
WHERE STAFFID = @StaffID
";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    conn.Open();

                    using (var tran = conn.BeginTransaction())
                    {
                        try
                        {
                            conn.Execute(sql, entity, tran);
                            tran.Commit();
                        }
                        catch (Exception ex)
                        {
                            tran.Rollback();
                            throw ex;
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);
        }

        /// <summary>
        /// 削除対象キーに該当する職員情報を削除します。
        /// </summary>
        /// <param name="key">削除対象キー</param>
        public static void Delete(StaffEntity key)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            string sql = @"DELETE FROM SDMSTAFF WHERE STAFFID = @StaffID";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    conn.Open();

                    using (var tran = conn.BeginTransaction())
                    {
                        try
                        {
                            conn.Execute(sql, key, tran);
                            tran.Commit();
                        }
                        catch (Exception ex)
                        {
                            tran.Rollback();
                            throw ex;
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_START);
        }

        /// <summary>
        /// 職員情報を取得します。（コンボボックス設定用）
        /// </summary>
        /// <returns>職員情報</returns>
        public static IEnumerable<MasterEntity> GetMasterData()
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            IEnumerable<MasterEntity> list = null;

            string sql = @"
SELECT STAFFID AS VALUE, STAFFNAMEN AS NAME
  FROM SDMSTAFF
 ORDER BY STAFFID";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    list = conn.Query<MasterEntity>(sql);
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);

            return list;
        }

        #endregion
    }
}
