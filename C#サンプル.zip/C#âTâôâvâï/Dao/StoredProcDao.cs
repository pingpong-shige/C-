﻿using log4net;
using System.Data.SqlClient;
using Dapper;
using Suisitu.Common;
using System.Reflection;
using System;
using System.Data;

namespace Suisitu.Dao
{
    /// <summary>
    /// ストアドプロシージャDaoクラス
    /// </summary>
    public class StoredProcDao
    {
        private static readonly ILog logger = LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);

        #region パブリックメソッド

        /// <summary>
        /// 届出排水量(通常)の合計が50㎥以上かチェックします。
        /// </summary>
        /// <param name="nendo">年度</param>
        /// <param name="kanriNo">管理番号</param>
        /// <returns>True：チェックOK / False:チェックNG</returns>
        public static bool IsHaisuiryo50m3ijo(int nendo, int kanriNo)
        {
            //logger.Debug(Constant.LOG_METHOD_START);
            
            string sql = @"FNC_IsHaisuiryo50m3ijo";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    var param = new DynamicParameters(new { Nendo = nendo, KanriNo = kanriNo });
                    param.Add("result", dbType: DbType.Boolean, direction: ParameterDirection.ReturnValue);

                    conn.Execute(sql, param, commandType: CommandType.StoredProcedure);

                    return param.Get<bool>("result");
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);
        }

        /// <summary>
        /// 流域コードが児島湖流域(14,15,19,21)かチェックします。
        /// </summary>
        /// <param name="ryuikiCode">流域コード</param>
        /// <returns>True：チェックOK / False:チェックNG</returns>
        public static bool FNC_IsKojimakoRyuiki(string ryuikiCode)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            string sql = @"dbo.FNC_IsKojimakoRyuiki";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    var param = new DynamicParameters(new { RyuikiCode = ryuikiCode });
                    param.Add("result", dbType: DbType.Boolean, direction: ParameterDirection.ReturnValue);

                    conn.Execute(sql, param, commandType: CommandType.StoredProcedure);

                    return param.Get<bool>("result");
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);
        }

        #endregion
    }
}
