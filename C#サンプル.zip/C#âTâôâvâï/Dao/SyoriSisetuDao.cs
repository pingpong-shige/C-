﻿using Dapper;
using log4net;
using Suisitu.Common;
using Suisitu.Entity;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Reflection;

namespace Suisitu.Dao
{
    /// <summary>
    /// 処理施設Daoクラス
    /// </summary>
    public class SyoriSisetuDao
    {
        private static readonly ILog logger = LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);

        #region パブリックメソッド

        /// <summary>
        /// 選択対象キーに該当する処理施設情報を取得します。
        /// </summary>
        /// <param name="key">選択対象キー</param>
        /// <returns>処理施設情報</returns>
        public static IEnumerable<SyoriSisetuEntity> SelectList(SyoriSisetuEntity key)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            IEnumerable<SyoriSisetuEntity> list = null;

            string sql = @"SELECT * FROM SDTSYORISISETU WHERE NENDO = @Nendo AND KANRINO = @KanriNo ORDER BY CONVERT(INT, SSNO)";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    list = conn.Query<SyoriSisetuEntity>(sql, key);
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);

            return list;
        }

        /// <summary>
        /// 処理施設情報を取得します。
        /// </summary>
        /// <returns>処理施設情報</returns>
        public static IEnumerable<SyoriSisetuEntity> SelectAll()
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            IEnumerable<SyoriSisetuEntity> list = null;

            string sql = @"SELECT * FROM SDTSYORISISETU ORDER BY NENDO, KANRINO";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    list = conn.Query<SyoriSisetuEntity>(sql);
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);

            return list;
        }

        /// <summary>
        /// 選択対象キーに該当する処理施設情報を取得します。
        /// </summary>
        /// <param name="key">選択対象キー</param>
        /// <returns>処理施設情報</returns>
        public static SyoriSisetuEntity Select(SyoriSisetuEntity key)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            SyoriSisetuEntity entity = null;

            string sql = @"SELECT * FROM SDTSYORISISETU WHERE Nendo = @Nendo AND KanriNo = @KanriNo AND SsNo = @SsNo";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    entity = conn.QueryFirstOrDefault<SyoriSisetuEntity>(sql, key);
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);

            return entity;
        }

        /// <summary>
        /// 選択対象キーに該当する処理施設管理番号の最大値＋1を取得します。
        /// 該当データが存在しない場合は、"001"を返します。
        /// </summary>
        /// <param name="key">選択対象キー</param>
        /// <returns>新処理施設管理番号</returns>
        public static string GetNewSsNo(SyoriSisetuEntity key)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            dynamic entity = null;

            string sql = @"SELECT MAX(CONVERT(INT, SSNO)) + 1 AS MAXSSNO FROM SDTSYORISISETU WHERE NENDO = @Nendo AND KANRINO = @KanriNo";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    entity = conn.QueryFirstOrDefault(sql, key);
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);

            return entity.MAXSSNO == null ? "001" : String.Format("{0:000}", (int)entity.MAXSSNO);
        }

        /// <summary>
        /// 処理施設情報を登録します。
        /// </summary>
        /// <param name="entity">登録データ</param>
        public static void Insert(SyoriSisetuEntity entity)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            string sql = @"
INSERT INTO SDTSYORISISETU(
       NENDO
      ,KANRINO
      ,SSNO
      ,SISETUNAMEN
      ,TDKDJURIDATE
      ,BIKO
      ,TOROKUDATE
      ,UPDDATE
      ,REV
     )
     VALUES (
      @Nendo
     ,@KanriNo
     ,@SsNo
     ,@SisetuNameN
     ,@TdkdjuriDate
     ,@Biko
     ,@TorokuDate
     ,@UpdDate
     ,@Rev
      )
";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    conn.Open();

                    using (var tran = conn.BeginTransaction())
                    {
                        try
                        {
                            conn.Execute(sql, entity, tran);
                            tran.Commit();
                        }
                        catch (Exception ex)
                        {
                            tran.Rollback();
                            throw ex;
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);
        }

        /// <summary>
        /// 届出履歴情報を更新します。
        /// </summary>
        /// <param name="entity">更新データ</param>
        public static void Update(SyoriSisetuEntity entity)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            string sql = @"
UPDATE SDTSYORISISETU
   SET NENDO = @Nendo
      ,KANRINO = @KanriNo
      ,SSNO = @SsNo
      ,SISETUNAMEN = @SisetuNameN
      ,TDKDJURIDATE = @TdkdjuriDate
      ,BIKO = @Biko
      ,UPDDATE = @UpdDate
      ,REV = REV + @Rev
 WHERE NENDO = @Nendo
   AND KANRINO = @KanriNo
   AND SSNO = @SsNo
";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    conn.Open();

                    using (var tran = conn.BeginTransaction())
                    {
                        try
                        {
                            conn.Execute(sql, entity, tran);
                            tran.Commit();
                        }
                        catch (Exception ex)
                        {
                            tran.Rollback();
                            throw ex;
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);
        }

        /// <summary>
        /// 削除対象キーに該当する処理施設情報を削除します。
        /// </summary>
        /// <param name="key">削除対象キー</param>
        public static void Delete(SyoriSisetuEntity key)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            string sql = @"DELETE FROM SDTSYORISISETU WHERE NENDO = @Nendo AND KANRINO = @KanriNo AND SSNO = @SsNo";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    conn.Open();

                    using (var tran = conn.BeginTransaction())
                    {
                        try
                        {
                            conn.Execute(sql, key, tran);
                            tran.Commit();
                        }
                        catch (Exception ex)
                        {
                            tran.Rollback();
                            throw ex;
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);
        }

        /// <summary>
        /// 年度、管理番号に該当する処理施設情報を削除します。
        /// </summary>
        /// <param name="nendo">年度</param>
        /// <param name="kanriNo">管理番号</param>
        public static void Delete(int nendo, int kanriNo)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            string sql = @"DELETE FROM SDTSYORISISETU WHERE NENDO = @Nendo AND KANRINO = @KanriNo";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    conn.Open();

                    using (var tran = conn.BeginTransaction())
                    {
                        try
                        {
                            conn.Execute(sql, new { Nendo = nendo, KanriNo = kanriNo }, tran);
                            tran.Commit();
                        }
                        catch (Exception ex)
                        {
                            tran.Rollback();
                            throw ex;
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);
        }

        #endregion
    }
}
