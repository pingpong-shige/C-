﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using Dapper;
using Suisitu.Common;
using Suisitu.Entity;

namespace Suisitu.Dao
{
    /// <summary>
    /// 届出管理Daoクラス
    /// </summary>
    public class TodokedeKanriDao
    {
        #region パブリックメソッド

        /// <summary>
        /// 選択対象キーに該当する届出管理情報を取得します。
        /// </summary>
        /// <param name="key">選択対象キー</param>
        /// <returns>届出管理情報</returns>
        public static TodokedeKanriEntity Select(TodokedeKanriEntity key)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            TodokedeKanriEntity entity = null;

            string sql = @"SELECT * FROM SDVTODOKEDEKANRI WHERE NENDO = @Nendo AND KANRINO = @KanriNo";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    entity = conn.QueryFirstOrDefault<TodokedeKanriEntity>(sql, key);
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);

            return entity == null ? new TodokedeKanriEntity { Nendo = key.Nendo, KanriNo = key.KanriNo } : entity;
        }

        #endregion
    }
}
