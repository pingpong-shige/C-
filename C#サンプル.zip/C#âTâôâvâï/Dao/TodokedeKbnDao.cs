﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using Dapper;
using Suisitu.Common;
using Suisitu.Entity;

namespace Suisitu.Dao
{
    /// <summary>
    /// 届出区分Daoクラス
    /// </summary>
    public class TodokedeKbnDao
    {
        #region パブリックメソッド

        /// <summary>
        /// 届出区分情報を取得します。
        /// </summary>
        /// <returns>届出区分情報</returns>
        public static IEnumerable<TodokedeKbnEntity> SelectAll()
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            IEnumerable<TodokedeKbnEntity> list = null;

            string sql = @"SELECT * FROM SDCTODOKEDEKBN ORDER BY TODOKEDEKBN";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    list = conn.Query<TodokedeKbnEntity>(sql);
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);

            return list;
        }

        /// <summary>
        /// 選択対象キーに該当する届出区分情報を取得します。
        /// </summary>
        /// <param name="key">選択対象キー</param>
        /// <returns>届出区分情報</returns>
        public static TodokedeKbnEntity Select(TodokedeKbnEntity key)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            TodokedeKbnEntity entity = null;

            string sql = @"SELECT * FROM SDCTODOKEDEKBN WHERE TODOKEDEKBN = @TodokedeKbn";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    entity = conn.QueryFirstOrDefault<TodokedeKbnEntity>(sql, key);
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);

            return entity;
        }

        /// <summary>
        /// 法区分コードに該当する届出区分情報を取得します。（コンボボックス設定用）
        /// </summary>
        /// <param name="parent">法区分コード</param>
        /// <returns>届出区分情報</returns>
        public static IEnumerable<MasterEntity> GetMasterData(string parent)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            IEnumerable<MasterEntity> list = null;

            string sql = @"
SELECT TODOKEDEKBN AS VALUE, TODOKEDEKBNNAMEN AS NAME
  FROM SDCTODOKEDEKBN
 WHERE PARENT = @Parent
 ORDER BY TODOKEDEKBN";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    list = conn.Query<MasterEntity>(sql, new TodokedeKbnEntity { Parent = parent });
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);

            return list;
        }

        /// <summary>
        /// 届出区分情報を登録します。
        /// </summary>
        /// <param name="entity">登録データ</param>
        public static void Insert(TodokedeKbnEntity entity)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            string sql = @"
INSERT INTO SDCTODOKEDEKBN( 
    TODOKEDEKBN
   ,TODOKEDEKBNNAMEN
   ,PARENT
   ,UPDDATE
   ,REV
)
VALUES ( 
    @TodokedeKbn
   ,@TodokedeKbnNameN
   ,@Parent
   ,@UpdDate
   ,@Rev
)
";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    conn.Open();

                    using (var tran = conn.BeginTransaction())
                    {
                        try
                        {
                            conn.Execute(sql, entity, tran);
                            tran.Commit();
                        }
                        catch (Exception ex)
                        {
                            tran.Rollback();
                            throw ex;
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);
        }

        /// <summary>
        /// 届出区分情報を更新します。
        /// </summary>
        /// <param name="entity">更新データ</param>
        public static void Update(TodokedeKbnEntity entity)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            string sql = @"
UPDATE SDCTODOKEDEKBN
   SET TODOKEDEKBN = @TodokedeKbn
      ,TODOKEDEKBNNAMEN = @TodokedeKbnNameN
      ,PARENT = @Parent
      ,UPDDATE = @UpdDate
      ,REV = REV + @Rev
WHERE TODOKEDEKBN = @TodokedeKbn
";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    conn.Open();

                    using (var tran = conn.BeginTransaction())
                    {
                        try
                        {
                            conn.Execute(sql, entity, tran);
                            tran.Commit();
                        }
                        catch (Exception ex)
                        {
                            tran.Rollback();
                            throw ex;
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);
        }

        /// <summary>
        /// 削除対象キーに該当する届出区分情報を削除します。
        /// </summary>
        /// <param name="key">削除対象キー</param>
        public static void Delete(TodokedeKbnEntity key)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            string sql = @"DELETE FROM SDCTODOKEDEKBN WHERE TODOKEDEKBN = @TodokedeKbn";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    conn.Open();

                    using (var tran = conn.BeginTransaction())
                    {
                        try
                        {
                            conn.Execute(sql, key, tran);
                            tran.Commit();
                        }
                        catch (Exception ex)
                        {
                            tran.Rollback();
                            throw ex;
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);
        }

        #endregion
    }
}
