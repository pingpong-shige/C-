﻿using System.Collections.Generic;
using System.Linq;
using log4net;
using System.Data.SqlClient;
using Dapper;
using Suisitu.Common;
using System.Reflection;
using Suisitu.Entity;
using System;
using System.Data;

namespace Suisitu.Dao
{
    /// <summary>
    /// 届出履歴Daoクラス
    /// </summary>
    public class TodokedeRirekiDao
    {
        private static readonly ILog logger = LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);

        #region パブリックメソッド

        /// <summary>
        /// 選択対象キーに該当する届出履歴情報を取得します。
        /// </summary>
        /// <param name="key">選択対象キー</param>
        /// <returns>届出履歴情報</returns>
        public static IEnumerable<TodokedeRirekiEntity> SelectList(TodokedeRirekiEntity key)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            IEnumerable<TodokedeRirekiEntity> list = null;

            string sql = @"SELECT * FROM SDTTODOKEDERIREKI WHERE NENDO = @Nendo AND KANRINO = @KanriNo ORDER BY TODOKEDEDATE DESC, CONVERT(INT, TDKDNO)";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    list = conn.Query<TodokedeRirekiEntity>(sql, key);
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);

            return list;
        }

        /// <summary>
        /// 選択対象キーに該当する届出履歴情報を取得します。
        /// </summary>
        /// <param name="key">選択対象キー</param>
        /// <returns>届出履歴情報</returns>
        public static TodokedeRirekiEntity Select(TodokedeRirekiEntity key)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            TodokedeRirekiEntity entity = null;

            string sql = @"SELECT * FROM SDTTODOKEDERIREKI WHERE Nendo = @Nendo AND KanriNo = @KanriNo AND TdkdNo = @TdkdNo";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    entity = conn.QueryFirstOrDefault<TodokedeRirekiEntity>(sql, key);
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);

            return entity;
        }

        /// <summary>
        /// 選択対象キーに該当する届出履歴管理番号の最大値＋1を取得します。
        /// 該当データが存在しない場合は、"001"を返します。
        /// </summary>
        /// <param name="key">選択対象キー</param>
        /// <returns>新届出履歴管理番号</returns>
        public static string GetNewTdkdNo(TodokedeRirekiEntity key)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            dynamic entity = null;

            string sql = @"SELECT MAX(CONVERT(INT, TDKDNO)) + 1 AS MAXTDKDNO FROM SDTTODOKEDERIREKI WHERE NENDO = @Nendo AND KANRINO = @KanriNo";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    entity = conn.QueryFirstOrDefault(sql, key);
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);

            return entity.MAXTDKDNO == null ? "001" : String.Format("{0:000}", (int)entity.MAXTDKDNO);
        }

        /// <summary>
        /// 届出履歴情報を登録します。
        /// </summary>
        /// <param name="entity">登録データ</param>
        public static void Insert(TodokedeRirekiEntity entity)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            string sql = @"
INSERT INTO SDTTODOKEDERIREKI(
       NENDO
      ,KANRINO
      ,TDKDNO
      ,TODOKEDEDATE
      ,KESSAIDATE
      ,UKETUKENO
      ,HOKBNCODE
      ,TDKDSYUBETU
      ,TDKDSYUBETUS
      ,TDKDKBN
      ,BIKO1
      ,BIKO2
      ,BIKO3
      ,SINSAKIKAN
      ,SINSEITENPUFLAG
      ,SINKIFLAG
      ,TSHAISIFLAG
      ,YUGAISIYOHAISIFLAG
      ,YUGAICHOZOHAISIFLAG
      ,HAISUI50IJOFLAG
      ,KOJIMAKORYUIKIFLAG
      ,TOROKUDATE
      ,UPDDATE
      ,REV
     )
     VALUES (
      @Nendo
     ,@KanriNo
     ,@TdkdNo
     ,@TodokedeDate
     ,@KessaiDate
     ,@UketukeNo
     ,@HokbnCode
     ,@TdkdSyubetu
     ,@TdkdSyubetuS
     ,@TdkdKbn
     ,@Biko1
     ,@Biko2
     ,@Biko3
     ,@SinsaKikan
     ,@SinseiTenpuFlag
     ,@SinkiFlag
     ,@TsHaisiFlag
     ,@YugaiSiyoHaisiFlag
     ,@YugaiChozoHaisiFlag
     ,@Haisui50IjoFlag
     ,@KojimaKoryuikiFlag
     ,@TorokuDate
     ,@UpdDate
     ,@Rev
      )
";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    conn.Open();

                    using (var tran = conn.BeginTransaction())
                    {
                        try
                        {
                            conn.Execute(sql, entity, tran);
                            tran.Commit();
                        }
                        catch (Exception ex)
                        {
                            tran.Rollback();
                            throw ex;
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);
        }

        /// <summary>
        /// 届出履歴情報を更新します。
        /// </summary>
        /// <param name="entity">更新データ</param>
        public static void Update(TodokedeRirekiEntity entity)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            string sql = @"
UPDATE SDTTODOKEDERIREKI
   SET NENDO = @Nendo
      ,KANRINO = @KanriNo
      ,TDKDNO = @TdkdNo
      ,TODOKEDEDATE = @TodokedeDate
      ,KESSAIDATE = @KessaiDate
      ,UKETUKENO = @UketukeNo
      ,HOKBNCODE = @HokbnCode
      ,TDKDSYUBETU = @TdkdSyubetu
      ,TDKDSYUBETUS = @TdkdSyubetuS
      ,TDKDKBN = @TdkdKbn
      ,BIKO1 = @Biko1
      ,BIKO2 = @Biko2
      ,BIKO3 = @Biko3
      ,SINSAKIKAN = @SinsaKikan
      ,SINSEITENPUFLAG = @SinseiTenpuFlag
      ,SINKIFLAG = @SinkiFlag
      ,TSHAISIFLAG = @TsHaisiFlag
      ,YUGAISIYOHAISIFLAG = @YugaiSiyoHaisiFlag
      ,YUGAICHOZOHAISIFLAG = @YugaiChozoHaisiFlag
      ,HAISUI50IJOFLAG = @Haisui50IjoFlag
      ,KOJIMAKORYUIKIFLAG = @KojimaKoryuikiFlag
      ,UPDDATE = @UpdDate
      ,REV = REV + @Rev
 WHERE NENDO = @Nendo
   AND KANRINO = @KanriNo
   AND TDKDNO = @TdkdNo
";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    conn.Open();

                    using (var tran = conn.BeginTransaction())
                    {
                        try
                        {
                            conn.Execute(sql, entity, tran);
                            tran.Commit();
                        }
                        catch (Exception ex)
                        {
                            tran.Rollback();
                            throw ex;
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);
        }

        /// <summary>
        /// 削除対象キーに該当する届出履歴情報を削除します。
        /// </summary>
        /// <param name="key">削除対象キー</param>
        public static void Delete(TodokedeRirekiEntity key)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            string sql = @"DELETE FROM SDTTODOKEDERIREKI WHERE NENDO = @Nendo AND KANRINO = @KanriNo AND TDKDNO = @TdkdNo";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    conn.Open();

                    using (var tran = conn.BeginTransaction())
                    {
                        try
                        {
                            conn.Execute(sql, key, tran);
                            tran.Commit();
                        }
                        catch (Exception ex)
                        {
                            tran.Rollback();
                            throw ex;
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);
        }


        /// <summary>
        /// 年度、管理番号に該当する届出履歴情報を削除します。
        /// </summary>
        /// <param name="nendo">年度</param>
        /// <param name="kanriNo">管理番号</param>
        public static void Delete(int nendo, int kanriNo)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            string sql = @"DELETE FROM SDTTODOKEDERIREKI WHERE NENDO = @Nendo AND KANRINO = @KanriNo";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    conn.Open();

                    using (var tran = conn.BeginTransaction())
                    {
                        try
                        {
                            conn.Execute(sql, new TodokedeRirekiEntity { Nendo = nendo, KanriNo = kanriNo }, tran);
                            tran.Commit();
                        }
                        catch (Exception ex)
                        {
                            tran.Rollback();
                            throw ex;
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);
        }

        #endregion
    }
}
