﻿using Dapper;
using log4net;
using Suisitu.Common;
using Suisitu.Entity;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Reflection;

namespace Suisitu.Dao
{
    /// <summary>
    /// 特定施設等表Daoクラス
    /// </summary>
    public class TokuteiSisetuTouDao
    {
        private static readonly ILog logger = LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);

        #region パブリックメソッド

        /// <summary>
        /// 選択対象キーに該当する特定施設等情報を取得します。
        /// </summary>
        /// <param name="key">選択対象キー</param>
        /// <returns>特定施設等情報</returns>
        public static IEnumerable<TokuteiSisetuTouEntity> SelectList(TokuteiSisetuTouEntity key)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            IEnumerable<TokuteiSisetuTouEntity> list = null;

            string sql = @"SELECT * FROM SDTTOKUTEISISETUTOU WHERE NENDO = @Nendo AND KANRINO = @KanriNo ORDER BY SISETUKBN, DAIHYOFLAG DESC, HAISIDATE, CONVERT(INT, TSNO)";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    list = conn.Query<TokuteiSisetuTouEntity>(sql, key);
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);

            return list;
        }

        /// <summary>
        /// 特定施設等情報を取得します。
        /// </summary>
        /// <returns>特定施設情報</returns>
        public static IEnumerable<TokuteiSisetuTouEntity> SelectList()
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            IEnumerable<TokuteiSisetuTouEntity> list = null;

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                conn.Open();
                list = conn.Query<TokuteiSisetuTouEntity>(@"SELECT * FROM SDTTOKUTEISISETUTOU ORDER BY NENDO, KANRINO");
                conn.Close();
            }

            //logger.Debug(Constant.LOG_METHOD_END);

            return list;
        }

        /// <summary>
        /// 選択対象キーに該当する特定施設等情報を取得します。
        /// </summary>
        /// <param name="key">選択対象キー</param>
        /// <returns>特定施設等情報</returns>
        public static TokuteiSisetuTouEntity Select(TokuteiSisetuTouEntity key)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            TokuteiSisetuTouEntity entity = null;

            string sql = @"SELECT * FROM SDVTSYUGAISIYO WHERE Nendo = @Nendo AND KanriNo = @KanriNo AND TsNo = @TsNo";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    entity = conn.QueryFirstOrDefault<TokuteiSisetuTouEntity>(sql, key);
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);

            return entity;
        }

        /// <summary>
        /// 特定施設等情報を取得します。
        /// </summary>
        /// <returns>特定施設情報</returns>
        public static TokuteiSisetuTouEntity Select(string key)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            if (key == null)
                return new TokuteiSisetuTouEntity();

            TokuteiSisetuTouEntity entity = null;

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                conn.Open();
                entity = conn.QuerySingleOrDefault<TokuteiSisetuTouEntity>(@"SELECT * FROM SDVJIGYOJOITIRAN WHERE SEIRINO = @SeiriNo", new TokuteiSisetuTouEntity{ SeiriNo = key });
                conn.Close();
            }

            //logger.Debug(Constant.LOG_METHOD_END);

            return entity;
        }

        /// <summary>
        /// 特定施設種別を取得します。
        /// </summary>
        /// <returns>特定施設種別</returns>
        public static IEnumerable<MasterEntity> SelectList(bool flag)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            IEnumerable<MasterEntity> list = null;

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                conn.Open();
                list = conn.Query<MasterEntity>(@"SELECT TSSYUBETU AS VALUE, TSSYUBETUNAMEN AS NAME FROM SDCTSSYUBETU ORDER BY TSSYUBETUNO, TSSYUBETU");
                conn.Close();
            }

            //logger.Debug(Constant.LOG_METHOD_END);

            return list;
        }

        /// <summary>
        /// 特定施設種別(細区分)を取得します。
        /// </summary>
        /// <returns>特定施設種別</returns>
        public static IEnumerable<MasterEntity> SelectList(bool flag, string key)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            IEnumerable<MasterEntity> list = null;

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                conn.Open();
                list = conn.Query<MasterEntity>(@"SELECT SUBSTRING(TSSYUBETUSAI,4,1) AS VALUE, TSSYUBETUSAINAMEN AS NAME FROM SDCTSSYUBETUSAI WHERE PARENT = '" + key +"' ORDER BY TSSYUBETUSAI, TSSYUBETUSAINO");
                conn.Close();
            }

            //logger.Debug(Constant.LOG_METHOD_END);

            return list;
        }

        /// <summary>
        /// 選択対象キーに該当する施設番号の最大値＋1を取得します。
        /// 該当データが存在しない場合は、"001"を返します。
        /// </summary>
        /// <param name="key">選択対象キー</param>
        /// <returns>新施設番号</returns>
        public static string GetNewTsNo(TokuteiSisetuTouEntity key)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            dynamic entity = null;

            string sql = @"SELECT MAX(CONVERT(INT, TSNO)) + 1 AS MAXTSNO FROM SDTTOKUTEISISETUTOU WHERE NENDO = @Nendo AND KANRINO = @KanriNo";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    entity = conn.QueryFirstOrDefault(sql, key);
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);

            return entity.MAXTSNO == null ? "001" : String.Format("{0:000}", (int)entity.MAXTSNO);
        }

        /// <summary>
        /// 削除対象キーに該当する特定施設情報を削除します。
        /// </summary>
        /// <param name="key">削除対象キー</param>
        public static void Delete(TokuteiSisetuTouEntity key)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            string sql = @"DELETE FROM SDTTOKUTEISISETUTOU WHERE NENDO = @NENDO AND KANRINO = @KANRINO AND TSNO = @TSNO";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    conn.Open();

                    using (var tran = conn.BeginTransaction())
                    {
                        try
                        {
                            conn.Execute(sql, key, tran);
                            tran.Commit();
                        }
                        catch (Exception ex)
                        {
                            tran.Rollback();
                            throw ex;
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);
        }

        /// <summary>
        /// 年度、管理番号に該当する特定施設情報を削除します。
        /// </summary>
        /// <param name="nendo">年度</param>
        /// <param name="kanriNo">管理番号</param>
        public static void Delete(int nendo, int kanriNo)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            string sql = @"DELETE FROM SDTTOKUTEISISETUTOU WHERE NENDO = @Nendo AND KANRINO = @KanriNo";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    conn.Open();

                    using (var tran = conn.BeginTransaction())
                    {
                        try
                        {
                            conn.Execute(sql, new TokuteiSisetuTouEntity { Nendo = nendo, KanriNo = kanriNo }, tran);
                            tran.Commit();
                        }
                        catch (Exception ex)
                        {
                            tran.Rollback();
                            throw ex;
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);
        }

        /// <summary>
        /// 特定施設等   情報を更新します。
        /// </summary>
        /// <param name="entity">更新データ</param>
        public static void Update(TokuteiSisetuTouEntity entity)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            string sql = @"
UPDATE SDTTOKUTEISISETUTOU
   SET NENDO = @NENDO
     , KANRINO = @KANRINO 
     , TSNO = @TSNO
     , SISETUKBN = @SISETUKBN
     , SISETUNAMEN = @SISETUNAMEN
     , SETIDATE = @SETIDATE
     , HAISIDATE = @HAISIDATE
     , TSSYUBETU = @TSSYUBETU
     , TSSYUBETUSAI = @TSSYUBETUSAI
     , DAIHYOFLAG = @DAIHYOFLAG
     , SEIRINO = @SEIRINO
     , SISETUSU = @SISETUSU
     , YUGAISIYOFLAG = @YUGAISIYOFLAG
     , YUGAITIKASINTOUFLAG = @YUGAITIKASINTOUFLAG
     , BIKO = @BIKO
     , TOROKUDATE = @TOROKUDATE
     , HAISIFLAG = @HAISIFLAG
     , UPDDATE = @UPDDATE
     , REV = @REV
    WHERE NENDO = @NENDO AND KANRINO = @KANRINO AND TSNO = @TSNO";

            
            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                conn.Open();
                conn.Execute(sql, entity);
                conn.Close();
            }

            //logger.Debug(Constant.LOG_METHOD_END);
        }

        /// <summary>
        /// SDTTOKUTEISISETUTOUテーブルを特定施設等情報画面の入力値で更新します。
        /// </summary>
        /// <param name="entity">挿入データ</param>
        public static void Insert(TokuteiSisetuTouEntity entity)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            string sql = @"
INSERT INTO SDTTOKUTEISISETUTOU( 
       NENDO
     , KANRINO 
     , TSNO
     , SISETUKBN
     , SISETUNAMEN
     , SETIDATE
     , HAISIDATE
     , TSSYUBETU
     , TSSYUBETUSAI
     , DAIHYOFLAG
     , SEIRINO
     , SISETUSU
     , YUGAISIYOFLAG
     , YUGAITIKASINTOUFLAG
     , BIKO
     , TOROKUDATE
     , HAISIFLAG
     , UPDDATE
     , REV
     )
     VALUES ( 
       @NENDO
     , @KANRINO 
     , @TSNO
     , @SISETUKBN
     , @SISETUNAMEN
     , @SETIDATE
     , @HAISIDATE
     , @TSSYUBETU
     , @TSSYUBETUSAI
     , @DAIHYOFLAG
     , @SEIRINO
     , @SISETUSU
     , @YUGAISIYOFLAG
     , @YUGAITIKASINTOUFLAG
     , @BIKO
     , @TOROKUDATE
     , @HAISIFLAG
     , @UPDDATE
     , @REV
      )";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                conn.Open();
                    conn.Execute(sql, entity);
                conn.Close();
            }

            //logger.Debug(Constant.LOG_METHOD_END);
        }

        /// <summary>
        /// 施設番号の最大値を取得します。
        /// </summary>
        /// <param name="table">テーブル名</param>
        /// <param name="column">カラム名</param>
        /// <param name="key">Entity</param>
        /// <returns>施設番号の最大値</returns>
        public static int GetMaxValue(TokuteiSisetuTouEntity key = null)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            int MaxValue;

            TokuteiSisetuTouEntity entity = null;

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                conn.Open();
                entity = conn.QuerySingle<TokuteiSisetuTouEntity>(@"SELECT MAX(CONVERT(int,TSNO)) AS TSNO FROM SDTTOKUTEISISETUTOU WHERE NENDO = @NENDO AND KANRINO = @KANRINO", key);
                conn.Close();
            }

            //logger.Debug(Constant.LOG_METHOD_END);

            MaxValue = int.Parse(entity.TsNo);

            return MaxValue;
        }

        #endregion
    }
}
