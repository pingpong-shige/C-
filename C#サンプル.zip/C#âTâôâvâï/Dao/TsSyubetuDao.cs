﻿using Dapper;
using log4net;
using Suisitu.Common;
using Suisitu.Entity;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Reflection;

namespace Suisitu.Dao
{
    /// <summary>
    /// 特定施設種別表Daoクラス
    /// </summary>
    public class TsSyubetuDao
    {
        private static readonly ILog logger = LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);

        #region パブリックメソッド

        /// <summary>
        /// 特定施設種別を取得します。
        /// </summary>
        /// <returns> 特定施設種別</returns>
        public static IEnumerable<TsSyubetuEntity> SelectAll()
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            IEnumerable<TsSyubetuEntity> list = null;

            string sql = @"SELECT * FROM SDCTSSYUBETU ORDER BY TSSYUBETU";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    list = conn.Query<TsSyubetuEntity>(sql, new TsSyubetuEntity { });
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);

            return list;
        }

        /// <summary>
        /// 選択対象キーに該当する特定施設種別を取得します。
        /// </summary>
        /// <param name="key">選択対象キー</param>
        /// <returns>特定施設種別</returns>
        public static TsSyubetuEntity Select(TsSyubetuEntity key)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            TsSyubetuEntity entity = null;

            string sql = @"SELECT * FROM SDCTSSYUBETU WHERE TSSYUBETU = @TsSyubetu";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    entity = conn.QueryFirstOrDefault<TsSyubetuEntity>(sql, key);
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);

            return entity;
        }

        /// <summary>
        /// 特定施設種別を登録します。
        /// </summary>
        /// <param name="entity">登録データ</param>
        public static void Insert(TsSyubetuEntity entity)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            string sql = @"
INSERT INTO SDCTSSYUBETU( 
    TSSYUBETU
   ,TSSYUBETUNAMEN
   ,TSSYUBETUNO
   ,UPDDATE
   ,REV
)
VALUES ( 
    @TsSyubetu
   ,@TsSyubetuNameN
   ,@TsSyubetuNo
   ,@UpdDate
   ,@Rev
)
";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    conn.Open();

                    using (var tran = conn.BeginTransaction())
                    {
                        try
                        {
                            conn.Execute(sql, entity, tran);
                            tran.Commit();
                        }
                        catch (Exception ex)
                        {
                            tran.Rollback();
                            throw ex;
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);
        }

        /// <summary>
        /// 特定施設種別を更新します。
        /// </summary>
        /// <param name="entity">更新データ</param>
        public static void Update(TsSyubetuEntity entity)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            string sql = @"
UPDATE SDCTSSYUBETU
   SET TSSYUBETUNAMEN = @TsSyubetuNameN
      ,TSSYUBETUNO = @TsSyubetuNo
      ,UPDDATE = @UpdDate
      ,REV = REV + @Rev
WHERE TSSYUBETU = @TsSyubetu
";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    conn.Open();

                    using (var tran = conn.BeginTransaction())
                    {
                        try
                        {
                            conn.Execute(sql, entity, tran);
                            tran.Commit();
                        }
                        catch (Exception ex)
                        {
                            tran.Rollback();
                            throw ex;
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);
        }

        /// <summary>
        /// 削除対象キーに該当する特定施設種別を削除します。
        /// </summary>
        /// <param name="key">削除対象キー</param>
        public static void Delete(TsSyubetuEntity key)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            string sql = @"DELETE FROM SDCTSSYUBETU WHERE TSSYUBETU = @TsSyubetu";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    conn.Open();

                    using (var tran = conn.BeginTransaction())
                    {
                        try
                        {
                            conn.Execute(sql, key, tran);
                            tran.Commit();
                        }
                        catch (Exception ex)
                        {
                            tran.Rollback();
                            throw ex;
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);
        }

        /// <summary>
        /// 特定施設種別情報を取得します。（コンボボックス設定用）
        /// </summary>
        /// <returns>特定施設種別情報</returns>
        public static IEnumerable<MasterEntity> GetMasterData()
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            IEnumerable<MasterEntity> list = null;

            string sql = @"
SELECT TSSYUBETU AS VALUE, TSSYUBETUNAMEN AS NAME
  FROM SDCTSSYUBETU
 ORDER BY TSSYUBETU
";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    list = conn.Query<MasterEntity>(sql);
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);

            return list;
        }

        #endregion
    }
}
