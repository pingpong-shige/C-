﻿using Dapper;
using log4net;
using Suisitu.Common;
using Suisitu.Entity;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Reflection;

namespace Suisitu.Dao
{
    /// <summary>
    /// 特定施設種別(細区分)表Daoクラス
    /// </summary>
    public class TsSyubetuSaiDao
    {
        private static readonly ILog logger = LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);

        #region パブリックメソッド

        /// <summary>
        /// 特定施設種別に該当する特定施設種別(細区分)を取得します。（コンボボックス設定用）
        /// </summary>
        /// <param name="parent">特定施設種別</param>
        /// <returns>特定施設種別(細区分)情報</returns>
        public static IEnumerable<MasterEntity> GetMasterData(string parent)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            IEnumerable<MasterEntity> list = null;

            string sql = @"
SELECT SUBSTRING(TSSYUBETUSAI, 4, 1) AS VALUE, TSSYUBETUSAINAMEN AS NAME
  FROM SDCTSSYUBETUSAI
 WHERE PARENT = @Parent
 ORDER BY TSSYUBETUSAI
";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    list = conn.Query<MasterEntity>(sql, new KubunNameEntity { Parent = parent });
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);

            return list;
        }

        /// <summary>
        /// 特定施設種別（細分類）情報を登録します。
        /// </summary>
        /// <param name="entity">登録データ</param>
        public static void Insert(TsSyubetuSaiEntity entity)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            string sql = @"
INSERT INTO SDCTSSYUBETUSAI( 
    TSSYUBETUSAI
   ,TSSYUBETUSAINAMEN
   ,TSSYUBETUSAINO
   ,PARENT
   ,UPDDATE
   ,REV
)
VALUES ( 
    @TsSyubetuSai
   ,@TsSyubetuSaiNameN
   ,@TsSyubetuSaiNo
   ,@Parent
   ,@UpdDate
   ,@Rev
)
";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    conn.Open();

                    using (var tran = conn.BeginTransaction())
                    {
                        try
                        {
                            conn.Execute(sql, entity, tran);
                            tran.Commit();
                        }
                        catch (Exception ex)
                        {
                            tran.Rollback();
                            throw ex;
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);
        }

        /// <summary>
        /// 特定施設種別（細分類）情報を更新します。
        /// </summary>
        /// <param name="entity">更新データ</param>
        public static void Update(TsSyubetuSaiEntity entity)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            string sql = @"
UPDATE SDCTSSYUBETUSAI
   SET TSSYUBETUSAINAMEN = @TsSyubetuSaiNameN
      ,TSSYUBETUSAINO = @TsSyubetuSaiNo
      ,UPDDATE = @UpdDate
      ,REV = REV + @Rev
WHERE TSSYUBETUSAI = @TsSyubetuSai
  AND PARENT = @Parent
";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    conn.Open();

                    using (var tran = conn.BeginTransaction())
                    {
                        try
                        {
                            conn.Execute(sql, entity, tran);
                            tran.Commit();
                        }
                        catch (Exception ex)
                        {
                            tran.Rollback();
                            throw ex;
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);
        }

        /// <summary>
        /// 削除対象キーに該当する特定施設種別（細分類）情報を削除します。
        /// </summary>
        /// <param name="key">削除対象キー</param>
        public static void Delete(TsSyubetuSaiEntity key)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            string sql = @"DELETE FROM SDCTSSYUBETUSAI WHERE TSSYUBETUSAI = @TsSyubetuSai";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    conn.Open();

                    using (var tran = conn.BeginTransaction())
                    {
                        try
                        {
                            conn.Execute(sql, key, tran);
                            tran.Commit();
                        }
                        catch (Exception ex)
                        {
                            tran.Rollback();
                            throw ex;
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);
        }

        /// <summary>
        /// 特定施設種別に該当する特定施設種別（細分類）情報を取得します。
        /// </summary>
        /// <param name="parent">特定施設種別</param>
        /// <returns>特定施設種別に該当する特定施設種別（細分類）情報</returns>
        public static IEnumerable<TsSyubetuSaiEntity> SelectByParent(TsSyubetuEntity key)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            IEnumerable<TsSyubetuSaiEntity> list = null;

            string sql = @"SELECT * FROM SDCTSSYUBETUSAI WHERE PARENT = @TsSyubetu ORDER BY TSSYUBETUSAI";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    list = conn.Query<TsSyubetuSaiEntity>(sql, key);
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);

            return list;
        }

        /// <summary>
        /// 特定施設種別、特定施設種別（細区分）に該当する特定施設種別（細分類）情報を取得します。
        /// </summary>
        /// <param name="key">選択対象キー</param>
        /// <returns>特定施設種別（細分類）情報</returns>
        public static TsSyubetuSaiEntity SelectByTsSyubetuSai(TsSyubetuSaiEntity key)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            TsSyubetuSaiEntity entity = null;

            string sql = @"SELECT * FROM SDCTSSYUBETUSAI WHERE TSSYUBETUSAI = @TsSyubetuSai";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    entity = conn.QueryFirstOrDefault<TsSyubetuSaiEntity>(sql, key);
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);

            return entity;
        }

        #endregion
    }
}
