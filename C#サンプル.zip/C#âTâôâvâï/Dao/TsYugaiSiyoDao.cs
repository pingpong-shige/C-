﻿using Dapper;
using Suisitu.Common;
using Suisitu.Entity;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace Suisitu.Dao
{
    /// <summary>
    /// 特定施設等有害物質使用状況Daoクラス
    /// </summary>
    public class TsYugaiSiyoDao
    {
        #region パブリックメソッド

        /// <summary>
        /// 選択対象キーに該当する特定施設等有害物質使用状況を取得します。
        /// </summary>
        /// <param name="key">選択対象キー</param>
        /// <returns>特定施設等有害物質使用状況</returns>
        public static TsYugaiSiyoEntity Select(TsYugaiSiyoEntity key)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            TsYugaiSiyoEntity entity = null;

            string sql = @"SELECT * FROM SDTTSYUGAISIYO WHERE NENDO = @Nendo AND KANRINO = @KanriNo AND TSNO = @TsNo AND KOMOKUCODE = @KomokuCode";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    entity = conn.QueryFirstOrDefault<TsYugaiSiyoEntity>(sql, key);
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);

            return entity;
        }

        /// <summary>
        /// 選択対象キーに該当する特定施設等情報を取得します。
        /// </summary>
        /// <param name="key">選択対象キー</param>
        /// <returns>特定施設等情報</returns>
        public static IEnumerable<TsYugaiSiyoEntity> SelectList(TsYugaiSiyoEntity key)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            IEnumerable<TsYugaiSiyoEntity> entity = null;

            string sql = @"SELECT * FROM SDVTSYUGAISIYO_2 WHERE Nendo = @Nendo AND KanriNo = @KanriNo AND TsNo = @TsNo ORDER BY WRTSEQNO, KOMOKUCODE";
//            string sql = @"SELECT * FROM 
//(select KOMOKUCODE, KOMOKUNAMEN from SDCKOMOKUCODE where KOMOKUFLAG in(1,2,3)) K
//left join 
//	(select KOMOKUCODE, GSIYOFLAG, KSIYOFLAG, BIKO 
//	 from SDTTSYUGAISIYO where NENDO = 9999 and KANRINO = 3 and TSNO = 001) Y
//	on K.KOMOKUCODE = Y.KOMOKUCODE";
            

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    entity = conn.Query<TsYugaiSiyoEntity>(sql, key);
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);

            return entity;
        }

        ///// <summary>
        ///// 事業場一覧情報を取得します。
        ///// </summary>
        ///// <returns>事業場一覧情報</returns>
        ////public static IEnumerable<TokuteiSisetuTouEntity> SelectList(TokuteiSisetuTouEntity param = null)
        //public static IEnumerable<JigyojoItiranEntity> SelectList(string key)
        //{
        //    //logger.Debug(Constant.LOG_METHOD_START);

        //    IEnumerable<JigyojoItiranEntity> list = null;

        //    string sql = @"SELECT * FROM SDVJIGYOJOITIRAN TS WHERE SUBSTRING(SEIRINO,1,3) = '" + key + "' ORDER BY NENDO, KANRINO, SEIRINO";

        //    using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
        //    {
        //        conn.Open();
        //        list = conn.Query<JigyojoItiranEntity>(sql);
        //        conn.Close();
        //    }

        //    //logger.Debug(Constant.LOG_METHOD_END);

        //    return list;
        //}

        /// <summary>
        /// SDTTOKUTEISISETUTOUテーブルを特定施設情報画面の入力値で更新します。
        /// </summary>
        /// <param name="entity">挿入データ</param>
        public static void Update(TsYugaiSiyoEntity entity)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            string sql = @"
UPDATE SDTTSYUGAISIYO
   SET NENDO = @NENDO
     , KANRINO = @KANRINO 
     , TSNO = @TSNO
     , KOMOKUCODE = @KOMOKUCODE
     , GSIYOFLAG = @GSIYOFLAG
     , KSIYOFLAG = @KSIYOFLAG
     , BIKO = @BIKO
     , TOROKUDATE = @TOROKUDATE
     , UPDDATE = @UPDDATE
     , REV = @REV
    WHERE NENDO = @NENDO AND KANRINO = @KANRINO AND TSNO = @TSNO AND KOMOKUCODE = @KOMOKUCODE";
            
            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                conn.Open();
                conn.Execute(sql, entity);
                conn.Close();
            }

            //logger.Debug(Constant.LOG_METHOD_END);
        }

        /// <summary>
        /// SDTTOKUTEISISETUTOUテーブルを特定施設情報画面の入力値で更新します。
        /// </summary>
        /// <param name="entity">挿入データ</param>
        public static void Insert(TsYugaiSiyoEntity entity)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            string sql = @"
INSERT INTO SDTTSYUGAISIYO( 
       NENDO
     , KANRINO 
     , TSNO
     , KOMOKUCODE
     , GSIYOFLAG
     , KSIYOFLAG
     , BIKO
     , TOROKUDATE
     , UPDDATE
     , REV
     )
     VALUES ( 
       @NENDO
     , @KANRINO 
     , @TSNO
     , @KOMOKUCODE
     , @GSIYOFLAG
     , @KSIYOFLAG
     , @BIKO
     , @TOROKUDATE
     , @UPDDATE
     , @REV
      )";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                conn.Open();
                conn.Execute(sql, entity);
                conn.Close();
            }

            //logger.Debug(Constant.LOG_METHOD_END);
        }

        /// <summary>
        /// パラメータと一致する値を持つレコード件数を取得します。
        /// </summary>
        /// <param name="table">テーブル名</param>
        /// <param name="column">カラム名</param>
        /// <param name="value">比較する値</param>
        /// <param name="key">Entity</param>
        /// <returns>レコード件数</returns>
        public static int GetRecodeCount(TsYugaiSiyoEntity key = null)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            int count;

            TsYugaiSiyoEntity entity = null;

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                conn.Open();
                entity = conn.QuerySingle<TsYugaiSiyoEntity>
                    (@"SELECT COUNT(*) AS KOMOKUCODE FROM SDTTSYUGAISIYO WHERE NENDO = @NENDO AND KANRINO = @KANRINO AND TSNO = @TSNO AND KOMOKUCODE = @KOMOKUCODE", key);
                conn.Close();
            }

            //logger.Debug(Constant.LOG_METHOD_END);

            count = int.Parse(entity.KomokuCode);

            return count;
        }


        /// <summary>
        /// 年度、管理番号に該当する特定施設等有害物質使用状況情報を削除します。
        /// </summary>
        /// <param name="nendo">年度</param>
        /// <param name="kanriNo">管理番号</param>
        public static void Delete(int nendo, int kanriNo)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            string sql = @"DELETE FROM SDTTSYUGAISIYO WHERE NENDO = @Nendo AND KANRINO = @KanriNo";

            using (var conn = new SqlConnection(DBUtils.GetConnectionString()))
            {
                try
                {
                    conn.Open();

                    using (var tran = conn.BeginTransaction())
                    {
                        try
                        {
                            conn.Execute(sql, new TokuteiSisetuTouEntity { Nendo = nendo, KanriNo = kanriNo }, tran);
                            tran.Commit();
                        }
                        catch (Exception ex)
                        {
                            tran.Rollback();
                            throw ex;
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            //logger.Debug(Constant.LOG_METHOD_END);
        }

        #endregion
    }
}
