﻿using Suisitu.Common;

namespace Suisitu.Entity
{
    /// <summary>
    /// 付帯設備等Entityクラス
    /// </summary>
    public class FutaiSetubiTouEntity
    {
        /// <summary>
        /// 年度
        /// </summary>
        public int Nendo { get; set; }

        /// <summary>
        /// 管理番号
        /// </summary>
        public int KanriNo { get; set; }

        /// <summary>
        /// 付帯設備等番号
        /// </summary>
        public string FsNo { get; set; }

        /// <summary>
        /// とりまとめ登録フラグ
        /// </summary>
        public string TorimatomeFlag { get; set; }

        /// <summary>
        /// とりまとめ登録フラグ(データバインド用)
        /// </summary>
        public bool TorimatomeFlagChk { get { return DBUtils.ConvertDaoCheckBoxFormat(TorimatomeFlag); } }

        /// <summary>
        /// とりまとめ登録フラグ(データグリッドビュー用)
        /// </summary>
        public string TorimatomeFlagV { get { return TorimatomeFlag == "1" ? "○" : ""; } }

        /// <summary>
        /// とりまとめメモ
        /// </summary>
        public string TorimatomeMemo { get; set; }

        /// <summary>
        /// 施設番号
        /// </summary>
        public string TsNo { get; set; }

        /// <summary>
        /// 施設名称
        /// </summary>
        public string SisetuNameN { get; set; }

        /// <summary>
        /// 設備有無フラグ1
        /// </summary>
        public string SetubiUmuFlag1 { get; set; }

        /// <summary>
        /// 設備有無フラグ1(データバインド用)
        /// </summary>
        public bool SetubiUmuFlag1Chk { get { return DBUtils.ConvertDaoCheckBoxFormat(SetubiUmuFlag1); } }

        /// <summary>
        /// 設備有無フラグ1(データグリッドビュー用)
        /// </summary>
        public string SetubiUmuFlag1V { get { return SetubiUmuFlag1 == "1" ? "○" : ""; } }

        /// <summary>
        /// 構造基準フラグ1
        /// </summary>
        public string KozoKijunFlag1 { get; set; }

        /// <summary>
        /// 構造基準フラグ1(データバインド用)
        /// </summary>
        public bool KozoKijunFlag1Chk { get { return DBUtils.ConvertDaoCheckBoxFormat(KozoKijunFlag1); } }

        /// <summary>
        /// 定期点検適用有無フラグ1
        /// </summary>
        public string TeikiTenkenUmuFlag1 { get; set; }

        /// <summary>
        /// 定期点検適用有無フラグ1(データバインド用)
        /// </summary>
        public bool TeikiTenkenUmuFlag1Chk { get { return DBUtils.ConvertDaoCheckBoxFormat(TeikiTenkenUmuFlag1); } }

        /// <summary>
        /// 設備有無フラグ2
        /// </summary>
        public string SetubiUmuFlag2 { get; set; }

        /// <summary>
        /// 設備有無フラグ2(データバインド用)
        /// </summary>
        public bool SetubiUmuFlag2Chk { get { return DBUtils.ConvertDaoCheckBoxFormat(SetubiUmuFlag2); } }

        /// <summary>
        /// 設備有無フラグ2(データグリッドビュー用)
        /// </summary>
        public string SetubiUmuFlag2V { get { return SetubiUmuFlag2 == "1" ? "○" : ""; } }

        /// <summary>
        /// 構造基準フラグ2
        /// </summary>
        public string KozoKijunFlag2 { get; set; }

        /// <summary>
        /// 構造基準フラグ2(データバインド用)
        /// </summary>
        public bool KozoKijunFlag2Chk { get { return DBUtils.ConvertDaoCheckBoxFormat(KozoKijunFlag2); } }

        /// <summary>
        /// 定期点検適用有無フラグ2
        /// </summary>
        public string TeikiTenkenUmuFlag2 { get; set; }

        /// <summary>
        /// 定期点検適用有無フラグ2(データバインド用)
        /// </summary>
        public bool TeikiTenkenUmuFlag2Chk { get { return DBUtils.ConvertDaoCheckBoxFormat(TeikiTenkenUmuFlag2); } }

        /// <summary>
        /// 設備有無フラグ3
        /// </summary>
        public string SetubiUmuFlag3 { get; set; }

        /// <summary>
        /// 設備有無フラグ3(データバインド用)
        /// </summary>
        public bool SetubiUmuFlag3Chk { get { return DBUtils.ConvertDaoCheckBoxFormat(SetubiUmuFlag3); } }

        /// <summary>
        /// 設備有無フラグ3(データグリッドビュー用)
        /// </summary>
        public string SetubiUmuFlag3V { get { return SetubiUmuFlag3 == "1" ? "○" : ""; } }

        /// <summary>
        /// 構造基準フラグ3
        /// </summary>
        public string KozoKijunFlag3 { get; set; }

        /// <summary>
        /// 構造基準フラグ3(データバインド用)
        /// </summary>
        public bool KozoKijunFlag3Chk { get { return DBUtils.ConvertDaoCheckBoxFormat(KozoKijunFlag3); } }

        /// <summary>
        /// 定期点検適用有無フラグ3
        /// </summary>
        public string TeikiTenkenUmuFlag3 { get; set; }

        /// <summary>
        /// 定期点検適用有無フラグ3(データバインド用)
        /// </summary>
        public bool TeikiTenkenUmuFlag3Chk { get { return DBUtils.ConvertDaoCheckBoxFormat(TeikiTenkenUmuFlag3); } }

        /// <summary>
        /// 設備有無フラグ4
        /// </summary>
        public string SetubiUmuFlag4 { get; set; }

        /// <summary>
        /// 設備有無フラグ4(データバインド用)
        /// </summary>
        public bool SetubiUmuFlag4Chk { get { return DBUtils.ConvertDaoCheckBoxFormat(SetubiUmuFlag4); } }

        /// <summary>
        /// 設備有無フラグ4(データグリッドビュー用)
        /// </summary>
        public string SetubiUmuFlag4V { get { return SetubiUmuFlag4 == "1" ? "○" : ""; } }

        /// <summary>
        /// 構造基準フラグ4
        /// </summary>
        public string KozoKijunFlag4 { get; set; }

        /// <summary>
        /// 構造基準フラグ4(データバインド用)
        /// </summary>
        public bool KozoKijunFlag4Chk { get { return DBUtils.ConvertDaoCheckBoxFormat(KozoKijunFlag4); } }

        /// <summary>
        /// 定期点検適用有無フラグ4
        /// </summary>
        public string TeikiTenkenUmuFlag4 { get; set; }

        /// <summary>
        /// 定期点検適用有無フラグ4(データバインド用)
        /// </summary>
        public bool TeikiTenkenUmuFlag4Chk { get { return DBUtils.ConvertDaoCheckBoxFormat(TeikiTenkenUmuFlag4); } }

        /// <summary>
        /// 設備有無フラグ5
        /// </summary>
        public string SetubiUmuFlag5 { get; set; }

        /// <summary>
        /// 設備有無フラグ5(データバインド用)
        /// </summary>
        public bool SetubiUmuFlag5Chk { get { return DBUtils.ConvertDaoCheckBoxFormat(SetubiUmuFlag5); } }

        /// <summary>
        /// 設備有無フラグ5(データグリッドビュー用)
        /// </summary>
        public string SetubiUmuFlag5V { get { return SetubiUmuFlag5 == "1" ? "○" : ""; } }

        /// <summary>
        /// 構造基準フラグ5
        /// </summary>
        public string KozoKijunFlag5 { get; set; }

        /// <summary>
        /// 構造基準フラグ5(データバインド用)
        /// </summary>
        public bool KozoKijunFlag5Chk { get { return DBUtils.ConvertDaoCheckBoxFormat(KozoKijunFlag5); } }

        /// <summary>
        /// 定期点検適用有無フラグ5
        /// </summary>
        public string TeikiTenkenUmuFlag5 { get; set; }

        /// <summary>
        /// 定期点検適用有無フラグ5(データバインド用)
        /// </summary>
        public bool TeikiTenkenUmuFlag5Chk { get { return DBUtils.ConvertDaoCheckBoxFormat(TeikiTenkenUmuFlag5); } }

        /// <summary>
        /// 設備有無フラグ6
        /// </summary>
        public string SetubiUmuFlag6 { get; set; }

        /// <summary>
        /// 設備有無フラグ6(データバインド用)
        /// </summary>
        public bool SetubiUmuFlag6Chk { get { return DBUtils.ConvertDaoCheckBoxFormat(SetubiUmuFlag6); } }

        /// <summary>
        /// 設備有無フラグ6(データグリッドビュー用)
        /// </summary>
        public string SetubiUmuFlag6V { get { return SetubiUmuFlag6 == "1" ? "○" : ""; } }

        /// <summary>
        /// 構造基準フラグ6
        /// </summary>
        public string KozoKijunFlag6 { get; set; }

        /// <summary>
        /// 構造基準フラグ6(データバインド用)
        /// </summary>
        public bool KozoKijunFlag6Chk { get { return DBUtils.ConvertDaoCheckBoxFormat(KozoKijunFlag6); } }

        /// <summary>
        /// 定期点検適用有無フラグ6
        /// </summary>
        public string TeikiTenkenUmuFlag6 { get; set; }

        /// <summary>
        /// 定期点検適用有無フラグ6(データバインド用)
        /// </summary>
        public bool TeikiTenkenUmuFlag6Chk { get { return DBUtils.ConvertDaoCheckBoxFormat(TeikiTenkenUmuFlag6); } }

        /// <summary>
        /// 設備有無フラグ7
        /// </summary>
        public string SetubiUmuFlag7 { get; set; }

        /// <summary>
        /// 設備有無フラグ7(データバインド用)
        /// </summary>
        public bool SetubiUmuFlag7Chk { get { return DBUtils.ConvertDaoCheckBoxFormat(SetubiUmuFlag7); } }

        /// <summary>
        /// 設備有無フラグ7(データグリッドビュー用)
        /// </summary>
        public string SetubiUmuFlag7V { get { return SetubiUmuFlag7 == "1" ? "○" : ""; } }

        /// <summary>
        /// 構造基準フラグ7
        /// </summary>
        public string KozoKijunFlag7 { get; set; }

        /// <summary>
        /// 構造基準フラグ7(データバインド用)
        /// </summary>
        public bool KozoKijunFlag7Chk { get { return DBUtils.ConvertDaoCheckBoxFormat(KozoKijunFlag7); } }

        /// <summary>
        /// 定期点検適用有無フラグ7
        /// </summary>
        public string TeikiTenkenUmuFlag7 { get; set; }

        /// <summary>
        /// 定期点検適用有無フラグ7(データバインド用)
        /// </summary>
        public bool TeikiTenkenUmuFlag7Chk { get { return DBUtils.ConvertDaoCheckBoxFormat(TeikiTenkenUmuFlag7); } }

        /// <summary>
        /// 備考
        /// </summary>
        public string Biko { get; set; }

        /// <summary>
        /// 登録日付
        /// </summary>
        public string TorokuDate { get; set; }

        /// <summary>
        /// 更新年月日
        /// </summary>
        public string UpdDate { get; set; }

        /// <summary>
        /// 更新回数
        /// </summary>
        public int Rev { get; set; }
    }
}
