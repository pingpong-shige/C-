﻿namespace Suisitu.Entity
{
    /// <summary>
    /// 原単位Entityクラス
    /// </summary>
    public class GentaniEntity
    {
        /// <summary>
        /// 産業分類（中分類）
        /// </summary>
        public string Sangyobc { get; set; }

        /// <summary>
        /// BOD
        /// </summary>
        public string Bod { get; set; }

        /// <summary>
        /// COD
        /// </summary>
        public string Cod { get; set; }

        /// <summary>
        /// T-N
        /// </summary>
        public string Tn { get; set; }

        /// <summary>
        /// T-P
        /// </summary>
        public string Tp { get; set; }

        /// <summary>
        /// 更新年月日
        /// </summary>
        public string UpdDate { get; set; }

        /// <summary>
        /// 更新回数
        /// </summary>
        public int Rev { get; set; }
    }
}
