﻿namespace Suisitu.Entity
{
    /// <summary>
    /// 業種区分Entityクラス
    /// </summary>
    class GyosyuKbnEntity
    {
        /// <summary>
        /// 業種区分コード
        /// </summary>
        public string GyosyuKbn { get; set; }

        /// <summary>
        /// 業種区分名称
        /// </summary>
        public string GyosyuKbnNameN { get; set; }

        /// <summary>
        /// 更新年月日
        /// </summary>
        public string UpdDate { get; set; }

        /// <summary>
        /// 更新回数
        /// </summary>
        public int Rev { get; set; }
    }
}