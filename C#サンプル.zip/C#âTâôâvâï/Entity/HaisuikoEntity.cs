﻿using Suisitu.Components.Common;

namespace Suisitu.Entity
{
    /// <summary>
    /// 排水口Entityクラス
    /// </summary>
    public class HaisuikoEntity
    {
        /// <summary>
        /// 年度
        /// </summary>
        public int Nendo { get; set; }

        /// <summary>
        /// 管理番号
        /// </summary>
        public int KanriNo { get; set; }

        /// <summary>
        /// 排水口番号
        /// </summary>
        public string HaisuikoNo { get; set; }

        /// <summary>
        /// 設置年月日
        /// </summary>
        public string SetiDate { get; set; }

        /// <summary>
        /// 設置年月日(和暦)
        /// </summary>
        public string SetiDateShortW { get { return WarekiDateUtil.GetShortJapaneseText(SetiDate.ToString()); } }

        /// <summary>
        /// 廃止年月日
        /// </summary>
        public string HaisiDate { get; set; }

        /// <summary>
        /// 廃止年月日(和暦)
        /// </summary>
        public string HaisiDateShortW { get { return WarekiDateUtil.GetShortJapaneseText(HaisiDate); } }

        /// <summary>
        /// 届出排水量（通常）
        /// </summary>
        public string TdkdHsAve { get; set; }

        /// <summary>
        /// 届出排水量（最大）
        /// </summary>
        public string TdkdHsMax { get; set; }

        /// <summary>
        /// 備考
        /// </summary>
        public string Biko { get; set; }

        /// <summary>
        /// 登録日付
        /// </summary>
        public string TorokuDate { get; set; }

        /// <summary>
        /// 廃止フラグ
        /// </summary>
        public string HaisiFlag { get; set; }

        /// <summary>
        /// 更新年月日
        /// </summary>
        public string UpdDate { get; set; }

        /// <summary>
        /// 更新回数
        /// </summary>
        public int Rev { get; set; }
    }
}
