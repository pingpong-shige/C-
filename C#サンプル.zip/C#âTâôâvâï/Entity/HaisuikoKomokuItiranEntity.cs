﻿namespace Suisitu.Entity
{
    /// <summary>
    /// 排水口項目一覧Entityクラス
    /// </summary>
    public class HaisuikoKomokuItiranEntity
    {
        /// <summary>
        /// 年度
        /// </summary>
        public int Nendo { get; set; }

        /// <summary>
        /// 管理番号
        /// </summary>
        public int KanriNo { get; set; }

        /// <summary>
        /// 排水口番号
        /// </summary>
        public string HaisuikoNo { get; set; }

        /// <summary>
        /// 項目コード
        /// </summary>
        public string KomokuCode { get; set; }

        /// <summary>
        /// 出力順番
        /// </summary>
        public string WrtSeqNo { get; set; }

        /// <summary>
        /// 項目名称
        /// </summary>
        public string KomokuNameN { get; set; }

        /// <summary>
        /// 単位
        /// </summary>
        public string TANI { get; set; }

        /// <summary>
        /// 届出値（通常）
        /// </summary>
        public string TdkdAve { get; set; }

        /// <summary>
        /// 届出値（最大）
        /// </summary>
        public string TdkdMax { get; set; }

        /// <summary>
        /// 採水項目フラグ
        /// </summary>
        public bool SaisuiKomokuFlag { get; set; }

        /// <summary>
        /// 登録日付
        /// </summary>
        public string TorokuDate { get; set; }

        /// <summary>
        /// 更新年月日
        /// </summary>
        public string UpdDate { get; set; }

        /// <summary>
        /// 更新回数
        /// </summary>
        public int Rev { get; set; }
    }
}
