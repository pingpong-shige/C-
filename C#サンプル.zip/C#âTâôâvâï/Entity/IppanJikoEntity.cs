﻿namespace Suisitu.Entity
{
    /// <summary>
    /// 一般事項Entityクラス
    /// </summary>
    public class IppanJikoEntity
    {
        /// <summary>
        /// 自治体コード
        /// </summary>
        public string JititaiCode { get; set; }

        /// <summary>
        /// 担当課名
        /// </summary>
        public string TantoKaNameN { get; set; }

        /// <summary>
        /// 電話番号
        /// </summary>
        public string TelNo { get; set; }

        /// <summary>
        /// FAX番号
        /// </summary>
        public string FaxNo { get; set; }

        /// <summary>
        /// メールアドレス
        /// </summary>
        public string EMail { get; set; }

        /// <summary>
        /// 更新年月日
        /// </summary>
        public string UpdDate { get; set; }

        /// <summary>
        /// 更新回数
        /// </summary>
        public int Rev { get; set; }
    }
}
