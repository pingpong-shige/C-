﻿namespace Suisitu.Entity
{
    /// <summary>
    /// 事業場一覧Entityクラス
    /// </summary>
    public class JigyojoItiranEntity
    {
        /// <summary>
        /// 年度
        /// </summary>
        public int Nendo { get; set; }

        /// <summary>
        /// 年度(和暦)
        /// </summary>
        public string NendoW { get; set; }

        /// <summary>
        /// 管理番号
        /// </summary>
        public int KanriNo { get; set; }

        /// <summary>
        /// 施設区分
        /// </summary>
        public string SisetuKbn { get; set; }

        /// <summary>
        /// 整理番号
        /// </summary>
        public string SeiriNo { get; set; }

        /// <summary>
        /// 事業所名称(漢字)
        /// </summary>
        public string JigyosyoNameN { get; set; }

        /// <summary>
        /// 所在地(住所)
        /// </summary>
        public string SyozaiJyusyo { get; set; }

        /// <summary>
        /// 事業所名称(カナ)
        /// </summary>
        public string JigyosyoNameK { get; set; }

        /// <summary>
        /// 申請者会社名等
        /// </summary>
        public string SinseiCopName { get; set; }

        /// <summary>
        /// 廃止フラグ
        /// </summary>
        public string HaisiFlag { get; set; }

        /// <summary>
        /// 廃止フラグ(データグリッドビュー用)
        /// </summary>
        public string HaisiFlagV { get { return HaisiFlag == "*" ? "×" : ""; } }

        /// <summary>
        /// 出力順番
        /// </summary>
        public string WrtSeqNo { get; set; }
    }
}
