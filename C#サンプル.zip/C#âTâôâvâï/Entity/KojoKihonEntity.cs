﻿using Suisitu.Common;
using System;

namespace Suisitu.Entity
{
    /// <summary>
    /// 工場事業場基本Entityクラス
    /// </summary>
    public class KojoKihonEntity
    {
        /// <summary>
        /// 年度
        /// </summary>
        public int Nendo { get; set; }

        /// <summary>
        /// 管理番号
        /// </summary>
        public int KanriNo { get; set; }

        /// <summary>
        /// 協定フラグ
        /// </summary>
        public string KyoteiFlag { get; set; }

        /// <summary>
        /// 協定フラグ(データバインド用)
        /// </summary>
        public bool KyoteiFlagChk { get { return DBUtils.ConvertDaoCheckBoxFormat(KyoteiFlag); } }

        /// <summary>
        /// 下水接続区分
        /// </summary>
        public string GesuiKbn { get; set; }

        /// <summary>
        /// 湖沼指定施設フラグ
        /// </summary>
        public string KosyoSiteiFlag { get; set; }

        /// <summary>
        /// 湖沼指定施設フラグ(データバインド用)
        /// </summary>
        public bool KosyoSiteiFlagChk { get { return DBUtils.ConvertDaoCheckBoxFormat(KosyoSiteiFlag); } }

        /// <summary>
        /// 湖沼準用指定施設フラグ
        /// </summary>
        public string KosyojSiteiFlag { get; set; }

        /// <summary>
        /// 環境省統一コード
        /// </summary>
        public string KankyosyoCode { get; set; }

        /// <summary>
        /// 事業所名称(漢字)
        /// </summary>
        public string JigyosyoNameN { get; set; }

        /// <summary>
        /// 事業所名称(カナ)
        /// </summary>
        public string JigyosyoNameK { get; set; }

        /// <summary>
        /// 検索用事業所名称(カナ)
        /// </summary>
        public string FindJigyosyoNameK { get; set; }

        /// <summary>
        /// 公害担当者職名・氏名
        /// </summary>
        public string KTantoNameN { get; set; }

        /// <summary>
        /// 所在地(郵便番号)
        /// </summary>
        public string SyozaiYubinNo { get; set; }

        /// <summary>
        /// 所在地(郵便番号 区番号)(データバインド用)
        /// </summary>
        public string SyozaiYubinNo1 { get { return CommonUtils.GetWardNo(SyozaiYubinNo); } }

        /// <summary>
        /// 所在地(郵便番号 町域番号)(データバインド用)
        /// </summary>
        public string SyozaiYubinNo2 { get { return CommonUtils.GetTownAreaNo(SyozaiYubinNo); } }

        /// <summary>
        /// 所在地(住所)
        /// </summary>
        public string SyozaiJyusyo { get; set; }

        /// <summary>
        /// 連絡先電話番号
        /// </summary>
        public string TelNo { get; set; }

        /// <summary>
        /// 備考1
        /// </summary>
        public string Biko1 { get; set; }

        /// <summary>
        /// 申請者(郵便番号)
        /// </summary>
        public string SinseiYubinNo { get; set; }

        /// <summary>
        /// 申請者(郵便番号 区番号)(データバインド用)
        /// </summary>
        public string SinseiYubinNo1 { get { return CommonUtils.GetWardNo(SinseiYubinNo); } }

        /// <summary>
        /// 申請者(郵便番号 町域番号)(データバインド用)
        /// </summary>
        public string SinseiYubinNo2 { get { return CommonUtils.GetTownAreaNo(SinseiYubinNo); } }

        /// <summary>
        /// 申請者(住所)
        /// </summary>
        public string SinseiJyusyo { get; set; }

        /// <summary>
        /// 申請者会社名等
        /// </summary>
        public string SinseiCopName { get; set; }

        /// <summary>
        /// 申請者役職名・氏名
        /// </summary>
        public string SinseiNameN { get; set; }

        /// <summary>
        /// 申請者電話番号
        /// </summary>
        public string SinseiTelNo { get; set; }

        /// <summary>
        /// 備考2
        /// </summary>
        public string Biko2 { get; set; }

        /// <summary>
        /// 産業分類(中分類)
        /// </summary>
        public string SangyoBC { get; set; }

        /// <summary>
        /// 産業分類(細分類)
        /// </summary>
        public string SangyoBS { get; set; }

        /// <summary>
        /// 総量規制番号
        /// </summary>
        public string SoryoKiseiNo { get; set; }

        /// <summary>
        /// 法区分コード
        /// </summary>
        public string HokbnCode { get; set; }

        /// <summary>
        /// 識別コード
        /// </summary>
        public string SikibetuCode { get; set; }

        /// <summary>
        /// 流域コード
        /// </summary>
        public string RyuikiCode { get; set; }

        /// <summary>
        /// 備考3
        /// </summary>
        public string Biko3 { get; set; }

        /// <summary>
        /// 汚濁負荷量報告送付先(郵便番号)
        /// </summary>
        public string OdakuYubinNo { get; set; }

        /// <summary>
        /// 汚濁負荷量報告送付先(郵便番号 区番号)(データバインド用)
        /// </summary>
        public string OdakuYubinNo1 { get { return CommonUtils.GetWardNo(OdakuYubinNo); } }

        /// <summary>
        /// 汚濁負荷量報告送付先(郵便番号 町域番号)(データバインド用)
        /// </summary>
        public string OdakuYubinNo2 { get { return CommonUtils.GetTownAreaNo(OdakuYubinNo); } }

        /// <summary>
        /// 汚濁負荷量報告送付先(住所)
        /// </summary>
        public string OdakuJyusyo { get; set; }

        /// <summary>
        /// 汚濁負荷量報告送付先（会社名等）
        /// </summary>
        public string OdakuCopName { get; set; }

        /// <summary>
        /// 汚濁負荷量報告送付先（役職名・氏名）
        /// </summary>
        public string OdakuNameN { get; set; }

        /// <summary>
        /// 備考4
        /// </summary>
        public string Biko4 { get; set; }

        /// <summary>
        /// 採水結果報告者名
        /// </summary>
        public string SaisuiNameN { get; set; }

        /// <summary>
        /// 採水FAX送付番号
        /// </summary>
        public string SaisuiFaxNo { get; set; }

        /// <summary>
        /// 備考5
        /// </summary>
        public string Biko5 { get; set; }

        /// <summary>
        /// 雨水専用排水口数
        /// </summary>
        public int UsuiHaisuiKosu { get; set; }

        /// <summary>
        /// 海水含有フラグ
        /// </summary>
        public string KaisuiGanyuFlag { get; set; }

        /// <summary>
        /// 有害有無
        /// </summary>
        public int YugaiUm { get; set; }

        /// <summary>
        /// 有害有無(データバインド用)
        /// </summary>
        public bool YugaiUmChk { get { return DBUtils.ConvertDaoCheckBoxFormat(YugaiUm); } }

        /// <summary>
        /// 要確認フラグ
        /// </summary>
        public string YokakuninFlag { get; set; }

        /// <summary>
        /// 要確認フラグ(データバインド用)
        /// </summary>
        public bool YokakuninFlagChk { get { return DBUtils.ConvertDaoCheckBoxFormat(YokakuninFlag); } }

        /// <summary>
        /// 排水基準適用フラグ
        /// </summary>
        public bool HaisuiKijunTekiyoFlag { get; set; }

        /// <summary>
        /// 暫定基準適用フラグ
        /// </summary>
        public bool ZanteiKijunTekiyoFlag { get; set; }

        /// <summary>
        /// 法3条1項但し書きフラグ
        /// </summary>
        public bool DotaiHo3Jo1KoFlag { get; set; }

        /// <summary>
        /// 有害物質使用特定事業場(5条1,2項) 現在使用フラグ
        /// </summary>
        public bool TsYugaiGenSiyo1Flag { get; set; }

        /// <summary>
        /// 有害物質使用特定事業場(5条1,2項) 過去使用フラグ
        /// </summary>
        public bool TsYugaiKakoSiyo1Flag { get; set; }

        /// <summary>
        /// 有害物質使用特定事業場(5条3項) 現在使用フラグ
        /// </summary>
        public bool TsYugaiGenSiyo2Flag { get; set; }

        /// <summary>
        /// 有害物質使用特定事業場(5条3項) 過去使用フラグ
        /// </summary>
        public bool TsYugaiKakoSiyo2Flag { get; set; }

        /// <summary>
        /// 有害物質貯蔵指定事業場 現在使用フラグ
        /// </summary>
        public bool TsYugaiGenSiyo3Flag { get; set; }

        /// <summary>
        /// 有害物質貯蔵指定事業場 過去使用フラグ
        /// </summary>
        public bool TsYugaiKakoSiyo3Flag { get; set; }

        /// <summary>
        /// 湖沼特定事業場フラグ
        /// </summary>
        public bool KosyoTokuteiJigyojoFlag { get; set; }

        /// <summary>
        /// 湖沼法準用指定施設フラグ
        /// </summary>
        public bool KosyoJunSiteiSisetuFlag { get; set; }

        /// <summary>
        /// 水質汚濁物質総合調査対象事業場フラグ
        /// </summary>
        public bool SogoChosaTaisyoFlag { get; set; }

        /// <summary>
        /// 登録日付
        /// </summary>
        public string TorokuDate { get; set; }

        /// <summary>
        /// 廃止フラグ
        /// </summary>
        public string HaisiFlag { get; set; }

        /// <summary>
        /// 更新年月日
        /// </summary>
        public string UpdDate { get; set; }

        /// <summary>
        /// 更新回数
        /// </summary>
        public int Rev { get; set; }
    }
}

