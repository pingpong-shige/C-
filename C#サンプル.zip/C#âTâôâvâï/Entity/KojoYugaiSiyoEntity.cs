﻿using Suisitu.Common;
using System;

namespace Suisitu.Entity
{
    /// <summary>
    /// 有害物質使用状況Entityクラス
    /// </summary>
    public class KojoYugaiSiyoEntity
    {
        /// <summary>
        /// 年度
        /// </summary>
        public int Nendo { get; set; }

        /// <summary>
        /// 管理番号
        /// </summary>
        public int KanriNo { get; set; }

        /// <summary>
        /// No
        /// </summary>
        public string No { get; set; }

        /// <summary>
        /// 項目コード
        /// </summary>
        public string KomokuCode { get; set; }

        /// <summary>
        /// 出力順番
        /// </summary>
        public int WrtSeqNo { get; set; }

        /// <summary>
        /// 項目名称
        /// </summary>
        public string KomokuNameN { get; set; }

        /// <summary>
        /// 使用状況 現在使用フラグ
        /// </summary>
        public int GSiyoFlag { get; set; }

        /// <summary>
        /// 使用状況 現在使用フラグ(データバインド用)
        /// </summary>
        public bool GSiyoFlagChk { get { return DBUtils.ConvertDaoCheckBoxFormat(GSiyoFlag); } }

        /// <summary>
        /// 使用状況 過去使用フラグ
        /// </summary>
        public int KSiyoFlag { get; set; }

        /// <summary>
        /// 使用状況 過去使用フラグ(データバインド用)
        /// </summary>
        public bool KSiyoFlagChk { get { return DBUtils.ConvertDaoCheckBoxFormat(KSiyoFlag); } }

        /// <summary>
        /// 特定施設以外を含む有害有無
        /// </summary>
        public bool YugaiSiyoFlag { get; set; }

        /// <summary>
        /// 登録日付
        /// </summary>
        public string TorokuDate { get; set; }

        /// <summary>
        /// 更新年月日
        /// </summary>
        public string UpdDate { get; set; }

        /// <summary>
        /// 更新回数
        /// </summary>
        public int Rev { get; set; }
    }
}

