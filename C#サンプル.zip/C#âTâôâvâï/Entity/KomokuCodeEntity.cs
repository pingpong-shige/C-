﻿namespace Suisitu.Entity
{
    /// <summary>
    /// 項目コードEntityクラス
    /// </summary>
    public class KomokuCodeEntity
    {
        /// <summary>
        /// 項目コード
        /// </summary>
        public string KomokuCode { get; set; }

        /// <summary>
        /// 項目フラグ
        /// </summary>
        public string KomokuFlag { get; set; }

        /// <summary>
        /// 整数部桁数
        /// </summary>
        public string SeisuKeta { get; set; }

        /// <summary>
        /// 小数部桁数
        /// </summary>
        public string SyosuKeta { get; set; }

        /// <summary>
        /// 項目名称
        /// </summary>
        public string KomokuNameN { get; set; }

        /// <summary>
        /// 立入フィールド名称
        /// </summary>
        public string TatiiriFieldName { get; set; }

        /// <summary>
        /// 排水口フィールド名称（通常）
        /// </summary>
        public string HaisuikoFNameAve { get; set; }

        /// <summary>
        /// 排水口フィールド名称（最大）
        /// </summary>
        public string HaisuikoFNameMax { get; set; }

        /// <summary>
        /// 排水口整数部桁数
        /// </summary>
        public string HaisuikoSeisuKeta { get; set; }

        /// <summary>
        /// 排水口小数部桁数
        /// </summary>
        public string HaisuikoSyosuKeta { get; set; }

        /// <summary>
        /// 基準値情報
        /// </summary>
        public string KjntiInf { get; set; }

        /// <summary>
        /// 単位
        /// </summary>
        public string Tani { get; set; }

        /// <summary>
        /// 定量下限値
        /// </summary>
        public string Kagenti { get; set; }

        /// <summary>
        /// 出力順番
        /// </summary>
        public string WrtSeqNo { get; set; }

        /// <summary>
        /// 更新年月日
        /// </summary>
        public string UpdDate { get; set; }

        /// <summary>
        /// 更新回数
        /// </summary>
        public int Rev { get; set; }
    }
}
