﻿namespace Suisitu.Entity
{
    /// <summary>
    /// 区分名称Entityクラス
    /// </summary>
    public class KubunNameEntity
    {
        /// <summary>
        /// 識別ＩＤ
        /// </summary>
        public string Id { get; set; }

        /// <summary>
        /// 区分
        /// </summary>
        public string Kubun { get; set; }

        /// <summary>
        /// 区分名
        /// </summary>
        public string KubunNameN { get; set; }

        /// <summary>
        /// 分類区分
        /// </summary>
        public string Parent { get; set; }

        /// <summary>
        /// 出力順番
        /// </summary>
        public int WrtSeqNo { get; set; }

        /// <summary>
        /// 更新年月日
        /// </summary>
        public string UpdDate { get; set; }

        /// <summary>
        /// 更新回数
        /// </summary>
        public int Rev { get; set; }
    }
}
