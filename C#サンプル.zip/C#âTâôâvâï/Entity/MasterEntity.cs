﻿using Suisitu.Components.Entity;
using System;
using System.Collections;

namespace Suisitu.Entity
{
    /// <summary>
    /// コンボボックス用Entityクラス
    /// </summary>
    public class MasterEntity : IEntity
    {
        ///// <summary>
        ///// コード
        ///// </summary>
        public string Value { get; }

        ///// <summary>
        ///// コード名称
        ///// </summary>
        public string Name { get; }

        public IEnumerator GetEnumerator()
        {
            throw new NotImplementedException();
        }
    }
}
