﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Suisitu.Entity
{
    /// <summary>
    /// 汚濁負荷量Entityクラス
    /// </summary>
    public class OdakuFukaryoEntity
    {
        /// <summary>
        /// 年度
        /// </summary>
        public int Nendo { get; set; }

        /// <summary>
        /// 管理番号
        /// </summary>
        public int KanriNo { get; set; }

        /// <summary>
        /// COD許容汚濁負荷量
        /// </summary>
        public double CodKyoyoFukaryo { get; set; }
        
        /// <summary>
        /// COD届出等汚濁負荷量
        /// </summary>
        public double CodTdkdFukaryo { get; set; }

        /// <summary>
        /// T-N許容汚濁負荷量
        /// </summary>
        public double TnKyoyoFukaryo { get; set; }

        /// <summary>
        /// T-N届出等汚濁負荷量
        /// </summary>
        public double TnTdkdFukaryo { get; set; }

        /// <summary>
        /// T-P許容汚濁負荷量
        /// </summary>
        public double TpKyoyoFukaryo { get; set; }

        /// <summary>
        /// T-P届出等汚濁負荷量
        /// </summary>
        public double TpTdkdFukaryo { get; set; }

        /// <summary>
        /// その他許容汚濁負荷量
        /// </summary>
        public double SonotaKyoyoFukaryo { get; set; }

        /// <summary>
        /// その他届出等汚濁負荷量
        /// </summary>
        public double SonotaTdkdFukaryo { get; set; }

        /// <summary>
        /// 届出排水量（通常）
        /// </summary>
        public double SoryoAve { get; set; }

        /// <summary>
        /// 届出排水量（最大）
        /// </summary>
        public double SoryoMax { get; set; }

        /// <summary>
        /// 備考
        /// </summary>
        public string Biko { get; set; }

        /// <summary>
        /// 登録日付
        /// </summary>
        public string TorokuDate { get; set; }

        /// <summary>
        /// 更新年月日
        /// </summary>
        public string UpdDate { get; set; }

        /// <summary>
        /// 更新回数
        /// </summary>
        public int Rev { get; set; }
    }
}
