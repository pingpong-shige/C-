﻿namespace Suisitu.Entity
{
    /// <summary>
    /// 流域コードEntityクラス
    /// </summary>
    public class RyuikiCodeEntity
    {
        /// <summary>
        /// 流域コード
        /// </summary>
        public string RyuikiCode { get; set; }

        /// <summary>
        /// 基準点コード
        /// </summary>
        public string KijuntenCode { get; set; }

        /// <summary>
        /// 流域名称
        /// </summary>
        public string RyuikiNameN { get; set; }

        /// <summary>
        /// ab規制適用フラグ
        /// </summary>
        public string AbKiseiTekiyoFlag { get; set; }

        /// <summary>
        /// 更新年月日
        /// </summary>
        public string UpdDate { get; set; }

        /// <summary>
        /// 更新回数
        /// </summary>
        public int Rev { get; set; }
    }
}
