﻿namespace Suisitu.Entity
{
    /// <summary>
    /// 採水業者コードEntityクラス
    /// </summary>
    public class SGyosyaCodeEntity
    {
        /// <summary>
        /// 業者コード
        /// </summary>
        public string Gyosyacode { get; set; }

        /// <summary>
        /// 業者名称
        /// </summary>
        public string GyosyaNameN { get; set; }

        /// <summary>
        /// 担当者氏名
        /// </summary>
        public string TantoNameN { get; set; }

        /// <summary>
        /// 更新年月日
        /// </summary>
        public string UpdDate { get; set; }

        /// <summary>
        /// 更新回数
        /// </summary>
        public int Rev { get; set; }
    }
}
