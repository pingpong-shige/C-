﻿using Suisitu.Components.Common;

namespace Suisitu.Entity
{
    /// <summary>
    /// 採水計画Entityクラス
    /// </summary>
    public class SaisuiKeikakuEntity
    {
        /// <summary>
        /// 年度
        /// </summary>
        public int Nendo { get; set; }

        /// <summary>
        /// 年度（表示用）
        /// </summary>
        public string NendoW { get { return WarekiDateUtil.GetNendoText(Nendo); } }

        /// <summary>
        /// 採水年月回
        /// </summary>
        public string SaisuiKai { get; set; }

        /// <summary>
        /// 採水年月回　年月
        /// </summary>
        public string SaisuiKaiYm { get { return SaisuiKai.Substring(0, 6); } }

        /// <summary>
        /// 採水年月回　回
        /// </summary>
        public string SaisuiKaiKai { get { return SaisuiKai.Substring(6) + "回目"; } }

        /// <summary>
        /// 採水年月日
        /// </summary>
        public string SaisuiDate { get; set; }

        /// <summary>
        /// 採水年月日(データグリッドビュー用)
        /// </summary>
        public string SaisuiDateV { get { return WarekiDateUtil.GetShortJapaneseText(SaisuiDate); } }

        /// <summary>
        /// 試験成績表作成日時
        /// </summary>
        public string SheetDate { get; set; }

        /// <summary>
        /// 試験成績表作成日時(データグリッドビュー用)
        /// </summary>
        public string SheetDateV { get { return SheetDate == null ? null : WarekiDateUtil.GetShortJapaneseText(SheetDate.Substring(0, 10)) + "　" + SheetDate.Substring(11); } }

        /// <summary>
        /// 状況
        /// </summary>
        public string Status { get; set; }

        /// <summary>
        /// 状況(データグリッドビュー用)
        /// </summary>
        public string StatusKubunNameN { get; set; }

        /// <summary>
        /// 分析業者コード
        /// </summary>
        public string GyosyaCode { get; set; }

        /// <summary>
        /// 採水者名
        /// </summary>
        public string SaisuisyaNameN { get; set; }

        /// <summary>
        /// 立ち入り管理番号
        /// </summary>
        public string TatiiriKanriNo { get; set; }

        /// <summary>
        /// 管理番号
        /// </summary>
        public int KanriNo { get; set; }

        /// <summary>
        /// 排水口番号
        /// </summary>
        public string HaisuikoNo { get; set; }

        /// <summary>
        /// 項目コード
        /// </summary>
        public string KomokuCode { get; set; }
        
        /// <summary>
        /// 登録日
        /// </summary>
        public string TorokuDate { get; set; }

        /// <summary>
        /// 廃止フラグ
        /// </summary>
        public string HaisiFlag { get; set; }

        /// <summary>
        /// 更新日
        /// </summary>
        public string UpdDate { get; set; }

        /// <summary>
        /// 更新回数
        /// </summary>
        public int Rev { get; set; }

        /// <summary>
        /// 事業所名称(漢字)
        /// </summary>
        public string JigyosyoNameN { get; set; }
    }
}
