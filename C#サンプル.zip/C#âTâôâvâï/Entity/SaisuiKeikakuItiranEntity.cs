﻿using Suisitu.Components.Common;

namespace Suisitu.Entity
{
    /// <summary>
    /// 採水計画一覧Entityクラス
    /// </summary>
    public class SaisuiKeikakuItiranEntity
    {
        /// <summary>
        /// 年度
        /// </summary>
        public int Nendo { get; set; }
        
        /// <summary>
        /// 採水年月日FROM
        /// </summary>
        public string SaisuiDateFrom { get; set; }

        /// <summary>
        /// 採水年月日TO
        /// </summary>
        public string SaisuiDateTo { get; set; }

        /// <summary>
        /// 採水年月回
        /// </summary>
        public string SaisuiKai { get; set; }

        /// <summary>
        /// 採水年月回(データグリッドビュー用)
        /// </summary>
        public string SaisuiKaiV { get { return WarekiDateUtil.GetShortJapaneseText(SaisuiKai.Substring(0, 6)) + " " + SaisuiKai.Substring(6) + "回目"; } }

        /// <summary>
        /// 採水年月日
        /// </summary>
        public string SaisuiDate { get; set; }

        /// <summary>
        /// 採水年月日(データグリッドビュー用)
        /// </summary>
        public string SaisuiDateV { get { return WarekiDateUtil.GetShortJapaneseText(SaisuiDate); } }

        /// <summary>
        /// 検体数
        /// </summary>
        public string KentaiSu { get; set; }

        /// <summary>
        /// 試験成績表作成日時
        /// </summary>
        public string SheetDate { get; set; }

        /// <summary>
        /// 試験成績表作成日時(データグリッドビュー用)
        /// </summary>
        public string SheetDateV { get { return SheetDate == null ? null :WarekiDateUtil.GetShortJapaneseText(SheetDate.Substring(0, 10)) + " " + SheetDate.Substring(11); } }

        /// <summary>
        /// 状況
        /// </summary>
        public string Status { get; set; }

        /// <summary>
        /// 状況(データグリッドビュー用)
        /// </summary>
        public string StatusKubunNameN { get; set; }

        /// <summary>
        /// 更新日
        /// </summary>
        public string UpdDate { get; set; }

        /// <summary>
        /// 更新回数
        /// </summary>
        public int Rev { get; set; }
    }
}
