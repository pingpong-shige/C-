﻿namespace Suisitu.Entity
{
    /// <summary>
    /// 産業分類（中分類）Entityクラス
    /// </summary>
    public class SangyoBcEntity
    {
        /// <summary>
        /// 産業分類（中分類）
        /// </summary>
        public string Sangyobc { get; set; }

        /// <summary>
        /// 産業分類（中分類）名称
        /// </summary>
        public string SangyobcNameN { get; set; }

        /// <summary>
        /// 更新年月日
        /// </summary>
        public string UpdDate { get; set; }

        /// <summary>
        /// 更新回数
        /// </summary>
        public int Rev { get; set; }
    }
}
