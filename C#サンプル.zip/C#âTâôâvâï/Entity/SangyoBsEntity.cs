﻿namespace Suisitu.Entity
{
    /// <summary>
    /// 産業分類（細分類）Entityクラス
    /// </summary>
    public class SangyoBsEntity
    {
        /// <summary>
        /// 産業分類（細分類）
        /// </summary>
        public string Sangyobs { get; set; }

        /// <summary>
        /// 産業分類（細分類）名称
        /// </summary>
        public string SangyobsNameN { get; set; }

        /// <summary>
        /// 産業分類（中分類）
        /// </summary>
        public string Parent { get; set; }

        /// <summary>
        /// 更新年月日
        /// </summary>
        public string UpdDate { get; set; }

        /// <summary>
        /// 更新回数
        /// </summary>
        public int Rev { get; set; }
    }
}
