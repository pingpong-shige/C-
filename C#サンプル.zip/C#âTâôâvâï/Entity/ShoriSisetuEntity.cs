﻿using Suisitu.Components.Common;

namespace Suisitu.Entity
{
    /// <summary>
    /// 処理施設Entityクラス
    /// </summary>
    public class SyoriSisetuEntity
    {
        /// <summary>
        /// 年度
        /// </summary>
        public int Nendo { get; set; }

        /// <summary>
        /// 管理番号
        /// </summary>
        public int KanriNo { get; set; }

        /// <summary>
        /// 処理施設番号
        /// </summary>
        public string SsNo { get; set; }

        /// <summary>
        /// 施設名
        /// </summary>
        public string SisetuNameN { get; set; }

        /// <summary>
        /// 最新届出等受理日
        /// </summary>
        public string TdkdjuriDate { get; set; }

        /// <summary>
        /// 最新届出等受理日(和暦)
        /// </summary>
        public string TdkdjuriDateShortW { get { return WarekiDateUtil.GetShortJapaneseText(TdkdjuriDate == null ? "" :TdkdjuriDate.ToString()); } }

        /// <summary>
        /// 備考
        /// </summary>
        public string Biko { get; set; }

        /// <summary>
        /// 登録日付
        /// </summary>
        public string TorokuDate { get; set; }

        /// <summary>
        /// 更新年月日
        /// </summary>
        public string UpdDate { get; set; }

        /// <summary>
        /// 更新回数
        /// </summary>
        public int Rev { get; set; }
    }
}
