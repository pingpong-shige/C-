﻿namespace Suisitu.Entity
{
    /// <summary>
    /// 識別コードEntityクラス
    /// </summary>
    class SikibetuCodeEntity
    {
        /// <summary>
        /// 識別コード
        /// </summary>
        public string SikibetuCode { get; set; }

        /// <summary>
        /// 識別名称
        /// </summary>
        public string SikibetuNameN { get; set; }

        /// <summary>
        /// 更新年月日
        /// </summary>
        public string UpdDate { get; set; }

        /// <summary>
        /// 更新回数
        /// </summary>
        public int Rev { get; set; }
    }
}