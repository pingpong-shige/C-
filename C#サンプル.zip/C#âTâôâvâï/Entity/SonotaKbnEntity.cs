﻿namespace Suisitu.Entity
{
    /// <summary>
    /// その他区分Entityクラス
    /// </summary>
    class SonotaKbnEntity
    {
        /// <summary>
        /// 識別ID
        /// </summary>
        public string Id { get; set; }

        /// <summary>
        /// 区分
        /// </summary>
        public string Kubun { get; set; }

        /// <summary>
        /// 区分名
        /// </summary>
        public string KubunNameN { get; set; }

        /// <summary>
        /// 分類区分
        /// </summary>
        public string Parent { get; set; }

        /// <summary>
        /// 出力順番
        /// </summary>
        public string WrtSeqNo { get; set; }

        /// <summary>
        /// 更新年月日
        /// </summary>
        public string UpdDate { get; set; }

        /// <summary>
        /// 更新回数
        /// </summary>
        public int Rev { get; set; }
    }
}