﻿namespace Suisitu.Entity
{
    /// <summary>
    /// 職員IDEntityクラス
    /// </summary>
    class StaffEntity
    {
        /// <summary>
        /// 職員ID
        /// </summary>
        public string StaffID { get; set; }

        /// <summary>
        /// 職員名
        /// </summary>
        public string StaffNameN { get; set; }

        /// <summary>
        /// パスワード
        /// </summary>
        public string PassWord { get; set; }

        /// <summary>
        /// 管理者フラグ
        /// </summary>
        public string KanrisyaFlag { get; set; }

        /// <summary>
        /// 管理者フラグ（データグリッドビュー用）
        /// </summary>
        public string KanrisyaFlagV { get { return KanrisyaFlag == "1" ? "○" : ""; }}

        /// <summary>
        /// 更新年月日
        /// </summary>
        public string UpdDate { get; set; }

        /// <summary>
        /// 更新回数
        /// </summary>
        public int Rev { get; set; }
    }
}