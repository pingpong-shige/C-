﻿using Suisitu.Common;
using Suisitu.Components.Common;

namespace Suisitu.Entity
{
    /// <summary>
    /// 届出管理Entityクラス
    /// </summary>
    public class TodokedeKanriEntity
    {
        /// <summary>
        /// 年度
        /// </summary>
        public int Nendo { get; set; }

        /// <summary>
        /// 年度(和暦)
        /// </summary>
        public string NendoW { get { return WarekiDateUtil.GetNendoText(Nendo); } }

        /// <summary>
        /// 管理番号
        /// </summary>
        public int KanriNo { get; set; }

        /// <summary>
        /// 整理番号
        /// </summary>
        public string SeiriNo { get; set; }

        /// <summary>
        /// 整理番号(使用)
        /// </summary>
        public string SeiriNo_Siyo { get; set; }

        /// <summary>
        /// 整理番号(貯蔵)
        /// </summary>
        public string SeiriNo_Chozo { get; set; }

        /// <summary>
        /// 事業所名称(漢字)
        /// </summary>
        public string JigyosyoNameN { get; set; }

        /// <summary>
        /// 所在地(住所)
        /// </summary>
        public string SyozaiJyusyo { get; set; }

        /// <summary>
        /// 事業所名称(カナ)
        /// </summary>
        public string JigyosyoNameK { get; set; }

        /// <summary>
        /// 協定フラグ
        /// </summary>
        public string KyoteiFlag { get; set; }

        /// <summary>
        /// 協定フラグ(データバインド用)
        /// </summary>
        public bool KyoteiFlagChk { get { return DBUtils.ConvertDaoCheckBoxFormat(KyoteiFlag); } }

        /// <summary>
        /// 法3条1項但し書き
        /// </summary>
        public bool DotaiHo3Jo1Ko { get; set; }
    }
}
