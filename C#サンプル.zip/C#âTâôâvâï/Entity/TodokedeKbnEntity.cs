﻿namespace Suisitu.Entity
{
    /// <summary>
    /// 届出区分Entityクラス
    /// </summary>
    public class TodokedeKbnEntity
    {
        /// <summary>
        /// 届出区分
        /// </summary>
        public string TodokedeKbn { get; set; }

        /// <summary>
        /// 届出区分名称
        /// </summary>
        public string TodokedeKbnNameN { get; set; }

        /// <summary>
        /// 法区分コード
        /// </summary>
        public string Parent { get; set; }

        /// <summary>
        /// 更新年月日
        /// </summary>
        public string UpdDate { get; set; }

        /// <summary>
        /// 更新回数
        /// </summary>
        public int Rev { get; set; }
    }
}
