﻿using Suisitu.Common;
using Suisitu.Components.Common;

namespace Suisitu.Entity
{
    /// <summary>
    /// 届出履歴Entityクラス
    /// </summary>
    public class TodokedeRirekiEntity
    {
        /// <summary>
        /// 年度
        /// </summary>
        public int Nendo { get; set; }

        /// <summary>
        /// 管理番号
        /// </summary>
        public int KanriNo { get; set; }

        /// <summary>
        /// 届出履歴管理番号
        /// </summary>
        public string TdkdNo { get; set; }

        /// <summary>
        /// 届出年月日
        /// </summary>
        public string TodokedeDate { get; set; }

        /// <summary>
        /// 届出年月日(和暦)
        /// </summary>
        public string TodokedeDateShortW { get { return WarekiDateUtil.GetShortJapaneseText(TodokedeDate.ToString()); } }

        /// <summary>
        /// 決裁年月日
        /// </summary>
        public string KessaiDate { get; set; }

        /// <summary>
        /// 受付番号
        /// </summary>
        public string UketukeNo { get; set; }

        /// <summary>
        /// 法区分コード
        /// </summary>
        public string HokbnCode { get; set; }

        /// <summary>
        /// 届出代表施設種別
        /// </summary>
        public string TdkdSyubetu { get; set; }

        /// <summary>
        /// 届出代表施設種別（細区分）
        /// </summary>
        public string TdkdSyubetuS { get; set; }

        /// <summary>
        /// 届出区分
        /// </summary>
        public string TdkdKbn { get; set; }

        /// <summary>
        /// 備考1（申請・届出内容1）
        /// </summary>
        public string Biko1 { get; set; }

        /// <summary>
        /// 備考2（申請・届出内容2）
        /// </summary>
        public string Biko2 { get; set; }

        /// <summary>
        /// 備考3
        /// </summary>
        public string Biko3 { get; set; }

        /// <summary>
        /// 審査期間
        /// </summary>
        public string SinsaKikan { get; set; }

        /// <summary>
        /// 実施期間短縮申請書の添付有フラグ
        /// </summary>
        public string SinseiTenpuFlag { get; set; }

        /// <summary>
        /// 実施期間短縮申請書の添付有フラグ(データバインド用)
        /// </summary>
        public bool SinseiTenpuFlagChk { get { return DBUtils.ConvertDaoCheckBoxFormat(SinseiTenpuFlag); } }

        /// <summary>
        /// 新規設置フラグ
        /// </summary>
        public string SinkiFlag { get; set; }

        /// <summary>
        /// 新規設置フラグ(データバインド用)
        /// </summary>
        public bool SinkiFlagChk { get { return DBUtils.ConvertDaoCheckBoxFormat(SinkiFlag); } }

        /// <summary>
        /// 特定施設全廃止フラグ
        /// </summary>
        public string TsHaisiFlag { get; set; }

        /// <summary>
        /// 特定施設全廃止フラグ(データバインド用)
        /// </summary>
        public bool TsHaisiFlagChk { get { return DBUtils.ConvertDaoCheckBoxFormat(TsHaisiFlag); } }

        /// <summary>
        /// 有害物質使用特定施設全廃止フラグ
        /// </summary>
        public string YugaiSiyoHaisiFlag { get; set; }

        /// <summary>
        /// 有害物質使用特定施設全廃止フラグ(データバインド用)
        /// </summary>
        public bool YugaiSiyoHaisiFlagChk { get { return DBUtils.ConvertDaoCheckBoxFormat(YugaiSiyoHaisiFlag); } }

        /// <summary>
        /// 有害物質貯蔵指定施設全廃止フラグ㎥以上フラグ
        /// </summary>
        public string YugaiChozoHaisiFlag { get; set; }

        /// <summary>
        /// <summary>
        /// 有害物質貯蔵指定施設全廃止フラグ㎥以上フラグ(データバインド用)
        /// </summary>
        public bool YugaiChozoHaisiFlagChk { get { return DBUtils.ConvertDaoCheckBoxFormat(YugaiChozoHaisiFlag); } }

        /// 日平均排水量50㎥以上フラグ
        /// </summary>
        public string Haisui50IjoFlag { get; set; }

        /// 日平均排水量50㎥以上フラグ(データバインド用)
        /// </summary>
        public bool Haisui50IjoFlagChk { get { return DBUtils.ConvertDaoCheckBoxFormat(Haisui50IjoFlag); } }

        /// <summary>
        /// 児島湖流域フラグ
        /// </summary>
        public string KojimaKoryuikiFlag { get; set; }

        /// <summary>
        /// 児島湖流域フラグ(データバインド用)
        /// </summary>
        public bool KojimaKoryuikiFlagChk { get { return DBUtils.ConvertDaoCheckBoxFormat(KojimaKoryuikiFlag); } }

        /// <summary>
        /// 登録日付
        /// </summary>
        public string TorokuDate { get; set; }

        /// <summary>
        /// 更新年月日
        /// </summary>
        public string UpdDate { get; set; }

        /// <summary>
        /// 更新回数
        /// </summary>
        public int Rev { get; set; }
    }
}
