﻿using Suisitu.Common;
using Suisitu.Components.Common;

namespace Suisitu.Entity
{
    /// <summary>
    /// 特定施設等Entityクラス
    /// </summary>
    public class TokuteiSisetuTouEntity
    {
        /// <summary>
        /// 年度
        /// </summary>
        public int Nendo { get; set; }

        /// <summary>
        /// 管理番号
        /// </summary>
        public int KanriNo { get; set; }

        /// <summary>
        /// 施設番号
        /// </summary>
        public string TsNo { get; set; }

        /// <summary>
        /// 施設区分
        /// </summary>
        public string SisetuKbn { get; set; }

        /// <summary>
        /// 施設名
        /// </summary>
        public string SisetuNameN { get; set; }

        /// <summary>
        /// 設置年月日
        /// </summary>
        public string SetiDate { get; set; }

        /// <summary>
        /// 設置年月日(和暦)
        /// </summary>
        public string SetiDateW { get { return WarekiDateUtil.GetShortJapaneseText(SetiDate.ToString()); } }

        /// <summary>
        /// 廃止年月日
        /// </summary>
        public string HaisiDate { get; set; }

        /// <summary>
        /// 廃止年月日(和暦)
        /// </summary>
        public string HaisiDateW { get { return WarekiDateUtil.GetShortJapaneseText(HaisiDate.ToString()); } }

        /// <summary>
        /// 特定施設種別
        /// </summary>
        public string TsSyubetu { get; set; }

        /// <summary>
        /// 特定施設種別(細区分)
        /// </summary>
        public string TsSyubetuSai { get; set; }

        /// <summary>
        /// 代表フラグ
        /// </summary>
        public string DaihyoFlag { get; set; }

        /// <summary>
        /// 代表フラグ(データバインド用)
        /// </summary>
        public bool DaihyoFlagChk { get { return DBUtils.ConvertDaoCheckBoxFormat(DaihyoFlag); } }

        /// <summary>
        /// 代表フラグ(データグリッドビュー用)
        /// </summary>
        public string DaihyoFlagV { get { return DaihyoFlag == "1" ? "○" : "×"; } }
        /// <summary>
        /// 整理番号
        /// </summary>
        public string SeiriNo { get; set; }

        /// <summary>
        /// 整理番号(前半)(データバインド用)
        /// </summary>
        public string SeiriNo1 { get { return CommonUtils.GetFormerSeiriNo(SeiriNo); } }

        /// <summary>
        /// 整理番号(後半)(データバインド用)
        /// </summary>
        public string SeiriNo2 { get { return CommonUtils.GetLatterSeiriNo(SeiriNo); } }
        /// <summary>
        /// 設置基数
        /// </summary>
        public string Sisetusu { get; set; }

        /// <summary>
        /// 有害物質使用特定施設フラグ
        /// </summary>
        public string YugaiSiyoFlag { get; set; }

        /// <summary>
        /// 有害物質使用特定施設フラグ(データバインド用)
        /// </summary>
        public bool YugaiSiyoFlagChk { get { return DBUtils.ConvertDaoCheckBoxFormat(YugaiSiyoFlag); } }

        /// <summary>
        /// 有害地下浸透事業場フラグ
        /// </summary>
        public string YugaiTikasintouFlag { get; set; }

        /// <summary>
        /// 有害地下浸透事業場フラグ(データバインド用)
        /// </summary>
        public bool YugaiTikasintouFlagChk { get { return DBUtils.ConvertDaoCheckBoxFormat(YugaiTikasintouFlag); } }

        /// <summary>
        /// 備考
        /// </summary>
        public string Biko { get; set; }

        /// <summary>
        /// 登録日付
        /// </summary>
        public string TorokuDate { get; set; }

        /// <summary>
        /// 廃止フラグ
        /// </summary>
        public string HaisiFlag { get; set; }

        /// <summary>
        /// 廃止フラグ(データグリッドビュー用)
        /// </summary>
        public string HaisiFlagV { get { return HaisiFlag == "*" ? "×" : ""; } }

        /// <summary>
        /// 更新年月日
        /// </summary>
        public string UpdDate { get; set; }

        /// <summary>
        /// 更新回数
        /// </summary>
        public int Rev { get; set; }
    }
}
