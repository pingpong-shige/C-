﻿namespace Suisitu.Entity
{
    /// <summary>
    /// 特定施設種別Entityクラス
    /// </summary>
    public class TsSyubetuEntity
    {
        /// <summary>
        /// 特定施設種別
        /// </summary>
        public string TsSyubetu { get; set; }

        /// <summary>
        /// 特定施設種別名称
        /// </summary>
        public string TsSyubetuNameN { get; set; }

        /// <summary>
        /// 特定施設種別番号
        /// </summary>
        public string TsSyubetuNo { get; set; }

        /// <summary>
        /// 更新年月日
        /// </summary>
        public string UpdDate { get; set; }

        /// <summary>
        /// 更新回数
        /// </summary>
        public int Rev { get; set; }
    }
}
