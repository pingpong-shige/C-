﻿namespace Suisitu.Entity
{
    /// <summary>
    /// 特定施設種別(細区分)Entityクラス
    /// </summary>
    public class TsSyubetuSaiEntity
    {
        /// <summary>
        /// 特定施設種別(細区分)
        /// </summary>
        public string TsSyubetuSai { get; set; }

        /// <summary>
        /// 特定施設種別名称(細区分)
        /// </summary>
        public string TsSyubetuSaiNameN { get; set; }

        /// <summary>
        /// 特定施設種別番号(細区分)
        /// </summary>
        public string TsSyubetuSaiNo { get; set; }

        /// <summary>
        /// 特定施設種別
        /// </summary>
        public string Parent { get; set; }

        /// <summary>
        /// 更新年月日
        /// </summary>
        public string UpdDate { get; set; }

        /// <summary>
        /// 更新回数
        /// </summary>
        public int Rev { get; set; }
    }
}
