﻿using Suisitu.Common;

namespace Suisitu.Entity
{
    /// <summary>
    /// 特定施設等有害物質使用状況Entityクラス
    /// </summary>
    public class TsYugaiSiyoEntity
    {
        /// <summary>
        /// 年度
        /// </summary>
        public int Nendo { get; set; }

        /// <summary>
        /// 管理番号
        /// </summary>
        public int KanriNo { get; set; }

        /// <summary>
        /// 施設番号
        /// </summary>
        public string TsNo { get; set; }

        /// <summary>
        /// 項目コード
        /// </summary>
        public string KomokuCode { get; set; }

        /// <summary>
        /// 出力順番
        /// </summary>
        public string WrtSeqNo { get; set; }

        /// <summary>
        /// 項目名称
        /// </summary>
        public string KomokuNameN { get; set; }

        /// <summary>
        /// 単位
        /// </summary>
        public string Tani { get; set; }

        /// <summary>
        /// 現在使用
        /// </summary>
        public string GsiyoFlag { get; set; }
        
        /// <summary>
        /// 過去使用
        /// </summary>
        public string KsiyoFlag { get; set; }
        
        /// <summary>
        /// 備考
        /// </summary>
        public string Biko { get; set; }

        /// <summary>
        /// 登録日付
        /// </summary>
        public string TorokuDate { get; set; }

        /// <summary>
        /// 更新年月日
        /// </summary>
        public string UpdDate { get; set; }

        /// <summary>
        /// 更新回数
        /// </summary>
        public int Rev { get; set; }
    }
}
