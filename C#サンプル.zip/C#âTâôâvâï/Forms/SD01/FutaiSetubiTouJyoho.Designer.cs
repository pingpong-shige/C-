﻿namespace Suisitu.Forms.SD01
{
    partial class FutaiSetubiTouJyoho
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.btnReturn = new System.Windows.Forms.Button();
            this.btnRegist = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.txtFsNo = new System.Windows.Forms.TextBox();
            this.bsFutaiSetubiTou = new System.Windows.Forms.BindingSource(this.components);
            this.lbltxtTsNo = new System.Windows.Forms.Label();
            this.lblFsNo = new System.Windows.Forms.Label();
            this.txtTorimatomeMemo = new System.Windows.Forms.TextBox();
            this.lblBiko = new System.Windows.Forms.Label();
            this.txtBiko = new System.Windows.Forms.TextBox();
            this.lblMemo = new System.Windows.Forms.Label();
            this.chkTorimatome = new System.Windows.Forms.CheckBox();
            this.txtTsNo = new System.Windows.Forms.TextBox();
            this.txtSisetuNameN = new System.Windows.Forms.TextBox();
            this.lblSisetuNameN = new System.Windows.Forms.Label();
            this.lblUmu = new System.Windows.Forms.Label();
            this.tblFutaiSetubi = new System.Windows.Forms.TableLayoutPanel();
            this.lblSetubiMesyo = new System.Windows.Forms.Label();
            this.lblSetubiUmu = new System.Windows.Forms.Label();
            this.lblKijyun = new System.Windows.Forms.Label();
            this.lblTenken = new System.Windows.Forms.Label();
            this.lblYukamen = new System.Windows.Forms.Label();
            this.lblHontai = new System.Windows.Forms.Label();
            this.lblTijyo = new System.Windows.Forms.Label();
            this.lblTika = new System.Windows.Forms.Label();
            this.lblHaisuiko = new System.Windows.Forms.Label();
            this.blYobi1 = new System.Windows.Forms.Label();
            this.lblYobi2 = new System.Windows.Forms.Label();
            this.chkSetubiUmuFlag1 = new System.Windows.Forms.CheckBox();
            this.chkSetubiUmuFlag2 = new System.Windows.Forms.CheckBox();
            this.chkSetubiUmuFlag3 = new System.Windows.Forms.CheckBox();
            this.chkSetubiUmuFlag4 = new System.Windows.Forms.CheckBox();
            this.chkSetubiUmuFlag5 = new System.Windows.Forms.CheckBox();
            this.chkSetubiUmuFlag6 = new System.Windows.Forms.CheckBox();
            this.chkSetubiUmuFlag7 = new System.Windows.Forms.CheckBox();
            this.chkKozoKijunFlag1 = new System.Windows.Forms.CheckBox();
            this.chkKozoKijunFlag2 = new System.Windows.Forms.CheckBox();
            this.chkKozoKijunFlag3 = new System.Windows.Forms.CheckBox();
            this.chkKozoKijunFlag4 = new System.Windows.Forms.CheckBox();
            this.chkKozoKijunFlag5 = new System.Windows.Forms.CheckBox();
            this.chkKozoKijunFlag6 = new System.Windows.Forms.CheckBox();
            this.chkKozoKijunFlag7 = new System.Windows.Forms.CheckBox();
            this.chkTeikiTenkenUmuFlag1 = new System.Windows.Forms.CheckBox();
            this.chkTeikiTenkenUmuFlag2 = new System.Windows.Forms.CheckBox();
            this.chkTeikiTenkenUmuFlag3 = new System.Windows.Forms.CheckBox();
            this.chkTeikiTenkenUmuFlag4 = new System.Windows.Forms.CheckBox();
            this.chkTeikiTenkenUmuFlag5 = new System.Windows.Forms.CheckBox();
            this.chkTeikiTenkenUmuFlag6 = new System.Windows.Forms.CheckBox();
            this.chkTeikiTenkenUmuFlag7 = new System.Windows.Forms.CheckBox();
            this.backColorChangeOnFocusProvider1 = new Suisitu.Component.BackColorChangeOnFocusProvider();
            ((System.ComponentModel.ISupportInitialize)(this.bsFutaiSetubiTou)).BeginInit();
            this.tblFutaiSetubi.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnReturn
            // 
            this.btnReturn.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnReturn.Location = new System.Drawing.Point(510, 15);
            this.btnReturn.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.btnReturn.Name = "btnReturn";
            this.btnReturn.Size = new System.Drawing.Size(100, 30);
            this.btnReturn.TabIndex = 3;
            this.btnReturn.Text = "戻る";
            this.btnReturn.UseVisualStyleBackColor = true;
            this.btnReturn.Click += new System.EventHandler(this.btnReturn_Click);
            // 
            // btnRegist
            // 
            this.btnRegist.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnRegist.Location = new System.Drawing.Point(290, 15);
            this.btnRegist.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.btnRegist.Name = "btnRegist";
            this.btnRegist.Size = new System.Drawing.Size(100, 30);
            this.btnRegist.TabIndex = 1;
            this.btnRegist.Text = "登録";
            this.btnRegist.UseVisualStyleBackColor = true;
            this.btnRegist.Click += new System.EventHandler(this.btnRegist_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnCancel.Location = new System.Drawing.Point(400, 15);
            this.btnCancel.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(100, 30);
            this.btnCancel.TabIndex = 2;
            this.btnCancel.Text = "キャンセル";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnDelete.Location = new System.Drawing.Point(510, 597);
            this.btnDelete.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(100, 30);
            this.btnDelete.TabIndex = 31;
            this.btnDelete.Text = "削除";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // txtFsNo
            // 
            this.txtFsNo.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsFutaiSetubiTou, "FsNo", true, System.Windows.Forms.DataSourceUpdateMode.Never));
            this.txtFsNo.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtFsNo.Location = new System.Drawing.Point(166, 57);
            this.txtFsNo.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.txtFsNo.MaxLength = 3;
            this.txtFsNo.Name = "txtFsNo";
            this.txtFsNo.Size = new System.Drawing.Size(57, 31);
            this.txtFsNo.TabIndex = 4;
            // 
            // bsFutaiSetubiTou
            // 
            this.bsFutaiSetubiTou.DataSource = typeof(Suisitu.Entity.FutaiSetubiTouEntity);
            // 
            // lbltxtTsNo
            // 
            this.lbltxtTsNo.AutoSize = true;
            this.lbltxtTsNo.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lbltxtTsNo.Location = new System.Drawing.Point(15, 126);
            this.lbltxtTsNo.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lbltxtTsNo.Name = "lbltxtTsNo";
            this.lbltxtTsNo.Size = new System.Drawing.Size(74, 24);
            this.lbltxtTsNo.TabIndex = 150;
            this.lbltxtTsNo.Text = "施設番号";
            this.lbltxtTsNo.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblFsNo
            // 
            this.lblFsNo.AutoSize = true;
            this.lblFsNo.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblFsNo.Location = new System.Drawing.Point(15, 60);
            this.lblFsNo.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblFsNo.Name = "lblFsNo";
            this.lblFsNo.Size = new System.Drawing.Size(122, 24);
            this.lblFsNo.TabIndex = 148;
            this.lblFsNo.Text = "付帯設備等番号";
            this.lblFsNo.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtTorimatomeMemo
            // 
            this.txtTorimatomeMemo.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsFutaiSetubiTou, "TorimatomeMemo", true, System.Windows.Forms.DataSourceUpdateMode.Never));
            this.txtTorimatomeMemo.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtTorimatomeMemo.ImeMode = System.Windows.Forms.ImeMode.Hiragana;
            this.txtTorimatomeMemo.Location = new System.Drawing.Point(241, 90);
            this.txtTorimatomeMemo.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.txtTorimatomeMemo.MaxLength = 50;
            this.txtTorimatomeMemo.Name = "txtTorimatomeMemo";
            this.txtTorimatomeMemo.Size = new System.Drawing.Size(370, 31);
            this.txtTorimatomeMemo.TabIndex = 6;
            // 
            // lblBiko
            // 
            this.lblBiko.AutoSize = true;
            this.lblBiko.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblBiko.Location = new System.Drawing.Point(15, 495);
            this.lblBiko.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblBiko.Name = "lblBiko";
            this.lblBiko.Size = new System.Drawing.Size(42, 24);
            this.lblBiko.TabIndex = 154;
            this.lblBiko.Text = "備考";
            this.lblBiko.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtBiko
            // 
            this.txtBiko.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsFutaiSetubiTou, "Biko", true, System.Windows.Forms.DataSourceUpdateMode.Never));
            this.txtBiko.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtBiko.ImeMode = System.Windows.Forms.ImeMode.Hiragana;
            this.txtBiko.Location = new System.Drawing.Point(165, 495);
            this.txtBiko.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.txtBiko.MaxLength = 100;
            this.txtBiko.Multiline = true;
            this.txtBiko.Name = "txtBiko";
            this.txtBiko.Size = new System.Drawing.Size(444, 90);
            this.txtBiko.TabIndex = 30;
            // 
            // lblMemo
            // 
            this.lblMemo.AutoSize = true;
            this.lblMemo.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblMemo.Location = new System.Drawing.Point(189, 93);
            this.lblMemo.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblMemo.Name = "lblMemo";
            this.lblMemo.Size = new System.Drawing.Size(42, 24);
            this.lblMemo.TabIndex = 157;
            this.lblMemo.Text = "メモ";
            this.lblMemo.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // chkTorimatome
            // 
            this.chkTorimatome.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.chkTorimatome.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bsFutaiSetubiTou, "TorimatomeFlagChk", true, System.Windows.Forms.DataSourceUpdateMode.Never));
            this.chkTorimatome.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkTorimatome.Location = new System.Drawing.Point(13, 90);
            this.chkTorimatome.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.chkTorimatome.Name = "chkTorimatome";
            this.chkTorimatome.Size = new System.Drawing.Size(169, 31);
            this.chkTorimatome.TabIndex = 5;
            this.chkTorimatome.Text = "とりまとめ登録";
            this.chkTorimatome.UseVisualStyleBackColor = true;
            this.chkTorimatome.CheckedChanged += new System.EventHandler(this.chkTorimatome_CheckedChanged);
            // 
            // txtTsNo
            // 
            this.txtTsNo.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsFutaiSetubiTou, "TsNo", true, System.Windows.Forms.DataSourceUpdateMode.Never));
            this.txtTsNo.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtTsNo.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.txtTsNo.Location = new System.Drawing.Point(166, 123);
            this.txtTsNo.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.txtTsNo.MaxLength = 3;
            this.txtTsNo.Name = "txtTsNo";
            this.txtTsNo.Size = new System.Drawing.Size(57, 31);
            this.txtTsNo.TabIndex = 7;
            // 
            // txtSisetuNameN
            // 
            this.txtSisetuNameN.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsFutaiSetubiTou, "SisetuNameN", true, System.Windows.Forms.DataSourceUpdateMode.Never));
            this.txtSisetuNameN.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtSisetuNameN.ImeMode = System.Windows.Forms.ImeMode.Hiragana;
            this.txtSisetuNameN.Location = new System.Drawing.Point(166, 156);
            this.txtSisetuNameN.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.txtSisetuNameN.MaxLength = 100;
            this.txtSisetuNameN.Name = "txtSisetuNameN";
            this.txtSisetuNameN.Size = new System.Drawing.Size(445, 31);
            this.txtSisetuNameN.TabIndex = 8;
            // 
            // lblSisetuNameN
            // 
            this.lblSisetuNameN.AutoSize = true;
            this.lblSisetuNameN.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblSisetuNameN.Location = new System.Drawing.Point(15, 159);
            this.lblSisetuNameN.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblSisetuNameN.Name = "lblSisetuNameN";
            this.lblSisetuNameN.Size = new System.Drawing.Size(74, 24);
            this.lblSisetuNameN.TabIndex = 150;
            this.lblSisetuNameN.Text = "施設名称";
            this.lblSisetuNameN.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblUmu
            // 
            this.lblUmu.AutoSize = true;
            this.lblUmu.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblUmu.Location = new System.Drawing.Point(15, 201);
            this.lblUmu.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblUmu.Name = "lblUmu";
            this.lblUmu.Size = new System.Drawing.Size(106, 24);
            this.lblUmu.TabIndex = 150;
            this.lblUmu.Text = "各設備の有無";
            this.lblUmu.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tblFutaiSetubi
            // 
            this.tblFutaiSetubi.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tblFutaiSetubi.ColumnCount = 4;
            this.tblFutaiSetubi.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 140F));
            this.tblFutaiSetubi.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.tblFutaiSetubi.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.tblFutaiSetubi.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.tblFutaiSetubi.Controls.Add(this.lblSetubiMesyo, 0, 0);
            this.tblFutaiSetubi.Controls.Add(this.lblSetubiUmu, 1, 0);
            this.tblFutaiSetubi.Controls.Add(this.lblKijyun, 2, 0);
            this.tblFutaiSetubi.Controls.Add(this.lblTenken, 3, 0);
            this.tblFutaiSetubi.Controls.Add(this.lblYukamen, 0, 1);
            this.tblFutaiSetubi.Controls.Add(this.lblHontai, 0, 2);
            this.tblFutaiSetubi.Controls.Add(this.lblTijyo, 0, 3);
            this.tblFutaiSetubi.Controls.Add(this.lblTika, 0, 4);
            this.tblFutaiSetubi.Controls.Add(this.lblHaisuiko, 0, 5);
            this.tblFutaiSetubi.Controls.Add(this.blYobi1, 0, 6);
            this.tblFutaiSetubi.Controls.Add(this.lblYobi2, 0, 7);
            this.tblFutaiSetubi.Controls.Add(this.chkSetubiUmuFlag1, 1, 1);
            this.tblFutaiSetubi.Controls.Add(this.chkSetubiUmuFlag2, 1, 2);
            this.tblFutaiSetubi.Controls.Add(this.chkSetubiUmuFlag3, 1, 3);
            this.tblFutaiSetubi.Controls.Add(this.chkSetubiUmuFlag4, 1, 4);
            this.tblFutaiSetubi.Controls.Add(this.chkSetubiUmuFlag5, 1, 5);
            this.tblFutaiSetubi.Controls.Add(this.chkSetubiUmuFlag6, 1, 6);
            this.tblFutaiSetubi.Controls.Add(this.chkSetubiUmuFlag7, 1, 7);
            this.tblFutaiSetubi.Controls.Add(this.chkKozoKijunFlag1, 2, 1);
            this.tblFutaiSetubi.Controls.Add(this.chkKozoKijunFlag2, 2, 2);
            this.tblFutaiSetubi.Controls.Add(this.chkKozoKijunFlag3, 2, 3);
            this.tblFutaiSetubi.Controls.Add(this.chkKozoKijunFlag4, 2, 4);
            this.tblFutaiSetubi.Controls.Add(this.chkKozoKijunFlag5, 2, 5);
            this.tblFutaiSetubi.Controls.Add(this.chkKozoKijunFlag6, 2, 6);
            this.tblFutaiSetubi.Controls.Add(this.chkKozoKijunFlag7, 2, 7);
            this.tblFutaiSetubi.Controls.Add(this.chkTeikiTenkenUmuFlag1, 3, 1);
            this.tblFutaiSetubi.Controls.Add(this.chkTeikiTenkenUmuFlag2, 3, 2);
            this.tblFutaiSetubi.Controls.Add(this.chkTeikiTenkenUmuFlag3, 3, 3);
            this.tblFutaiSetubi.Controls.Add(this.chkTeikiTenkenUmuFlag4, 3, 4);
            this.tblFutaiSetubi.Controls.Add(this.chkTeikiTenkenUmuFlag5, 3, 5);
            this.tblFutaiSetubi.Controls.Add(this.chkTeikiTenkenUmuFlag6, 3, 6);
            this.tblFutaiSetubi.Controls.Add(this.chkTeikiTenkenUmuFlag7, 3, 7);
            this.tblFutaiSetubi.Location = new System.Drawing.Point(165, 201);
            this.tblFutaiSetubi.Name = "tblFutaiSetubi";
            this.tblFutaiSetubi.RowCount = 8;
            this.tblFutaiSetubi.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 60F));
            this.tblFutaiSetubi.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tblFutaiSetubi.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tblFutaiSetubi.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tblFutaiSetubi.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tblFutaiSetubi.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tblFutaiSetubi.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tblFutaiSetubi.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tblFutaiSetubi.Size = new System.Drawing.Size(445, 279);
            this.tblFutaiSetubi.TabIndex = 9;
            // 
            // lblSetubiMesyo
            // 
            this.lblSetubiMesyo.AutoSize = true;
            this.lblSetubiMesyo.BackColor = System.Drawing.SystemColors.Control;
            this.lblSetubiMesyo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblSetubiMesyo.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblSetubiMesyo.Location = new System.Drawing.Point(1, 1);
            this.lblSetubiMesyo.Margin = new System.Windows.Forms.Padding(0);
            this.lblSetubiMesyo.Name = "lblSetubiMesyo";
            this.lblSetubiMesyo.Size = new System.Drawing.Size(140, 60);
            this.lblSetubiMesyo.TabIndex = 150;
            this.lblSetubiMesyo.Text = "設備名称";
            this.lblSetubiMesyo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblSetubiUmu
            // 
            this.lblSetubiUmu.AutoSize = true;
            this.lblSetubiUmu.BackColor = System.Drawing.SystemColors.Control;
            this.lblSetubiUmu.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblSetubiUmu.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblSetubiUmu.Location = new System.Drawing.Point(142, 1);
            this.lblSetubiUmu.Margin = new System.Windows.Forms.Padding(0);
            this.lblSetubiUmu.Name = "lblSetubiUmu";
            this.lblSetubiUmu.Size = new System.Drawing.Size(100, 60);
            this.lblSetubiUmu.TabIndex = 150;
            this.lblSetubiUmu.Text = "設備有無";
            this.lblSetubiUmu.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblKijyun
            // 
            this.lblKijyun.AutoSize = true;
            this.lblKijyun.BackColor = System.Drawing.SystemColors.Control;
            this.lblKijyun.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblKijyun.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblKijyun.Location = new System.Drawing.Point(243, 1);
            this.lblKijyun.Margin = new System.Windows.Forms.Padding(0);
            this.lblKijyun.Name = "lblKijyun";
            this.lblKijyun.Size = new System.Drawing.Size(100, 60);
            this.lblKijyun.TabIndex = 150;
            this.lblKijyun.Text = "構造基準";
            this.lblKijyun.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblTenken
            // 
            this.lblTenken.AutoSize = true;
            this.lblTenken.BackColor = System.Drawing.SystemColors.Control;
            this.lblTenken.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblTenken.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblTenken.Location = new System.Drawing.Point(344, 1);
            this.lblTenken.Margin = new System.Windows.Forms.Padding(0);
            this.lblTenken.Name = "lblTenken";
            this.lblTenken.Size = new System.Drawing.Size(100, 60);
            this.lblTenken.TabIndex = 150;
            this.lblTenken.Text = "定期点検\r\n適用有無";
            this.lblTenken.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblYukamen
            // 
            this.lblYukamen.AutoSize = true;
            this.lblYukamen.BackColor = System.Drawing.SystemColors.Control;
            this.lblYukamen.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblYukamen.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblYukamen.Location = new System.Drawing.Point(1, 62);
            this.lblYukamen.Margin = new System.Windows.Forms.Padding(0);
            this.lblYukamen.Name = "lblYukamen";
            this.lblYukamen.Size = new System.Drawing.Size(140, 30);
            this.lblYukamen.TabIndex = 150;
            this.lblYukamen.Text = "床面及び周囲";
            this.lblYukamen.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblHontai
            // 
            this.lblHontai.AutoSize = true;
            this.lblHontai.BackColor = System.Drawing.SystemColors.Control;
            this.lblHontai.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblHontai.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblHontai.Location = new System.Drawing.Point(1, 93);
            this.lblHontai.Margin = new System.Windows.Forms.Padding(0);
            this.lblHontai.Name = "lblHontai";
            this.lblHontai.Size = new System.Drawing.Size(140, 30);
            this.lblHontai.TabIndex = 150;
            this.lblHontai.Text = "施設本体";
            this.lblHontai.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblTijyo
            // 
            this.lblTijyo.AutoSize = true;
            this.lblTijyo.BackColor = System.Drawing.SystemColors.Control;
            this.lblTijyo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblTijyo.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblTijyo.Location = new System.Drawing.Point(1, 124);
            this.lblTijyo.Margin = new System.Windows.Forms.Padding(0);
            this.lblTijyo.Name = "lblTijyo";
            this.lblTijyo.Size = new System.Drawing.Size(140, 30);
            this.lblTijyo.TabIndex = 150;
            this.lblTijyo.Text = "地上配管";
            this.lblTijyo.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblTika
            // 
            this.lblTika.AutoSize = true;
            this.lblTika.BackColor = System.Drawing.SystemColors.Control;
            this.lblTika.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblTika.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblTika.Location = new System.Drawing.Point(1, 155);
            this.lblTika.Margin = new System.Windows.Forms.Padding(0);
            this.lblTika.Name = "lblTika";
            this.lblTika.Size = new System.Drawing.Size(140, 30);
            this.lblTika.TabIndex = 150;
            this.lblTika.Text = "地下配管";
            this.lblTika.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblHaisuiko
            // 
            this.lblHaisuiko.AutoSize = true;
            this.lblHaisuiko.BackColor = System.Drawing.SystemColors.Control;
            this.lblHaisuiko.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblHaisuiko.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblHaisuiko.Location = new System.Drawing.Point(1, 186);
            this.lblHaisuiko.Margin = new System.Windows.Forms.Padding(0);
            this.lblHaisuiko.Name = "lblHaisuiko";
            this.lblHaisuiko.Size = new System.Drawing.Size(140, 30);
            this.lblHaisuiko.TabIndex = 150;
            this.lblHaisuiko.Text = "排水口等";
            this.lblHaisuiko.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // blYobi1
            // 
            this.blYobi1.AutoSize = true;
            this.blYobi1.BackColor = System.Drawing.SystemColors.Control;
            this.blYobi1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.blYobi1.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.blYobi1.Location = new System.Drawing.Point(1, 217);
            this.blYobi1.Margin = new System.Windows.Forms.Padding(0);
            this.blYobi1.Name = "blYobi1";
            this.blYobi1.Size = new System.Drawing.Size(140, 30);
            this.blYobi1.TabIndex = 150;
            this.blYobi1.Text = "予備１";
            this.blYobi1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblYobi2
            // 
            this.lblYobi2.AutoSize = true;
            this.lblYobi2.BackColor = System.Drawing.SystemColors.Control;
            this.lblYobi2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblYobi2.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblYobi2.Location = new System.Drawing.Point(1, 248);
            this.lblYobi2.Margin = new System.Windows.Forms.Padding(0);
            this.lblYobi2.Name = "lblYobi2";
            this.lblYobi2.Size = new System.Drawing.Size(140, 30);
            this.lblYobi2.TabIndex = 150;
            this.lblYobi2.Text = "予備２";
            this.lblYobi2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // chkSetubiUmuFlag1
            // 
            this.chkSetubiUmuFlag1.BackColor = System.Drawing.SystemColors.Window;
            this.chkSetubiUmuFlag1.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.chkSetubiUmuFlag1.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bsFutaiSetubiTou, "SetubiUmuFlag1Chk", true, System.Windows.Forms.DataSourceUpdateMode.Never));
            this.chkSetubiUmuFlag1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.chkSetubiUmuFlag1.Location = new System.Drawing.Point(142, 62);
            this.chkSetubiUmuFlag1.Margin = new System.Windows.Forms.Padding(0);
            this.chkSetubiUmuFlag1.Name = "chkSetubiUmuFlag1";
            this.chkSetubiUmuFlag1.Size = new System.Drawing.Size(100, 30);
            this.chkSetubiUmuFlag1.TabIndex = 9;
            this.chkSetubiUmuFlag1.UseVisualStyleBackColor = false;
            // 
            // chkSetubiUmuFlag2
            // 
            this.chkSetubiUmuFlag2.BackColor = System.Drawing.SystemColors.Window;
            this.chkSetubiUmuFlag2.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.chkSetubiUmuFlag2.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bsFutaiSetubiTou, "SetubiUmuFlag2Chk", true, System.Windows.Forms.DataSourceUpdateMode.Never));
            this.chkSetubiUmuFlag2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.chkSetubiUmuFlag2.Location = new System.Drawing.Point(142, 93);
            this.chkSetubiUmuFlag2.Margin = new System.Windows.Forms.Padding(0);
            this.chkSetubiUmuFlag2.Name = "chkSetubiUmuFlag2";
            this.chkSetubiUmuFlag2.Size = new System.Drawing.Size(100, 30);
            this.chkSetubiUmuFlag2.TabIndex = 12;
            this.chkSetubiUmuFlag2.UseVisualStyleBackColor = false;
            // 
            // chkSetubiUmuFlag3
            // 
            this.chkSetubiUmuFlag3.BackColor = System.Drawing.SystemColors.Window;
            this.chkSetubiUmuFlag3.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.chkSetubiUmuFlag3.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bsFutaiSetubiTou, "SetubiUmuFlag3Chk", true, System.Windows.Forms.DataSourceUpdateMode.Never));
            this.chkSetubiUmuFlag3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.chkSetubiUmuFlag3.Location = new System.Drawing.Point(142, 124);
            this.chkSetubiUmuFlag3.Margin = new System.Windows.Forms.Padding(0);
            this.chkSetubiUmuFlag3.Name = "chkSetubiUmuFlag3";
            this.chkSetubiUmuFlag3.Size = new System.Drawing.Size(100, 30);
            this.chkSetubiUmuFlag3.TabIndex = 15;
            this.chkSetubiUmuFlag3.UseVisualStyleBackColor = false;
            // 
            // chkSetubiUmuFlag4
            // 
            this.chkSetubiUmuFlag4.BackColor = System.Drawing.SystemColors.Window;
            this.chkSetubiUmuFlag4.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.chkSetubiUmuFlag4.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bsFutaiSetubiTou, "SetubiUmuFlag4Chk", true, System.Windows.Forms.DataSourceUpdateMode.Never));
            this.chkSetubiUmuFlag4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.chkSetubiUmuFlag4.Location = new System.Drawing.Point(142, 155);
            this.chkSetubiUmuFlag4.Margin = new System.Windows.Forms.Padding(0);
            this.chkSetubiUmuFlag4.Name = "chkSetubiUmuFlag4";
            this.chkSetubiUmuFlag4.Size = new System.Drawing.Size(100, 30);
            this.chkSetubiUmuFlag4.TabIndex = 18;
            this.chkSetubiUmuFlag4.UseVisualStyleBackColor = false;
            // 
            // chkSetubiUmuFlag5
            // 
            this.chkSetubiUmuFlag5.BackColor = System.Drawing.SystemColors.Window;
            this.chkSetubiUmuFlag5.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.chkSetubiUmuFlag5.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bsFutaiSetubiTou, "SetubiUmuFlag5Chk", true, System.Windows.Forms.DataSourceUpdateMode.Never));
            this.chkSetubiUmuFlag5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.chkSetubiUmuFlag5.Location = new System.Drawing.Point(142, 186);
            this.chkSetubiUmuFlag5.Margin = new System.Windows.Forms.Padding(0);
            this.chkSetubiUmuFlag5.Name = "chkSetubiUmuFlag5";
            this.chkSetubiUmuFlag5.Size = new System.Drawing.Size(100, 30);
            this.chkSetubiUmuFlag5.TabIndex = 21;
            this.chkSetubiUmuFlag5.UseVisualStyleBackColor = false;
            // 
            // chkSetubiUmuFlag6
            // 
            this.chkSetubiUmuFlag6.BackColor = System.Drawing.SystemColors.Window;
            this.chkSetubiUmuFlag6.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.chkSetubiUmuFlag6.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bsFutaiSetubiTou, "SetubiUmuFlag6Chk", true, System.Windows.Forms.DataSourceUpdateMode.Never));
            this.chkSetubiUmuFlag6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.chkSetubiUmuFlag6.Location = new System.Drawing.Point(142, 217);
            this.chkSetubiUmuFlag6.Margin = new System.Windows.Forms.Padding(0);
            this.chkSetubiUmuFlag6.Name = "chkSetubiUmuFlag6";
            this.chkSetubiUmuFlag6.Size = new System.Drawing.Size(100, 30);
            this.chkSetubiUmuFlag6.TabIndex = 24;
            this.chkSetubiUmuFlag6.UseVisualStyleBackColor = false;
            // 
            // chkSetubiUmuFlag7
            // 
            this.chkSetubiUmuFlag7.BackColor = System.Drawing.SystemColors.Window;
            this.chkSetubiUmuFlag7.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.chkSetubiUmuFlag7.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bsFutaiSetubiTou, "SetubiUmuFlag7Chk", true, System.Windows.Forms.DataSourceUpdateMode.Never));
            this.chkSetubiUmuFlag7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.chkSetubiUmuFlag7.Location = new System.Drawing.Point(142, 248);
            this.chkSetubiUmuFlag7.Margin = new System.Windows.Forms.Padding(0);
            this.chkSetubiUmuFlag7.Name = "chkSetubiUmuFlag7";
            this.chkSetubiUmuFlag7.Size = new System.Drawing.Size(100, 30);
            this.chkSetubiUmuFlag7.TabIndex = 27;
            this.chkSetubiUmuFlag7.UseVisualStyleBackColor = false;
            // 
            // chkKozoKijunFlag1
            // 
            this.chkKozoKijunFlag1.BackColor = System.Drawing.SystemColors.Window;
            this.chkKozoKijunFlag1.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.chkKozoKijunFlag1.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bsFutaiSetubiTou, "KozoKijunFlag1Chk", true, System.Windows.Forms.DataSourceUpdateMode.Never));
            this.chkKozoKijunFlag1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.chkKozoKijunFlag1.Location = new System.Drawing.Point(243, 62);
            this.chkKozoKijunFlag1.Margin = new System.Windows.Forms.Padding(0);
            this.chkKozoKijunFlag1.Name = "chkKozoKijunFlag1";
            this.chkKozoKijunFlag1.Size = new System.Drawing.Size(100, 30);
            this.chkKozoKijunFlag1.TabIndex = 10;
            this.chkKozoKijunFlag1.UseVisualStyleBackColor = false;
            // 
            // chkKozoKijunFlag2
            // 
            this.chkKozoKijunFlag2.BackColor = System.Drawing.SystemColors.Window;
            this.chkKozoKijunFlag2.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.chkKozoKijunFlag2.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bsFutaiSetubiTou, "KozoKijunFlag2Chk", true, System.Windows.Forms.DataSourceUpdateMode.Never));
            this.chkKozoKijunFlag2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.chkKozoKijunFlag2.Location = new System.Drawing.Point(243, 93);
            this.chkKozoKijunFlag2.Margin = new System.Windows.Forms.Padding(0);
            this.chkKozoKijunFlag2.Name = "chkKozoKijunFlag2";
            this.chkKozoKijunFlag2.Size = new System.Drawing.Size(100, 30);
            this.chkKozoKijunFlag2.TabIndex = 13;
            this.chkKozoKijunFlag2.UseVisualStyleBackColor = false;
            // 
            // chkKozoKijunFlag3
            // 
            this.chkKozoKijunFlag3.BackColor = System.Drawing.SystemColors.Window;
            this.chkKozoKijunFlag3.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.chkKozoKijunFlag3.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bsFutaiSetubiTou, "KozoKijunFlag3Chk", true, System.Windows.Forms.DataSourceUpdateMode.Never));
            this.chkKozoKijunFlag3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.chkKozoKijunFlag3.Location = new System.Drawing.Point(243, 124);
            this.chkKozoKijunFlag3.Margin = new System.Windows.Forms.Padding(0);
            this.chkKozoKijunFlag3.Name = "chkKozoKijunFlag3";
            this.chkKozoKijunFlag3.Size = new System.Drawing.Size(100, 30);
            this.chkKozoKijunFlag3.TabIndex = 16;
            this.chkKozoKijunFlag3.UseVisualStyleBackColor = false;
            // 
            // chkKozoKijunFlag4
            // 
            this.chkKozoKijunFlag4.BackColor = System.Drawing.SystemColors.Window;
            this.chkKozoKijunFlag4.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.chkKozoKijunFlag4.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bsFutaiSetubiTou, "KozoKijunFlag4Chk", true, System.Windows.Forms.DataSourceUpdateMode.Never));
            this.chkKozoKijunFlag4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.chkKozoKijunFlag4.Location = new System.Drawing.Point(243, 155);
            this.chkKozoKijunFlag4.Margin = new System.Windows.Forms.Padding(0);
            this.chkKozoKijunFlag4.Name = "chkKozoKijunFlag4";
            this.chkKozoKijunFlag4.Size = new System.Drawing.Size(100, 30);
            this.chkKozoKijunFlag4.TabIndex = 19;
            this.chkKozoKijunFlag4.UseVisualStyleBackColor = false;
            // 
            // chkKozoKijunFlag5
            // 
            this.chkKozoKijunFlag5.BackColor = System.Drawing.SystemColors.Window;
            this.chkKozoKijunFlag5.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.chkKozoKijunFlag5.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bsFutaiSetubiTou, "KozoKijunFlag5Chk", true, System.Windows.Forms.DataSourceUpdateMode.Never));
            this.chkKozoKijunFlag5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.chkKozoKijunFlag5.Location = new System.Drawing.Point(243, 186);
            this.chkKozoKijunFlag5.Margin = new System.Windows.Forms.Padding(0);
            this.chkKozoKijunFlag5.Name = "chkKozoKijunFlag5";
            this.chkKozoKijunFlag5.Size = new System.Drawing.Size(100, 30);
            this.chkKozoKijunFlag5.TabIndex = 22;
            this.chkKozoKijunFlag5.UseVisualStyleBackColor = false;
            // 
            // chkKozoKijunFlag6
            // 
            this.chkKozoKijunFlag6.BackColor = System.Drawing.SystemColors.Window;
            this.chkKozoKijunFlag6.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.chkKozoKijunFlag6.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bsFutaiSetubiTou, "KozoKijunFlag6Chk", true, System.Windows.Forms.DataSourceUpdateMode.Never));
            this.chkKozoKijunFlag6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.chkKozoKijunFlag6.Location = new System.Drawing.Point(243, 217);
            this.chkKozoKijunFlag6.Margin = new System.Windows.Forms.Padding(0);
            this.chkKozoKijunFlag6.Name = "chkKozoKijunFlag6";
            this.chkKozoKijunFlag6.Size = new System.Drawing.Size(100, 30);
            this.chkKozoKijunFlag6.TabIndex = 25;
            this.chkKozoKijunFlag6.UseVisualStyleBackColor = false;
            // 
            // chkKozoKijunFlag7
            // 
            this.chkKozoKijunFlag7.BackColor = System.Drawing.SystemColors.Window;
            this.chkKozoKijunFlag7.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.chkKozoKijunFlag7.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bsFutaiSetubiTou, "KozoKijunFlag7Chk", true, System.Windows.Forms.DataSourceUpdateMode.Never));
            this.chkKozoKijunFlag7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.chkKozoKijunFlag7.Location = new System.Drawing.Point(243, 248);
            this.chkKozoKijunFlag7.Margin = new System.Windows.Forms.Padding(0);
            this.chkKozoKijunFlag7.Name = "chkKozoKijunFlag7";
            this.chkKozoKijunFlag7.Size = new System.Drawing.Size(100, 30);
            this.chkKozoKijunFlag7.TabIndex = 28;
            this.chkKozoKijunFlag7.UseVisualStyleBackColor = false;
            // 
            // chkTeikiTenkenUmuFlag1
            // 
            this.chkTeikiTenkenUmuFlag1.BackColor = System.Drawing.SystemColors.Window;
            this.chkTeikiTenkenUmuFlag1.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.chkTeikiTenkenUmuFlag1.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bsFutaiSetubiTou, "TeikiTenkenUmuFlag1Chk", true, System.Windows.Forms.DataSourceUpdateMode.Never));
            this.chkTeikiTenkenUmuFlag1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.chkTeikiTenkenUmuFlag1.Location = new System.Drawing.Point(344, 62);
            this.chkTeikiTenkenUmuFlag1.Margin = new System.Windows.Forms.Padding(0);
            this.chkTeikiTenkenUmuFlag1.Name = "chkTeikiTenkenUmuFlag1";
            this.chkTeikiTenkenUmuFlag1.Size = new System.Drawing.Size(100, 30);
            this.chkTeikiTenkenUmuFlag1.TabIndex = 11;
            this.chkTeikiTenkenUmuFlag1.UseVisualStyleBackColor = false;
            // 
            // chkTeikiTenkenUmuFlag2
            // 
            this.chkTeikiTenkenUmuFlag2.BackColor = System.Drawing.SystemColors.Window;
            this.chkTeikiTenkenUmuFlag2.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.chkTeikiTenkenUmuFlag2.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bsFutaiSetubiTou, "TeikiTenkenUmuFlag2Chk", true, System.Windows.Forms.DataSourceUpdateMode.Never));
            this.chkTeikiTenkenUmuFlag2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.chkTeikiTenkenUmuFlag2.Location = new System.Drawing.Point(344, 93);
            this.chkTeikiTenkenUmuFlag2.Margin = new System.Windows.Forms.Padding(0);
            this.chkTeikiTenkenUmuFlag2.Name = "chkTeikiTenkenUmuFlag2";
            this.chkTeikiTenkenUmuFlag2.Size = new System.Drawing.Size(100, 30);
            this.chkTeikiTenkenUmuFlag2.TabIndex = 14;
            this.chkTeikiTenkenUmuFlag2.UseVisualStyleBackColor = false;
            // 
            // chkTeikiTenkenUmuFlag3
            // 
            this.chkTeikiTenkenUmuFlag3.BackColor = System.Drawing.SystemColors.Window;
            this.chkTeikiTenkenUmuFlag3.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.chkTeikiTenkenUmuFlag3.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bsFutaiSetubiTou, "TeikiTenkenUmuFlag3Chk", true, System.Windows.Forms.DataSourceUpdateMode.Never));
            this.chkTeikiTenkenUmuFlag3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.chkTeikiTenkenUmuFlag3.Location = new System.Drawing.Point(344, 124);
            this.chkTeikiTenkenUmuFlag3.Margin = new System.Windows.Forms.Padding(0);
            this.chkTeikiTenkenUmuFlag3.Name = "chkTeikiTenkenUmuFlag3";
            this.chkTeikiTenkenUmuFlag3.Size = new System.Drawing.Size(100, 30);
            this.chkTeikiTenkenUmuFlag3.TabIndex = 17;
            this.chkTeikiTenkenUmuFlag3.UseVisualStyleBackColor = false;
            // 
            // chkTeikiTenkenUmuFlag4
            // 
            this.chkTeikiTenkenUmuFlag4.BackColor = System.Drawing.SystemColors.Window;
            this.chkTeikiTenkenUmuFlag4.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.chkTeikiTenkenUmuFlag4.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bsFutaiSetubiTou, "TeikiTenkenUmuFlag4Chk", true, System.Windows.Forms.DataSourceUpdateMode.Never));
            this.chkTeikiTenkenUmuFlag4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.chkTeikiTenkenUmuFlag4.Location = new System.Drawing.Point(344, 155);
            this.chkTeikiTenkenUmuFlag4.Margin = new System.Windows.Forms.Padding(0);
            this.chkTeikiTenkenUmuFlag4.Name = "chkTeikiTenkenUmuFlag4";
            this.chkTeikiTenkenUmuFlag4.Size = new System.Drawing.Size(100, 30);
            this.chkTeikiTenkenUmuFlag4.TabIndex = 20;
            this.chkTeikiTenkenUmuFlag4.UseVisualStyleBackColor = false;
            // 
            // chkTeikiTenkenUmuFlag5
            // 
            this.chkTeikiTenkenUmuFlag5.BackColor = System.Drawing.SystemColors.Window;
            this.chkTeikiTenkenUmuFlag5.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.chkTeikiTenkenUmuFlag5.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bsFutaiSetubiTou, "TeikiTenkenUmuFlag5Chk", true, System.Windows.Forms.DataSourceUpdateMode.Never));
            this.chkTeikiTenkenUmuFlag5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.chkTeikiTenkenUmuFlag5.Location = new System.Drawing.Point(344, 186);
            this.chkTeikiTenkenUmuFlag5.Margin = new System.Windows.Forms.Padding(0);
            this.chkTeikiTenkenUmuFlag5.Name = "chkTeikiTenkenUmuFlag5";
            this.chkTeikiTenkenUmuFlag5.Size = new System.Drawing.Size(100, 30);
            this.chkTeikiTenkenUmuFlag5.TabIndex = 23;
            this.chkTeikiTenkenUmuFlag5.UseVisualStyleBackColor = false;
            // 
            // chkTeikiTenkenUmuFlag6
            // 
            this.chkTeikiTenkenUmuFlag6.BackColor = System.Drawing.SystemColors.Window;
            this.chkTeikiTenkenUmuFlag6.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.chkTeikiTenkenUmuFlag6.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bsFutaiSetubiTou, "TeikiTenkenUmuFlag6Chk", true, System.Windows.Forms.DataSourceUpdateMode.Never));
            this.chkTeikiTenkenUmuFlag6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.chkTeikiTenkenUmuFlag6.Location = new System.Drawing.Point(344, 217);
            this.chkTeikiTenkenUmuFlag6.Margin = new System.Windows.Forms.Padding(0);
            this.chkTeikiTenkenUmuFlag6.Name = "chkTeikiTenkenUmuFlag6";
            this.chkTeikiTenkenUmuFlag6.Size = new System.Drawing.Size(100, 30);
            this.chkTeikiTenkenUmuFlag6.TabIndex = 26;
            this.chkTeikiTenkenUmuFlag6.UseVisualStyleBackColor = false;
            // 
            // chkTeikiTenkenUmuFlag7
            // 
            this.chkTeikiTenkenUmuFlag7.BackColor = System.Drawing.SystemColors.Window;
            this.chkTeikiTenkenUmuFlag7.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.chkTeikiTenkenUmuFlag7.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bsFutaiSetubiTou, "TeikiTenkenUmuFlag7Chk", true, System.Windows.Forms.DataSourceUpdateMode.Never));
            this.chkTeikiTenkenUmuFlag7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.chkTeikiTenkenUmuFlag7.Location = new System.Drawing.Point(344, 248);
            this.chkTeikiTenkenUmuFlag7.Margin = new System.Windows.Forms.Padding(0);
            this.chkTeikiTenkenUmuFlag7.Name = "chkTeikiTenkenUmuFlag7";
            this.chkTeikiTenkenUmuFlag7.Size = new System.Drawing.Size(100, 30);
            this.chkTeikiTenkenUmuFlag7.TabIndex = 29;
            this.chkTeikiTenkenUmuFlag7.UseVisualStyleBackColor = false;
            // 
            // backColorChangeOnFocusProvider1
            // 
            this.backColorChangeOnFocusProvider1.Target = this;
            // 
            // FutaiSetubiTouJyoho
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.ClientSize = new System.Drawing.Size(628, 646);
            this.Controls.Add(this.tblFutaiSetubi);
            this.Controls.Add(this.btnReturn);
            this.Controls.Add(this.btnRegist);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.txtFsNo);
            this.Controls.Add(this.lblUmu);
            this.Controls.Add(this.lblSisetuNameN);
            this.Controls.Add(this.lbltxtTsNo);
            this.Controls.Add(this.txtSisetuNameN);
            this.Controls.Add(this.lblFsNo);
            this.Controls.Add(this.txtTsNo);
            this.Controls.Add(this.txtTorimatomeMemo);
            this.Controls.Add(this.lblBiko);
            this.Controls.Add(this.txtBiko);
            this.Controls.Add(this.lblMemo);
            this.Controls.Add(this.chkTorimatome);
            this.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "FutaiSetubiTouJyoho";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "付帯設備等情報";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FutaiSetubiTouJyoho_FormClosing);
            this.Load += new System.EventHandler(this.FutaiSetubiTouJyoho_Load);
            ((System.ComponentModel.ISupportInitialize)(this.bsFutaiSetubiTou)).EndInit();
            this.tblFutaiSetubi.ResumeLayout(false);
            this.tblFutaiSetubi.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnReturn;
        private System.Windows.Forms.Button btnRegist;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.TextBox txtFsNo;
        private System.Windows.Forms.Label lbltxtTsNo;
        private System.Windows.Forms.Label lblFsNo;
        private System.Windows.Forms.TextBox txtTorimatomeMemo;
        private System.Windows.Forms.Label lblBiko;
        private System.Windows.Forms.TextBox txtBiko;
        private System.Windows.Forms.Label lblMemo;
        private System.Windows.Forms.CheckBox chkTorimatome;
        private System.Windows.Forms.TextBox txtTsNo;
        private System.Windows.Forms.TextBox txtSisetuNameN;
        private System.Windows.Forms.Label lblSisetuNameN;
        private System.Windows.Forms.Label lblUmu;
        private System.Windows.Forms.TableLayoutPanel tblFutaiSetubi;
        private System.Windows.Forms.Label lblSetubiMesyo;
        private System.Windows.Forms.Label lblSetubiUmu;
        private System.Windows.Forms.Label lblKijyun;
        private System.Windows.Forms.Label lblTenken;
        private System.Windows.Forms.Label lblYukamen;
        private System.Windows.Forms.Label lblHontai;
        private System.Windows.Forms.Label lblTijyo;
        private System.Windows.Forms.Label lblTika;
        private System.Windows.Forms.Label lblHaisuiko;
        private System.Windows.Forms.Label blYobi1;
        private System.Windows.Forms.Label lblYobi2;
        private System.Windows.Forms.CheckBox chkSetubiUmuFlag1;
        private System.Windows.Forms.CheckBox chkSetubiUmuFlag2;
        private System.Windows.Forms.CheckBox chkSetubiUmuFlag3;
        private System.Windows.Forms.CheckBox chkSetubiUmuFlag4;
        private System.Windows.Forms.CheckBox chkSetubiUmuFlag5;
        private System.Windows.Forms.CheckBox chkSetubiUmuFlag6;
        private System.Windows.Forms.CheckBox chkSetubiUmuFlag7;
        private System.Windows.Forms.CheckBox chkKozoKijunFlag1;
        private System.Windows.Forms.CheckBox chkKozoKijunFlag2;
        private System.Windows.Forms.CheckBox chkKozoKijunFlag3;
        private System.Windows.Forms.CheckBox chkKozoKijunFlag4;
        private System.Windows.Forms.CheckBox chkKozoKijunFlag5;
        private System.Windows.Forms.CheckBox chkKozoKijunFlag6;
        private System.Windows.Forms.CheckBox chkKozoKijunFlag7;
        private System.Windows.Forms.CheckBox chkTeikiTenkenUmuFlag1;
        private System.Windows.Forms.CheckBox chkTeikiTenkenUmuFlag2;
        private System.Windows.Forms.CheckBox chkTeikiTenkenUmuFlag3;
        private System.Windows.Forms.CheckBox chkTeikiTenkenUmuFlag4;
        private System.Windows.Forms.CheckBox chkTeikiTenkenUmuFlag5;
        private System.Windows.Forms.CheckBox chkTeikiTenkenUmuFlag6;
        private System.Windows.Forms.CheckBox chkTeikiTenkenUmuFlag7;
        private Component.BackColorChangeOnFocusProvider backColorChangeOnFocusProvider1;
        private System.Windows.Forms.BindingSource bsFutaiSetubiTou;
    }
}