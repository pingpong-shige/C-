﻿using Suisitu.Common;
using Suisitu.Dao;
using Suisitu.Entity;
using Suisitu.Enum;
using System;
using System.Windows.Forms;

namespace Suisitu.Forms.SD01
{
    #pragma warning disable 168

    using CommonEvents = Suisitu.Common.Events;

    /// <summary>
    /// 付帯設備等情報画面クラス
    /// </summary>
    public partial class FutaiSetubiTouJyoho : Form
    {
        // 付帯設備等情報
        private FutaiSetubiTouEntity selectedItem_;

        // アクションモード
        private EnumActionKbn actionMode_;

        // 新規追加された付帯設備等番号(付帯設備等一覧のフォーカス用)
        public string addedFsNo_ = "";
        #region コンストラクタ

        /// <summary>
        /// コンストラクタ
        /// </summary>
        /// <param name="key">付帯設備等情報</param>
        /// <param name="mode">アクションモード</param>
        public FutaiSetubiTouJyoho(FutaiSetubiTouEntity key, EnumActionKbn mode)
        {
            InitializeComponent();

            selectedItem_ = key;
            actionMode_ = mode;
            
            txtTsNo.KeyPress += new KeyPressEventHandler(CommonEvents.txtHalfNumber_KeyPress);
        }

        #endregion
        
        #region イベント

        /// <summary>
        /// 画面が表示されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void FutaiSetubiTouJyoho_Load(object sender, EventArgs e)
        {
            // データを画面表示する
            InitializeData();

            // 画面ロックマトリックスを定義する
            SetLockMatrix();
        }

        /// <summary>
        /// キャンセルボタンが選択されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnCancel_Click(object sender, EventArgs e)
        {
            InitializeData();
        }

        /// <summary>
        /// 登録ボタンが選択されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnRegist_Click(object sender, EventArgs e)
        {
            // 登録データを作成する
            FutaiSetubiTouEntity entity = CreateRegisterData();

            // バリデーションチェックする
            if (!Validation(entity))
                return;

            // 付帯設備等情報を登録する
            Register(entity);

            // 画面を閉じるときの前処理
            ClosingPreprocessing();

            Close();
        }

        /// <summary>
        /// 戻るボタンが選択されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnReturn_Click(object sender, EventArgs e)
        {
            Return();
        }

        /// <summary>
        /// 削除ボタンが選択されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnDelete_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("表示中のデータを削除します。よろしいですか？", Text,
                MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button2);

            if (result == DialogResult.Yes)
            {
                FutaiSetubiTouDao.Delete((FutaiSetubiTouEntity)bsFutaiSetubiTou.Current);
            }

            // 画面を閉じるときの前処理
            ClosingPreprocessing();

            Close();
        }

        /// <summary>
        /// とりまとめ登録チェックボックスの値が変更されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void chkTorimatome_CheckedChanged(object sender, EventArgs e)
        {
            // とりまとめ登録チェックフラグがONの場合
            if (chkTorimatome.Checked)
            {
                txtTorimatomeMemo.Enabled = true;
                txtTsNo.Enabled = false;
                txtTsNo.Text = "";
            }
            // とりまとめ登録チェックフラグがOFFの場合
            else
            {
                txtTorimatomeMemo.Enabled = false;
                txtTorimatomeMemo.Text = "";
                txtTsNo.Enabled = true;
            }
        }

        /// <summary>
        /// 画面を閉じるときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void FutaiSetubiTouJyoho_FormClosing(object sender, FormClosingEventArgs e)
        {
            // 各種ボタンイベントから画面を閉じる場合
            if (this.Tag == null)
                Return(e);
        }

        #endregion

        #region プライベートメソッド

        /// <summary>
        /// 画面に表示するデータを初期化します。
        /// </summary>
        private void InitializeData()
        {
            Clear();
            
            switch (actionMode_)
            {
                // 選択、複写の場合
                case EnumActionKbn.Select:
                case EnumActionKbn.Copy:

                    FutaiSetubiTouEntity descEntity = new FutaiSetubiTouEntity();
                    BeanUtils.CopyObjectProperties(selectedItem_, descEntity);

                    if (actionMode_ == EnumActionKbn.Copy)
                    {
                        descEntity.FsNo = FutaiSetubiTouDao.GetNewFsNo(descEntity);
                    }

                    bsFutaiSetubiTou.DataSource = descEntity;
                    
                    break;

                // 追加の場合
                case EnumActionKbn.Add:

                    txtFsNo.Text = FutaiSetubiTouDao.GetNewFsNo(selectedItem_);

                    break;
            }
        }

        /// <summary>
        /// ロックマトリックス定義
        /// </summary>
        private void SetLockMatrix()
        {
            txtFsNo.Enabled = false;

            // 追加と複写の場合は削除ボタンを入力不可にする
            if (actionMode_ == EnumActionKbn.Add || actionMode_ == EnumActionKbn.Copy)
            {
                btnDelete.Enabled = false;
            }

            // とりまとめ登録チェックフラグがONの場合
            if (chkTorimatome.Checked == true)
            {
                txtTorimatomeMemo.Enabled = true;
                txtTsNo.Enabled = false;
                //txtTsNo.Text = "";
            }
            // とりまとめ登録チェックフラグがOFFの場合
            else
            {
                txtTorimatomeMemo.Enabled = false;
                //txtTorimatomeMemo.Text = "";
                txtTsNo.Enabled = true;
            }

            // 年度が通年以外の場合
            if (selectedItem_.Nendo != 9999)
            {
                btnRegist.Enabled = false;
                btnCancel.Enabled = false;
                btnDelete.Enabled = false;
                txtFsNo.Enabled = false;
                chkTorimatome.Enabled = false;
                txtTorimatomeMemo.Enabled = false;
                txtTsNo.Enabled = false;
                txtSisetuNameN.Enabled = false;
                chkSetubiUmuFlag1.Enabled = false;
                chkKozoKijunFlag1.Enabled = false;
                chkTeikiTenkenUmuFlag1.Enabled = false;
                chkSetubiUmuFlag2.Enabled = false;
                chkKozoKijunFlag2.Enabled = false;
                chkTeikiTenkenUmuFlag2.Enabled = false;
                chkSetubiUmuFlag3.Enabled = false;
                chkKozoKijunFlag3.Enabled = false;
                chkTeikiTenkenUmuFlag3.Enabled = false;
                chkSetubiUmuFlag4.Enabled = false;
                chkKozoKijunFlag4.Enabled = false;
                chkTeikiTenkenUmuFlag4.Enabled = false;
                chkSetubiUmuFlag5.Enabled = false;
                chkKozoKijunFlag5.Enabled = false;
                chkTeikiTenkenUmuFlag5.Enabled = false;
                chkSetubiUmuFlag6.Enabled = false;
                chkKozoKijunFlag6.Enabled = false;
                chkTeikiTenkenUmuFlag6.Enabled = false;
                chkSetubiUmuFlag7.Enabled = false;
                chkKozoKijunFlag7.Enabled = false;
                chkTeikiTenkenUmuFlag7.Enabled = false;
                txtBiko.Enabled = false;
            }
        }

        /// <summary>
        /// 画面のクリア処理
        /// </summary>
        private void Clear()
        {
            bsFutaiSetubiTou.Clear();
        }

        /// <summary>
        /// 呼び出し元の画面に戻ります。
        /// </summary>
        private void Return(FormClosingEventArgs close = null)
        {
            try
            {
                if (actionMode_ == EnumActionKbn.Add || actionMode_ == EnumActionKbn.Copy
                    || !CompareToControlsAndObject(selectedItem_))
                {
                    DialogResult result = MessageBox.Show("編集中のデータを保存しますか？", Text,
                        MessageBoxButtons.YesNo, MessageBoxIcon.Information, MessageBoxDefaultButton.Button2);

                    if (result == DialogResult.Yes)
                    {
                        // 登録データを作成する
                        FutaiSetubiTouEntity entity = CreateRegisterData();

                        // バリデーションチェックする
                        if (!Validation(entity))
                        {
                            // FormClosingイベントを中止
                            if (close != null)
                                close.Cancel = true;

                            return;
                        }

                        // 付帯設備等情報を登録する
                        Register(entity);
                    }
                }
            }
            catch (Exception ex)
            {
                // なにもしない
            }

            // 画面を閉じるときの前処理
            ClosingPreprocessing();

            Close();
        }

        /// <summary>
        /// 編集前と編集後を比較します。
        /// (データソースとコントロール値を比較します。)
        /// </summary>
        /// <param name="source">編集前のオブジェクト</param>
        /// <returns>True:差異なし / False:差異あり</returns>
        private bool CompareToControlsAndObject(FutaiSetubiTouEntity source)
        {
            // 付帯設備等番号
            if (txtFsNo.Text != source.FsNo)
                return false;

            // とりまとめ登録
            if (DBUtils.ConvertDaoCheckBoxFormat(chkTorimatome.Checked) != source.TorimatomeFlag)
                return false;

            // メモ
            if (txtTorimatomeMemo.Text != source.TorimatomeMemo)
                return false;

            // 施設番号
            if (txtTsNo.Text != source.TsNo)
                return false;

            // 施設名称
            if (txtSisetuNameN.Text != source.SisetuNameN)
                return false;

            // 床面及び周囲 設備有無
            if (DBUtils.ConvertDaoCheckBoxFormat(chkSetubiUmuFlag1.Checked) != source.SetubiUmuFlag1)
                return false;

            // 床面及び周囲 構造基準
            if (DBUtils.ConvertDaoCheckBoxFormat(chkKozoKijunFlag1.Checked) != source.KozoKijunFlag1)
                return false;

            // 床面及び周囲 定期点検適用有無
            if (DBUtils.ConvertDaoCheckBoxFormat(chkTeikiTenkenUmuFlag1.Checked) != source.TeikiTenkenUmuFlag1)
                return false;

            // 施設本体 設備有無
            if (DBUtils.ConvertDaoCheckBoxFormat(chkSetubiUmuFlag2.Checked) != source.SetubiUmuFlag2)
                return false;

            // 施設本体 構造基準
            if (DBUtils.ConvertDaoCheckBoxFormat(chkKozoKijunFlag2.Checked) != source.KozoKijunFlag2)
                return false;

            // 施設本体 定期点検適用有無
            if (DBUtils.ConvertDaoCheckBoxFormat(chkTeikiTenkenUmuFlag2.Checked) != source.TeikiTenkenUmuFlag2)
                return false;

            // 地上配管 設備有無
            if (DBUtils.ConvertDaoCheckBoxFormat(chkSetubiUmuFlag3.Checked) != source.SetubiUmuFlag3)
                return false;

            // 地上配管 構造基準
            if (DBUtils.ConvertDaoCheckBoxFormat(chkKozoKijunFlag3.Checked) != source.KozoKijunFlag3)
                return false;

            // 地上配管 定期点検適用有無
            if (DBUtils.ConvertDaoCheckBoxFormat(chkTeikiTenkenUmuFlag3.Checked) != source.TeikiTenkenUmuFlag3)
                return false;

            // 地下配管 設備有無
            if (DBUtils.ConvertDaoCheckBoxFormat(chkSetubiUmuFlag4.Checked) != source.SetubiUmuFlag4)
                return false;

            // 地下配管 構造基準
            if (DBUtils.ConvertDaoCheckBoxFormat(chkKozoKijunFlag4.Checked) != source.KozoKijunFlag4)
                return false;

            // 地下配管 定期点検適用有無
            if (DBUtils.ConvertDaoCheckBoxFormat(chkTeikiTenkenUmuFlag4.Checked) != source.TeikiTenkenUmuFlag4)
                return false;

            // 排水口等 設備有無
            if (DBUtils.ConvertDaoCheckBoxFormat(chkSetubiUmuFlag5.Checked) != source.SetubiUmuFlag5)
                return false;

            // 排水口等 構造基準
            if (DBUtils.ConvertDaoCheckBoxFormat(chkKozoKijunFlag5.Checked) != source.KozoKijunFlag5)
                return false;

            // 排水口等 定期点検適用有無
            if (DBUtils.ConvertDaoCheckBoxFormat(chkTeikiTenkenUmuFlag5.Checked) != source.TeikiTenkenUmuFlag5)
                return false;

            // 予備１ 設備有無
            if (DBUtils.ConvertDaoCheckBoxFormat(chkSetubiUmuFlag6.Checked) != source.SetubiUmuFlag6)
                return false;

            // 予備１ 構造基準
            if (DBUtils.ConvertDaoCheckBoxFormat(chkKozoKijunFlag6.Checked) != source.KozoKijunFlag6)
                return false;

            // 予備１ 定期点検適用有無
            if (DBUtils.ConvertDaoCheckBoxFormat(chkTeikiTenkenUmuFlag6.Checked) != source.TeikiTenkenUmuFlag6)
                return false;

            // 予備２ 設備有無
            if (DBUtils.ConvertDaoCheckBoxFormat(chkSetubiUmuFlag7.Checked) != source.SetubiUmuFlag7)
                return false;

            // 予備２ 構造基準
            if (DBUtils.ConvertDaoCheckBoxFormat(chkKozoKijunFlag7.Checked) != source.KozoKijunFlag7)
                return false;

            // 予備２ 定期点検適用有無
            if (DBUtils.ConvertDaoCheckBoxFormat(chkTeikiTenkenUmuFlag7.Checked) != source.TeikiTenkenUmuFlag7)
                return false;

            // 備考
            if (txtBiko.Text != source.Biko)
                return false;

            return true;
        }

        /// <summary>
        /// バリデーションをチェックします。
        /// </summary>
        /// <returns>True:チェックOK / False:チェックNG</returns>
        private bool Validation(FutaiSetubiTouEntity entity)
        {
            // チェック項目は特になし
            return true;
        }

        /// <summary>
        /// 登録用付帯設備等情報を作成します。
        /// </summary>
        /// <returns>付帯設備等情報</returns>
        private FutaiSetubiTouEntity CreateRegisterData()
        {
            // 登録データを作成する
            FutaiSetubiTouEntity entity = new FutaiSetubiTouEntity
            {
                Nendo = selectedItem_.Nendo,
                KanriNo = selectedItem_.KanriNo,
                FsNo = txtFsNo.Text,
                TorimatomeFlag = DBUtils.ConvertDaoCheckBoxFormat(chkTorimatome.Checked),
                TorimatomeMemo = txtTorimatomeMemo.Text,
                TsNo = txtTsNo.Text,
                SisetuNameN = txtSisetuNameN.Text,
                SetubiUmuFlag1 = DBUtils.ConvertDaoCheckBoxFormat(chkSetubiUmuFlag1.Checked),
                KozoKijunFlag1 = DBUtils.ConvertDaoCheckBoxFormat(chkKozoKijunFlag1.Checked),
                TeikiTenkenUmuFlag1 = DBUtils.ConvertDaoCheckBoxFormat(chkTeikiTenkenUmuFlag1.Checked),
                SetubiUmuFlag2 = DBUtils.ConvertDaoCheckBoxFormat(chkSetubiUmuFlag2.Checked),
                KozoKijunFlag2 = DBUtils.ConvertDaoCheckBoxFormat(chkKozoKijunFlag2.Checked),
                TeikiTenkenUmuFlag2 = DBUtils.ConvertDaoCheckBoxFormat(chkTeikiTenkenUmuFlag2.Checked),
                SetubiUmuFlag3 = DBUtils.ConvertDaoCheckBoxFormat(chkSetubiUmuFlag3.Checked),
                KozoKijunFlag3 = DBUtils.ConvertDaoCheckBoxFormat(chkKozoKijunFlag3.Checked),
                TeikiTenkenUmuFlag3 = DBUtils.ConvertDaoCheckBoxFormat(chkTeikiTenkenUmuFlag3.Checked),
                SetubiUmuFlag4 = DBUtils.ConvertDaoCheckBoxFormat(chkSetubiUmuFlag4.Checked),
                KozoKijunFlag4 = DBUtils.ConvertDaoCheckBoxFormat(chkKozoKijunFlag4.Checked),
                TeikiTenkenUmuFlag4 = DBUtils.ConvertDaoCheckBoxFormat(chkTeikiTenkenUmuFlag4.Checked),
                SetubiUmuFlag5 = DBUtils.ConvertDaoCheckBoxFormat(chkSetubiUmuFlag5.Checked),
                KozoKijunFlag5 = DBUtils.ConvertDaoCheckBoxFormat(chkKozoKijunFlag5.Checked),
                TeikiTenkenUmuFlag5 = DBUtils.ConvertDaoCheckBoxFormat(chkTeikiTenkenUmuFlag5.Checked),
                SetubiUmuFlag6 = DBUtils.ConvertDaoCheckBoxFormat(chkSetubiUmuFlag6.Checked),
                KozoKijunFlag6 = DBUtils.ConvertDaoCheckBoxFormat(chkKozoKijunFlag6.Checked),
                TeikiTenkenUmuFlag6 = DBUtils.ConvertDaoCheckBoxFormat(chkTeikiTenkenUmuFlag6.Checked),
                SetubiUmuFlag7 = DBUtils.ConvertDaoCheckBoxFormat(chkSetubiUmuFlag7.Checked),
                KozoKijunFlag7 = DBUtils.ConvertDaoCheckBoxFormat(chkKozoKijunFlag7.Checked),
                TeikiTenkenUmuFlag7 = DBUtils.ConvertDaoCheckBoxFormat(chkTeikiTenkenUmuFlag7.Checked),
                Biko = txtBiko.Text,
                TorokuDate = DateTime.Now.ToString(),
                UpdDate = DateTime.Now.ToString(),
                Rev = 1,
            };

            return entity;
        }

        /// <summary>
        /// 付帯設備等情報を登録します。
        /// </summary>
        /// <param name="entity">付帯設備等情報</param>
        private void Register(FutaiSetubiTouEntity entity)
        {
            // 該当データが存在しない場合
            if (FutaiSetubiTouDao.Select(entity) == null)
            {
                // 付帯設備等情報を登録する
                FutaiSetubiTouDao.Insert(entity);

                // 登録された付帯設備等番号を保持する
                addedFsNo_ = entity.FsNo;
            }
            // 該当データが存在する場合
            else
            {
                // 付帯設備等情報を更新する
                FutaiSetubiTouDao.Update(entity);
            }
        }

        /// <summary>
        /// 画面を閉じるときの前処理
        /// </summary>
        private void ClosingPreprocessing()
        {
            this.Tag = true;
        }

        #endregion
    }
}
