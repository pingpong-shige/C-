﻿namespace Suisitu.Forms.SD01
{
    partial class HaisuikijunTouJyoho
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.chkKyote = new System.Windows.Forms.CheckBox();
            this.chkKaisuiGanyu = new System.Windows.Forms.CheckBox();
            this.txtUsuiHaisuikoSu = new System.Windows.Forms.TextBox();
            this.lblUsui = new System.Windows.Forms.Label();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnReturn = new System.Windows.Forms.Button();
            this.btnRegist = new System.Windows.Forms.Button();
            this.btnItiran = new System.Windows.Forms.Button();
            this.dgvHaisuiKijyunTou = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.backColorChangeOnFocusProvider1 = new Suisitu.Component.BackColorChangeOnFocusProvider();
            ((System.ComponentModel.ISupportInitialize)(this.dgvHaisuiKijyunTou)).BeginInit();
            this.SuspendLayout();
            // 
            // chkKyote
            // 
            this.chkKyote.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.chkKyote.Enabled = false;
            this.chkKyote.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.chkKyote.Location = new System.Drawing.Point(15, 111);
            this.chkKyote.Name = "chkKyote";
            this.chkKyote.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.chkKyote.Size = new System.Drawing.Size(159, 22);
            this.chkKyote.TabIndex = 6;
            this.chkKyote.Text = "協定";
            this.chkKyote.UseVisualStyleBackColor = true;
            // 
            // chkKaisuiGanyu
            // 
            this.chkKaisuiGanyu.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.chkKaisuiGanyu.Enabled = false;
            this.chkKaisuiGanyu.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.chkKaisuiGanyu.Location = new System.Drawing.Point(15, 78);
            this.chkKaisuiGanyu.Name = "chkKaisuiGanyu";
            this.chkKaisuiGanyu.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.chkKaisuiGanyu.Size = new System.Drawing.Size(159, 22);
            this.chkKaisuiGanyu.TabIndex = 5;
            this.chkKaisuiGanyu.Text = "海水の含有";
            this.chkKaisuiGanyu.UseVisualStyleBackColor = true;
            // 
            // txtUsuiHaisuikoSu
            // 
            this.txtUsuiHaisuikoSu.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.txtUsuiHaisuikoSu.Location = new System.Drawing.Point(159, 42);
            this.txtUsuiHaisuikoSu.Name = "txtUsuiHaisuikoSu";
            this.txtUsuiHaisuikoSu.Size = new System.Drawing.Size(40, 31);
            this.txtUsuiHaisuikoSu.TabIndex = 4;
            // 
            // lblUsui
            // 
            this.lblUsui.AutoSize = true;
            this.lblUsui.Location = new System.Drawing.Point(15, 45);
            this.lblUsui.Name = "lblUsui";
            this.lblUsui.Size = new System.Drawing.Size(138, 24);
            this.lblUsui.TabIndex = 53;
            this.lblUsui.Text = "雨水専用排水口数";
            // 
            // btnCancel
            // 
            this.btnCancel.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnCancel.Location = new System.Drawing.Point(654, 15);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(100, 30);
            this.btnCancel.TabIndex = 2;
            this.btnCancel.Text = "キャンセル";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnReturn
            // 
            this.btnReturn.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnReturn.Location = new System.Drawing.Point(760, 15);
            this.btnReturn.Name = "btnReturn";
            this.btnReturn.Size = new System.Drawing.Size(100, 30);
            this.btnReturn.TabIndex = 3;
            this.btnReturn.Text = "戻る";
            this.btnReturn.UseVisualStyleBackColor = true;
            this.btnReturn.Click += new System.EventHandler(this.btnReturn_Click);
            // 
            // btnRegist
            // 
            this.btnRegist.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnRegist.Location = new System.Drawing.Point(548, 15);
            this.btnRegist.Name = "btnRegist";
            this.btnRegist.Size = new System.Drawing.Size(100, 30);
            this.btnRegist.TabIndex = 1;
            this.btnRegist.Text = "登録";
            this.btnRegist.UseVisualStyleBackColor = true;
            this.btnRegist.Click += new System.EventHandler(this.btnRegist_Click);
            // 
            // btnItiran
            // 
            this.btnItiran.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnItiran.Location = new System.Drawing.Point(730, 106);
            this.btnItiran.Name = "btnItiran";
            this.btnItiran.Size = new System.Drawing.Size(130, 30);
            this.btnItiran.TabIndex = 7;
            this.btnItiran.Text = "特定施設等一覧";
            this.btnItiran.UseVisualStyleBackColor = true;
            this.btnItiran.Click += new System.EventHandler(this.btnItiran_Click);
            // 
            // dgvHaisuiKijyunTou
            // 
            this.dgvHaisuiKijyunTou.AllowUserToAddRows = false;
            this.dgvHaisuiKijyunTou.AllowUserToDeleteRows = false;
            this.dgvHaisuiKijyunTou.AllowUserToResizeColumns = false;
            this.dgvHaisuiKijyunTou.AllowUserToResizeRows = false;
            this.dgvHaisuiKijyunTou.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvHaisuiKijyunTou.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column3,
            this.Column4,
            this.Column5,
            this.Column6});
            this.dgvHaisuiKijyunTou.Location = new System.Drawing.Point(19, 151);
            this.dgvHaisuiKijyunTou.MultiSelect = false;
            this.dgvHaisuiKijyunTou.Name = "dgvHaisuiKijyunTou";
            this.dgvHaisuiKijyunTou.RowHeadersVisible = false;
            this.dgvHaisuiKijyunTou.RowTemplate.Height = 21;
            this.dgvHaisuiKijyunTou.Size = new System.Drawing.Size(840, 520);
            this.dgvHaisuiKijyunTou.TabIndex = 57;
            // 
            // Column1
            // 
            this.Column1.HeaderText = "項目";
            this.Column1.Name = "Column1";
            this.Column1.Width = 150;
            // 
            // Column2
            // 
            this.Column2.HeaderText = "単位";
            this.Column2.Name = "Column2";
            this.Column2.Width = 70;
            // 
            // Column3
            // 
            this.Column3.HeaderText = "排水基準（通常）";
            this.Column3.Name = "Column3";
            // 
            // Column4
            // 
            this.Column4.HeaderText = "排水基準（最大）";
            this.Column4.Name = "Column4";
            // 
            // Column5
            // 
            this.Column5.HeaderText = "暫定　　排水基準";
            this.Column5.Name = "Column5";
            // 
            // Column6
            // 
            this.Column6.HeaderText = "備考";
            this.Column6.Name = "Column6";
            this.Column6.Width = 300;
            // 
            // backColorChangeOnFocusProvider1
            // 
            this.backColorChangeOnFocusProvider1.Target = this;
            // 
            // HaisuikijunTouJyoho
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.ClientSize = new System.Drawing.Size(877, 692);
            this.Controls.Add(this.dgvHaisuiKijyunTou);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnItiran);
            this.Controls.Add(this.btnReturn);
            this.Controls.Add(this.btnRegist);
            this.Controls.Add(this.chkKyote);
            this.Controls.Add(this.chkKaisuiGanyu);
            this.Controls.Add(this.txtUsuiHaisuikoSu);
            this.Controls.Add(this.lblUsui);
            this.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "HaisuikijunTouJyoho";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "排水基準等情報";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.HaisuikijunTouJyoho_FormClosing);
            this.Load += new System.EventHandler(this.HaisuikijunTouJyoho_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvHaisuiKijyunTou)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.CheckBox chkKyote;
        public System.Windows.Forms.CheckBox chkKaisuiGanyu;
        private System.Windows.Forms.TextBox txtUsuiHaisuikoSu;
        private System.Windows.Forms.Label lblUsui;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnReturn;
        private System.Windows.Forms.Button btnRegist;
        private System.Windows.Forms.Button btnItiran;
        private System.Windows.Forms.DataGridView dgvHaisuiKijyunTou;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column6;
        private Component.BackColorChangeOnFocusProvider backColorChangeOnFocusProvider1;
    }
}