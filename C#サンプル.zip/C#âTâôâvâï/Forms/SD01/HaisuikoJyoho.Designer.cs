﻿namespace Suisitu.Forms.SD01
{
    partial class HaisuikoJyoho
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnRegist = new System.Windows.Forms.Button();
            this.btnReturn = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.txtBiko = new System.Windows.Forms.TextBox();
            this.txtHaisuikoNo = new System.Windows.Forms.TextBox();
            this.lblBiko = new System.Windows.Forms.Label();
            this.lblHaisiDate = new System.Windows.Forms.Label();
            this.lblSetiDate = new System.Windows.Forms.Label();
            this.lblHaisuikoNo = new System.Windows.Forms.Label();
            this.lblJigyojoLine = new System.Windows.Forms.Label();
            this.lblJigyojo = new System.Windows.Forms.Label();
            this.lblTdkdhsAve = new System.Windows.Forms.Label();
            this.lblTdkdhsMax = new System.Windows.Forms.Label();
            this.lblTdkdhsAveUnit = new System.Windows.Forms.Label();
            this.lblTdkdhsMaxUnit = new System.Windows.Forms.Label();
            this.txtTdkdhsAve = new System.Windows.Forms.TextBox();
            this.txtTdkdhsMax = new System.Windows.Forms.TextBox();
            this.dgvHaisuikoKomokuItiran = new System.Windows.Forms.DataGridView();
            this.bsHaisuikoKomokuItiran = new System.Windows.Forms.BindingSource(this.components);
            this.wdSetiDate = new Suisitu.Components.Controls.WarekiDate();
            this.wdHaisiDate = new Suisitu.Components.Controls.WarekiDate();
            this.bsHaisuiko = new System.Windows.Forms.BindingSource(this.components);
            this.backColorChangeOnFocusProvider1 = new Suisitu.Component.BackColorChangeOnFocusProvider();
            this.KomokuNameN = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TANI = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TdkdAve = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TdkdMax = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.saisuiKomokuFlagDataGridViewCheckBoxColumn = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.KomokuCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dgvHaisuikoKomokuItiran)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsHaisuikoKomokuItiran)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsHaisuiko)).BeginInit();
            this.SuspendLayout();
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(583, 646);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(100, 30);
            this.btnDelete.TabIndex = 10;
            this.btnDelete.Text = "削除";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnRegist
            // 
            this.btnRegist.Location = new System.Drawing.Point(370, 15);
            this.btnRegist.Name = "btnRegist";
            this.btnRegist.Size = new System.Drawing.Size(100, 30);
            this.btnRegist.TabIndex = 1;
            this.btnRegist.Text = "登録";
            this.btnRegist.UseVisualStyleBackColor = true;
            this.btnRegist.Click += new System.EventHandler(this.btnRegist_Click);
            // 
            // btnReturn
            // 
            this.btnReturn.Location = new System.Drawing.Point(582, 15);
            this.btnReturn.Name = "btnReturn";
            this.btnReturn.Size = new System.Drawing.Size(100, 30);
            this.btnReturn.TabIndex = 3;
            this.btnReturn.Text = "戻る";
            this.btnReturn.UseVisualStyleBackColor = true;
            this.btnReturn.Click += new System.EventHandler(this.btnReturn_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(476, 15);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(100, 30);
            this.btnCancel.TabIndex = 2;
            this.btnCancel.Text = "キャンセル";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // txtBiko
            // 
            this.txtBiko.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsHaisuiko, "Biko", true, System.Windows.Forms.DataSourceUpdateMode.Never));
            this.txtBiko.Location = new System.Drawing.Point(162, 145);
            this.txtBiko.Multiline = true;
            this.txtBiko.Name = "txtBiko";
            this.txtBiko.ScrollBars = System.Windows.Forms.ScrollBars.Horizontal;
            this.txtBiko.Size = new System.Drawing.Size(520, 84);
            this.txtBiko.TabIndex = 7;
            // 
            // txtHaisuikoNo
            // 
            this.txtHaisuikoNo.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsHaisuiko, "HaisuikoNo", true, System.Windows.Forms.DataSourceUpdateMode.Never));
            this.txtHaisuikoNo.Location = new System.Drawing.Point(162, 46);
            this.txtHaisuikoNo.Name = "txtHaisuikoNo";
            this.txtHaisuikoNo.Size = new System.Drawing.Size(53, 31);
            this.txtHaisuikoNo.TabIndex = 4;
            // 
            // lblBiko
            // 
            this.lblBiko.AutoSize = true;
            this.lblBiko.Location = new System.Drawing.Point(15, 148);
            this.lblBiko.Name = "lblBiko";
            this.lblBiko.Size = new System.Drawing.Size(42, 24);
            this.lblBiko.TabIndex = 4;
            this.lblBiko.Text = "備考";
            // 
            // lblHaisiDate
            // 
            this.lblHaisiDate.AutoSize = true;
            this.lblHaisiDate.Location = new System.Drawing.Point(15, 115);
            this.lblHaisiDate.Name = "lblHaisiDate";
            this.lblHaisiDate.Size = new System.Drawing.Size(90, 24);
            this.lblHaisiDate.TabIndex = 5;
            this.lblHaisiDate.Text = "廃止年月日";
            // 
            // lblSetiDate
            // 
            this.lblSetiDate.AutoSize = true;
            this.lblSetiDate.Location = new System.Drawing.Point(15, 82);
            this.lblSetiDate.Name = "lblSetiDate";
            this.lblSetiDate.Size = new System.Drawing.Size(90, 24);
            this.lblSetiDate.TabIndex = 6;
            this.lblSetiDate.Text = "設置年月日";
            // 
            // lblHaisuikoNo
            // 
            this.lblHaisuikoNo.AutoSize = true;
            this.lblHaisuikoNo.Location = new System.Drawing.Point(15, 49);
            this.lblHaisuikoNo.Name = "lblHaisuikoNo";
            this.lblHaisuikoNo.Size = new System.Drawing.Size(90, 24);
            this.lblHaisuikoNo.TabIndex = 7;
            this.lblHaisuikoNo.Text = "排水口番号";
            // 
            // lblJigyojoLine
            // 
            this.lblJigyojoLine.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblJigyojoLine.Font = new System.Drawing.Font("ＭＳ ゴシック", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblJigyojoLine.Location = new System.Drawing.Point(95, 248);
            this.lblJigyojoLine.Name = "lblJigyojoLine";
            this.lblJigyojoLine.Size = new System.Drawing.Size(590, 1);
            this.lblJigyojoLine.TabIndex = 18;
            // 
            // lblJigyojo
            // 
            this.lblJigyojo.AutoSize = true;
            this.lblJigyojo.Font = new System.Drawing.Font("メイリオ", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblJigyojo.Location = new System.Drawing.Point(15, 239);
            this.lblJigyojo.Name = "lblJigyojo";
            this.lblJigyojo.Size = new System.Drawing.Size(74, 20);
            this.lblJigyojo.TabIndex = 19;
            this.lblJigyojo.Text = "届出値情報";
            // 
            // lblTdkdhsAve
            // 
            this.lblTdkdhsAve.AutoSize = true;
            this.lblTdkdhsAve.Location = new System.Drawing.Point(27, 267);
            this.lblTdkdhsAve.Name = "lblTdkdhsAve";
            this.lblTdkdhsAve.Size = new System.Drawing.Size(122, 24);
            this.lblTdkdhsAve.TabIndex = 4;
            this.lblTdkdhsAve.Text = "排水量（通常）";
            // 
            // lblTdkdhsMax
            // 
            this.lblTdkdhsMax.AutoSize = true;
            this.lblTdkdhsMax.Location = new System.Drawing.Point(27, 300);
            this.lblTdkdhsMax.Name = "lblTdkdhsMax";
            this.lblTdkdhsMax.Size = new System.Drawing.Size(122, 24);
            this.lblTdkdhsMax.TabIndex = 4;
            this.lblTdkdhsMax.Text = "　　　（最大）";
            // 
            // lblTdkdhsAveUnit
            // 
            this.lblTdkdhsAveUnit.AutoSize = true;
            this.lblTdkdhsAveUnit.Location = new System.Drawing.Point(285, 267);
            this.lblTdkdhsAveUnit.Name = "lblTdkdhsAveUnit";
            this.lblTdkdhsAveUnit.Size = new System.Drawing.Size(55, 24);
            this.lblTdkdhsAveUnit.TabIndex = 4;
            this.lblTdkdhsAveUnit.Text = "m³/日";
            // 
            // lblTdkdhsMaxUnit
            // 
            this.lblTdkdhsMaxUnit.AutoSize = true;
            this.lblTdkdhsMaxUnit.Location = new System.Drawing.Point(285, 300);
            this.lblTdkdhsMaxUnit.Name = "lblTdkdhsMaxUnit";
            this.lblTdkdhsMaxUnit.Size = new System.Drawing.Size(55, 24);
            this.lblTdkdhsMaxUnit.TabIndex = 4;
            this.lblTdkdhsMaxUnit.Text = "m³/日";
            // 
            // txtTdkdhsAve
            // 
            this.txtTdkdhsAve.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsHaisuiko, "TdkdHsAve", true, System.Windows.Forms.DataSourceUpdateMode.Never));
            this.txtTdkdhsAve.Location = new System.Drawing.Point(162, 264);
            this.txtTdkdhsAve.MaxLength = 5;
            this.txtTdkdhsAve.Name = "txtTdkdhsAve";
            this.txtTdkdhsAve.Size = new System.Drawing.Size(120, 31);
            this.txtTdkdhsAve.TabIndex = 8;
            this.txtTdkdhsAve.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtTdkdhsMax
            // 
            this.txtTdkdhsMax.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsHaisuiko, "TdkdHsMax", true, System.Windows.Forms.DataSourceUpdateMode.Never));
            this.txtTdkdhsMax.Location = new System.Drawing.Point(162, 297);
            this.txtTdkdhsMax.MaxLength = 5;
            this.txtTdkdhsMax.Name = "txtTdkdhsMax";
            this.txtTdkdhsMax.Size = new System.Drawing.Size(120, 31);
            this.txtTdkdhsMax.TabIndex = 9;
            this.txtTdkdhsMax.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // dgvHaisuikoKomokuItiran
            // 
            this.dgvHaisuikoKomokuItiran.AllowUserToAddRows = false;
            this.dgvHaisuikoKomokuItiran.AllowUserToDeleteRows = false;
            this.dgvHaisuikoKomokuItiran.AllowUserToResizeColumns = false;
            this.dgvHaisuikoKomokuItiran.AllowUserToResizeRows = false;
            this.dgvHaisuikoKomokuItiran.AutoGenerateColumns = false;
            this.dgvHaisuikoKomokuItiran.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvHaisuikoKomokuItiran.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.KomokuNameN,
            this.TANI,
            this.TdkdAve,
            this.TdkdMax,
            this.saisuiKomokuFlagDataGridViewCheckBoxColumn,
            this.KomokuCode});
            this.dgvHaisuikoKomokuItiran.DataSource = this.bsHaisuikoKomokuItiran;
            this.dgvHaisuikoKomokuItiran.Location = new System.Drawing.Point(19, 342);
            this.dgvHaisuikoKomokuItiran.MultiSelect = false;
            this.dgvHaisuikoKomokuItiran.Name = "dgvHaisuikoKomokuItiran";
            this.dgvHaisuikoKomokuItiran.RowHeadersVisible = false;
            this.dgvHaisuikoKomokuItiran.RowTemplate.Height = 21;
            this.dgvHaisuikoKomokuItiran.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvHaisuikoKomokuItiran.Size = new System.Drawing.Size(663, 289);
            this.dgvHaisuikoKomokuItiran.TabIndex = 20;
            // 
            // bsHaisuikoKomokuItiran
            // 
            this.bsHaisuikoKomokuItiran.DataSource = typeof(Suisitu.Entity.HaisuikoKomokuItiranEntity);
            // 
            // wdSetiDate
            // 
            this.wdSetiDate.Location = new System.Drawing.Point(162, 79);
            this.wdSetiDate.Name = "wdSetiDate";
            this.wdSetiDate.Size = new System.Drawing.Size(102, 31);
            this.wdSetiDate.TabIndex = 5;
            // 
            // wdHaisiDate
            // 
            this.wdHaisiDate.Location = new System.Drawing.Point(162, 112);
            this.wdHaisiDate.Name = "wdHaisiDate";
            this.wdHaisiDate.Size = new System.Drawing.Size(102, 31);
            this.wdHaisiDate.TabIndex = 6;
            // 
            // bsHaisuiko
            // 
            this.bsHaisuiko.DataSource = typeof(Suisitu.Entity.HaisuikoEntity);
            // 
            // backColorChangeOnFocusProvider1
            // 
            this.backColorChangeOnFocusProvider1.Target = this;
            // 
            // KomokuNameN
            // 
            this.KomokuNameN.DataPropertyName = "KomokuNameN";
            this.KomokuNameN.HeaderText = "項目";
            this.KomokuNameN.Name = "KomokuNameN";
            this.KomokuNameN.ReadOnly = true;
            this.KomokuNameN.Width = 258;
            // 
            // TANI
            // 
            this.TANI.DataPropertyName = "TANI";
            this.TANI.HeaderText = "単位";
            this.TANI.Name = "TANI";
            this.TANI.ReadOnly = true;
            this.TANI.Width = 80;
            // 
            // TdkdAve
            // 
            this.TdkdAve.DataPropertyName = "TdkdAve";
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.TdkdAve.DefaultCellStyle = dataGridViewCellStyle1;
            this.TdkdAve.HeaderText = "届出値     （通常）";
            this.TdkdAve.Name = "TdkdAve";
            this.TdkdAve.Width = 120;
            // 
            // TdkdMax
            // 
            this.TdkdMax.DataPropertyName = "TdkdMax";
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.TdkdMax.DefaultCellStyle = dataGridViewCellStyle2;
            this.TdkdMax.HeaderText = "届出値     （最大）";
            this.TdkdMax.Name = "TdkdMax";
            this.TdkdMax.Width = 120;
            // 
            // saisuiKomokuFlagDataGridViewCheckBoxColumn
            // 
            this.saisuiKomokuFlagDataGridViewCheckBoxColumn.DataPropertyName = "SaisuiKomokuFlag";
            this.saisuiKomokuFlagDataGridViewCheckBoxColumn.HeaderText = "採水 項目";
            this.saisuiKomokuFlagDataGridViewCheckBoxColumn.Name = "saisuiKomokuFlagDataGridViewCheckBoxColumn";
            this.saisuiKomokuFlagDataGridViewCheckBoxColumn.Width = 65;
            // 
            // KomokuCode
            // 
            this.KomokuCode.DataPropertyName = "KomokuCode";
            this.KomokuCode.HeaderText = "項目コード";
            this.KomokuCode.Name = "KomokuCode";
            this.KomokuCode.Visible = false;
            // 
            // HaisuikoJyoho
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.ClientSize = new System.Drawing.Size(701, 690);
            this.Controls.Add(this.dgvHaisuikoKomokuItiran);
            this.Controls.Add(this.lblJigyojoLine);
            this.Controls.Add(this.lblJigyojo);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnRegist);
            this.Controls.Add(this.btnReturn);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.wdSetiDate);
            this.Controls.Add(this.wdHaisiDate);
            this.Controls.Add(this.txtBiko);
            this.Controls.Add(this.txtTdkdhsMax);
            this.Controls.Add(this.txtTdkdhsAve);
            this.Controls.Add(this.txtHaisuikoNo);
            this.Controls.Add(this.lblTdkdhsMax);
            this.Controls.Add(this.lblTdkdhsMaxUnit);
            this.Controls.Add(this.lblTdkdhsAveUnit);
            this.Controls.Add(this.lblTdkdhsAve);
            this.Controls.Add(this.lblBiko);
            this.Controls.Add(this.lblHaisiDate);
            this.Controls.Add(this.lblSetiDate);
            this.Controls.Add(this.lblHaisuikoNo);
            this.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "HaisuikoJyoho";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "排水口情報";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.HaisuikoJyoho_FormClosing);
            this.Load += new System.EventHandler(this.HaisuikoJyoho_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvHaisuikoKomokuItiran)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsHaisuikoKomokuItiran)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsHaisuiko)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnRegist;
        private System.Windows.Forms.Button btnReturn;
        private System.Windows.Forms.Button btnCancel;
        private Components.Controls.WarekiDate wdHaisiDate;
        private System.Windows.Forms.TextBox txtBiko;
        private System.Windows.Forms.TextBox txtHaisuikoNo;
        private System.Windows.Forms.Label lblBiko;
        private System.Windows.Forms.Label lblHaisiDate;
        private System.Windows.Forms.Label lblSetiDate;
        private System.Windows.Forms.Label lblHaisuikoNo;
        private Components.Controls.WarekiDate wdSetiDate;
        private System.Windows.Forms.Label lblJigyojoLine;
        private System.Windows.Forms.Label lblJigyojo;
        private System.Windows.Forms.Label lblTdkdhsAve;
        private System.Windows.Forms.Label lblTdkdhsMax;
        private System.Windows.Forms.Label lblTdkdhsAveUnit;
        private System.Windows.Forms.Label lblTdkdhsMaxUnit;
        private System.Windows.Forms.TextBox txtTdkdhsAve;
        private System.Windows.Forms.TextBox txtTdkdhsMax;
        private System.Windows.Forms.DataGridView dgvHaisuikoKomokuItiran;
        private Component.BackColorChangeOnFocusProvider backColorChangeOnFocusProvider1;
        private System.Windows.Forms.BindingSource bsHaisuiko;
        private System.Windows.Forms.BindingSource bsHaisuikoKomokuItiran;
        private System.Windows.Forms.DataGridViewTextBoxColumn KomokuNameN;
        private System.Windows.Forms.DataGridViewTextBoxColumn TANI;
        private System.Windows.Forms.DataGridViewTextBoxColumn TdkdAve;
        private System.Windows.Forms.DataGridViewTextBoxColumn TdkdMax;
        private System.Windows.Forms.DataGridViewCheckBoxColumn saisuiKomokuFlagDataGridViewCheckBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn KomokuCode;
    }
}