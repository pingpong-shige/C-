﻿using Suisitu.Common;
using Suisitu.Dao;
using Suisitu.Entity;
using Suisitu.Enum;
using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace Suisitu.Forms.SD01
{
    #pragma warning disable 168

    using CommonEvents = Suisitu.Common.Events;

    /// <summary>
    /// 排水口情報画面クラス
    /// </summary>
    public partial class HaisuikoJyoho : Form
    {
        // 排水口情報
        private HaisuikoEntity selectedItem_;

        // 排水口項目リスト
        private List<HaisuikoKomokuItiranEntity> selectedKomokuList_;

        // アクションモード
        private EnumActionKbn actionMode_;

        // 新規追加された排水口番号(排水口一覧のフォーカス用)
        public string addedHaisuikoNo_ = "";

        #region コンストラクタ

        /// <summary>
        /// コンストラクタ
        /// </summary>
        /// <param name="key">排水口情報</param>
        /// <param name="mode">アクションモード</param>
        public HaisuikoJyoho(HaisuikoEntity key, EnumActionKbn mode)
        {
            InitializeComponent();

            selectedItem_ = key;
            actionMode_ = mode;

            this.txtHaisuikoNo.KeyPress += new KeyPressEventHandler(CommonEvents.txtHalfNumber_KeyPress);
            this.wdSetiDate.KeyPress += new KeyPressEventHandler(CommonEvents.txtHalfNumber_KeyPress);
            this.wdHaisiDate.KeyPress += new KeyPressEventHandler(CommonEvents.txtHalfNumber_KeyPress);
            this.txtTdkdhsAve.KeyPress += new KeyPressEventHandler(CommonEvents.txtHalfDecimal_KeyPress);
            this.txtTdkdhsMax.KeyPress += new KeyPressEventHandler(CommonEvents.txtHalfDecimal_KeyPress);
        }
        #endregion

        #region イベント

        /// <summary>
        /// 画面が表示されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void HaisuikoJyoho_Load(object sender, EventArgs e)
        {
            // 画面ロックマトリックスを定義する
            SetLockMatrix();

            // データを画面表示する
            InitializeData();
        }

        /// <summary>
        /// 戻るボタンが選択されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnReturn_Click(object sender, EventArgs e)
        {
            Return();
        }

        /// <summary>
        /// キャンセルボタンが選択されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnCancel_Click(object sender, EventArgs e)
        {
            InitializeData();
        }

        /// <summary>
        /// 登録ボタンが選択されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnRegist_Click(object sender, EventArgs e)
        {
            // 登録データを作成する
            HaisuikoContainer container = CreateRegisterData();

            // バリデーションチェックする
            if (!Validation())
                return;

            // 排水口コンテナを登録する
            Register(container);

            // 画面を閉じるときの前処理
            ClosingPreprocessing();

            Close();
        }

        /// <summary>
        /// 削除ボタンが選択されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnDelete_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("表示中のデータを削除します。よろしいですか？", Text,
                MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button2);

            if (result == DialogResult.Yes)
            {
                // 排水口情報を削除する
                HaisuikoDao.Delete((HaisuikoEntity)bsHaisuiko.Current);

                // 排水口項目情報を削除する
                var list = ConvertDgvHaisuikoKomokuItiranToList();
                foreach (var entity in list)
                {
                    HaisuikoKomokuDao.Delete(entity);
                }

            }

            // 画面を閉じるときの前処理
            ClosingPreprocessing();

            Close();
        }

        /// <summary>
        /// 画面を閉じるときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void HaisuikoJyoho_FormClosing(object sender, FormClosingEventArgs e)
        {
            // 各種ボタンイベントから画面を閉じる場合
            if (this.Tag == null)
                Return();
        }

        #endregion

        #region プライベートメソッド

        /// <summary>
        /// 画面に表示するデータを初期化します。
        /// </summary>
        private void InitializeData()
        {
            Clear();

            switch (actionMode_)
            {
                // 選択、複写の場合
                case EnumActionKbn.Select:
                case EnumActionKbn.Copy:

                    HaisuikoEntity descEntity = new HaisuikoEntity();
                    BeanUtils.CopyObjectProperties(selectedItem_, descEntity);

                    wdSetiDate.Value = descEntity.SetiDate;
                    wdHaisiDate.Value = descEntity.HaisiDate;

                    HaisuikoKomokuItiranEntity param;

                    if (actionMode_ == EnumActionKbn.Copy)
                    {
                        descEntity.HaisuikoNo = HaisuikoDao.GetNewHaisuikoNo(descEntity);

                        param = new HaisuikoKomokuItiranEntity
                        {
                            Nendo = selectedItem_.Nendo,
                            KanriNo = selectedItem_.KanriNo,
                            HaisuikoNo = selectedItem_.HaisuikoNo,
                        };
                    }
                    else
                    {
                        param = new HaisuikoKomokuItiranEntity
                        {
                            Nendo = selectedItem_.Nendo,
                            KanriNo = selectedItem_.KanriNo,
                            HaisuikoNo = descEntity.HaisuikoNo,
                        };
                    }

                    bsHaisuiko.DataSource = descEntity;

                    selectedKomokuList_ = HaisuikoKomokuItiranDao.Select(param);

                    List<HaisuikoKomokuItiranEntity> list = new List<HaisuikoKomokuItiranEntity>();

                    foreach (var komoku in selectedKomokuList_)
                    {
                        list.Add(BeanUtils.DeepCopyProperties<HaisuikoKomokuItiranEntity>(komoku));
                    }

                    bsHaisuikoKomokuItiran.DataSource = list;

                    break;

                // 追加の場合
                case EnumActionKbn.Add:
                    txtHaisuikoNo.Text = HaisuikoDao.GetNewHaisuikoNo(selectedItem_);

                    bsHaisuikoKomokuItiran.DataSource = KomokuCodeDao.SelectAll();

                    break;
            }
        }

        /// <summary>
        /// ロックマトリックス定義
        /// </summary>
        private void SetLockMatrix()
        {
            txtHaisuikoNo.Enabled = false;

            // 追加と複写の場合は削除ボタンを入力不可にする
            if (actionMode_ == EnumActionKbn.Add || actionMode_ == EnumActionKbn.Copy)
            {
                btnDelete.Enabled = false;
            }

            // 年度が通年以外の場合
            if (selectedItem_.Nendo != 9999)
            {
                btnRegist.Enabled = false;
                btnCancel.Enabled = false;
                btnDelete.Enabled = false;

                wdSetiDate.Enabled = false;
                wdHaisiDate.Enabled = false;
                txtBiko.Enabled = false;

                txtTdkdhsAve.Enabled = false;
                txtTdkdhsMax.Enabled = false;

                dgvHaisuikoKomokuItiran.Enabled = false;
            }
        }

        /// <summary>
        /// 画面のクリア処理
        /// </summary>
        private void Clear()
        {
            bsHaisuiko.Clear();
            bsHaisuikoKomokuItiran.Clear();

            wdSetiDate.Value = null;
            wdHaisiDate.Value = null;
        }

        /// <summary>
        /// 呼び出し元の画面に戻ります。
        /// </summary>
        private void Return()
        {
            try
            {
                if (actionMode_ == EnumActionKbn.Add || actionMode_ == EnumActionKbn.Copy
                    //|| !CompareToHaisuiko((HaisuikoEntity)bsHaisuiko.DataSource) || !CompareToHaisuikoKomokuItiran((List<HaisuikoKomokuItiranEntity>)bsHaisuikoKomokuItiran.DataSource))
                    || !CompareToHaisuiko((HaisuikoEntity)bsHaisuiko.DataSource) || !CompareToHaisuikoKomokuItiran(ConvertDgvHaisuikoKomokuItiranToList()))
                {
                    DialogResult result = MessageBox.Show("編集中のデータを保存しますか？", Text,
                        MessageBoxButtons.YesNo, MessageBoxIcon.Information, MessageBoxDefaultButton.Button2);

                    if (result == DialogResult.Yes)
                    {
                        // 登録データを作成する
                        HaisuikoContainer container = CreateRegisterData();

                        // バリデーションチェックする
                        if (!Validation())
                            return;

                        // 排水口コンテナを登録する
                        Register(container);
                    }
                }
            }
            catch (Exception ex)
            {
                // なにもしない
            }

            // 画面を閉じるときの前処理
            ClosingPreprocessing();

            Close();
        }

        /// <summary>
        /// 編集前と編集後を比較します。
        /// (データソースとコントロール値を比較します。)
        /// </summary>
        /// <param name="source">編集前のオブジェクト</param>
        /// <returns>True:差異なし / False:差異あり</returns>
        private bool CompareToHaisuiko(HaisuikoEntity source)
        {
            // 設置年月日
            if (CommonUtils.FormatToDate(wdSetiDate.Value) != source.SetiDate)
                return false;

            // 廃止年月日
            if (CommonUtils.FormatToDate(wdHaisiDate.Value) != source.HaisiDate)
                return false;

            // 備考
            if (txtBiko.Text != source.Biko)
                return false;

            // 排水量（通常）
            if (txtTdkdhsAve.Text != source.TdkdHsAve)
                return false;

            // 排水量（最大）
            if (txtTdkdhsMax.Text != source.TdkdHsMax)
                return false;

            return true;
        }

        /// <summary>
        /// 排水口項目一覧の編集前と編集後を比較します。
        /// </summary>
        /// <param name="list">編集後の排水口項目一覧情報</param>
        /// <returns>True:差異なし / False:差異あり</returns>
        private bool CompareToHaisuikoKomokuItiran(List<HaisuikoKomokuItiranEntity> list)
        {
            var result = true;

            foreach (var entity in list)
            {
                result = CompareToHaisuikoKomokuItiran(entity);
                // 差異有の場合はループを抜ける
                if (!result) break;
            }

            return result;
        }

        /// <summary>
        /// 排水口項目一覧の編集前と編集後を比較します。
        /// </summary>
        /// <param name="entity">編集後の排水口項目情報</param>
        /// <returns>True:差異なし / False:差異あり</returns>
        private bool CompareToHaisuikoKomokuItiran(HaisuikoKomokuItiranEntity entity)
        {
            foreach (var komoku in selectedKomokuList_)
            {
                if (komoku.KomokuCode == entity.KomokuCode)
                {
                    if (komoku.TdkdAve != entity.TdkdAve || komoku.TdkdMax != entity.TdkdMax || komoku.SaisuiKomokuFlag != entity.SaisuiKomokuFlag)
                        return false;

                    break;
                }
            }

            return true;
        }

        /// <summary>
        /// バリデーションをチェックします。
        /// </summary>
        /// <returns>True:チェックOK / False:チェックNG</returns>
        private bool Validation()
        {
            // 必須入力チェック
            if (string.IsNullOrEmpty(txtTdkdhsAve.Text))
            {
                MessageUtils.NoInputDataMessage(CommonUtils.Trim(lblTdkdhsAve.Text), Text);
                txtTdkdhsAve.Focus();
                return false;
            }

            if (string.IsNullOrEmpty(txtTdkdhsMax.Text))
            {
                MessageUtils.NoInputDataMessage(CommonUtils.Trim(lblTdkdhsMax.Text), Text);
                txtTdkdhsMax.Focus();
                return false;
            }

            // 日付整合性チェック
            if (!ValidationUtils.ValidateConcistencyDate(wdSetiDate.Value, wdHaisiDate.Value))
            {
                MessageUtils.NotConcistencyDate(CommonUtils.Trim(lblSetiDate.Text), CommonUtils.Trim(lblHaisiDate.Text), Text);
                wdHaisiDate.Focus();
                return false;
            }

            string minValue = "0.0";
            string maxValue = "999.9";

            // 書式チェック
            string regExp = @"^[0-9]{1,3}(\.[0-9]{1})?$";
            if (!Regex.IsMatch(txtTdkdhsAve.Text, regExp))
            {
                MessageUtils.TypeAndRangeErrorMessage(CommonUtils.Trim(lblTdkdhsAve.Text), minValue, maxValue, Text);
                txtTdkdhsAve.Focus();
                return false;
            }
            if (!Regex.IsMatch(txtTdkdhsMax.Text, regExp))
            {
                MessageUtils.TypeAndRangeErrorMessage(CommonUtils.Trim(lblTdkdhsMax.Text), minValue, maxValue, Text);
                txtTdkdhsMax.Focus();
                return false;
            }

            return true;
        }

        /// <summary>
        /// 登録用排水口情報を作成します。
        /// </summary>
        /// <returns>排水口コンテナ</returns>
        private HaisuikoContainer CreateRegisterData()
        {
            // 登録データを作成する
            HaisuikoEntity haisuikoEntity = new HaisuikoEntity
            {
                Nendo = selectedItem_.Nendo,
                KanriNo = selectedItem_.KanriNo,
                HaisuikoNo = txtHaisuikoNo.Text,
                SetiDate = CommonUtils.FormatToDate(wdSetiDate.Value),
                HaisiDate = CommonUtils.FormatToDate(wdHaisiDate.Value),
                TdkdHsAve = txtTdkdhsAve.Text,
                TdkdHsMax = txtTdkdhsMax.Text,
                Biko = txtBiko.Text,
                TorokuDate = DateTime.Now.ToString(),
                HaisiFlag = "",
                UpdDate = DateTime.Now.ToString(),
                Rev = 1,
            };

            var list = new List<HaisuikoKomokuItiranEntity>();

            foreach (DataGridViewRow row in dgvHaisuikoKomokuItiran.Rows)
            {
                var haisuikoKomokuEntity = new HaisuikoKomokuItiranEntity
                {
                    Nendo = selectedItem_.Nendo,
                    KanriNo = selectedItem_.KanriNo,
                    HaisuikoNo = txtHaisuikoNo.Text,
                    KomokuCode = Convert.ToString(row.Cells[5].Value),
                    TdkdAve = string.IsNullOrEmpty(Convert.ToString(row.Cells[2].Value)) ? null : Convert.ToString(row.Cells[2].Value),
                    TdkdMax = string.IsNullOrEmpty(Convert.ToString(row.Cells[3].Value)) ? null : Convert.ToString(row.Cells[3].Value),
                    SaisuiKomokuFlag = Convert.ToBoolean(row.Cells[4].Value),
                    TorokuDate = DateTime.Now.ToString(),
                    UpdDate = DateTime.Now.ToString(),
                    Rev = 1,
                };

                if (!IsTargetRegistrationData(haisuikoKomokuEntity))
                    continue;

                list.Add(haisuikoKomokuEntity);
            }

            // 排水口コンテナを作成する
            HaisuikoContainer container = new HaisuikoContainer
            {
                Haisuiko = haisuikoEntity,
                HaisuikoKomokuList = list,
            };

            return container;
        }

        /// <summary>
        /// 排水口コンテナを登録します。
        /// </summary>
        /// <param name="container">排水口コンテナ</param>
        private void Register(HaisuikoContainer container)
        {
            var haisuiko = container.Haisuiko;
            var komokuList = container.HaisuikoKomokuList;

            // 該当データが存在しない場合
            if (HaisuikoDao.Select(haisuiko) == null)
            {
                // 排水口情報を登録する
                HaisuikoDao.Insert(haisuiko);

                // 登録された排水口番号を保持する
                addedHaisuikoNo_ = haisuiko.HaisuikoNo;
            }
            // 該当データが存在する場合
            else
            {
                // 届出履歴情報を更新する
                HaisuikoDao.Update(haisuiko);
            }

            foreach (var komoku in komokuList)
            {

                // 該当データが存在しない場合
                if (HaisuikoKomokuDao.Select(komoku) == null)
                {
                    // 排水口項目情報を登録する
                    HaisuikoKomokuDao.Insert(komoku);
                }
                else
                {
                    // 排水口項目情報を更新する
                    HaisuikoKomokuDao.Update(komoku);
                }
            }
        }

        /// <summary>
        /// 排水口項目情報が登録対象かどうか判定します。
        /// </summary>
        /// <returns>True:対象 / False:対象外</returns>
        private bool IsTargetRegistrationData(HaisuikoKomokuItiranEntity entity)
        {
            // すでに登録済みのデータの場合
            if (HaisuikoKomokuDao.Select(entity) != null)
            { 
                // 編集前後で差異がある場合
                if (!CompareToHaisuikoKomokuItiran(entity))
                {
                    return true;
                }
            }
            else
            {
                // 登録データが初期値の場合
                if (string.IsNullOrEmpty(entity.TdkdAve) && string.IsNullOrEmpty(entity.TdkdMax)
                    && entity.SaisuiKomokuFlag == false)
                {
                    // なにもしない
                }
                else
                {
                    return true;
                }
            }

            return false;
        }

        private List<HaisuikoKomokuItiranEntity> ConvertDgvHaisuikoKomokuItiranToList()
        {
            var list = new List<HaisuikoKomokuItiranEntity>();

            foreach (DataGridViewRow row in dgvHaisuikoKomokuItiran.Rows)
            {
                var haisuikoKomokuEntity = new HaisuikoKomokuItiranEntity
                {
                    Nendo = selectedItem_.Nendo,
                    KanriNo = selectedItem_.KanriNo,
                    HaisuikoNo = txtHaisuikoNo.Text,
                    KomokuCode = Convert.ToString(row.Cells[5].Value),
                    TdkdAve = string.IsNullOrEmpty(Convert.ToString(row.Cells[2].Value)) ? null : Convert.ToString(row.Cells[2].Value),
                    TdkdMax = string.IsNullOrEmpty(Convert.ToString(row.Cells[3].Value)) ? null : Convert.ToString(row.Cells[3].Value),
                    SaisuiKomokuFlag = Convert.ToBoolean(row.Cells[4].Value),
                    TorokuDate = DateTime.Now.ToString(),
                    UpdDate = DateTime.Now.ToString(),
                    Rev = 1,
                };

                list.Add(haisuikoKomokuEntity);
            }

            return list;
        }

        /// <summary>
        /// 画面を閉じるときの前処理
        /// </summary>
        private void ClosingPreprocessing()
        {
            this.Tag = true;
        }

        #endregion
    }

    /// <summary>
    /// 排水口Containerクラス
    /// </summary>
    class HaisuikoContainer
    {
        /// <summary>
        /// 排水口情報
        /// </summary>
        public HaisuikoEntity Haisuiko { get; set; }

        /// <summary>
        /// 排水口項目リスト
        /// </summary>
        public List<HaisuikoKomokuItiranEntity> HaisuikoKomokuList { get; set; }
    }
}