﻿namespace Suisitu.Forms.SD01
{
    partial class JigyojoItiran
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel1 = new System.Windows.Forms.Panel();
            this.txtKanriNo = new System.Windows.Forms.TextBox();
            this.lblKanriNo = new System.Windows.Forms.Label();
            this.cboNendo = new System.Windows.Forms.ComboBox();
            this.txtSeriNo = new System.Windows.Forms.TextBox();
            this.btnEnd = new System.Windows.Forms.Button();
            this.btnSearch = new System.Windows.Forms.Button();
            this.txtSinseiCopName = new System.Windows.Forms.TextBox();
            this.txtJigyojoAdrs = new System.Windows.Forms.TextBox();
            this.txtJigyojoNameK = new System.Windows.Forms.TextBox();
            this.txtJigyojoName = new System.Windows.Forms.TextBox();
            this.lblSinseiCopName = new System.Windows.Forms.Label();
            this.lblAdrs = new System.Windows.Forms.Label();
            this.lblNameK = new System.Windows.Forms.Label();
            this.lblName = new System.Windows.Forms.Label();
            this.lblNendo = new System.Windows.Forms.Label();
            this.lblSeriNo = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lblCountRecord = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btnBottom = new System.Windows.Forms.Button();
            this.btnTop = new System.Windows.Forms.Button();
            this.btnDel = new System.Windows.Forms.Button();
            this.btnSelect = new System.Windows.Forms.Button();
            this.btnAdd = new System.Windows.Forms.Button();
            this.dgvJigyojoItiran = new System.Windows.Forms.DataGridView();
            this.HaisiFlagV = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SeiriNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.JigyosyoNameN = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SyozaiJyusyo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bsJigyojoItiran = new System.Windows.Forms.BindingSource(this.components);
            this.backColorChangeOnFocusProvider1 = new Suisitu.Component.BackColorChangeOnFocusProvider();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvJigyojoItiran)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsJigyojoItiran)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.txtKanriNo);
            this.panel1.Controls.Add(this.lblKanriNo);
            this.panel1.Controls.Add(this.cboNendo);
            this.panel1.Controls.Add(this.txtSeriNo);
            this.panel1.Controls.Add(this.btnEnd);
            this.panel1.Controls.Add(this.btnSearch);
            this.panel1.Controls.Add(this.txtSinseiCopName);
            this.panel1.Controls.Add(this.txtJigyojoAdrs);
            this.panel1.Controls.Add(this.txtJigyojoNameK);
            this.panel1.Controls.Add(this.txtJigyojoName);
            this.panel1.Controls.Add(this.lblSinseiCopName);
            this.panel1.Controls.Add(this.lblAdrs);
            this.panel1.Controls.Add(this.lblNameK);
            this.panel1.Controls.Add(this.lblName);
            this.panel1.Controls.Add(this.lblNendo);
            this.panel1.Controls.Add(this.lblSeriNo);
            this.panel1.Location = new System.Drawing.Point(12, 9);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(988, 188);
            this.panel1.TabIndex = 3;
            // 
            // txtKanriNo
            // 
            this.txtKanriNo.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtKanriNo.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.txtKanriNo.Location = new System.Drawing.Point(586, 12);
            this.txtKanriNo.MaxLength = 8;
            this.txtKanriNo.Name = "txtKanriNo";
            this.txtKanriNo.Size = new System.Drawing.Size(90, 31);
            this.txtKanriNo.TabIndex = 3;
            // 
            // lblKanriNo
            // 
            this.lblKanriNo.AutoSize = true;
            this.lblKanriNo.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblKanriNo.Location = new System.Drawing.Point(506, 15);
            this.lblKanriNo.Name = "lblKanriNo";
            this.lblKanriNo.Size = new System.Drawing.Size(74, 24);
            this.lblKanriNo.TabIndex = 52;
            this.lblKanriNo.Text = "管理番号";
            // 
            // cboNendo
            // 
            this.cboNendo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboNendo.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.cboNendo.FormattingEnabled = true;
            this.cboNendo.Location = new System.Drawing.Point(173, 12);
            this.cboNendo.Name = "cboNendo";
            this.cboNendo.Size = new System.Drawing.Size(121, 32);
            this.cboNendo.TabIndex = 1;
            this.cboNendo.SelectedIndexChanged += new System.EventHandler(this.cboNendo_SelectedIndexChanged);
            // 
            // txtSeriNo
            // 
            this.txtSeriNo.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtSeriNo.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.txtSeriNo.Location = new System.Drawing.Point(399, 12);
            this.txtSeriNo.MaxLength = 8;
            this.txtSeriNo.Name = "txtSeriNo";
            this.txtSeriNo.Size = new System.Drawing.Size(90, 31);
            this.txtSeriNo.TabIndex = 2;
            // 
            // btnEnd
            // 
            this.btnEnd.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnEnd.Location = new System.Drawing.Point(873, 144);
            this.btnEnd.Name = "btnEnd";
            this.btnEnd.Size = new System.Drawing.Size(100, 30);
            this.btnEnd.TabIndex = 9;
            this.btnEnd.Text = "終了";
            this.btnEnd.UseVisualStyleBackColor = true;
            this.btnEnd.Click += new System.EventHandler(this.btnEnd_Click);
            // 
            // btnSearch
            // 
            this.btnSearch.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnSearch.Location = new System.Drawing.Point(767, 145);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(100, 30);
            this.btnSearch.TabIndex = 8;
            this.btnSearch.Text = "検索";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // txtSinseiCopName
            // 
            this.txtSinseiCopName.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtSinseiCopName.ImeMode = System.Windows.Forms.ImeMode.Hiragana;
            this.txtSinseiCopName.Location = new System.Drawing.Point(173, 144);
            this.txtSinseiCopName.MaxLength = 16;
            this.txtSinseiCopName.Name = "txtSinseiCopName";
            this.txtSinseiCopName.Size = new System.Drawing.Size(463, 31);
            this.txtSinseiCopName.TabIndex = 7;
            // 
            // txtJigyojoAdrs
            // 
            this.txtJigyojoAdrs.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtJigyojoAdrs.ImeMode = System.Windows.Forms.ImeMode.Hiragana;
            this.txtJigyojoAdrs.Location = new System.Drawing.Point(173, 111);
            this.txtJigyojoAdrs.MaxLength = 100;
            this.txtJigyojoAdrs.Name = "txtJigyojoAdrs";
            this.txtJigyojoAdrs.Size = new System.Drawing.Size(463, 31);
            this.txtJigyojoAdrs.TabIndex = 6;
            // 
            // txtJigyojoNameK
            // 
            this.txtJigyojoNameK.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtJigyojoNameK.ImeMode = System.Windows.Forms.ImeMode.Katakana;
            this.txtJigyojoNameK.Location = new System.Drawing.Point(173, 78);
            this.txtJigyojoNameK.MaxLength = 100;
            this.txtJigyojoNameK.Name = "txtJigyojoNameK";
            this.txtJigyojoNameK.Size = new System.Drawing.Size(463, 31);
            this.txtJigyojoNameK.TabIndex = 5;
            // 
            // txtJigyojoName
            // 
            this.txtJigyojoName.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtJigyojoName.ImeMode = System.Windows.Forms.ImeMode.Hiragana;
            this.txtJigyojoName.Location = new System.Drawing.Point(173, 45);
            this.txtJigyojoName.MaxLength = 100;
            this.txtJigyojoName.Name = "txtJigyojoName";
            this.txtJigyojoName.Size = new System.Drawing.Size(463, 31);
            this.txtJigyojoName.TabIndex = 4;
            // 
            // lblSinseiCopName
            // 
            this.lblSinseiCopName.AutoSize = true;
            this.lblSinseiCopName.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblSinseiCopName.Location = new System.Drawing.Point(15, 147);
            this.lblSinseiCopName.Name = "lblSinseiCopName";
            this.lblSinseiCopName.Size = new System.Drawing.Size(138, 24);
            this.lblSinseiCopName.TabIndex = 51;
            this.lblSinseiCopName.Text = "届出申請会社名等";
            // 
            // lblAdrs
            // 
            this.lblAdrs.AutoSize = true;
            this.lblAdrs.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblAdrs.Location = new System.Drawing.Point(15, 114);
            this.lblAdrs.Name = "lblAdrs";
            this.lblAdrs.Size = new System.Drawing.Size(138, 24);
            this.lblAdrs.TabIndex = 51;
            this.lblAdrs.Text = "工場事業場所在地";
            // 
            // lblNameK
            // 
            this.lblNameK.AutoSize = true;
            this.lblNameK.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblNameK.Location = new System.Drawing.Point(15, 81);
            this.lblNameK.Name = "lblNameK";
            this.lblNameK.Size = new System.Drawing.Size(154, 24);
            this.lblNameK.TabIndex = 50;
            this.lblNameK.Text = "工場事業場名称カナ";
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblName.Location = new System.Drawing.Point(15, 48);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(122, 24);
            this.lblName.TabIndex = 50;
            this.lblName.Text = "工場事業場名称";
            // 
            // lblNendo
            // 
            this.lblNendo.AutoSize = true;
            this.lblNendo.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblNendo.Location = new System.Drawing.Point(15, 15);
            this.lblNendo.Name = "lblNendo";
            this.lblNendo.Size = new System.Drawing.Size(42, 24);
            this.lblNendo.TabIndex = 49;
            this.lblNendo.Text = "年度";
            // 
            // lblSeriNo
            // 
            this.lblSeriNo.AutoSize = true;
            this.lblSeriNo.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblSeriNo.Location = new System.Drawing.Point(310, 15);
            this.lblSeriNo.Name = "lblSeriNo";
            this.lblSeriNo.Size = new System.Drawing.Size(74, 24);
            this.lblSeriNo.TabIndex = 49;
            this.lblSeriNo.Text = "整理番号";
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.lblCountRecord);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.btnBottom);
            this.panel2.Controls.Add(this.btnTop);
            this.panel2.Controls.Add(this.btnDel);
            this.panel2.Controls.Add(this.btnSelect);
            this.panel2.Controls.Add(this.btnAdd);
            this.panel2.Controls.Add(this.dgvJigyojoItiran);
            this.panel2.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.panel2.Location = new System.Drawing.Point(12, 203);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(988, 515);
            this.panel2.TabIndex = 23;
            // 
            // lblCountRecord
            // 
            this.lblCountRecord.AutoSize = true;
            this.lblCountRecord.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblCountRecord.Location = new System.Drawing.Point(75, 24);
            this.lblCountRecord.Name = "lblCountRecord";
            this.lblCountRecord.Size = new System.Drawing.Size(20, 24);
            this.lblCountRecord.TabIndex = 7;
            this.lblCountRecord.Text = "0";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.label2.Location = new System.Drawing.Point(15, 24);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 24);
            this.label2.TabIndex = 6;
            this.label2.Text = "件数 = ";
            // 
            // btnBottom
            // 
            this.btnBottom.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnBottom.Location = new System.Drawing.Point(873, 9);
            this.btnBottom.Name = "btnBottom";
            this.btnBottom.Size = new System.Drawing.Size(100, 30);
            this.btnBottom.TabIndex = 11;
            this.btnBottom.Text = "最後";
            this.btnBottom.UseVisualStyleBackColor = true;
            this.btnBottom.Click += new System.EventHandler(this.btnBottom_Click);
            // 
            // btnTop
            // 
            this.btnTop.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnTop.Location = new System.Drawing.Point(767, 9);
            this.btnTop.Name = "btnTop";
            this.btnTop.Size = new System.Drawing.Size(100, 30);
            this.btnTop.TabIndex = 10;
            this.btnTop.Text = "先頭";
            this.btnTop.UseVisualStyleBackColor = true;
            this.btnTop.Click += new System.EventHandler(this.btnTop_Click);
            // 
            // btnDel
            // 
            this.btnDel.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnDel.Location = new System.Drawing.Point(661, 470);
            this.btnDel.Name = "btnDel";
            this.btnDel.Size = new System.Drawing.Size(100, 30);
            this.btnDel.TabIndex = 12;
            this.btnDel.Text = "削除";
            this.btnDel.UseVisualStyleBackColor = true;
            this.btnDel.Click += new System.EventHandler(this.btnDel_Click);
            // 
            // btnSelect
            // 
            this.btnSelect.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnSelect.Location = new System.Drawing.Point(873, 470);
            this.btnSelect.Name = "btnSelect";
            this.btnSelect.Size = new System.Drawing.Size(100, 30);
            this.btnSelect.TabIndex = 14;
            this.btnSelect.Text = "選択";
            this.btnSelect.UseVisualStyleBackColor = true;
            this.btnSelect.Click += new System.EventHandler(this.btnSelect_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnAdd.Location = new System.Drawing.Point(767, 470);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(100, 30);
            this.btnAdd.TabIndex = 13;
            this.btnAdd.Text = "追加";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // dgvJigyojoItiran
            // 
            this.dgvJigyojoItiran.AllowUserToAddRows = false;
            this.dgvJigyojoItiran.AllowUserToDeleteRows = false;
            this.dgvJigyojoItiran.AllowUserToResizeColumns = false;
            this.dgvJigyojoItiran.AllowUserToResizeRows = false;
            this.dgvJigyojoItiran.AutoGenerateColumns = false;
            this.dgvJigyojoItiran.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvJigyojoItiran.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.HaisiFlagV,
            this.SeiriNo,
            this.JigyosyoNameN,
            this.SyozaiJyusyo});
            this.dgvJigyojoItiran.DataSource = this.bsJigyojoItiran;
            this.dgvJigyojoItiran.Location = new System.Drawing.Point(15, 48);
            this.dgvJigyojoItiran.MultiSelect = false;
            this.dgvJigyojoItiran.Name = "dgvJigyojoItiran";
            this.dgvJigyojoItiran.ReadOnly = true;
            this.dgvJigyojoItiran.RowHeadersVisible = false;
            this.dgvJigyojoItiran.RowHeadersWidth = 25;
            this.dgvJigyojoItiran.RowTemplate.Height = 21;
            this.dgvJigyojoItiran.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvJigyojoItiran.Size = new System.Drawing.Size(957, 412);
            this.dgvJigyojoItiran.TabIndex = 0;
            this.dgvJigyojoItiran.CellMouseDoubleClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgvJigyojoItiran_CellMouseDoubleClick);
            // 
            // HaisiFlagV
            // 
            this.HaisiFlagV.DataPropertyName = "HaisiFlagV";
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.HaisiFlagV.DefaultCellStyle = dataGridViewCellStyle1;
            this.HaisiFlagV.HeaderText = "廃止";
            this.HaisiFlagV.Name = "HaisiFlagV";
            this.HaisiFlagV.ReadOnly = true;
            this.HaisiFlagV.Width = 65;
            // 
            // SeiriNo
            // 
            this.SeiriNo.DataPropertyName = "SeiriNo";
            this.SeiriNo.HeaderText = "整理番号";
            this.SeiriNo.Name = "SeiriNo";
            this.SeiriNo.ReadOnly = true;
            // 
            // JigyosyoNameN
            // 
            this.JigyosyoNameN.DataPropertyName = "JigyosyoNameN";
            this.JigyosyoNameN.HeaderText = "工場事業場名称";
            this.JigyosyoNameN.Name = "JigyosyoNameN";
            this.JigyosyoNameN.ReadOnly = true;
            this.JigyosyoNameN.Width = 370;
            // 
            // SyozaiJyusyo
            // 
            this.SyozaiJyusyo.DataPropertyName = "SyozaiJyusyo";
            this.SyozaiJyusyo.HeaderText = "工場事業場所在地";
            this.SyozaiJyusyo.Name = "SyozaiJyusyo";
            this.SyozaiJyusyo.ReadOnly = true;
            this.SyozaiJyusyo.Width = 402;
            // 
            // bsJigyojoItiran
            // 
            this.bsJigyojoItiran.DataSource = typeof(Suisitu.Entity.JigyojoItiranEntity);
            // 
            // backColorChangeOnFocusProvider1
            // 
            this.backColorChangeOnFocusProvider1.Target = this;
            // 
            // JigyojoItiran
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.ClientSize = new System.Drawing.Size(1008, 730);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "JigyojoItiran";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "工場事業場一覧";
            this.Load += new System.EventHandler(this.JigyojoItiran_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvJigyojoItiran)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsJigyojoItiran)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        public System.Windows.Forms.TextBox txtJigyojoAdrs;
        public System.Windows.Forms.TextBox txtJigyojoName;
        public System.Windows.Forms.Label lblAdrs;
        public System.Windows.Forms.Label lblName;
        public System.Windows.Forms.Label lblSeriNo;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnBottom;
        private System.Windows.Forms.Button btnTop;
        private System.Windows.Forms.Button btnDel;
        private System.Windows.Forms.Button btnSelect;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.DataGridView dgvJigyojoItiran;
        private System.Windows.Forms.Button btnEnd;
        private System.Windows.Forms.Button btnSearch;
        public System.Windows.Forms.TextBox txtSeriNo;
        private System.Windows.Forms.BindingSource bsJigyojoItiran;
        private System.Windows.Forms.Label lblCountRecord;
        public System.Windows.Forms.TextBox txtSinseiCopName;
        public System.Windows.Forms.TextBox txtJigyojoNameK;
        public System.Windows.Forms.Label lblSinseiCopName;
        public System.Windows.Forms.Label lblNameK;
        public System.Windows.Forms.Label lblNendo;
        private System.Windows.Forms.ComboBox cboNendo;
        private Component.BackColorChangeOnFocusProvider backColorChangeOnFocusProvider1;
        public System.Windows.Forms.TextBox txtKanriNo;
        public System.Windows.Forms.Label lblKanriNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn HaisiFlagV;
        private System.Windows.Forms.DataGridViewTextBoxColumn SeiriNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn JigyosyoNameN;
        private System.Windows.Forms.DataGridViewTextBoxColumn SyozaiJyusyo;
    }
}