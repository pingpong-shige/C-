﻿using Suisitu.Common;
using Suisitu.Components.Common;
using Suisitu.Components.Controls;
using Suisitu.Dao;
using Suisitu.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace Suisitu.Forms.SD01
{
    using CommonEvents = Suisitu.Common.Events;

    /// <summary>
    /// 工場事業場一覧画面クラス
    /// </summary>
    public partial class JigyojoItiran : Form
    {

        private JigyojoItiranEntity searchKey_;

        #region コンストラクタ

        /// <summary>
        /// コンストラクタ
        /// </summary>
        public JigyojoItiran()
        {
            InitializeComponent();

            this.txtSeriNo.KeyPress += new KeyPressEventHandler(CommonEvents.txtHalfAll_KeyPress);
            this.txtKanriNo.KeyPress += new KeyPressEventHandler(CommonEvents.txtHalfNumber_KeyPress);
            this.txtJigyojoName.KeyPress += new KeyPressEventHandler(CommonEvents.txtFullAll_KeyPress);
            this.txtJigyojoNameK.KeyPress += new KeyPressEventHandler(CommonEvents.txtFullKatakana_KeyPress);
            this.txtJigyojoAdrs.KeyPress += new KeyPressEventHandler(CommonEvents.txtFullAll_KeyPress);
            this.txtSinseiCopName.KeyPress += new KeyPressEventHandler(CommonEvents.txtFullAll_KeyPress);
        }

        #endregion

        #region イベント

        /// <summary>
        /// 画面が表示されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void JigyojoItiran_Load(object sender, EventArgs e)
        {
            List<ValueComboItem> cboList = new List<ValueComboItem>();

            IEnumerable<dynamic> nendoList = KojoKihonDao.GetNendoList();
            foreach (var nendo in nendoList)
            {
                cboList.Add(new ValueComboItem(nendo.NENDO.ToString(), WarekiDateUtil.GetNendoText(Convert.ToInt32(nendo.NENDO))));
            }

            if (cboList.Count == 0)
                cboList.Add(new ValueComboItem("9999", "通年"));

            cboNendo.DataSource = cboList;
            cboNendo.DisplayMember = "Value";
            cboNendo.ValueMember = "Key";
        }

        /// <summary>
        /// 検索ボタンが選択されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnSearch_Click(object sender, EventArgs e)
        {
            searchKey_ = new JigyojoItiranEntity()
            {
                Nendo = int.Parse(cboNendo.SelectedValue.ToString()),
                KanriNo = string.IsNullOrEmpty(txtKanriNo.Text) ? 0 : int.Parse(txtKanriNo.Text),
                SeiriNo = DBUtils.AddWildCard(txtSeriNo.Text),
                JigyosyoNameN = DBUtils.AddWildCard(txtJigyojoName.Text),
                JigyosyoNameK = DBUtils.AddWildCard(txtJigyojoNameK.Text),
                SyozaiJyusyo = DBUtils.AddWildCard(txtJigyojoAdrs.Text),
                SinseiCopName = DBUtils.AddWildCard(txtSinseiCopName.Text),
            };

            IEnumerable<JigyojoItiranEntity> list = JigyojoItiranDao.SelectList(searchKey_);
            bsJigyojoItiran.DataSource = list;
            lblCountRecord.Text = list.Count().ToString();

            var isExist = list.Count() > 0;

            if (!isExist)
                MessageUtils.NoFoundDataMessage(Text);

            // 画面ロックマトリックスを定義する
            SetLockMatrix();
        }

        /// <summary>
        /// 終了ボタンが選択されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnEnd_Click(object sender, EventArgs e)
        {
            Close();
        }

        /// <summary>
        /// 先頭ボタンが選択されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnTop_Click(object sender, EventArgs e)
        {
            bsJigyojoItiran.MoveFirst();
        }

        /// <summary>
        /// 最後ボタンが選択されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnBottom_Click(object sender, EventArgs e)
        {
            bsJigyojoItiran.MoveLast();
        }

        /// <summary>
        /// 削除ボタンが選択されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnDel_Click(object sender, EventArgs e)
        {
            if (bsJigyojoItiran.Current == null)
                return;

            DialogResult result = MessageBox.Show("選択している工場事業場の全データを削除します。よろしいですか。", Text,
                MessageBoxButtons.YesNo,  MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button2);

            if (result == DialogResult.Yes)
            {
                JigyojoItiranEntity entity = (JigyojoItiranEntity)bsJigyojoItiran.Current;

                // 年度、管理番号をキーに以下のテーブルから該当データを削除する

                // 工場事業場基本表
                KojoKihonDao.Delete(new KojoKihonEntity { Nendo = entity.Nendo, KanriNo = entity.KanriNo });

                // 届出履歴表
                TodokedeRirekiDao.Delete(entity.Nendo, entity.KanriNo);

                // 特定施設等表
                TokuteiSisetuTouDao.Delete(entity.Nendo, entity.KanriNo);

                // 特定施設等有害使用状況表
                TsYugaiSiyoDao.Delete(entity.Nendo, entity.KanriNo);

                // 処理施設表
                SyoriSisetuDao.Delete(entity.Nendo, entity.KanriNo);

                // 付帯設備等表
                FutaiSetubiTouDao.Delete(entity.Nendo, entity.KanriNo);

                // 排水口表
                HaisuikoDao.Delete(entity.Nendo, entity.KanriNo);

                // 排水口項目表
                HaisuikoKomokuDao.Delete(entity.Nendo, entity.KanriNo);

                // 排水基準表
                HaisuiKijunDao.Delete(entity.Nendo, entity.KanriNo);

                // 汚濁負荷量表
                OdakuFukaryoDao.Delete(entity.Nendo, entity.KanriNo);

                // 採水立入指導表
                TatiiriSidoDao.Delete(entity.Nendo, entity.KanriNo);

                // 採水立入結果表
                TatiiriKetukaDao.Delete(entity.Nendo, entity.KanriNo);

                // 総量規制表
                SoryoKiseiDao.Delete(entity.Nendo, entity.KanriNo);

                // 採水計画表
                SaisuiKeikakuDao.Delete(entity.Nendo, entity.KanriNo);

                // 採水事業場表
                SaisuiJigyojoDao.Delete(entity.Nendo, entity.KanriNo);

                // データグリッドビューから該当データを削除する
                bsJigyojoItiran.RemoveAt(dgvJigyojoItiran.CurrentRow.Index);

                // レコードカウンタを更新する
                lblCountRecord.Text = bsJigyojoItiran.Count.ToString();
            }
        }

        /// <summary>
        /// 追加ボタンが選択されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnAdd_Click(object sender, EventArgs e)
        {
            int nendo;
            int.TryParse((string)cboNendo.SelectedValue, out nendo);

            JigyojoItiranEntity entity = new JigyojoItiranEntity()
            {
                Nendo = nendo,
            };

            // 水質届出管理画面を表示する
            using (var dialog = new TodokedeKanri(entity))
            {
                dialog.ShowDialog();
            }
        }

        /// <summary>
        /// 選択ボタンが選択されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnSelect_Click(object sender, EventArgs e)
        {
            ShowTodokedeKanri();
        }

        /// <summary>
        /// データグリッドビューのセルがダブルクリックされたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void dgvJigyojoItiran_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (bsJigyojoItiran.Current != null)
                ShowTodokedeKanri();
        }

        /// <summary>
        /// 年度コンボボックスの値が変更されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void cboNendo_SelectedIndexChanged(object sender, EventArgs e)
        {
            // 画面をクリアする
            Clear();

            // 画面ロックマトリックスを定義する
            SetLockMatrix();
        }

        #endregion

        #region プライベートメソッド

        /// <summary>
        /// ロックマトリックス定義
        /// </summary>
        /// <param name="enabled">使用可フラグ</param>
        //private void SetLockMatrix(bool enabled)
        private void SetLockMatrix()
        {
            // 年度が「通年」かつ一覧の件数が1件以上存在する場合
            if(cboNendo.SelectedValue.ToString() == "9999" && bsJigyojoItiran.Count > 0)
            {
                btnDel.Enabled = true;
                btnAdd.Enabled = true;
                btnSelect.Enabled = true;
            }
            // 年度が「通年」以外かつ一覧の件数が1件以上存在する場合
            else if (cboNendo.SelectedValue.ToString() != "9999" && bsJigyojoItiran.Count > 0)
            {
                btnDel.Enabled = false;
                btnAdd.Enabled = false;
                btnSelect.Enabled = true;

            }
            // 年度が「通年」かつ一覧の件数が0件の場合
            else if (cboNendo.SelectedValue.ToString() == "9999" && bsJigyojoItiran.Count == 0)
            {
                btnDel.Enabled = false;
                btnAdd.Enabled = true;
                btnSelect.Enabled = false;
            }
            // 年度が「通年」以外かつ一覧の件数が0件の場合
            else if (cboNendo.SelectedValue.ToString() != "9999" && bsJigyojoItiran.Count == 0)
            {
                btnDel.Enabled = false;
                btnAdd.Enabled = false;
                btnSelect.Enabled = false;
            }
        }

        /// <summary>
        /// 水質届出管理画面を表示します。
        /// </summary>
        private void ShowTodokedeKanri()
        {
            // 水質届出管理画面を表示する
            using (var dialog = new TodokedeKanri((JigyojoItiranEntity)bsJigyojoItiran.Current))
            {
                dialog.ShowDialog();
            }
        }

        /// <summary>
        /// 画面のクリア処理
        /// </summary>
        private void Clear()
        {
            bsJigyojoItiran.DataSource = null;
            lblCountRecord.Text = "0";
        }

        #endregion
    }
}
