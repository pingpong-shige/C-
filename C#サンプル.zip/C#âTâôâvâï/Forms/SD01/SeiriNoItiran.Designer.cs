﻿namespace Suisitu.Forms.SD01
{
    partial class SeiriNoItiran
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lblSeiriNo = new System.Windows.Forms.Label();
            this.lblSeiriNoHi = new System.Windows.Forms.Label();
            this.txtSeiriNo2 = new System.Windows.Forms.TextBox();
            this.txtSeiriNo1 = new System.Windows.Forms.TextBox();
            this.txtTsSyubetu = new System.Windows.Forms.TextBox();
            this.lblTsSyubetu = new System.Windows.Forms.Label();
            this.btnSearch = new System.Windows.Forms.Button();
            this.lblCountRecord = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btnBottom = new System.Windows.Forms.Button();
            this.btnTop = new System.Windows.Forms.Button();
            this.btnSelect = new System.Windows.Forms.Button();
            this.dgvJigyojoItiran = new System.Windows.Forms.DataGridView();
            this.btnOK = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.backColorChangeOnFocusProvider1 = new Suisitu.Component.BackColorChangeOnFocusProvider();
            this.bsTokuteiSisetuTou = new System.Windows.Forms.BindingSource(this.components);
            this.bsJigyojoItiran = new System.Windows.Forms.BindingSource(this.components);
            this.jigyojoItiranEntityBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.haisiFlagDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.seiriNoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.jigyosyoNameNDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvJigyojoItiran)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsTokuteiSisetuTou)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsJigyojoItiran)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.jigyojoItiranEntityBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.lblSeiriNo);
            this.panel2.Controls.Add(this.lblSeiriNoHi);
            this.panel2.Controls.Add(this.txtSeiriNo2);
            this.panel2.Controls.Add(this.txtSeiriNo1);
            this.panel2.Controls.Add(this.txtTsSyubetu);
            this.panel2.Controls.Add(this.lblTsSyubetu);
            this.panel2.Controls.Add(this.btnSearch);
            this.panel2.Controls.Add(this.lblCountRecord);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.btnBottom);
            this.panel2.Controls.Add(this.btnTop);
            this.panel2.Controls.Add(this.btnSelect);
            this.panel2.Controls.Add(this.dgvJigyojoItiran);
            this.panel2.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.panel2.Location = new System.Drawing.Point(15, 15);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(695, 636);
            this.panel2.TabIndex = 24;
            // 
            // lblSeiriNo
            // 
            this.lblSeiriNo.AutoSize = true;
            this.lblSeiriNo.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblSeiriNo.Location = new System.Drawing.Point(15, 592);
            this.lblSeiriNo.Name = "lblSeiriNo";
            this.lblSeiriNo.Size = new System.Drawing.Size(74, 24);
            this.lblSeiriNo.TabIndex = 129;
            this.lblSeiriNo.Text = "整理番号";
            // 
            // lblSeiriNoHi
            // 
            this.lblSeiriNoHi.AutoSize = true;
            this.lblSeiriNoHi.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblSeiriNoHi.Location = new System.Drawing.Point(154, 592);
            this.lblSeiriNoHi.Name = "lblSeiriNoHi";
            this.lblSeiriNoHi.Size = new System.Drawing.Size(17, 24);
            this.lblSeiriNoHi.TabIndex = 128;
            this.lblSeiriNoHi.Text = "-";
            // 
            // txtSeiriNo2
            // 
            this.txtSeiriNo2.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtSeiriNo2.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.txtSeiriNo2.Location = new System.Drawing.Point(177, 588);
            this.txtSeiriNo2.MaxLength = 4;
            this.txtSeiriNo2.Name = "txtSeiriNo2";
            this.txtSeiriNo2.Size = new System.Drawing.Size(53, 31);
            this.txtSeiriNo2.TabIndex = 6;
            this.txtSeiriNo2.Leave += new System.EventHandler(this.txtSeiriNo2_Leave);
            // 
            // txtSeiriNo1
            // 
            this.txtSeiriNo1.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtSeiriNo1.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.txtSeiriNo1.Location = new System.Drawing.Point(95, 588);
            this.txtSeiriNo1.MaxLength = 4;
            this.txtSeiriNo1.Name = "txtSeiriNo1";
            this.txtSeiriNo1.Size = new System.Drawing.Size(53, 31);
            this.txtSeiriNo1.TabIndex = 5;
            this.txtSeiriNo1.Leave += new System.EventHandler(this.txtSeiriNo1_Leave);
            // 
            // txtTsSyubetu
            // 
            this.txtTsSyubetu.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsTokuteiSisetuTou, "TsSyubetu", true, System.Windows.Forms.DataSourceUpdateMode.Never));
            this.txtTsSyubetu.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtTsSyubetu.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.txtTsSyubetu.Location = new System.Drawing.Point(95, 12);
            this.txtTsSyubetu.MaxLength = 4;
            this.txtTsSyubetu.Name = "txtTsSyubetu";
            this.txtTsSyubetu.Size = new System.Drawing.Size(53, 31);
            this.txtTsSyubetu.TabIndex = 1;
            // 
            // lblTsSyubetu
            // 
            this.lblTsSyubetu.AutoSize = true;
            this.lblTsSyubetu.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblTsSyubetu.Location = new System.Drawing.Point(15, 15);
            this.lblTsSyubetu.Name = "lblTsSyubetu";
            this.lblTsSyubetu.Size = new System.Drawing.Size(74, 24);
            this.lblTsSyubetu.TabIndex = 9;
            this.lblTsSyubetu.Text = "施設種別";
            // 
            // btnSearch
            // 
            this.btnSearch.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnSearch.Location = new System.Drawing.Point(155, 12);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(100, 30);
            this.btnSearch.TabIndex = 2;
            this.btnSearch.Text = "検索";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // lblCountRecord
            // 
            this.lblCountRecord.AutoSize = true;
            this.lblCountRecord.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblCountRecord.Location = new System.Drawing.Point(81, 54);
            this.lblCountRecord.Name = "lblCountRecord";
            this.lblCountRecord.Size = new System.Drawing.Size(20, 24);
            this.lblCountRecord.TabIndex = 7;
            this.lblCountRecord.Text = "0";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.label2.Location = new System.Drawing.Point(15, 54);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 24);
            this.label2.TabIndex = 6;
            this.label2.Text = "件数 = ";
            // 
            // btnBottom
            // 
            this.btnBottom.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnBottom.Location = new System.Drawing.Point(575, 33);
            this.btnBottom.Name = "btnBottom";
            this.btnBottom.Size = new System.Drawing.Size(100, 30);
            this.btnBottom.TabIndex = 4;
            this.btnBottom.Text = "最後";
            this.btnBottom.UseVisualStyleBackColor = true;
            this.btnBottom.Click += new System.EventHandler(this.btnBottom_Click);
            // 
            // btnTop
            // 
            this.btnTop.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnTop.Location = new System.Drawing.Point(469, 33);
            this.btnTop.Name = "btnTop";
            this.btnTop.Size = new System.Drawing.Size(100, 30);
            this.btnTop.TabIndex = 3;
            this.btnTop.Text = "先頭";
            this.btnTop.UseVisualStyleBackColor = true;
            this.btnTop.Click += new System.EventHandler(this.btnTop_Click);
            // 
            // btnSelect
            // 
            this.btnSelect.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnSelect.Location = new System.Drawing.Point(575, 589);
            this.btnSelect.Name = "btnSelect";
            this.btnSelect.Size = new System.Drawing.Size(100, 30);
            this.btnSelect.TabIndex = 7;
            this.btnSelect.Text = "選択";
            this.btnSelect.UseVisualStyleBackColor = true;
            this.btnSelect.Click += new System.EventHandler(this.btnSelect_Click);
            // 
            // dgvJigyojoItiran
            // 
            this.dgvJigyojoItiran.AllowUserToAddRows = false;
            this.dgvJigyojoItiran.AllowUserToDeleteRows = false;
            this.dgvJigyojoItiran.AllowUserToResizeColumns = false;
            this.dgvJigyojoItiran.AllowUserToResizeRows = false;
            this.dgvJigyojoItiran.AutoGenerateColumns = false;
            this.dgvJigyojoItiran.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvJigyojoItiran.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.haisiFlagDataGridViewTextBoxColumn,
            this.seiriNoDataGridViewTextBoxColumn,
            this.jigyosyoNameNDataGridViewTextBoxColumn});
            this.dgvJigyojoItiran.DataSource = this.bsJigyojoItiran;
            this.dgvJigyojoItiran.Location = new System.Drawing.Point(19, 78);
            this.dgvJigyojoItiran.MultiSelect = false;
            this.dgvJigyojoItiran.Name = "dgvJigyojoItiran";
            this.dgvJigyojoItiran.ReadOnly = true;
            this.dgvJigyojoItiran.RowHeadersVisible = false;
            this.dgvJigyojoItiran.RowHeadersWidth = 25;
            this.dgvJigyojoItiran.RowTemplate.Height = 21;
            this.dgvJigyojoItiran.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvJigyojoItiran.Size = new System.Drawing.Size(655, 496);
            this.dgvJigyojoItiran.TabIndex = 0;
            this.dgvJigyojoItiran.CellMouseDoubleClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgvJigyojoItiran_CellMouseDoubleClick);
            // 
            // btnOK
            // 
            this.btnOK.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnOK.Location = new System.Drawing.Point(504, 666);
            this.btnOK.Name = "btnOK";
            this.btnOK.Size = new System.Drawing.Size(100, 30);
            this.btnOK.TabIndex = 8;
            this.btnOK.Text = "OK";
            this.btnOK.UseVisualStyleBackColor = true;
            this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnCancel.Location = new System.Drawing.Point(610, 666);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(100, 30);
            this.btnCancel.TabIndex = 9;
            this.btnCancel.Text = "キャンセル";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // backColorChangeOnFocusProvider1
            // 
            this.backColorChangeOnFocusProvider1.Target = this;
            // 
            // bsTokuteiSisetuTou
            // 
            this.bsTokuteiSisetuTou.DataSource = typeof(Suisitu.Entity.TokuteiSisetuTouEntity);
            // 
            // bsJigyojoItiran
            // 
            this.bsJigyojoItiran.DataSource = typeof(Suisitu.Entity.JigyojoItiranEntity);
            // 
            // jigyojoItiranEntityBindingSource
            // 
            this.jigyojoItiranEntityBindingSource.DataSource = typeof(Suisitu.Entity.JigyojoItiranEntity);
            // 
            // haisiFlagDataGridViewTextBoxColumn
            // 
            this.haisiFlagDataGridViewTextBoxColumn.DataPropertyName = "HaisiFlagV";
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.haisiFlagDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle1;
            this.haisiFlagDataGridViewTextBoxColumn.HeaderText = "廃止";
            this.haisiFlagDataGridViewTextBoxColumn.Name = "haisiFlagDataGridViewTextBoxColumn";
            this.haisiFlagDataGridViewTextBoxColumn.ReadOnly = true;
            this.haisiFlagDataGridViewTextBoxColumn.Width = 65;
            // 
            // seiriNoDataGridViewTextBoxColumn
            // 
            this.seiriNoDataGridViewTextBoxColumn.DataPropertyName = "SeiriNo";
            this.seiriNoDataGridViewTextBoxColumn.HeaderText = "整理番号";
            this.seiriNoDataGridViewTextBoxColumn.Name = "seiriNoDataGridViewTextBoxColumn";
            this.seiriNoDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // jigyosyoNameNDataGridViewTextBoxColumn
            // 
            this.jigyosyoNameNDataGridViewTextBoxColumn.DataPropertyName = "JigyosyoNameN";
            this.jigyosyoNameNDataGridViewTextBoxColumn.HeaderText = "工場事業場名称";
            this.jigyosyoNameNDataGridViewTextBoxColumn.Name = "jigyosyoNameNDataGridViewTextBoxColumn";
            this.jigyosyoNameNDataGridViewTextBoxColumn.ReadOnly = true;
            this.jigyosyoNameNDataGridViewTextBoxColumn.Width = 468;
            // 
            // SeiriNoItiran
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.ClientSize = new System.Drawing.Size(724, 715);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.btnOK);
            this.Controls.Add(this.btnCancel);
            this.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "SeiriNoItiran";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "整理番号一覧";
            this.Load += new System.EventHandler(this.SeiriNoItiran_Load);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvJigyojoItiran)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsTokuteiSisetuTou)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsJigyojoItiran)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.jigyojoItiranEntityBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lblCountRecord;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnBottom;
        private System.Windows.Forms.Button btnTop;
        private System.Windows.Forms.Button btnSelect;
        private System.Windows.Forms.DataGridView dgvJigyojoItiran;
        private System.Windows.Forms.Button btnOK;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Label lblTsSyubetu;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.TextBox txtSeiriNo2;
        private System.Windows.Forms.TextBox txtSeiriNo1;
        private System.Windows.Forms.TextBox txtTsSyubetu;
        private System.Windows.Forms.Label lblSeiriNo;
        private System.Windows.Forms.Label lblSeiriNoHi;
        private System.Windows.Forms.BindingSource bsJigyojoItiran;
        private System.Windows.Forms.BindingSource bsTokuteiSisetuTou;
        private System.Windows.Forms.BindingSource jigyojoItiranEntityBindingSource;
        private Component.BackColorChangeOnFocusProvider backColorChangeOnFocusProvider1;
        private System.Windows.Forms.DataGridViewTextBoxColumn haisiFlagDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn seiriNoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn jigyosyoNameNDataGridViewTextBoxColumn;
    }
}