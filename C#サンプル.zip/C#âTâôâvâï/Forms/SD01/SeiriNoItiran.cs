﻿using Suisitu.Common;
using Suisitu.Dao;
using Suisitu.Entity;
using System;
using System.Windows.Forms;

namespace Suisitu.Forms.SD01
{
    using System.Collections.Generic;
    using System.Linq;
    using CommonEvents = Suisitu.Common.Events;

    /// <summary>
    /// 整理番号一覧画面クラス
    /// </summary>
    public partial class SeiriNoItiran : Form
    {
        //private TokuteiSisetuTouEntity selectedItem_;
        public static TokuteiSisetuTouEntity selectedItem_;

        private string key_;

        /// <summary>
        /// コンストラクタ
        /// </summary>
        /// <param name="selectedItem">一覧で選択されているレコード情報</param>
        public SeiriNoItiran(string key, TokuteiSisetuTouEntity selectedItem)
        {
            InitializeComponent();

            selectedItem_ = selectedItem;

            key_ = key;

            this.txtTsSyubetu.KeyPress += new KeyPressEventHandler(CommonEvents.txtHalfAll_KeyPress);
            this.txtSeiriNo1.KeyPress += new KeyPressEventHandler(CommonEvents.txtHalfAll_KeyPress);
            this.txtSeiriNo2.KeyPress += new KeyPressEventHandler(CommonEvents.txtHalfNumber_KeyPress);
        }

        /// <summary>
        /// 画面が表示されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void SeiriNoItiran_Load(object sender, EventArgs e)
        {
            ////一覧画面で選択されたレコード情報を表示（画面上部）
            //bsTokuteiSisetuTou.DataSource = TokuteiSisetuTouDao.Select(this.selectedItem_);

            ////施設種別テキストボックスの値をセット
            //txtTsSyubetu.Text = key_;
            ////整理番号テキストボックスの値をセット
            //txtSeiriNo1.Text = key_;

            //if (key_ == "E01" || key_ == "E02")
            //{
            //    txtTsSyubetu.Enabled = false;
            //    txtSeiriNo1.Enabled = false;
            //}


            // データを画面表示する
            InitializeData();

            // 画面ロックマトリックスを定義する
            SetLockMatrix();
        }

        /// <summary>
        /// 検索ボタンが選択されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnSearch_Click(object sender, EventArgs e)
        {
            string tsSyubetu = txtTsSyubetu.Text;

            // 整理番号一覧取得・表示（DataGridView）
            //bsJigyojoItiran.DataSource = JigyojoItiranDao.SelectList(selectedItem_);
            IEnumerable<JigyojoItiranEntity> list = JigyojoItiranDao.SelectList(tsSyubetu);
            bsJigyojoItiran.DataSource = list;
            lblCountRecord.Text = list.Count().ToString();

            // 整理番号一覧レコードカウンタを更新する
            //lblCountRecord.Text = bsJigyojoItiran.Count.ToString();

            // 画面ロックマトリックスを定義する
            SetLockMatrix();
        }

        /// <summary>
        /// 選択ボタンが選択されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnSelect_Click(object sender, EventArgs e)
        {
            string tsSyubetu = txtTsSyubetu.Text;

            //選択行の整理番号を画面下部の整理番号テキストボックスに分割して表示
            string SeiriNo = dgvJigyojoItiran.CurrentRow.Cells[1].Value.ToString();

            if (tsSyubetu == "E01" || tsSyubetu == "E02")
            {
                //施設区分がE01、E02のどちらかの場合先頭3桁の値を格納
                txtSeiriNo1.Text = SeiriNo.Substring(0, 3);
            }
            else
            {
                //施設区分が特定施設の場合、先頭3桁の値を0埋めでフォーマットして格納
                txtSeiriNo1.Text = string.Format("{0:D3}", int.Parse(SeiriNo.Substring(0, 3)));
            }

            txtSeiriNo2.Text = string.Format("{0:D4}", int.Parse(SeiriNo.Substring(4, 4)) + 1);

            SeiriNo = null;
        }

        /// <summary>
        /// ＜特定施設等施設一覧＞
        /// データグリッドビューのセルがダブルクリックされたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void dgvJigyojoItiran_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (bsTokuteiSisetuTou.Current != null)
            {
                string tsSyubetu = txtTsSyubetu.Text;

                //選択行の整理番号を画面下部の整理番号テキストボックスに分割して表示
                string SeiriNo = dgvJigyojoItiran.CurrentRow.Cells[1].Value.ToString();

                if (tsSyubetu == "E01" || tsSyubetu == "E02")
                {
                    //施設区分がE01、E02のどちらかの場合先頭3桁の値を格納
                    txtSeiriNo1.Text = SeiriNo.Substring(0, 3);
                }
                else
                {
                    //施設区分が特定施設の場合、先頭3桁の値を0埋めでフォーマットして格納
                    txtSeiriNo1.Text = string.Format("{0:D3}", int.Parse(SeiriNo.Substring(0, 3)));
                }

                txtSeiriNo2.Text = string.Format("{0:D4}", int.Parse(SeiriNo.Substring(4, 4)) + 1);

                SeiriNo = null;
            }
        }

        /// <summary>
        /// OKボタンが選択されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnOK_Click(object sender, EventArgs e)
        {
            if (!Validation())
                return;

            //TokuteiSisetuTouJyoho.txtSeiriNo1_ = txtSeiriNo1.Text;
            //TokuteiSisetuTouJyoho.txtSeiriNo2_ = txtSeiriNo2.Text;

            selectedItem_.SeiriNo = txtSeiriNo1.Text + "-" + txtSeiriNo2.Text;
            selectedItem_.DaihyoFlag = "1";

            //自画面を閉じる
            Close();
        }

        /// <summary>
        /// 先頭ボタンが選択されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnTop_Click(object sender, EventArgs e)
        {
            //if(dgvJigyojoItiran.RowCount > 1)
            //{
            //    //一覧の先頭行を選択状態にする
            //    dgvJigyojoItiran.Rows[0].Selected = true;
            //    dgvJigyojoItiran.CurrentCell = dgvJigyojoItiran[0, 0];
            //}

            bsJigyojoItiran.MoveFirst();
        }

        /// <summary>
        /// 最後ボタンが選択されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnBottom_Click(object sender, EventArgs e)
        {
            //if (dgvJigyojoItiran.RowCount > 1)
            //{
            //    //一覧の最終行を選択状態にする
            //    dgvJigyojoItiran.Rows[dgvJigyojoItiran.RowCount - 1].Selected = true;
            //    dgvJigyojoItiran.CurrentCell = dgvJigyojoItiran[0, dgvJigyojoItiran.RowCount - 1];
            //}

            bsJigyojoItiran.MoveLast();
        }

        /// <summary>
        /// キャンセルボタンが選択されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnCancel_Click(object sender, EventArgs e)
        {
            //自画面を閉じる
            Close();
        }

        /// <summary>
        /// 整理番号テキストボックス（左）のフォーカスが外れたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void txtSeiriNo1_Leave(object sender, EventArgs e)
        {
            FormatSeiriNo(sender);
        }

        /// <summary>
        /// 整理番号テキストボックス（右）のフォーカスが外れたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void txtSeiriNo2_Leave(object sender, EventArgs e)
        {
            FormatSeiriNo(sender);
        }

        #region プライベートメソッド

        /// <summary>
        /// 画面に表示するデータを初期化します。
        /// </summary>
        private void InitializeData()
        {
            //Clear();

            //switch (actionMode_)
            //{
            //    // 選択、複写の場合
            //    case EnumActionKbn.Select:
            //    case EnumActionKbn.Copy:

            //        TokuteiSisetuTouEntity descEntity = new TokuteiSisetuTouEntity();
            //        BeanUtils.CopyObjectProperties(selectedItem_, descEntity);

            //        if (actionMode_ == EnumActionKbn.Copy)
            //        {
            //            descEntity.TsNo = TokuteiSisetuTouDao.GetNewTsNo(descEntity);
            //        }

            //        bsTokuteiSisetuTou.DataSource = descEntity;

            //        cboSisetuKbn.SelectedKey = descEntity.SisetuKbn;
            //        cboTsSyubetu.SelectedKey = descEntity.TsSyubetu;
            //        cboTsSyubetuSai.Value = descEntity.TsSyubetuSai;
            //        wrkSetiDate.Value = descEntity.SetiDate;
            //        wrkHaisiDate.Value = descEntity.HaisiDate;

            //        break;

            //    // 追加の場合
            //    case EnumActionKbn.Add:

            //        txtTsNo.Text = TokuteiSisetuTouDao.GetNewTsNo(selectedItem_);

            //        break;
            //}

            //一覧画面で選択されたレコード情報を表示（画面上部）
            bsJigyojoItiran.DataSource = TokuteiSisetuTouDao.Select(key_);//////////

            //施設種別テキストボックスの値をセット
            txtTsSyubetu.Text = key_;
            //整理番号テキストボックスの値をセット
            txtSeiriNo1.Text = key_;
        }

        /// <summary>
        /// ロックマトリックス定義
        /// </summary>
        private void SetLockMatrix()
        {
            if (key_ == "E01" || key_ == "E02")
            {
                txtTsSyubetu.Enabled = false;
                txtSeiriNo1.Enabled = false;
            }
            
            if (bsJigyojoItiran.Count == 0)
            {
                btnSelect.Enabled = false;
            }
            else
            {
                btnSelect.Enabled = true;
            }
        }

        /// <summary>
        /// バリデーションをチェックします。
        /// </summary>
        /// <returns>True:チェックOK / False:チェックNG</returns>
        private bool Validation()
        {
            // 必須入力チェック
            if (string.IsNullOrEmpty(txtSeiriNo1.Text))
            {
                MessageUtils.NoInputDataMessage(CommonUtils.Trim(lblSeiriNo.Text), Text);
                txtSeiriNo1.Focus();
                return false;
            }

            if (string.IsNullOrEmpty(txtSeiriNo2.Text))
            {
                MessageUtils.NoInputDataMessage(CommonUtils.Trim(lblSeiriNo.Text), Text);
                txtSeiriNo2.Focus();
                return false;
            }

            return true;
        }

        /// <summary>
        /// 整理番号を0埋め形式にフォーマットします。
        /// </summary>
        /// <param name="sender">呼び出し元テキストボックスのNameプロパティ</param>
        private void FormatSeiriNo(object sender)
        {
            int i;

            if (((TextBox)sender).Name == "txtSeiriNo1")
            {
                if (!int.TryParse(txtSeiriNo1.Text, out i) && !string.IsNullOrEmpty(txtSeiriNo1.Text))
                {
                    //入力された値が数値でなない場合メッセージを表示
                    MessageUtils.TypeErrorMessage(CommonUtils.Trim(lblSeiriNo.Text), Text);
                    txtSeiriNo1.Focus();
                    return;
                }

                //入力された値が数値の場合0埋め3桁の形式にフォーマットする
                if (!string.IsNullOrEmpty(txtSeiriNo1.Text))
                {
                    txtSeiriNo1.Text = string.Format("{0:D3}", int.Parse(txtSeiriNo1.Text));
                }
            }
            else
            {
                if (!int.TryParse(txtSeiriNo2.Text, out i) && !string.IsNullOrEmpty(txtSeiriNo2.Text))
                {
                    //入力された値が数値でなない場合メッセージを表示
                    MessageUtils.TypeErrorMessage(CommonUtils.Trim(lblSeiriNo.Text), Text);
                    txtSeiriNo2.Focus();
                    return;
                }

                //入力された値が数値の場合0埋め4桁の形式にフォーマットする
                if (!string.IsNullOrEmpty(txtSeiriNo2.Text))
                {
                    txtSeiriNo2.Text = string.Format("{0:D4}", int.Parse(txtSeiriNo2.Text));
                }
            }
        }

        #endregion
    }
}
