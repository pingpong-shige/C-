﻿namespace Suisitu.Forms.SD01
{
    partial class SyoriSisetuJyoho
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lblSsNo = new System.Windows.Forms.Label();
            this.lblSisetuNameN = new System.Windows.Forms.Label();
            this.lblTdkdJuriDate = new System.Windows.Forms.Label();
            this.lblBiko = new System.Windows.Forms.Label();
            this.txtSsNo = new System.Windows.Forms.TextBox();
            this.bsShoriSisetu = new System.Windows.Forms.BindingSource(this.components);
            this.txtSisetuNameN = new System.Windows.Forms.TextBox();
            this.txtBiko = new System.Windows.Forms.TextBox();
            this.wdTdkdJuriDate = new Suisitu.Components.Controls.WarekiDate();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnReturn = new System.Windows.Forms.Button();
            this.btnRegist = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.backColorChangeOnFocusProvider1 = new Suisitu.Component.BackColorChangeOnFocusProvider();
            ((System.ComponentModel.ISupportInitialize)(this.bsShoriSisetu)).BeginInit();
            this.SuspendLayout();
            // 
            // lblSsNo
            // 
            this.lblSsNo.AutoSize = true;
            this.lblSsNo.Location = new System.Drawing.Point(15, 49);
            this.lblSsNo.Name = "lblSsNo";
            this.lblSsNo.Size = new System.Drawing.Size(106, 24);
            this.lblSsNo.TabIndex = 0;
            this.lblSsNo.Text = "処理施設番号";
            // 
            // lblSisetuNameN
            // 
            this.lblSisetuNameN.AutoSize = true;
            this.lblSisetuNameN.Location = new System.Drawing.Point(15, 82);
            this.lblSisetuNameN.Name = "lblSisetuNameN";
            this.lblSisetuNameN.Size = new System.Drawing.Size(74, 24);
            this.lblSisetuNameN.TabIndex = 0;
            this.lblSisetuNameN.Text = "施設名称";
            // 
            // lblTdkdJuriDate
            // 
            this.lblTdkdJuriDate.AutoSize = true;
            this.lblTdkdJuriDate.Location = new System.Drawing.Point(15, 115);
            this.lblTdkdJuriDate.Name = "lblTdkdJuriDate";
            this.lblTdkdJuriDate.Size = new System.Drawing.Size(138, 24);
            this.lblTdkdJuriDate.TabIndex = 0;
            this.lblTdkdJuriDate.Text = "最新届出等受理日";
            // 
            // lblBiko
            // 
            this.lblBiko.AutoSize = true;
            this.lblBiko.Location = new System.Drawing.Point(15, 148);
            this.lblBiko.Name = "lblBiko";
            this.lblBiko.Size = new System.Drawing.Size(42, 24);
            this.lblBiko.TabIndex = 0;
            this.lblBiko.Text = "備考";
            // 
            // txtSsNo
            // 
            this.txtSsNo.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsShoriSisetu, "SsNo", true, System.Windows.Forms.DataSourceUpdateMode.Never));
            this.txtSsNo.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.txtSsNo.Location = new System.Drawing.Point(162, 46);
            this.txtSsNo.MaxLength = 3;
            this.txtSsNo.Name = "txtSsNo";
            this.txtSsNo.Size = new System.Drawing.Size(53, 31);
            this.txtSsNo.TabIndex = 4;
            // 
            // bsShoriSisetu
            // 
            this.bsShoriSisetu.DataSource = typeof(Suisitu.Entity.SyoriSisetuEntity);
            // 
            // txtSisetuNameN
            // 
            this.txtSisetuNameN.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsShoriSisetu, "SisetuNameN", true, System.Windows.Forms.DataSourceUpdateMode.Never));
            this.txtSisetuNameN.ImeMode = System.Windows.Forms.ImeMode.Hiragana;
            this.txtSisetuNameN.Location = new System.Drawing.Point(162, 79);
            this.txtSisetuNameN.MaxLength = 100;
            this.txtSisetuNameN.Name = "txtSisetuNameN";
            this.txtSisetuNameN.Size = new System.Drawing.Size(322, 31);
            this.txtSisetuNameN.TabIndex = 5;
            // 
            // txtBiko
            // 
            this.txtBiko.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsShoriSisetu, "Biko", true, System.Windows.Forms.DataSourceUpdateMode.Never));
            this.txtBiko.ImeMode = System.Windows.Forms.ImeMode.Hiragana;
            this.txtBiko.Location = new System.Drawing.Point(162, 145);
            this.txtBiko.MaxLength = 100;
            this.txtBiko.Multiline = true;
            this.txtBiko.Name = "txtBiko";
            this.txtBiko.ScrollBars = System.Windows.Forms.ScrollBars.Horizontal;
            this.txtBiko.Size = new System.Drawing.Size(563, 78);
            this.txtBiko.TabIndex = 7;
            // 
            // wdTdkdJuriDate
            // 
            this.wdTdkdJuriDate.Location = new System.Drawing.Point(162, 112);
            this.wdTdkdJuriDate.Name = "wdTdkdJuriDate";
            this.wdTdkdJuriDate.Size = new System.Drawing.Size(102, 31);
            this.wdTdkdJuriDate.TabIndex = 6;
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(519, 15);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(100, 30);
            this.btnCancel.TabIndex = 2;
            this.btnCancel.Text = "キャンセル";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnReturn
            // 
            this.btnReturn.Location = new System.Drawing.Point(625, 15);
            this.btnReturn.Name = "btnReturn";
            this.btnReturn.Size = new System.Drawing.Size(100, 30);
            this.btnReturn.TabIndex = 3;
            this.btnReturn.Text = "戻る";
            this.btnReturn.UseVisualStyleBackColor = true;
            this.btnReturn.Click += new System.EventHandler(this.btnReturn_Click);
            // 
            // btnRegist
            // 
            this.btnRegist.Location = new System.Drawing.Point(413, 15);
            this.btnRegist.Name = "btnRegist";
            this.btnRegist.Size = new System.Drawing.Size(100, 30);
            this.btnRegist.TabIndex = 1;
            this.btnRegist.Text = "登録";
            this.btnRegist.UseVisualStyleBackColor = true;
            this.btnRegist.Click += new System.EventHandler(this.btnRegist_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(625, 238);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(100, 30);
            this.btnDelete.TabIndex = 8;
            this.btnDelete.Text = "削除";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // backColorChangeOnFocusProvider1
            // 
            this.backColorChangeOnFocusProvider1.Target = this;
            // 
            // SyoriSisetuJyoho
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.ClientSize = new System.Drawing.Size(742, 285);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnRegist);
            this.Controls.Add(this.btnReturn);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.wdTdkdJuriDate);
            this.Controls.Add(this.txtBiko);
            this.Controls.Add(this.txtSisetuNameN);
            this.Controls.Add(this.txtSsNo);
            this.Controls.Add(this.lblBiko);
            this.Controls.Add(this.lblTdkdJuriDate);
            this.Controls.Add(this.lblSisetuNameN);
            this.Controls.Add(this.lblSsNo);
            this.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "SyoriSisetuJyoho";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "処理施設情報";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.SyoriSisetuJyoho_FormClosing);
            this.Load += new System.EventHandler(this.SyoriSisetuJyoho_Load);
            ((System.ComponentModel.ISupportInitialize)(this.bsShoriSisetu)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblSsNo;
        private System.Windows.Forms.Label lblSisetuNameN;
        private System.Windows.Forms.Label lblTdkdJuriDate;
        private System.Windows.Forms.Label lblBiko;
        private System.Windows.Forms.TextBox txtSsNo;
        private System.Windows.Forms.TextBox txtSisetuNameN;
        private System.Windows.Forms.TextBox txtBiko;
        private Components.Controls.WarekiDate wdTdkdJuriDate;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnReturn;
        private System.Windows.Forms.Button btnRegist;
        private System.Windows.Forms.Button btnDelete;
        private Component.BackColorChangeOnFocusProvider backColorChangeOnFocusProvider1;
        private System.Windows.Forms.BindingSource bsShoriSisetu;
    }
}