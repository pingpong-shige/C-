﻿using Suisitu.Common;
using Suisitu.Dao;
using Suisitu.Entity;
using Suisitu.Enum;
using System;
using System.Windows.Forms;

namespace Suisitu.Forms.SD01
{
    #pragma warning disable 168

    using CommonEvents = Suisitu.Common.Events;

    /// <summary>
    /// 処理施設情報画面クラス
    /// </summary>
    public partial class SyoriSisetuJyoho : Form
    {
        // 処理施設情報
        private SyoriSisetuEntity selectedItem_;

        // アクションモード
        private EnumActionKbn actionMode_;

        // 新規追加された処理施設番号(処理施設一覧のフォーカス用)
        public string addedSsNo_ = "";

        #region コンストラクタ

        /// <summary>
        /// コンストラクタ
        /// </summary>
        /// <param name="key">処理施設情報</param>
        /// <param name="mode">アクションモード</param>
        public SyoriSisetuJyoho(SyoriSisetuEntity key, EnumActionKbn mode)
        {
            InitializeComponent();

            selectedItem_ = key;
            actionMode_ = mode;
            
            this.wdTdkdJuriDate.KeyPress += new KeyPressEventHandler(CommonEvents.txtHalfNumber_KeyPress);
        }
        #endregion

        #region イベント

        /// <summary>
        /// 画面が表示されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void SyoriSisetuJyoho_Load(object sender, EventArgs e)
        {
            // 画面ロックマトリックスを定義する
            SetLockMatrix();

            // データを画面表示する
            InitializeData();
        }

        /// <summary>
        /// 戻るボタンが選択されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnReturn_Click(object sender, EventArgs e)
        {
            Return();
        }

        /// <summary>
        /// キャンセルボタンが選択されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnCancel_Click(object sender, EventArgs e)
        {
            InitializeData();
        }

        /// <summary>
        /// 登録が選択されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnRegist_Click(object sender, EventArgs e)
        {
            // 登録データを作成する
            SyoriSisetuEntity entity = CreateRegisterData();

            // バリデーションチェックする
            if (!Validation(entity))
                return;

            // 処理施設情報を登録する
            Register(entity);

            // 画面を閉じるときの前処理
            ClosingPreprocessing();

            Close();
        }

        /// <summary>
        /// 削除ボタンが選択されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnDelete_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("表示中のデータを削除します。よろしいですか？", Text,
                MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button2);

            if (result == DialogResult.Yes)
            {
                SyoriSisetuDao.Delete((SyoriSisetuEntity)bsShoriSisetu.Current);
            }

            // 画面を閉じるときの前処理
            ClosingPreprocessing();

            Close();
        }

        /// <summary>
        /// 画面を閉じるときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void SyoriSisetuJyoho_FormClosing(object sender, FormClosingEventArgs e)
        {
            // 各種ボタンイベントから画面を閉じる場合
            if (this.Tag == null)
                Return(e);
        }

        #endregion

        #region プライベートメソッド

        /// <summary>
        /// 画面に表示するデータを初期化します。
        /// </summary>
        private void InitializeData()
        {
            Clear();
            
            switch (actionMode_)
            {
                // 選択、複写の場合
                case EnumActionKbn.Select:
                case EnumActionKbn.Copy:

                    SyoriSisetuEntity descEntity = new SyoriSisetuEntity();
                    BeanUtils.CopyObjectProperties(selectedItem_, descEntity);

                    if (actionMode_ == EnumActionKbn.Copy)
                    {
                        descEntity.SsNo = SyoriSisetuDao.GetNewSsNo(descEntity);
                    }

                    bsShoriSisetu.DataSource = descEntity;
                    
                    wdTdkdJuriDate.Value = descEntity.TdkdjuriDate;

                    break;

                // 追加の場合
                case EnumActionKbn.Add:

                    txtSsNo.Text = SyoriSisetuDao.GetNewSsNo(selectedItem_);

                    break;
            }
        }

        /// <summary>
        /// ロックマトリックス定義
        /// </summary>
        private void SetLockMatrix()
        {
            txtSsNo.Enabled = false;

            // 追加と複写の場合は削除ボタンを入力不可にする
            if (actionMode_ == EnumActionKbn.Add || actionMode_ == EnumActionKbn.Copy)
            {
                btnDelete.Enabled = false;
            }

            // 年度が通年以外の場合
            if (selectedItem_.Nendo != 9999)
            {
                btnRegist.Enabled = false;
                btnCancel.Enabled = false;
                btnDelete.Enabled = false;
                txtSisetuNameN.Enabled = false;
                wdTdkdJuriDate.Enabled = false;
                txtBiko.Enabled = false;
            }
        }

        /// <summary>
        /// 画面のクリア処理
        /// </summary>
        private void Clear()
        {
            bsShoriSisetu.Clear();

            txtSsNo.Clear();
            txtSisetuNameN.Clear();
            wdTdkdJuriDate.Value = null;
            txtBiko.Clear();
        }

        /// <summary>
        /// 呼び出し元の画面に戻ります。
        /// </summary>
        private void Return(FormClosingEventArgs close = null)
        {
            try
            {
                if (actionMode_ == EnumActionKbn.Add || actionMode_ == EnumActionKbn.Copy
                    || !CompareToControlsAndObject(selectedItem_))
                {
                    DialogResult result = MessageBox.Show("編集中のデータを保存しますか？", Text,
                        MessageBoxButtons.YesNo, MessageBoxIcon.Information, MessageBoxDefaultButton.Button2);

                    if (result == DialogResult.Yes)
                    {
                        // 登録データを作成する
                        SyoriSisetuEntity entity = CreateRegisterData();

                        // バリデーションチェックする
                        if (!Validation(entity))
                        {
                            // FormClosingイベントを中止
                            if (close != null)
                                close.Cancel = true;

                            return;
                        }

                        // 処理施設情報を登録する
                        Register(entity);
                    }
                }
            }
            catch (Exception ex)
            {
                // なにもしない
            }

            // 画面を閉じるときの前処理
            ClosingPreprocessing();

            Close();
        }

        /// <summary>
        /// 編集前と編集後を比較します。
        /// (データソースとコントロール値を比較します。)
        /// </summary>
        /// <param name="source">編集前のオブジェクト</param>
        /// <returns>True:差異なし / False:差異あり</returns>
        private bool CompareToControlsAndObject(SyoriSisetuEntity source)
        {
            // 処理施設管理番号
            if (txtSsNo.Text != source.SsNo)
                return false;

            // 施設名称
            if (txtSisetuNameN.Text != source.SisetuNameN)
                return false;

            // 最新届出等受理日
            if (CommonUtils.FormatToDate(wdTdkdJuriDate.Value) != source.TdkdjuriDate)
                return false;

            // 備考
            if (txtBiko.Text != source.Biko)
                return false;

            return true;
        }

        /// <summary>
        /// バリデーションをチェックします。
        /// </summary>
        /// <returns>True:チェックOK / False:チェックNG</returns>
        private bool Validation(SyoriSisetuEntity entity)
        {
            // バリデーションが必要な項目は特になし

            return true;
        }


        /// <summary>
        /// 登録用処理施設情報を作成します。
        /// </summary>
        /// <returns>処理施設情報</returns>
        private SyoriSisetuEntity CreateRegisterData()
        {
            // 登録データを作成する
            SyoriSisetuEntity entity = new SyoriSisetuEntity
            {
                Nendo = selectedItem_.Nendo,
                KanriNo = selectedItem_.KanriNo,
                SsNo = txtSsNo.Text,
                SisetuNameN = txtSisetuNameN.Text,
                TdkdjuriDate = CommonUtils.FormatToDate(wdTdkdJuriDate.Value),
                Biko = txtBiko.Text,
                TorokuDate = DateTime.Now.ToString(),
                UpdDate = DateTime.Now.ToString(),
                Rev = 1,
            };

            return entity;
        }

        /// <summary>
        /// 処理施設情報を登録します。
        /// </summary>
        /// <param name="entity">処理施設情報</param>
        private void Register(SyoriSisetuEntity entity)
        {
            // 該当データが存在しない場合
            if (SyoriSisetuDao.Select(entity) == null)
            {
                // 処理施設情報を登録する
                SyoriSisetuDao.Insert(entity);

                // 登録された処理施設番号を保持する
                addedSsNo_ = entity.SsNo;
            }
            // 該当データが存在する場合
            else
            {
                // 処理施設情報を更新する
                SyoriSisetuDao.Update(entity);
            }
        }

        /// <summary>
        /// 画面を閉じるときの前処理
        /// </summary>
        private void ClosingPreprocessing()
        {
            this.Tag = true;
        }

        #endregion

    }
}
