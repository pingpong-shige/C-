﻿namespace Suisitu.Forms.SD01
{
    partial class TodokedeKanri
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            this.tabTodokedeKanri = new System.Windows.Forms.TabControl();
            this.tabKojyoKihon = new System.Windows.Forms.TabPage();
            this.lblGesuikbn = new System.Windows.Forms.Label();
            this.btnCopy2 = new System.Windows.Forms.Button();
            this.lblSaisuiLine = new System.Windows.Forms.Label();
            this.lblOdakuCopName = new System.Windows.Forms.Label();
            this.txtBiko4 = new System.Windows.Forms.TextBox();
            this.lblSaisui = new System.Windows.Forms.Label();
            this.txtOdakuNameN = new System.Windows.Forms.TextBox();
            this.lblSaisuiNameN = new System.Windows.Forms.Label();
            this.lblOdakuYubinNo = new System.Windows.Forms.Label();
            this.lblSaisuiFaxNo = new System.Windows.Forms.Label();
            this.lblBiko4 = new System.Windows.Forms.Label();
            this.lblOdakuFkaryoSofusakiLine = new System.Windows.Forms.Label();
            this.lblOdakuNameN = new System.Windows.Forms.Label();
            this.txtSaisuiNameN = new System.Windows.Forms.TextBox();
            this.txtOdakuCopName = new System.Windows.Forms.TextBox();
            this.lblOdakuFukaryoSofusaki = new System.Windows.Forms.Label();
            this.txtOdakuYubinNo1 = new System.Windows.Forms.TextBox();
            this.txtSaisuiFaxNo = new System.Windows.Forms.TextBox();
            this.txtOdakuJyusyo = new System.Windows.Forms.TextBox();
            this.btnSiyoJokyo = new System.Windows.Forms.Button();
            this.lblSofusakiYubinNoHi = new System.Windows.Forms.Label();
            this.txtBiko5 = new System.Windows.Forms.TextBox();
            this.lblOdakuJyusyo = new System.Windows.Forms.Label();
            this.lblKihonkomoku2Line = new System.Windows.Forms.Label();
            this.txtOdakuYubinNo2 = new System.Windows.Forms.TextBox();
            this.lblBiko5 = new System.Windows.Forms.Label();
            this.lblKihonkomoku2 = new System.Windows.Forms.Label();
            this.txtKankyosyoCode = new System.Windows.Forms.TextBox();
            this.lblKihonkomoku1Line = new System.Windows.Forms.Label();
            this.lblKihonkomoku1 = new System.Windows.Forms.Label();
            this.lblChozoSite = new System.Windows.Forms.Label();
            this.lblKankyosyoCode = new System.Windows.Forms.Label();
            this.btnCopy1 = new System.Windows.Forms.Button();
            this.lblSiyoTokute2 = new System.Windows.Forms.Label();
            this.lblSiyoTokute1 = new System.Windows.Forms.Label();
            this.lblYugaiUm = new System.Windows.Forms.Label();
            this.txtBiko2 = new System.Windows.Forms.TextBox();
            this.chkYokakunin = new System.Windows.Forms.CheckBox();
            this.chkYugaiUm = new System.Windows.Forms.CheckBox();
            this.lblTodokedeSinseishaLine = new System.Windows.Forms.Label();
            this.chkChosataisho = new System.Windows.Forms.CheckBox();
            this.chkKosyohoJunyoSite = new System.Windows.Forms.CheckBox();
            this.lblSinseiCopName = new System.Windows.Forms.Label();
            this.chkKosyohoSite = new System.Windows.Forms.CheckBox();
            this.chkKosyoTokute = new System.Windows.Forms.CheckBox();
            this.lblTodokedeSinseisha = new System.Windows.Forms.Label();
            this.chkChozoSiteKakosiyo = new System.Windows.Forms.CheckBox();
            this.chkKyote2 = new System.Windows.Forms.CheckBox();
            this.chkChozoSite = new System.Windows.Forms.CheckBox();
            this.lblBiko2 = new System.Windows.Forms.Label();
            this.chkSiyoTokute2Kakosiyo = new System.Windows.Forms.CheckBox();
            this.chkZanteiKijunFlag = new System.Windows.Forms.CheckBox();
            this.chkSiyoTokute2 = new System.Windows.Forms.CheckBox();
            this.txtSyozaiJyusyo = new System.Windows.Forms.TextBox();
            this.chkSiyoTokute1Kakosiyo = new System.Windows.Forms.CheckBox();
            this.chkHaisuiKijun = new System.Windows.Forms.CheckBox();
            this.chkSiyoTokute1 = new System.Windows.Forms.CheckBox();
            this.txtSinseiNameN = new System.Windows.Forms.TextBox();
            this.chkTadasigaki2 = new System.Windows.Forms.CheckBox();
            this.btnCancelKojoKihon = new System.Windows.Forms.Button();
            this.lblSoryoKiseiNo = new System.Windows.Forms.Label();
            this.lblSinseiYubinNo = new System.Windows.Forms.Label();
            this.txtSoryoKiseiNo = new System.Windows.Forms.TextBox();
            this.lblSyozaiJyusyo = new System.Windows.Forms.Label();
            this.txtBiko3 = new System.Windows.Forms.TextBox();
            this.lblSinseiNameN = new System.Windows.Forms.Label();
            this.lblSangyoBC = new System.Windows.Forms.Label();
            this.lblBiko3 = new System.Windows.Forms.Label();
            this.btnRegistKojoKihon = new System.Windows.Forms.Button();
            this.lblSangyoBS = new System.Windows.Forms.Label();
            this.txtSinseiCopName = new System.Windows.Forms.TextBox();
            this.txtBiko1 = new System.Windows.Forms.TextBox();
            this.lblHoKbnCode = new System.Windows.Forms.Label();
            this.txtSinseiTelNo = new System.Windows.Forms.TextBox();
            this.lblKojoKihon = new System.Windows.Forms.Label();
            this.lblSinseiTelNo = new System.Windows.Forms.Label();
            this.lblJigyosyoNameN = new System.Windows.Forms.Label();
            this.txtSinseiYubinNo1 = new System.Windows.Forms.TextBox();
            this.lblBiko1 = new System.Windows.Forms.Label();
            this.txtSinseiJyusyo = new System.Windows.Forms.TextBox();
            this.lblRyuikiCode = new System.Windows.Forms.Label();
            this.lblJigyojoLine = new System.Windows.Forms.Label();
            this.lblSikibetuCode = new System.Windows.Forms.Label();
            this.lblTodokedeYubinNoHi = new System.Windows.Forms.Label();
            this.lblJigyosyoNameK = new System.Windows.Forms.Label();
            this.lblSinseiJyusyo = new System.Windows.Forms.Label();
            this.lblJigyojo = new System.Windows.Forms.Label();
            this.txtSinseiYubinNo2 = new System.Windows.Forms.TextBox();
            this.txtKTantoNameN = new System.Windows.Forms.TextBox();
            this.lbltxtSyozaiYubinNo = new System.Windows.Forms.Label();
            this.lblKTantoNameN = new System.Windows.Forms.Label();
            this.txtJigyosyoNameN = new System.Windows.Forms.TextBox();
            this.txtTelNo = new System.Windows.Forms.TextBox();
            this.txtJigyosyoNameK = new System.Windows.Forms.TextBox();
            this.lbltxtTelNo = new System.Windows.Forms.Label();
            this.txtSyozaiYubinNo2 = new System.Windows.Forms.TextBox();
            this.txtSyozaiYubinNo1 = new System.Windows.Forms.TextBox();
            this.lblJigyojoYubinNoHi = new System.Windows.Forms.Label();
            this.tabTodokedeRireki = new System.Windows.Forms.TabPage();
            this.lblCountNumberTodokedeRireki = new System.Windows.Forms.Label();
            this.dgvTodokedeRireki = new System.Windows.Forms.DataGridView();
            this.lblCountRecordTodokedeRireki = new System.Windows.Forms.Label();
            this.lblTodokedeRireki = new System.Windows.Forms.Label();
            this.btnCopyTodokedeRireki = new System.Windows.Forms.Button();
            this.btnSelectTodokedeRireki = new System.Windows.Forms.Button();
            this.btnAddTodokedeRireki = new System.Windows.Forms.Button();
            this.tabTokuteiSisetu = new System.Windows.Forms.TabPage();
            this.lblCountRecordTokuteiSisetuTou = new System.Windows.Forms.Label();
            this.lblCountNumberTokuteiSisetu = new System.Windows.Forms.Label();
            this.lblTokuteiSisetu = new System.Windows.Forms.Label();
            this.btnCopyTokuteiSisetuTou = new System.Windows.Forms.Button();
            this.btnSelectTokuteiSisetuTou = new System.Windows.Forms.Button();
            this.btnAddTokuteiSisetuTou = new System.Windows.Forms.Button();
            this.dgvTokuteiSisetuTou = new System.Windows.Forms.DataGridView();
            this.tabFutaisetubi = new System.Windows.Forms.TabPage();
            this.lblCountRecordFutaiSetubiTou = new System.Windows.Forms.Label();
            this.lblCountNumberFutaiSetubiTou = new System.Windows.Forms.Label();
            this.lblFutaiSetubiTou = new System.Windows.Forms.Label();
            this.btnCopyFutaiSetubiTou = new System.Windows.Forms.Button();
            this.btnSelectFutaiSetubiTou = new System.Windows.Forms.Button();
            this.btnAddFutaiSetubiTou = new System.Windows.Forms.Button();
            this.dgvFutaiSetubiTou = new System.Windows.Forms.DataGridView();
            this.tabShoriSisetu = new System.Windows.Forms.TabPage();
            this.lblCountRecordShoriSisetu = new System.Windows.Forms.Label();
            this.lblCountNumberShoriSisetu = new System.Windows.Forms.Label();
            this.lblShoriSisetu = new System.Windows.Forms.Label();
            this.btnCopyShoriSisetu = new System.Windows.Forms.Button();
            this.btnSelectShoriSisetu = new System.Windows.Forms.Button();
            this.btnAddShoriSisetu = new System.Windows.Forms.Button();
            this.dgvShoriSisetu = new System.Windows.Forms.DataGridView();
            this.TdkdjuriDateShortW = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SsNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabHaisuiko = new System.Windows.Forms.TabPage();
            this.chkHaisuikijyunTekiyo = new System.Windows.Forms.CheckBox();
            this.chkKojimaKoRyuiki = new System.Windows.Forms.CheckBox();
            this.chkKaisuiGanyuFlag = new System.Windows.Forms.CheckBox();
            this.txtTdkdhsMax = new System.Windows.Forms.TextBox();
            this.txtUsuiHaisuikoSu = new System.Windows.Forms.TextBox();
            this.txtTdkdhsAve = new System.Windows.Forms.TextBox();
            this.lblTdkdHsMax = new System.Windows.Forms.Label();
            this.lblTdkdHsMaxUnit = new System.Windows.Forms.Label();
            this.lblTdkdHsAveUnit = new System.Windows.Forms.Label();
            this.lblUsuiHaisuikoSu = new System.Windows.Forms.Label();
            this.lblTdkdHsAve = new System.Windows.Forms.Label();
            this.lblCountRecordHaisuiko = new System.Windows.Forms.Label();
            this.lblCountNumberHaisuiko = new System.Windows.Forms.Label();
            this.lblHaisuiko = new System.Windows.Forms.Label();
            this.btnCopyHaisuiko = new System.Windows.Forms.Button();
            this.btnSelectHaisuiko = new System.Windows.Forms.Button();
            this.btnHaisuikijyunTou = new System.Windows.Forms.Button();
            this.btnHaisuikoJyoho = new System.Windows.Forms.Button();
            this.btnAddHaisuiko = new System.Windows.Forms.Button();
            this.dgvHaisuiko = new System.Windows.Forms.DataGridView();
            this.tabOdakuFukaryo = new System.Windows.Forms.TabPage();
            this.tblOdakuFukaryo = new System.Windows.Forms.TableLayoutPanel();
            this.lblSpaceOdakuFukaryo = new System.Windows.Forms.Label();
            this.lblCodOdakuFukaryo = new System.Windows.Forms.Label();
            this.lblTdkdFukaryo = new System.Windows.Forms.Label();
            this.lblTdkdhsAveOdakuFukaryo = new System.Windows.Forms.Label();
            this.lblTdkdhsMaxOdakuFukaryo = new System.Windows.Forms.Label();
            this.lblBikoOdakuFukaryo = new System.Windows.Forms.Label();
            this.lblTnOdakuFukaryo = new System.Windows.Forms.Label();
            this.lblTpOdakuFukaryo = new System.Windows.Forms.Label();
            this.lblSonotaOdakuFukaryo = new System.Windows.Forms.Label();
            this.lblKyoyoFukaryo = new System.Windows.Forms.Label();
            this.txtCodKyoyoFukaryo = new System.Windows.Forms.TextBox();
            this.txtTnKyoyoFukaryo = new System.Windows.Forms.TextBox();
            this.txtTpKyoyoFukaryo = new System.Windows.Forms.TextBox();
            this.txtSonotaKyoyoFukaryo = new System.Windows.Forms.TextBox();
            this.txtCodTdkdFukaryo = new System.Windows.Forms.TextBox();
            this.txtTnTdkdFukaryo = new System.Windows.Forms.TextBox();
            this.txtTpTdkdFukaryo = new System.Windows.Forms.TextBox();
            this.txtSonotaTdkdFukaryo = new System.Windows.Forms.TextBox();
            this.txtTdkdhsAveOdakuFukaryo = new System.Windows.Forms.TextBox();
            this.txtTdkdhsMaxOdakuFukaryo = new System.Windows.Forms.TextBox();
            this.txtBikoOdakuFukaryo = new System.Windows.Forms.TextBox();
            this.btnCancelOdakuFukaryo = new System.Windows.Forms.Button();
            this.btnRegistOdakuFukaryo = new System.Windows.Forms.Button();
            this.lblOdakuFukaryo = new System.Windows.Forms.Label();
            this.tabSoryoKise = new System.Windows.Forms.TabPage();
            this.lblTpLine = new System.Windows.Forms.Label();
            this.lblTnLine = new System.Windows.Forms.Label();
            this.lblCodLine = new System.Windows.Forms.Label();
            this.tblTp = new System.Windows.Forms.TableLayoutPanel();
            this.lblGyosyuKbnTp = new System.Windows.Forms.Label();
            this.lblTpTable = new System.Windows.Forms.Label();
            this.lblCpo = new System.Windows.Forms.Label();
            this.lblCpi = new System.Windows.Forms.Label();
            this.lblSpaceTp1 = new System.Windows.Forms.Label();
            this.lblOsenJyotaiTp = new System.Windows.Forms.Label();
            this.lblOjAveTp = new System.Windows.Forms.Label();
            this.OjMaxTp = new System.Windows.Forms.Label();
            this.lblTSuiryoTp = new System.Windows.Forms.Label();
            this.lblTSuiryoAveTp = new System.Windows.Forms.Label();
            this.lblTSuiryoMaxTp = new System.Windows.Forms.Label();
            this.lblTSuiryoQpo = new System.Windows.Forms.Label();
            this.lblTSuiryoQpi = new System.Windows.Forms.Label();
            this.lblSpaceTp2 = new System.Windows.Forms.Label();
            this.lblOdakuFukaryoTp = new System.Windows.Forms.Label();
            this.lblOdakuFukaryoAveTp = new System.Windows.Forms.Label();
            this.lblOdakuFukaryoMaxTp = new System.Windows.Forms.Label();
            this.lblKijyunTiTp = new System.Windows.Forms.Label();
            this.lblLp = new System.Windows.Forms.Label();
            this.lblScrolBerTp = new System.Windows.Forms.Label();
            this.dgvTp = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn39 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn40 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn41 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn42 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn43 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn44 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn45 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn46 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn47 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn48 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn49 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn50 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn51 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn52 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lblTp = new System.Windows.Forms.Label();
            this.btnDeleteMeisaiTp = new System.Windows.Forms.Button();
            this.btnAddMeisaiTp = new System.Windows.Forms.Button();
            this.TblTn = new System.Windows.Forms.TableLayoutPanel();
            this.lblGyosyuKbnTn = new System.Windows.Forms.Label();
            this.lblTnTable = new System.Windows.Forms.Label();
            this.lblCno = new System.Windows.Forms.Label();
            this.lblCni = new System.Windows.Forms.Label();
            this.lblSpaceTn1 = new System.Windows.Forms.Label();
            this.lblOsenJyotaiTn = new System.Windows.Forms.Label();
            this.lblOjAveTn = new System.Windows.Forms.Label();
            this.OjMaxTn = new System.Windows.Forms.Label();
            this.lblTSuiryoTn = new System.Windows.Forms.Label();
            this.lblTSuiryoAveTn = new System.Windows.Forms.Label();
            this.lblTSuiryoMaxTn = new System.Windows.Forms.Label();
            this.lblTSuiryoQno = new System.Windows.Forms.Label();
            this.lblTSuiryoQni = new System.Windows.Forms.Label();
            this.lblSpaceTn2 = new System.Windows.Forms.Label();
            this.lblOdakuFukaryoTn = new System.Windows.Forms.Label();
            this.lblOdakuFukaryoAveTn = new System.Windows.Forms.Label();
            this.lblOdakuFukaryoMaxTn = new System.Windows.Forms.Label();
            this.lblKijyunTiTn = new System.Windows.Forms.Label();
            this.lblLn = new System.Windows.Forms.Label();
            this.lblScrolBerTn = new System.Windows.Forms.Label();
            this.dgvTn = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn25 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn26 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn27 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn28 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn29 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn30 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn31 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn32 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn33 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn34 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn35 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn36 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn37 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn38 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lblTn = new System.Windows.Forms.Label();
            this.btnDeleteMeisaiTn = new System.Windows.Forms.Button();
            this.btnAddMeisaiTn = new System.Windows.Forms.Button();
            this.tblCod = new System.Windows.Forms.TableLayoutPanel();
            this.lblGyosyuKbnCod = new System.Windows.Forms.Label();
            this.lblCodTable = new System.Windows.Forms.Label();
            this.lblCco = new System.Windows.Forms.Label();
            this.lblCci = new System.Windows.Forms.Label();
            this.lblCcj = new System.Windows.Forms.Label();
            this.lblOsenJyotaiCod = new System.Windows.Forms.Label();
            this.lblOjAveCod = new System.Windows.Forms.Label();
            this.OjMaxCod = new System.Windows.Forms.Label();
            this.lblTSuiryoCod = new System.Windows.Forms.Label();
            this.lblTSuiryoAveCod = new System.Windows.Forms.Label();
            this.lblTSuiryoMaxCod = new System.Windows.Forms.Label();
            this.lblTSuiryoQco = new System.Windows.Forms.Label();
            this.lblTSuiryoQci = new System.Windows.Forms.Label();
            this.lblTSuiryoQcj = new System.Windows.Forms.Label();
            this.lblOdakuFukaryoCod = new System.Windows.Forms.Label();
            this.lblOdakuFukaryoAveCod = new System.Windows.Forms.Label();
            this.lblOdakuFukaryoMaxCod = new System.Windows.Forms.Label();
            this.lblKijyunTiCod = new System.Windows.Forms.Label();
            this.lblLc = new System.Windows.Forms.Label();
            this.lblScrolBerCod = new System.Windows.Forms.Label();
            this.dgvCod = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lblCod = new System.Windows.Forms.Label();
            this.btnDeleteMeisaiCod = new System.Windows.Forms.Button();
            this.btnAddMeisaiCod = new System.Windows.Forms.Button();
            this.btnCalcSoryoKise = new System.Windows.Forms.Button();
            this.btnCancelSoryoKise = new System.Windows.Forms.Button();
            this.btnRegistSoryoKise = new System.Windows.Forms.Button();
            this.lblSoryoKise = new System.Windows.Forms.Label();
            this.tblSoryoKise = new System.Windows.Forms.TableLayoutPanel();
            this.lblSpaceSoryoKise = new System.Windows.Forms.Label();
            this.lblCodSoryoKise = new System.Windows.Forms.Label();
            this.lblTdkdFukaryoSoryoKise = new System.Windows.Forms.Label();
            this.lblTdkdhsAveSoryoKise = new System.Windows.Forms.Label();
            this.lblTdkdhsMaxSoryoKise = new System.Windows.Forms.Label();
            this.lblBikoSoryoKise = new System.Windows.Forms.Label();
            this.lblTnSoryoKise = new System.Windows.Forms.Label();
            this.lblTpSoryoKise = new System.Windows.Forms.Label();
            this.lblSonotaSoryoKise = new System.Windows.Forms.Label();
            this.lblKyoyoFukaryoSoryoKise = new System.Windows.Forms.Label();
            this.txtCodKyoyoFukaryoSoryoKise = new System.Windows.Forms.TextBox();
            this.textBtxtTnKyoyoFukaryoSoryoKiseox15 = new System.Windows.Forms.TextBox();
            this.txtTpKyoyoFukaryoSoryoKise = new System.Windows.Forms.TextBox();
            this.txtSonotaKyoyoFukarySoryoKise = new System.Windows.Forms.TextBox();
            this.txtCodTdkdFukaryoSoryoKise = new System.Windows.Forms.TextBox();
            this.txtTnTdkdFukaryoSoryoKise = new System.Windows.Forms.TextBox();
            this.txtTpTdkdFukaryoSoryoKise = new System.Windows.Forms.TextBox();
            this.txtSonotaTdkdFukaryoSoryoKise = new System.Windows.Forms.TextBox();
            this.txtTdkdhsAveSoryoKise = new System.Windows.Forms.TextBox();
            this.txtTdkdhsMaxSoryoKise = new System.Windows.Forms.TextBox();
            this.txtBikoSoryoKise = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.checkBox10 = new System.Windows.Forms.CheckBox();
            this.checkBox6 = new System.Windows.Forms.CheckBox();
            this.button1 = new System.Windows.Forms.Button();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.txtJigyojoSeriNo2 = new System.Windows.Forms.TextBox();
            this.lblJigyojoSeriNo2 = new System.Windows.Forms.Label();
            this.txtJigyojoSeriNo1 = new System.Windows.Forms.TextBox();
            this.lblJigyojoSeriNo1 = new System.Windows.Forms.Label();
            this.pnlTodokedeKanri = new System.Windows.Forms.Panel();
            this.txtJigyojoSeriNo3 = new System.Windows.Forms.TextBox();
            this.lblJigyojoSeriNo3 = new System.Windows.Forms.Label();
            this.chkTadasigaki = new System.Windows.Forms.CheckBox();
            this.chkKyote = new System.Windows.Forms.CheckBox();
            this.btnItiran = new System.Windows.Forms.Button();
            this.txtJigyojoAdrs = new System.Windows.Forms.TextBox();
            this.txtJigyojoName = new System.Windows.Forms.TextBox();
            this.txtNendo = new System.Windows.Forms.TextBox();
            this.txtKanriNo = new System.Windows.Forms.TextBox();
            this.lblAdrs = new System.Windows.Forms.Label();
            this.lblName = new System.Windows.Forms.Label();
            this.lblNendo = new System.Windows.Forms.Label();
            this.lblKanriNo = new System.Windows.Forms.Label();
            this.TSNO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cboGesuikbn = new Suisitu.Components.Controls.ValueCombo();
            this.cboRyuikiCode = new Suisitu.Components.Controls.ValueCombo();
            this.cboSikibetuCode = new Suisitu.Components.Controls.ValueCombo();
            this.cboHoKbnCode = new Suisitu.Components.Controls.ValueCombo();
            this.cboSangyoBS = new Suisitu.Components.Controls.ValueCombo();
            this.cboSangyoBC = new Suisitu.Components.Controls.ValueCombo();
            this.backColorChangeOnFocusProvider1 = new Suisitu.Component.BackColorChangeOnFocusProvider();
            this.bsTodokedeKanri = new System.Windows.Forms.BindingSource(this.components);
            this.bsKojoKihon = new System.Windows.Forms.BindingSource(this.components);
            this.TdkdNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TdkdKbn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TodokedeDateShortW = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.UketukeNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TdkdSyubetu = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TdkdSyubetuS = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Biko1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Biko2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Biko3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bsTodokedeRireki = new System.Windows.Forms.BindingSource(this.components);
            this.bsTokuteiSisetuTou = new System.Windows.Forms.BindingSource(this.components);
            this.fsNoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.torimatomeFlagVDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tsNoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sisetuNameNDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.setubiUmuFlag1VDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.setubiUmuFlag2VDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.setubiUmuFlag3VDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.setubiUmuFlag4VDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.setubiUmuFlag5VDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.setubiUmuFlag6VDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.setubiUmuFlag7VDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bsFutaiSetubiTou = new System.Windows.Forms.BindingSource(this.components);
            this.SisetuNameN = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Biko = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bsShoriSisetu = new System.Windows.Forms.BindingSource(this.components);
            this.HaisuikoNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SetiDateShortW = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.HaisiDateShortW = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn21 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn22 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn23 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bsHaisuiko = new System.Windows.Forms.BindingSource(this.components);
            this.bsOdakuFukaryo = new System.Windows.Forms.BindingSource(this.components);
            this.bsKubunName = new System.Windows.Forms.BindingSource(this.components);
            this.HaisiFlag = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn15 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn24 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabTodokedeKanri.SuspendLayout();
            this.tabKojyoKihon.SuspendLayout();
            this.tabTodokedeRireki.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTodokedeRireki)).BeginInit();
            this.tabTokuteiSisetu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTokuteiSisetuTou)).BeginInit();
            this.tabFutaisetubi.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvFutaiSetubiTou)).BeginInit();
            this.tabShoriSisetu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvShoriSisetu)).BeginInit();
            this.tabHaisuiko.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvHaisuiko)).BeginInit();
            this.tabOdakuFukaryo.SuspendLayout();
            this.tblOdakuFukaryo.SuspendLayout();
            this.tabSoryoKise.SuspendLayout();
            this.tblTp.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTp)).BeginInit();
            this.TblTn.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTn)).BeginInit();
            this.tblCod.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCod)).BeginInit();
            this.tblSoryoKise.SuspendLayout();
            this.pnlTodokedeKanri.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bsTodokedeKanri)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsKojoKihon)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsTodokedeRireki)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsTokuteiSisetuTou)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsFutaiSetubiTou)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsShoriSisetu)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsHaisuiko)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsOdakuFukaryo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsKubunName)).BeginInit();
            this.SuspendLayout();
            // 
            // tabTodokedeKanri
            // 
            this.tabTodokedeKanri.Appearance = System.Windows.Forms.TabAppearance.Buttons;
            this.tabTodokedeKanri.Controls.Add(this.tabKojyoKihon);
            this.tabTodokedeKanri.Controls.Add(this.tabTodokedeRireki);
            this.tabTodokedeKanri.Controls.Add(this.tabTokuteiSisetu);
            this.tabTodokedeKanri.Controls.Add(this.tabFutaisetubi);
            this.tabTodokedeKanri.Controls.Add(this.tabShoriSisetu);
            this.tabTodokedeKanri.Controls.Add(this.tabHaisuiko);
            this.tabTodokedeKanri.Controls.Add(this.tabOdakuFukaryo);
            this.tabTodokedeKanri.Controls.Add(this.tabSoryoKise);
            this.tabTodokedeKanri.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.tabTodokedeKanri.Location = new System.Drawing.Point(15, 173);
            this.tabTodokedeKanri.Name = "tabTodokedeKanri";
            this.tabTodokedeKanri.SelectedIndex = 0;
            this.tabTodokedeKanri.Size = new System.Drawing.Size(978, 561);
            this.tabTodokedeKanri.TabIndex = 1;
            this.tabTodokedeKanri.TabStop = false;
            this.tabTodokedeKanri.SelectedIndexChanged += new System.EventHandler(this.tabTodokedeKanri_SelectedIndexChanged);
            this.tabTodokedeKanri.Deselecting += new System.Windows.Forms.TabControlCancelEventHandler(this.tabTodokedeKanri_Deselecting);
            // 
            // tabKojyoKihon
            // 
            this.tabKojyoKihon.AutoScroll = true;
            this.tabKojyoKihon.AutoScrollMargin = new System.Drawing.Size(0, 15);
            this.tabKojyoKihon.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.tabKojyoKihon.Controls.Add(this.cboGesuikbn);
            this.tabKojyoKihon.Controls.Add(this.lblGesuikbn);
            this.tabKojyoKihon.Controls.Add(this.cboRyuikiCode);
            this.tabKojyoKihon.Controls.Add(this.cboSikibetuCode);
            this.tabKojyoKihon.Controls.Add(this.cboHoKbnCode);
            this.tabKojyoKihon.Controls.Add(this.cboSangyoBS);
            this.tabKojyoKihon.Controls.Add(this.cboSangyoBC);
            this.tabKojyoKihon.Controls.Add(this.btnCopy2);
            this.tabKojyoKihon.Controls.Add(this.lblSaisuiLine);
            this.tabKojyoKihon.Controls.Add(this.lblOdakuCopName);
            this.tabKojyoKihon.Controls.Add(this.txtBiko4);
            this.tabKojyoKihon.Controls.Add(this.lblSaisui);
            this.tabKojyoKihon.Controls.Add(this.txtOdakuNameN);
            this.tabKojyoKihon.Controls.Add(this.lblSaisuiNameN);
            this.tabKojyoKihon.Controls.Add(this.lblOdakuYubinNo);
            this.tabKojyoKihon.Controls.Add(this.lblSaisuiFaxNo);
            this.tabKojyoKihon.Controls.Add(this.lblBiko4);
            this.tabKojyoKihon.Controls.Add(this.lblOdakuFkaryoSofusakiLine);
            this.tabKojyoKihon.Controls.Add(this.lblOdakuNameN);
            this.tabKojyoKihon.Controls.Add(this.txtSaisuiNameN);
            this.tabKojyoKihon.Controls.Add(this.txtOdakuCopName);
            this.tabKojyoKihon.Controls.Add(this.lblOdakuFukaryoSofusaki);
            this.tabKojyoKihon.Controls.Add(this.txtOdakuYubinNo1);
            this.tabKojyoKihon.Controls.Add(this.txtSaisuiFaxNo);
            this.tabKojyoKihon.Controls.Add(this.txtOdakuJyusyo);
            this.tabKojyoKihon.Controls.Add(this.btnSiyoJokyo);
            this.tabKojyoKihon.Controls.Add(this.lblSofusakiYubinNoHi);
            this.tabKojyoKihon.Controls.Add(this.txtBiko5);
            this.tabKojyoKihon.Controls.Add(this.lblOdakuJyusyo);
            this.tabKojyoKihon.Controls.Add(this.lblKihonkomoku2Line);
            this.tabKojyoKihon.Controls.Add(this.txtOdakuYubinNo2);
            this.tabKojyoKihon.Controls.Add(this.lblBiko5);
            this.tabKojyoKihon.Controls.Add(this.lblKihonkomoku2);
            this.tabKojyoKihon.Controls.Add(this.txtKankyosyoCode);
            this.tabKojyoKihon.Controls.Add(this.lblKihonkomoku1Line);
            this.tabKojyoKihon.Controls.Add(this.lblKihonkomoku1);
            this.tabKojyoKihon.Controls.Add(this.lblChozoSite);
            this.tabKojyoKihon.Controls.Add(this.lblKankyosyoCode);
            this.tabKojyoKihon.Controls.Add(this.btnCopy1);
            this.tabKojyoKihon.Controls.Add(this.lblSiyoTokute2);
            this.tabKojyoKihon.Controls.Add(this.lblSiyoTokute1);
            this.tabKojyoKihon.Controls.Add(this.lblYugaiUm);
            this.tabKojyoKihon.Controls.Add(this.txtBiko2);
            this.tabKojyoKihon.Controls.Add(this.chkYokakunin);
            this.tabKojyoKihon.Controls.Add(this.chkYugaiUm);
            this.tabKojyoKihon.Controls.Add(this.lblTodokedeSinseishaLine);
            this.tabKojyoKihon.Controls.Add(this.chkChosataisho);
            this.tabKojyoKihon.Controls.Add(this.chkKosyohoJunyoSite);
            this.tabKojyoKihon.Controls.Add(this.lblSinseiCopName);
            this.tabKojyoKihon.Controls.Add(this.chkKosyohoSite);
            this.tabKojyoKihon.Controls.Add(this.chkKosyoTokute);
            this.tabKojyoKihon.Controls.Add(this.lblTodokedeSinseisha);
            this.tabKojyoKihon.Controls.Add(this.chkChozoSiteKakosiyo);
            this.tabKojyoKihon.Controls.Add(this.chkKyote2);
            this.tabKojyoKihon.Controls.Add(this.chkChozoSite);
            this.tabKojyoKihon.Controls.Add(this.lblBiko2);
            this.tabKojyoKihon.Controls.Add(this.chkSiyoTokute2Kakosiyo);
            this.tabKojyoKihon.Controls.Add(this.chkZanteiKijunFlag);
            this.tabKojyoKihon.Controls.Add(this.chkSiyoTokute2);
            this.tabKojyoKihon.Controls.Add(this.txtSyozaiJyusyo);
            this.tabKojyoKihon.Controls.Add(this.chkSiyoTokute1Kakosiyo);
            this.tabKojyoKihon.Controls.Add(this.chkHaisuiKijun);
            this.tabKojyoKihon.Controls.Add(this.chkSiyoTokute1);
            this.tabKojyoKihon.Controls.Add(this.txtSinseiNameN);
            this.tabKojyoKihon.Controls.Add(this.chkTadasigaki2);
            this.tabKojyoKihon.Controls.Add(this.btnCancelKojoKihon);
            this.tabKojyoKihon.Controls.Add(this.lblSoryoKiseiNo);
            this.tabKojyoKihon.Controls.Add(this.lblSinseiYubinNo);
            this.tabKojyoKihon.Controls.Add(this.txtSoryoKiseiNo);
            this.tabKojyoKihon.Controls.Add(this.lblSyozaiJyusyo);
            this.tabKojyoKihon.Controls.Add(this.txtBiko3);
            this.tabKojyoKihon.Controls.Add(this.lblSinseiNameN);
            this.tabKojyoKihon.Controls.Add(this.lblSangyoBC);
            this.tabKojyoKihon.Controls.Add(this.lblBiko3);
            this.tabKojyoKihon.Controls.Add(this.btnRegistKojoKihon);
            this.tabKojyoKihon.Controls.Add(this.lblSangyoBS);
            this.tabKojyoKihon.Controls.Add(this.txtSinseiCopName);
            this.tabKojyoKihon.Controls.Add(this.txtBiko1);
            this.tabKojyoKihon.Controls.Add(this.lblHoKbnCode);
            this.tabKojyoKihon.Controls.Add(this.txtSinseiTelNo);
            this.tabKojyoKihon.Controls.Add(this.lblKojoKihon);
            this.tabKojyoKihon.Controls.Add(this.lblSinseiTelNo);
            this.tabKojyoKihon.Controls.Add(this.lblJigyosyoNameN);
            this.tabKojyoKihon.Controls.Add(this.txtSinseiYubinNo1);
            this.tabKojyoKihon.Controls.Add(this.lblBiko1);
            this.tabKojyoKihon.Controls.Add(this.txtSinseiJyusyo);
            this.tabKojyoKihon.Controls.Add(this.lblRyuikiCode);
            this.tabKojyoKihon.Controls.Add(this.lblJigyojoLine);
            this.tabKojyoKihon.Controls.Add(this.lblSikibetuCode);
            this.tabKojyoKihon.Controls.Add(this.lblTodokedeYubinNoHi);
            this.tabKojyoKihon.Controls.Add(this.lblJigyosyoNameK);
            this.tabKojyoKihon.Controls.Add(this.lblSinseiJyusyo);
            this.tabKojyoKihon.Controls.Add(this.lblJigyojo);
            this.tabKojyoKihon.Controls.Add(this.txtSinseiYubinNo2);
            this.tabKojyoKihon.Controls.Add(this.txtKTantoNameN);
            this.tabKojyoKihon.Controls.Add(this.lbltxtSyozaiYubinNo);
            this.tabKojyoKihon.Controls.Add(this.lblKTantoNameN);
            this.tabKojyoKihon.Controls.Add(this.txtJigyosyoNameN);
            this.tabKojyoKihon.Controls.Add(this.txtTelNo);
            this.tabKojyoKihon.Controls.Add(this.txtJigyosyoNameK);
            this.tabKojyoKihon.Controls.Add(this.lbltxtTelNo);
            this.tabKojyoKihon.Controls.Add(this.txtSyozaiYubinNo2);
            this.tabKojyoKihon.Controls.Add(this.txtSyozaiYubinNo1);
            this.tabKojyoKihon.Controls.Add(this.lblJigyojoYubinNoHi);
            this.tabKojyoKihon.Location = new System.Drawing.Point(4, 36);
            this.tabKojyoKihon.Name = "tabKojyoKihon";
            this.tabKojyoKihon.Padding = new System.Windows.Forms.Padding(3);
            this.tabKojyoKihon.Size = new System.Drawing.Size(970, 521);
            this.tabKojyoKihon.TabIndex = 0;
            this.tabKojyoKihon.Text = "工場基本";
            // 
            // lblGesuikbn
            // 
            this.lblGesuikbn.AutoSize = true;
            this.lblGesuikbn.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblGesuikbn.Location = new System.Drawing.Point(478, 458);
            this.lblGesuikbn.Name = "lblGesuikbn";
            this.lblGesuikbn.Size = new System.Drawing.Size(74, 24);
            this.lblGesuikbn.TabIndex = 181;
            this.lblGesuikbn.Text = "下水接続";
            // 
            // btnCopy2
            // 
            this.btnCopy2.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnCopy2.Location = new System.Drawing.Point(16, 830);
            this.btnCopy2.Name = "btnCopy2";
            this.btnCopy2.Size = new System.Drawing.Size(100, 30);
            this.btnCopy2.TabIndex = 71;
            this.btnCopy2.Text = "②を複写";
            this.btnCopy2.UseVisualStyleBackColor = true;
            this.btnCopy2.Click += new System.EventHandler(this.btnCopy2_Click);
            // 
            // lblSaisuiLine
            // 
            this.lblSaisuiLine.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblSaisuiLine.Font = new System.Drawing.Font("ＭＳ ゴシック", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblSaisuiLine.Location = new System.Drawing.Point(78, 942);
            this.lblSaisuiLine.Name = "lblSaisuiLine";
            this.lblSaisuiLine.Size = new System.Drawing.Size(863, 1);
            this.lblSaisuiLine.TabIndex = 174;
            // 
            // lblOdakuCopName
            // 
            this.lblOdakuCopName.AutoSize = true;
            this.lblOdakuCopName.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblOdakuCopName.Location = new System.Drawing.Point(12, 867);
            this.lblOdakuCopName.Name = "lblOdakuCopName";
            this.lblOdakuCopName.Size = new System.Drawing.Size(74, 24);
            this.lblOdakuCopName.TabIndex = 114;
            this.lblOdakuCopName.Text = "会社名等";
            // 
            // txtBiko4
            // 
            this.txtBiko4.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsKojoKihon, "Biko4", true, System.Windows.Forms.DataSourceUpdateMode.Never));
            this.txtBiko4.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtBiko4.ImeMode = System.Windows.Forms.ImeMode.Hiragana;
            this.txtBiko4.Location = new System.Drawing.Point(601, 896);
            this.txtBiko4.MaxLength = 100;
            this.txtBiko4.Name = "txtBiko4";
            this.txtBiko4.Size = new System.Drawing.Size(336, 31);
            this.txtBiko4.TabIndex = 77;
            // 
            // lblSaisui
            // 
            this.lblSaisui.AutoSize = true;
            this.lblSaisui.Font = new System.Drawing.Font("メイリオ", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblSaisui.Location = new System.Drawing.Point(1, 933);
            this.lblSaisui.Name = "lblSaisui";
            this.lblSaisui.Size = new System.Drawing.Size(74, 20);
            this.lblSaisui.TabIndex = 175;
            this.lblSaisui.Text = "⑥採水情報";
            // 
            // txtOdakuNameN
            // 
            this.txtOdakuNameN.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsKojoKihon, "OdakuNameN", true, System.Windows.Forms.DataSourceUpdateMode.Never));
            this.txtOdakuNameN.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtOdakuNameN.ImeMode = System.Windows.Forms.ImeMode.Hiragana;
            this.txtOdakuNameN.Location = new System.Drawing.Point(152, 896);
            this.txtOdakuNameN.MaxLength = 16;
            this.txtOdakuNameN.Name = "txtOdakuNameN";
            this.txtOdakuNameN.Size = new System.Drawing.Size(304, 31);
            this.txtOdakuNameN.TabIndex = 73;
            // 
            // lblSaisuiNameN
            // 
            this.lblSaisuiNameN.AutoSize = true;
            this.lblSaisuiNameN.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblSaisuiNameN.Location = new System.Drawing.Point(12, 960);
            this.lblSaisuiNameN.Name = "lblSaisuiNameN";
            this.lblSaisuiNameN.Size = new System.Drawing.Size(106, 24);
            this.lblSaisuiNameN.TabIndex = 75;
            this.lblSaisuiNameN.Text = "結果報告者名";
            // 
            // lblOdakuYubinNo
            // 
            this.lblOdakuYubinNo.AutoSize = true;
            this.lblOdakuYubinNo.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblOdakuYubinNo.Location = new System.Drawing.Point(478, 835);
            this.lblOdakuYubinNo.Name = "lblOdakuYubinNo";
            this.lblOdakuYubinNo.Size = new System.Drawing.Size(74, 24);
            this.lblOdakuYubinNo.TabIndex = 122;
            this.lblOdakuYubinNo.Text = "郵便番号";
            // 
            // lblSaisuiFaxNo
            // 
            this.lblSaisuiFaxNo.AutoSize = true;
            this.lblSaisuiFaxNo.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblSaisuiFaxNo.Location = new System.Drawing.Point(12, 992);
            this.lblSaisuiFaxNo.Name = "lblSaisuiFaxNo";
            this.lblSaisuiFaxNo.Size = new System.Drawing.Size(104, 24);
            this.lblSaisuiFaxNo.TabIndex = 89;
            this.lblSaisuiFaxNo.Text = "FAX送付番号";
            // 
            // lblBiko4
            // 
            this.lblBiko4.AutoSize = true;
            this.lblBiko4.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblBiko4.Location = new System.Drawing.Point(478, 899);
            this.lblBiko4.Name = "lblBiko4";
            this.lblBiko4.Size = new System.Drawing.Size(42, 24);
            this.lblBiko4.TabIndex = 140;
            this.lblBiko4.Text = "備考";
            // 
            // lblOdakuFkaryoSofusakiLine
            // 
            this.lblOdakuFkaryoSofusakiLine.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblOdakuFkaryoSofusakiLine.Font = new System.Drawing.Font("ＭＳ ゴシック", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblOdakuFkaryoSofusakiLine.Location = new System.Drawing.Point(182, 817);
            this.lblOdakuFkaryoSofusakiLine.Name = "lblOdakuFkaryoSofusakiLine";
            this.lblOdakuFkaryoSofusakiLine.Size = new System.Drawing.Size(759, 1);
            this.lblOdakuFkaryoSofusakiLine.TabIndex = 172;
            // 
            // lblOdakuNameN
            // 
            this.lblOdakuNameN.AutoSize = true;
            this.lblOdakuNameN.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblOdakuNameN.Location = new System.Drawing.Point(12, 899);
            this.lblOdakuNameN.Name = "lblOdakuNameN";
            this.lblOdakuNameN.Size = new System.Drawing.Size(74, 24);
            this.lblOdakuNameN.TabIndex = 139;
            this.lblOdakuNameN.Text = "担当者名";
            // 
            // txtSaisuiNameN
            // 
            this.txtSaisuiNameN.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsKojoKihon, "SaisuiNameN", true, System.Windows.Forms.DataSourceUpdateMode.Never));
            this.txtSaisuiNameN.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtSaisuiNameN.ImeMode = System.Windows.Forms.ImeMode.Hiragana;
            this.txtSaisuiNameN.Location = new System.Drawing.Point(152, 957);
            this.txtSaisuiNameN.MaxLength = 16;
            this.txtSaisuiNameN.Name = "txtSaisuiNameN";
            this.txtSaisuiNameN.Size = new System.Drawing.Size(304, 31);
            this.txtSaisuiNameN.TabIndex = 81;
            // 
            // txtOdakuCopName
            // 
            this.txtOdakuCopName.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsKojoKihon, "OdakuCopName", true, System.Windows.Forms.DataSourceUpdateMode.Never));
            this.txtOdakuCopName.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtOdakuCopName.ImeMode = System.Windows.Forms.ImeMode.Hiragana;
            this.txtOdakuCopName.Location = new System.Drawing.Point(152, 864);
            this.txtOdakuCopName.MaxLength = 16;
            this.txtOdakuCopName.Name = "txtOdakuCopName";
            this.txtOdakuCopName.Size = new System.Drawing.Size(304, 31);
            this.txtOdakuCopName.TabIndex = 72;
            // 
            // lblOdakuFukaryoSofusaki
            // 
            this.lblOdakuFukaryoSofusaki.AutoSize = true;
            this.lblOdakuFukaryoSofusaki.Font = new System.Drawing.Font("メイリオ", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblOdakuFukaryoSofusaki.Location = new System.Drawing.Point(1, 808);
            this.lblOdakuFukaryoSofusaki.Name = "lblOdakuFukaryoSofusaki";
            this.lblOdakuFukaryoSofusaki.Size = new System.Drawing.Size(178, 20);
            this.lblOdakuFukaryoSofusaki.TabIndex = 173;
            this.lblOdakuFukaryoSofusaki.Text = "⑤汚濁負荷量報告送付先情報";
            // 
            // txtOdakuYubinNo1
            // 
            this.txtOdakuYubinNo1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsKojoKihon, "OdakuYubinNo1", true, System.Windows.Forms.DataSourceUpdateMode.Never));
            this.txtOdakuYubinNo1.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtOdakuYubinNo1.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.txtOdakuYubinNo1.Location = new System.Drawing.Point(601, 832);
            this.txtOdakuYubinNo1.MaxLength = 3;
            this.txtOdakuYubinNo1.Name = "txtOdakuYubinNo1";
            this.txtOdakuYubinNo1.Size = new System.Drawing.Size(40, 31);
            this.txtOdakuYubinNo1.TabIndex = 74;
            // 
            // txtSaisuiFaxNo
            // 
            this.txtSaisuiFaxNo.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsKojoKihon, "SaisuiFaxNo", true, System.Windows.Forms.DataSourceUpdateMode.Never));
            this.txtSaisuiFaxNo.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtSaisuiFaxNo.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.txtSaisuiFaxNo.Location = new System.Drawing.Point(152, 989);
            this.txtSaisuiFaxNo.MaxLength = 13;
            this.txtSaisuiFaxNo.Name = "txtSaisuiFaxNo";
            this.txtSaisuiFaxNo.Size = new System.Drawing.Size(158, 31);
            this.txtSaisuiFaxNo.TabIndex = 83;
            // 
            // txtOdakuJyusyo
            // 
            this.txtOdakuJyusyo.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsKojoKihon, "OdakuJyusyo", true, System.Windows.Forms.DataSourceUpdateMode.Never));
            this.txtOdakuJyusyo.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtOdakuJyusyo.ImeMode = System.Windows.Forms.ImeMode.Hiragana;
            this.txtOdakuJyusyo.Location = new System.Drawing.Point(601, 864);
            this.txtOdakuJyusyo.MaxLength = 24;
            this.txtOdakuJyusyo.Name = "txtOdakuJyusyo";
            this.txtOdakuJyusyo.Size = new System.Drawing.Size(336, 31);
            this.txtOdakuJyusyo.TabIndex = 76;
            // 
            // btnSiyoJokyo
            // 
            this.btnSiyoJokyo.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnSiyoJokyo.Location = new System.Drawing.Point(537, 580);
            this.btnSiyoJokyo.Name = "btnSiyoJokyo";
            this.btnSiyoJokyo.Size = new System.Drawing.Size(150, 30);
            this.btnSiyoJokyo.TabIndex = 59;
            this.btnSiyoJokyo.Text = "有害物質使用状況";
            this.btnSiyoJokyo.UseVisualStyleBackColor = true;
            this.btnSiyoJokyo.Click += new System.EventHandler(this.btnSiyoJokyo_Click);
            // 
            // lblSofusakiYubinNoHi
            // 
            this.lblSofusakiYubinNoHi.AutoSize = true;
            this.lblSofusakiYubinNoHi.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblSofusakiYubinNoHi.Location = new System.Drawing.Point(647, 835);
            this.lblSofusakiYubinNoHi.Name = "lblSofusakiYubinNoHi";
            this.lblSofusakiYubinNoHi.Size = new System.Drawing.Size(17, 24);
            this.lblSofusakiYubinNoHi.TabIndex = 131;
            this.lblSofusakiYubinNoHi.Text = "-";
            // 
            // txtBiko5
            // 
            this.txtBiko5.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsKojoKihon, "Biko5", true, System.Windows.Forms.DataSourceUpdateMode.Never));
            this.txtBiko5.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtBiko5.ImeMode = System.Windows.Forms.ImeMode.Hiragana;
            this.txtBiko5.Location = new System.Drawing.Point(601, 953);
            this.txtBiko5.MaxLength = 100;
            this.txtBiko5.Name = "txtBiko5";
            this.txtBiko5.Size = new System.Drawing.Size(336, 31);
            this.txtBiko5.TabIndex = 82;
            // 
            // lblOdakuJyusyo
            // 
            this.lblOdakuJyusyo.AutoSize = true;
            this.lblOdakuJyusyo.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblOdakuJyusyo.Location = new System.Drawing.Point(478, 867);
            this.lblOdakuJyusyo.Name = "lblOdakuJyusyo";
            this.lblOdakuJyusyo.Size = new System.Drawing.Size(58, 24);
            this.lblOdakuJyusyo.TabIndex = 136;
            this.lblOdakuJyusyo.Text = "所在地";
            // 
            // lblKihonkomoku2Line
            // 
            this.lblKihonkomoku2Line.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblKihonkomoku2Line.Font = new System.Drawing.Font("ＭＳ ゴシック", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblKihonkomoku2Line.Location = new System.Drawing.Point(91, 533);
            this.lblKihonkomoku2Line.Name = "lblKihonkomoku2Line";
            this.lblKihonkomoku2Line.Size = new System.Drawing.Size(850, 1);
            this.lblKihonkomoku2Line.TabIndex = 170;
            // 
            // txtOdakuYubinNo2
            // 
            this.txtOdakuYubinNo2.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsKojoKihon, "OdakuYubinNo2", true, System.Windows.Forms.DataSourceUpdateMode.Never));
            this.txtOdakuYubinNo2.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtOdakuYubinNo2.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.txtOdakuYubinNo2.Location = new System.Drawing.Point(670, 832);
            this.txtOdakuYubinNo2.MaxLength = 4;
            this.txtOdakuYubinNo2.Name = "txtOdakuYubinNo2";
            this.txtOdakuYubinNo2.Size = new System.Drawing.Size(46, 31);
            this.txtOdakuYubinNo2.TabIndex = 75;
            // 
            // lblBiko5
            // 
            this.lblBiko5.AutoSize = true;
            this.lblBiko5.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblBiko5.Location = new System.Drawing.Point(478, 960);
            this.lblBiko5.Name = "lblBiko5";
            this.lblBiko5.Size = new System.Drawing.Size(42, 24);
            this.lblBiko5.TabIndex = 100;
            this.lblBiko5.Text = "備考";
            // 
            // lblKihonkomoku2
            // 
            this.lblKihonkomoku2.AutoSize = true;
            this.lblKihonkomoku2.Font = new System.Drawing.Font("メイリオ", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblKihonkomoku2.Location = new System.Drawing.Point(1, 524);
            this.lblKihonkomoku2.Name = "lblKihonkomoku2";
            this.lblKihonkomoku2.Size = new System.Drawing.Size(87, 20);
            this.lblKihonkomoku2.TabIndex = 171;
            this.lblKihonkomoku2.Text = "④基本項目２";
            // 
            // txtKankyosyoCode
            // 
            this.txtKankyosyoCode.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsKojoKihon, "KankyosyoCode", true, System.Windows.Forms.DataSourceUpdateMode.Never));
            this.txtKankyosyoCode.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtKankyosyoCode.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.txtKankyosyoCode.Location = new System.Drawing.Point(482, 772);
            this.txtKankyosyoCode.MaxLength = 10;
            this.txtKankyosyoCode.Name = "txtKankyosyoCode";
            this.txtKankyosyoCode.Size = new System.Drawing.Size(108, 31);
            this.txtKankyosyoCode.TabIndex = 64;
            // 
            // lblKihonkomoku1Line
            // 
            this.lblKihonkomoku1Line.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblKihonkomoku1Line.Font = new System.Drawing.Font("ＭＳ ゴシック", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblKihonkomoku1Line.Location = new System.Drawing.Point(91, 312);
            this.lblKihonkomoku1Line.Name = "lblKihonkomoku1Line";
            this.lblKihonkomoku1Line.Size = new System.Drawing.Size(850, 1);
            this.lblKihonkomoku1Line.TabIndex = 164;
            // 
            // lblKihonkomoku1
            // 
            this.lblKihonkomoku1.AutoSize = true;
            this.lblKihonkomoku1.Font = new System.Drawing.Font("メイリオ", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblKihonkomoku1.Location = new System.Drawing.Point(1, 303);
            this.lblKihonkomoku1.Name = "lblKihonkomoku1";
            this.lblKihonkomoku1.Size = new System.Drawing.Size(87, 20);
            this.lblKihonkomoku1.TabIndex = 167;
            this.lblKihonkomoku1.Text = "③基本項目１";
            // 
            // lblChozoSite
            // 
            this.lblChozoSite.AutoSize = true;
            this.lblChozoSite.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblChozoSite.Location = new System.Drawing.Point(12, 647);
            this.lblChozoSite.Name = "lblChozoSite";
            this.lblChozoSite.Size = new System.Drawing.Size(186, 24);
            this.lblChozoSite.TabIndex = 157;
            this.lblChozoSite.Text = "有害物質貯蔵指定事業場";
            // 
            // lblKankyosyoCode
            // 
            this.lblKankyosyoCode.AutoSize = true;
            this.lblKankyosyoCode.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblKankyosyoCode.Location = new System.Drawing.Point(338, 775);
            this.lblKankyosyoCode.Name = "lblKankyosyoCode";
            this.lblKankyosyoCode.Size = new System.Drawing.Size(138, 24);
            this.lblKankyosyoCode.TabIndex = 141;
            this.lblKankyosyoCode.Text = "環境省統一コード";
            // 
            // btnCopy1
            // 
            this.btnCopy1.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnCopy1.Location = new System.Drawing.Point(16, 199);
            this.btnCopy1.Name = "btnCopy1";
            this.btnCopy1.Size = new System.Drawing.Size(100, 30);
            this.btnCopy1.TabIndex = 21;
            this.btnCopy1.Text = "①を複写";
            this.btnCopy1.UseVisualStyleBackColor = true;
            this.btnCopy1.Click += new System.EventHandler(this.btnCopy1_Click);
            // 
            // lblSiyoTokute2
            // 
            this.lblSiyoTokute2.AutoSize = true;
            this.lblSiyoTokute2.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblSiyoTokute2.Location = new System.Drawing.Point(12, 615);
            this.lblSiyoTokute2.Name = "lblSiyoTokute2";
            this.lblSiyoTokute2.Size = new System.Drawing.Size(252, 24);
            this.lblSiyoTokute2.TabIndex = 155;
            this.lblSiyoTokute2.Text = "有害物質使用特定事業場(5条3項)";
            // 
            // lblSiyoTokute1
            // 
            this.lblSiyoTokute1.AutoSize = true;
            this.lblSiyoTokute1.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblSiyoTokute1.Location = new System.Drawing.Point(12, 583);
            this.lblSiyoTokute1.Name = "lblSiyoTokute1";
            this.lblSiyoTokute1.Size = new System.Drawing.Size(268, 24);
            this.lblSiyoTokute1.TabIndex = 153;
            this.lblSiyoTokute1.Text = "有害物質使用特定事業場(5条1,2項)";
            // 
            // lblYugaiUm
            // 
            this.lblYugaiUm.AutoSize = true;
            this.lblYugaiUm.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblYugaiUm.Location = new System.Drawing.Point(12, 551);
            this.lblYugaiUm.Name = "lblYugaiUm";
            this.lblYugaiUm.Size = new System.Drawing.Size(154, 24);
            this.lblYugaiUm.TabIndex = 156;
            this.lblYugaiUm.Text = "旧システム有害有無";
            // 
            // txtBiko2
            // 
            this.txtBiko2.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsKojoKihon, "BIKO2", true, System.Windows.Forms.DataSourceUpdateMode.Never));
            this.txtBiko2.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtBiko2.ImeMode = System.Windows.Forms.ImeMode.Hiragana;
            this.txtBiko2.Location = new System.Drawing.Point(601, 266);
            this.txtBiko2.MaxLength = 100;
            this.txtBiko2.Name = "txtBiko2";
            this.txtBiko2.Size = new System.Drawing.Size(336, 31);
            this.txtBiko2.TabIndex = 28;
            // 
            // chkYokakunin
            // 
            this.chkYokakunin.AutoSize = true;
            this.chkYokakunin.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bsKojoKihon, "YokakuninFlagChk", true, System.Windows.Forms.DataSourceUpdateMode.Never));
            this.chkYokakunin.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.chkYokakunin.Location = new System.Drawing.Point(422, 550);
            this.chkYokakunin.Name = "chkYokakunin";
            this.chkYokakunin.Size = new System.Drawing.Size(93, 28);
            this.chkYokakunin.TabIndex = 52;
            this.chkYokakunin.Text = "　要確認";
            this.chkYokakunin.UseVisualStyleBackColor = true;
            // 
            // chkYugaiUm
            // 
            this.chkYugaiUm.AutoSize = true;
            this.chkYugaiUm.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bsKojoKihon, "YugaiUmChk", true, System.Windows.Forms.DataSourceUpdateMode.Never));
            this.chkYugaiUm.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.chkYugaiUm.Location = new System.Drawing.Point(299, 550);
            this.chkYugaiUm.Name = "chkYugaiUm";
            this.chkYugaiUm.Size = new System.Drawing.Size(61, 28);
            this.chkYugaiUm.TabIndex = 51;
            this.chkYugaiUm.Text = "　有";
            this.chkYugaiUm.UseVisualStyleBackColor = true;
            // 
            // lblTodokedeSinseishaLine
            // 
            this.lblTodokedeSinseishaLine.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblTodokedeSinseishaLine.Font = new System.Drawing.Font("ＭＳ ゴシック", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblTodokedeSinseishaLine.Location = new System.Drawing.Point(130, 187);
            this.lblTodokedeSinseishaLine.Name = "lblTodokedeSinseishaLine";
            this.lblTodokedeSinseishaLine.Size = new System.Drawing.Size(811, 1);
            this.lblTodokedeSinseishaLine.TabIndex = 159;
            // 
            // chkChosataisho
            // 
            this.chkChosataisho.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.chkChosataisho.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bsKojoKihon, "SogoChosaTaisyoFlag", true, System.Windows.Forms.DataSourceUpdateMode.Never));
            this.chkChosataisho.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.chkChosataisho.Location = new System.Drawing.Point(12, 775);
            this.chkChosataisho.Name = "chkChosataisho";
            this.chkChosataisho.Size = new System.Drawing.Size(301, 28);
            this.chkChosataisho.TabIndex = 63;
            this.chkChosataisho.Text = "水質汚濁物質総合調査対象事業場";
            this.chkChosataisho.UseVisualStyleBackColor = true;
            // 
            // chkKosyohoJunyoSite
            // 
            this.chkKosyohoJunyoSite.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.chkKosyohoJunyoSite.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bsKojoKihon, "KosyoJunSiteiSisetuFlag", true, System.Windows.Forms.DataSourceUpdateMode.Never));
            this.chkKosyohoJunyoSite.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.chkKosyohoJunyoSite.Location = new System.Drawing.Point(12, 743);
            this.chkKosyohoJunyoSite.Name = "chkKosyohoJunyoSite";
            this.chkKosyohoJunyoSite.Size = new System.Drawing.Size(301, 28);
            this.chkKosyohoJunyoSite.TabIndex = 62;
            this.chkKosyohoJunyoSite.Text = "湖沼法準用指定施設";
            this.chkKosyohoJunyoSite.UseVisualStyleBackColor = true;
            // 
            // lblSinseiCopName
            // 
            this.lblSinseiCopName.AutoSize = true;
            this.lblSinseiCopName.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblSinseiCopName.Location = new System.Drawing.Point(12, 237);
            this.lblSinseiCopName.Name = "lblSinseiCopName";
            this.lblSinseiCopName.Size = new System.Drawing.Size(74, 24);
            this.lblSinseiCopName.TabIndex = 76;
            this.lblSinseiCopName.Text = "会社名等";
            // 
            // chkKosyohoSite
            // 
            this.chkKosyohoSite.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.chkKosyohoSite.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bsKojoKihon, "KosyoSiteiFlagChk", true, System.Windows.Forms.DataSourceUpdateMode.Never));
            this.chkKosyohoSite.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.chkKosyohoSite.Location = new System.Drawing.Point(12, 711);
            this.chkKosyohoSite.Name = "chkKosyohoSite";
            this.chkKosyohoSite.Size = new System.Drawing.Size(301, 28);
            this.chkKosyohoSite.TabIndex = 61;
            this.chkKosyohoSite.Text = "湖沼法指定施設";
            this.chkKosyohoSite.UseVisualStyleBackColor = true;
            // 
            // chkKosyoTokute
            // 
            this.chkKosyoTokute.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.chkKosyoTokute.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bsKojoKihon, "KosyoTokuteiJigyojoFlag", true, System.Windows.Forms.DataSourceUpdateMode.Never));
            this.chkKosyoTokute.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.chkKosyoTokute.Location = new System.Drawing.Point(12, 679);
            this.chkKosyoTokute.Name = "chkKosyoTokute";
            this.chkKosyoTokute.Size = new System.Drawing.Size(301, 28);
            this.chkKosyoTokute.TabIndex = 60;
            this.chkKosyoTokute.Text = "湖沼特定事業場";
            this.chkKosyoTokute.UseVisualStyleBackColor = true;
            // 
            // lblTodokedeSinseisha
            // 
            this.lblTodokedeSinseisha.AutoSize = true;
            this.lblTodokedeSinseisha.Font = new System.Drawing.Font("メイリオ", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblTodokedeSinseisha.Location = new System.Drawing.Point(1, 178);
            this.lblTodokedeSinseisha.Name = "lblTodokedeSinseisha";
            this.lblTodokedeSinseisha.Size = new System.Drawing.Size(126, 20);
            this.lblTodokedeSinseisha.TabIndex = 160;
            this.lblTodokedeSinseisha.Text = "②届出・申請者情報";
            // 
            // chkChozoSiteKakosiyo
            // 
            this.chkChozoSiteKakosiyo.AutoSize = true;
            this.chkChozoSiteKakosiyo.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bsKojoKihon, "TsYugaiKakoSiyo3Flag", true, System.Windows.Forms.DataSourceUpdateMode.Never));
            this.chkChozoSiteKakosiyo.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.chkChozoSiteKakosiyo.Location = new System.Drawing.Point(422, 646);
            this.chkChozoSiteKakosiyo.Name = "chkChozoSiteKakosiyo";
            this.chkChozoSiteKakosiyo.Size = new System.Drawing.Size(109, 28);
            this.chkChozoSiteKakosiyo.TabIndex = 58;
            this.chkChozoSiteKakosiyo.Text = "　過去使用";
            this.chkChozoSiteKakosiyo.UseVisualStyleBackColor = true;
            // 
            // chkKyote2
            // 
            this.chkKyote2.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.chkKyote2.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bsKojoKihon, "KyoteiFlagChk", true, System.Windows.Forms.DataSourceUpdateMode.Never));
            this.chkKyote2.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.chkKyote2.Location = new System.Drawing.Point(476, 396);
            this.chkKyote2.Name = "chkKyote2";
            this.chkKyote2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.chkKyote2.Size = new System.Drawing.Size(145, 22);
            this.chkKyote2.TabIndex = 39;
            this.chkKyote2.Text = "協定";
            this.chkKyote2.UseVisualStyleBackColor = true;
            // 
            // chkChozoSite
            // 
            this.chkChozoSite.AutoSize = true;
            this.chkChozoSite.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bsKojoKihon, "TsYugaiGenSiyo3Flag", true, System.Windows.Forms.DataSourceUpdateMode.Never));
            this.chkChozoSite.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.chkChozoSite.Location = new System.Drawing.Point(299, 646);
            this.chkChozoSite.Name = "chkChozoSite";
            this.chkChozoSite.Size = new System.Drawing.Size(109, 28);
            this.chkChozoSite.TabIndex = 57;
            this.chkChozoSite.Text = "　現在使用";
            this.chkChozoSite.UseVisualStyleBackColor = true;
            // 
            // lblBiko2
            // 
            this.lblBiko2.AutoSize = true;
            this.lblBiko2.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblBiko2.Location = new System.Drawing.Point(478, 269);
            this.lblBiko2.Name = "lblBiko2";
            this.lblBiko2.Size = new System.Drawing.Size(42, 24);
            this.lblBiko2.TabIndex = 113;
            this.lblBiko2.Text = "備考";
            // 
            // chkSiyoTokute2Kakosiyo
            // 
            this.chkSiyoTokute2Kakosiyo.AutoSize = true;
            this.chkSiyoTokute2Kakosiyo.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bsKojoKihon, "TsYugaiKakoSiyo2Flag", true, System.Windows.Forms.DataSourceUpdateMode.Never));
            this.chkSiyoTokute2Kakosiyo.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.chkSiyoTokute2Kakosiyo.Location = new System.Drawing.Point(422, 614);
            this.chkSiyoTokute2Kakosiyo.Name = "chkSiyoTokute2Kakosiyo";
            this.chkSiyoTokute2Kakosiyo.Size = new System.Drawing.Size(109, 28);
            this.chkSiyoTokute2Kakosiyo.TabIndex = 56;
            this.chkSiyoTokute2Kakosiyo.Text = "　過去使用";
            this.chkSiyoTokute2Kakosiyo.UseVisualStyleBackColor = true;
            // 
            // chkZanteiKijunFlag
            // 
            this.chkZanteiKijunFlag.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.chkZanteiKijunFlag.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bsKojoKihon, "ZanteiKijunTekiyoFlag", true, System.Windows.Forms.DataSourceUpdateMode.Never));
            this.chkZanteiKijunFlag.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.chkZanteiKijunFlag.Location = new System.Drawing.Point(476, 364);
            this.chkZanteiKijunFlag.Name = "chkZanteiKijunFlag";
            this.chkZanteiKijunFlag.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.chkZanteiKijunFlag.Size = new System.Drawing.Size(145, 22);
            this.chkZanteiKijunFlag.TabIndex = 38;
            this.chkZanteiKijunFlag.Text = "暫定基準適用";
            this.chkZanteiKijunFlag.UseVisualStyleBackColor = true;
            // 
            // chkSiyoTokute2
            // 
            this.chkSiyoTokute2.AutoSize = true;
            this.chkSiyoTokute2.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bsKojoKihon, "TsYugaiGenSiyo2Flag", true, System.Windows.Forms.DataSourceUpdateMode.Never));
            this.chkSiyoTokute2.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.chkSiyoTokute2.Location = new System.Drawing.Point(299, 614);
            this.chkSiyoTokute2.Name = "chkSiyoTokute2";
            this.chkSiyoTokute2.Size = new System.Drawing.Size(109, 28);
            this.chkSiyoTokute2.TabIndex = 55;
            this.chkSiyoTokute2.Text = "　現在使用";
            this.chkSiyoTokute2.UseVisualStyleBackColor = true;
            // 
            // txtSyozaiJyusyo
            // 
            this.txtSyozaiJyusyo.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsKojoKihon, "SYOZAIJYUSYO", true, System.Windows.Forms.DataSourceUpdateMode.Never));
            this.txtSyozaiJyusyo.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtSyozaiJyusyo.ImeMode = System.Windows.Forms.ImeMode.Hiragana;
            this.txtSyozaiJyusyo.Location = new System.Drawing.Point(601, 109);
            this.txtSyozaiJyusyo.MaxLength = 100;
            this.txtSyozaiJyusyo.Name = "txtSyozaiJyusyo";
            this.txtSyozaiJyusyo.Size = new System.Drawing.Size(336, 31);
            this.txtSyozaiJyusyo.TabIndex = 17;
            // 
            // chkSiyoTokute1Kakosiyo
            // 
            this.chkSiyoTokute1Kakosiyo.AutoSize = true;
            this.chkSiyoTokute1Kakosiyo.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bsKojoKihon, "TsYugaiKakoSiyo1Flag", true, System.Windows.Forms.DataSourceUpdateMode.Never));
            this.chkSiyoTokute1Kakosiyo.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.chkSiyoTokute1Kakosiyo.Location = new System.Drawing.Point(422, 582);
            this.chkSiyoTokute1Kakosiyo.Name = "chkSiyoTokute1Kakosiyo";
            this.chkSiyoTokute1Kakosiyo.Size = new System.Drawing.Size(109, 28);
            this.chkSiyoTokute1Kakosiyo.TabIndex = 54;
            this.chkSiyoTokute1Kakosiyo.Text = "　過去使用";
            this.chkSiyoTokute1Kakosiyo.UseVisualStyleBackColor = true;
            // 
            // chkHaisuiKijun
            // 
            this.chkHaisuiKijun.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.chkHaisuiKijun.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bsKojoKihon, "HaisuiKijunTekiyoFlag", true, System.Windows.Forms.DataSourceUpdateMode.Never));
            this.chkHaisuiKijun.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.chkHaisuiKijun.Location = new System.Drawing.Point(476, 332);
            this.chkHaisuiKijun.Name = "chkHaisuiKijun";
            this.chkHaisuiKijun.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.chkHaisuiKijun.Size = new System.Drawing.Size(145, 22);
            this.chkHaisuiKijun.TabIndex = 37;
            this.chkHaisuiKijun.Text = "排水基準適用";
            this.chkHaisuiKijun.UseVisualStyleBackColor = true;
            // 
            // chkSiyoTokute1
            // 
            this.chkSiyoTokute1.AutoSize = true;
            this.chkSiyoTokute1.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bsKojoKihon, "TsYugaiGenSiyo1Flag", true, System.Windows.Forms.DataSourceUpdateMode.Never));
            this.chkSiyoTokute1.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.chkSiyoTokute1.Location = new System.Drawing.Point(299, 582);
            this.chkSiyoTokute1.Name = "chkSiyoTokute1";
            this.chkSiyoTokute1.Size = new System.Drawing.Size(109, 28);
            this.chkSiyoTokute1.TabIndex = 53;
            this.chkSiyoTokute1.Text = "　現在使用";
            this.chkSiyoTokute1.UseVisualStyleBackColor = true;
            // 
            // txtSinseiNameN
            // 
            this.txtSinseiNameN.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsKojoKihon, "SINSEINAMEN", true, System.Windows.Forms.DataSourceUpdateMode.Never));
            this.txtSinseiNameN.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtSinseiNameN.ImeMode = System.Windows.Forms.ImeMode.Hiragana;
            this.txtSinseiNameN.Location = new System.Drawing.Point(152, 266);
            this.txtSinseiNameN.MaxLength = 16;
            this.txtSinseiNameN.Name = "txtSinseiNameN";
            this.txtSinseiNameN.Size = new System.Drawing.Size(305, 31);
            this.txtSinseiNameN.TabIndex = 23;
            // 
            // chkTadasigaki2
            // 
            this.chkTadasigaki2.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.chkTadasigaki2.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bsKojoKihon, "DotaiHo3Jo1KoFlag", true, System.Windows.Forms.DataSourceUpdateMode.Never));
            this.chkTadasigaki2.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.chkTadasigaki2.Location = new System.Drawing.Point(476, 428);
            this.chkTadasigaki2.Name = "chkTadasigaki2";
            this.chkTadasigaki2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.chkTadasigaki2.Size = new System.Drawing.Size(145, 22);
            this.chkTadasigaki2.TabIndex = 40;
            this.chkTadasigaki2.Text = "3条1項但し書き";
            this.chkTadasigaki2.UseVisualStyleBackColor = true;
            // 
            // btnCancelKojoKihon
            // 
            this.btnCancelKojoKihon.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btnCancelKojoKihon.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnCancelKojoKihon.Location = new System.Drawing.Point(846, 20);
            this.btnCancelKojoKihon.Name = "btnCancelKojoKihon";
            this.btnCancelKojoKihon.Size = new System.Drawing.Size(100, 30);
            this.btnCancelKojoKihon.TabIndex = 2;
            this.btnCancelKojoKihon.Text = "キャンセル";
            this.btnCancelKojoKihon.UseVisualStyleBackColor = true;
            this.btnCancelKojoKihon.Click += new System.EventHandler(this.btnCancelKojoKihon_Click);
            // 
            // lblSoryoKiseiNo
            // 
            this.lblSoryoKiseiNo.AutoSize = true;
            this.lblSoryoKiseiNo.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblSoryoKiseiNo.Location = new System.Drawing.Point(12, 394);
            this.lblSoryoKiseiNo.Name = "lblSoryoKiseiNo";
            this.lblSoryoKiseiNo.Size = new System.Drawing.Size(106, 24);
            this.lblSoryoKiseiNo.TabIndex = 120;
            this.lblSoryoKiseiNo.Text = "総量規制番号";
            // 
            // lblSinseiYubinNo
            // 
            this.lblSinseiYubinNo.AutoSize = true;
            this.lblSinseiYubinNo.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblSinseiYubinNo.Location = new System.Drawing.Point(478, 205);
            this.lblSinseiYubinNo.Name = "lblSinseiYubinNo";
            this.lblSinseiYubinNo.Size = new System.Drawing.Size(74, 24);
            this.lblSinseiYubinNo.TabIndex = 88;
            this.lblSinseiYubinNo.Text = "郵便番号";
            // 
            // txtSoryoKiseiNo
            // 
            this.txtSoryoKiseiNo.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsKojoKihon, "SoryoKiseiNo", true, System.Windows.Forms.DataSourceUpdateMode.Never));
            this.txtSoryoKiseiNo.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtSoryoKiseiNo.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.txtSoryoKiseiNo.Location = new System.Drawing.Point(152, 391);
            this.txtSoryoKiseiNo.MaxLength = 4;
            this.txtSoryoKiseiNo.Name = "txtSoryoKiseiNo";
            this.txtSoryoKiseiNo.Size = new System.Drawing.Size(102, 31);
            this.txtSoryoKiseiNo.TabIndex = 33;
            // 
            // lblSyozaiJyusyo
            // 
            this.lblSyozaiJyusyo.AutoSize = true;
            this.lblSyozaiJyusyo.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblSyozaiJyusyo.Location = new System.Drawing.Point(478, 112);
            this.lblSyozaiJyusyo.Name = "lblSyozaiJyusyo";
            this.lblSyozaiJyusyo.Size = new System.Drawing.Size(58, 24);
            this.lblSyozaiJyusyo.TabIndex = 123;
            this.lblSyozaiJyusyo.Text = "所在地";
            // 
            // txtBiko3
            // 
            this.txtBiko3.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsKojoKihon, "BIKO3", true, System.Windows.Forms.DataSourceUpdateMode.Never));
            this.txtBiko3.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtBiko3.ImeMode = System.Windows.Forms.ImeMode.Hiragana;
            this.txtBiko3.Location = new System.Drawing.Point(601, 487);
            this.txtBiko3.MaxLength = 100;
            this.txtBiko3.Name = "txtBiko3";
            this.txtBiko3.Size = new System.Drawing.Size(336, 31);
            this.txtBiko3.TabIndex = 42;
            // 
            // lblSinseiNameN
            // 
            this.lblSinseiNameN.AutoSize = true;
            this.lblSinseiNameN.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblSinseiNameN.Location = new System.Drawing.Point(12, 269);
            this.lblSinseiNameN.Name = "lblSinseiNameN";
            this.lblSinseiNameN.Size = new System.Drawing.Size(74, 24);
            this.lblSinseiNameN.TabIndex = 108;
            this.lblSinseiNameN.Text = "担当者名";
            // 
            // lblSangyoBC
            // 
            this.lblSangyoBC.AutoSize = true;
            this.lblSangyoBC.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblSangyoBC.Location = new System.Drawing.Point(12, 330);
            this.lblSangyoBC.Name = "lblSangyoBC";
            this.lblSangyoBC.Size = new System.Drawing.Size(122, 24);
            this.lblSangyoBC.TabIndex = 80;
            this.lblSangyoBC.Text = "産業分類中分類";
            // 
            // lblBiko3
            // 
            this.lblBiko3.AutoSize = true;
            this.lblBiko3.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblBiko3.Location = new System.Drawing.Point(478, 490);
            this.lblBiko3.Name = "lblBiko3";
            this.lblBiko3.Size = new System.Drawing.Size(42, 24);
            this.lblBiko3.TabIndex = 112;
            this.lblBiko3.Text = "備考";
            // 
            // btnRegistKojoKihon
            // 
            this.btnRegistKojoKihon.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btnRegistKojoKihon.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnRegistKojoKihon.Location = new System.Drawing.Point(740, 20);
            this.btnRegistKojoKihon.Name = "btnRegistKojoKihon";
            this.btnRegistKojoKihon.Size = new System.Drawing.Size(100, 30);
            this.btnRegistKojoKihon.TabIndex = 1;
            this.btnRegistKojoKihon.Text = "登録";
            this.btnRegistKojoKihon.UseVisualStyleBackColor = true;
            this.btnRegistKojoKihon.Click += new System.EventHandler(this.btnRegistKojoKihon_Click);
            // 
            // lblSangyoBS
            // 
            this.lblSangyoBS.AutoSize = true;
            this.lblSangyoBS.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblSangyoBS.Location = new System.Drawing.Point(12, 362);
            this.lblSangyoBS.Name = "lblSangyoBS";
            this.lblSangyoBS.Size = new System.Drawing.Size(122, 24);
            this.lblSangyoBS.TabIndex = 84;
            this.lblSangyoBS.Text = "　　　　細分類";
            // 
            // txtSinseiCopName
            // 
            this.txtSinseiCopName.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsKojoKihon, "SinseiCopName", true, System.Windows.Forms.DataSourceUpdateMode.Never));
            this.txtSinseiCopName.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtSinseiCopName.ImeMode = System.Windows.Forms.ImeMode.Hiragana;
            this.txtSinseiCopName.Location = new System.Drawing.Point(152, 234);
            this.txtSinseiCopName.MaxLength = 16;
            this.txtSinseiCopName.Name = "txtSinseiCopName";
            this.txtSinseiCopName.Size = new System.Drawing.Size(305, 31);
            this.txtSinseiCopName.TabIndex = 22;
            // 
            // txtBiko1
            // 
            this.txtBiko1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsKojoKihon, "BIKO1", true, System.Windows.Forms.DataSourceUpdateMode.Never));
            this.txtBiko1.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtBiko1.ImeMode = System.Windows.Forms.ImeMode.Hiragana;
            this.txtBiko1.Location = new System.Drawing.Point(601, 141);
            this.txtBiko1.MaxLength = 100;
            this.txtBiko1.Name = "txtBiko1";
            this.txtBiko1.Size = new System.Drawing.Size(336, 31);
            this.txtBiko1.TabIndex = 18;
            // 
            // lblHoKbnCode
            // 
            this.lblHoKbnCode.AutoSize = true;
            this.lblHoKbnCode.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblHoKbnCode.Location = new System.Drawing.Point(12, 426);
            this.lblHoKbnCode.Name = "lblHoKbnCode";
            this.lblHoKbnCode.Size = new System.Drawing.Size(106, 24);
            this.lblHoKbnCode.TabIndex = 87;
            this.lblHoKbnCode.Text = "法区分コード";
            // 
            // txtSinseiTelNo
            // 
            this.txtSinseiTelNo.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsKojoKihon, "SINSEITELNO", true, System.Windows.Forms.DataSourceUpdateMode.Never));
            this.txtSinseiTelNo.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtSinseiTelNo.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.txtSinseiTelNo.Location = new System.Drawing.Point(811, 202);
            this.txtSinseiTelNo.MaxLength = 13;
            this.txtSinseiTelNo.Name = "txtSinseiTelNo";
            this.txtSinseiTelNo.Size = new System.Drawing.Size(126, 31);
            this.txtSinseiTelNo.TabIndex = 26;
            // 
            // lblKojoKihon
            // 
            this.lblKojoKihon.AutoSize = true;
            this.lblKojoKihon.Font = new System.Drawing.Font("メイリオ", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblKojoKihon.Location = new System.Drawing.Point(384, 15);
            this.lblKojoKihon.Name = "lblKojoKihon";
            this.lblKojoKihon.Size = new System.Drawing.Size(203, 31);
            this.lblKojoKihon.TabIndex = 142;
            this.lblKojoKihon.Text = "工場事業場基本情報";
            // 
            // lblSinseiTelNo
            // 
            this.lblSinseiTelNo.AutoSize = true;
            this.lblSinseiTelNo.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblSinseiTelNo.Location = new System.Drawing.Point(731, 205);
            this.lblSinseiTelNo.Name = "lblSinseiTelNo";
            this.lblSinseiTelNo.Size = new System.Drawing.Size(74, 24);
            this.lblSinseiTelNo.TabIndex = 105;
            this.lblSinseiTelNo.Text = "電話番号";
            // 
            // lblJigyosyoNameN
            // 
            this.lblJigyosyoNameN.AutoSize = true;
            this.lblJigyosyoNameN.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblJigyosyoNameN.Location = new System.Drawing.Point(12, 80);
            this.lblJigyosyoNameN.Name = "lblJigyosyoNameN";
            this.lblJigyosyoNameN.Size = new System.Drawing.Size(42, 24);
            this.lblJigyosyoNameN.TabIndex = 77;
            this.lblJigyosyoNameN.Text = "名称";
            // 
            // txtSinseiYubinNo1
            // 
            this.txtSinseiYubinNo1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsKojoKihon, "SinseiYubinNo1", true, System.Windows.Forms.DataSourceUpdateMode.Never));
            this.txtSinseiYubinNo1.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtSinseiYubinNo1.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.txtSinseiYubinNo1.Location = new System.Drawing.Point(601, 202);
            this.txtSinseiYubinNo1.MaxLength = 3;
            this.txtSinseiYubinNo1.Name = "txtSinseiYubinNo1";
            this.txtSinseiYubinNo1.Size = new System.Drawing.Size(40, 31);
            this.txtSinseiYubinNo1.TabIndex = 24;
            // 
            // lblBiko1
            // 
            this.lblBiko1.AutoSize = true;
            this.lblBiko1.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblBiko1.Location = new System.Drawing.Point(478, 144);
            this.lblBiko1.Name = "lblBiko1";
            this.lblBiko1.Size = new System.Drawing.Size(42, 24);
            this.lblBiko1.TabIndex = 115;
            this.lblBiko1.Text = "備考";
            // 
            // txtSinseiJyusyo
            // 
            this.txtSinseiJyusyo.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsKojoKihon, "SINSEIJYUSYO", true, System.Windows.Forms.DataSourceUpdateMode.Never));
            this.txtSinseiJyusyo.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtSinseiJyusyo.ImeMode = System.Windows.Forms.ImeMode.Hiragana;
            this.txtSinseiJyusyo.Location = new System.Drawing.Point(601, 234);
            this.txtSinseiJyusyo.MaxLength = 24;
            this.txtSinseiJyusyo.Name = "txtSinseiJyusyo";
            this.txtSinseiJyusyo.Size = new System.Drawing.Size(336, 31);
            this.txtSinseiJyusyo.TabIndex = 27;
            // 
            // lblRyuikiCode
            // 
            this.lblRyuikiCode.AutoSize = true;
            this.lblRyuikiCode.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblRyuikiCode.Location = new System.Drawing.Point(12, 490);
            this.lblRyuikiCode.Name = "lblRyuikiCode";
            this.lblRyuikiCode.Size = new System.Drawing.Size(90, 24);
            this.lblRyuikiCode.TabIndex = 98;
            this.lblRyuikiCode.Text = "流域コード";
            // 
            // lblJigyojoLine
            // 
            this.lblJigyojoLine.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblJigyojoLine.Font = new System.Drawing.Font("ＭＳ ゴシック", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblJigyojoLine.Location = new System.Drawing.Point(116, 62);
            this.lblJigyojoLine.Name = "lblJigyojoLine";
            this.lblJigyojoLine.Size = new System.Drawing.Size(825, 1);
            this.lblJigyojoLine.TabIndex = 79;
            // 
            // lblSikibetuCode
            // 
            this.lblSikibetuCode.AutoSize = true;
            this.lblSikibetuCode.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblSikibetuCode.Location = new System.Drawing.Point(12, 458);
            this.lblSikibetuCode.Name = "lblSikibetuCode";
            this.lblSikibetuCode.Size = new System.Drawing.Size(90, 24);
            this.lblSikibetuCode.TabIndex = 99;
            this.lblSikibetuCode.Text = "識別コード";
            // 
            // lblTodokedeYubinNoHi
            // 
            this.lblTodokedeYubinNoHi.AutoSize = true;
            this.lblTodokedeYubinNoHi.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblTodokedeYubinNoHi.Location = new System.Drawing.Point(647, 206);
            this.lblTodokedeYubinNoHi.Name = "lblTodokedeYubinNoHi";
            this.lblTodokedeYubinNoHi.Size = new System.Drawing.Size(17, 24);
            this.lblTodokedeYubinNoHi.TabIndex = 95;
            this.lblTodokedeYubinNoHi.Text = "-";
            // 
            // lblJigyosyoNameK
            // 
            this.lblJigyosyoNameK.AutoSize = true;
            this.lblJigyosyoNameK.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblJigyosyoNameK.Location = new System.Drawing.Point(12, 112);
            this.lblJigyosyoNameK.Name = "lblJigyosyoNameK";
            this.lblJigyosyoNameK.Size = new System.Drawing.Size(74, 24);
            this.lblJigyosyoNameK.TabIndex = 85;
            this.lblJigyosyoNameK.Text = "名称カナ";
            // 
            // lblSinseiJyusyo
            // 
            this.lblSinseiJyusyo.AutoSize = true;
            this.lblSinseiJyusyo.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblSinseiJyusyo.Location = new System.Drawing.Point(478, 237);
            this.lblSinseiJyusyo.Name = "lblSinseiJyusyo";
            this.lblSinseiJyusyo.Size = new System.Drawing.Size(58, 24);
            this.lblSinseiJyusyo.TabIndex = 101;
            this.lblSinseiJyusyo.Text = "所在地";
            // 
            // lblJigyojo
            // 
            this.lblJigyojo.AutoSize = true;
            this.lblJigyojo.Font = new System.Drawing.Font("メイリオ", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblJigyojo.Location = new System.Drawing.Point(1, 53);
            this.lblJigyojo.Name = "lblJigyojo";
            this.lblJigyojo.Size = new System.Drawing.Size(113, 20);
            this.lblJigyojo.TabIndex = 78;
            this.lblJigyojo.Text = "①工場事業場情報";
            // 
            // txtSinseiYubinNo2
            // 
            this.txtSinseiYubinNo2.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsKojoKihon, "SinseiYubinNo2", true, System.Windows.Forms.DataSourceUpdateMode.Never));
            this.txtSinseiYubinNo2.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtSinseiYubinNo2.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.txtSinseiYubinNo2.Location = new System.Drawing.Point(669, 202);
            this.txtSinseiYubinNo2.MaxLength = 4;
            this.txtSinseiYubinNo2.Name = "txtSinseiYubinNo2";
            this.txtSinseiYubinNo2.Size = new System.Drawing.Size(46, 31);
            this.txtSinseiYubinNo2.TabIndex = 25;
            // 
            // txtKTantoNameN
            // 
            this.txtKTantoNameN.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsKojoKihon, "KTantoNameN", true, System.Windows.Forms.DataSourceUpdateMode.Never));
            this.txtKTantoNameN.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtKTantoNameN.ImeMode = System.Windows.Forms.ImeMode.Hiragana;
            this.txtKTantoNameN.Location = new System.Drawing.Point(152, 141);
            this.txtKTantoNameN.MaxLength = 16;
            this.txtKTantoNameN.Name = "txtKTantoNameN";
            this.txtKTantoNameN.Size = new System.Drawing.Size(305, 31);
            this.txtKTantoNameN.TabIndex = 13;
            // 
            // lbltxtSyozaiYubinNo
            // 
            this.lbltxtSyozaiYubinNo.AutoSize = true;
            this.lbltxtSyozaiYubinNo.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lbltxtSyozaiYubinNo.Location = new System.Drawing.Point(478, 80);
            this.lbltxtSyozaiYubinNo.Name = "lbltxtSyozaiYubinNo";
            this.lbltxtSyozaiYubinNo.Size = new System.Drawing.Size(74, 24);
            this.lbltxtSyozaiYubinNo.TabIndex = 90;
            this.lbltxtSyozaiYubinNo.Text = "郵便番号";
            // 
            // lblKTantoNameN
            // 
            this.lblKTantoNameN.AutoSize = true;
            this.lblKTantoNameN.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblKTantoNameN.Location = new System.Drawing.Point(12, 144);
            this.lblKTantoNameN.Name = "lblKTantoNameN";
            this.lblKTantoNameN.Size = new System.Drawing.Size(74, 24);
            this.lblKTantoNameN.TabIndex = 109;
            this.lblKTantoNameN.Text = "担当者名";
            // 
            // txtJigyosyoNameN
            // 
            this.txtJigyosyoNameN.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsKojoKihon, "JIGYOSYONAMEN", true, System.Windows.Forms.DataSourceUpdateMode.Never));
            this.txtJigyosyoNameN.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtJigyosyoNameN.ImeMode = System.Windows.Forms.ImeMode.Hiragana;
            this.txtJigyosyoNameN.Location = new System.Drawing.Point(152, 77);
            this.txtJigyosyoNameN.MaxLength = 100;
            this.txtJigyosyoNameN.Name = "txtJigyosyoNameN";
            this.txtJigyosyoNameN.Size = new System.Drawing.Size(305, 31);
            this.txtJigyosyoNameN.TabIndex = 11;
            // 
            // txtTelNo
            // 
            this.txtTelNo.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsKojoKihon, "TELNO", true, System.Windows.Forms.DataSourceUpdateMode.Never));
            this.txtTelNo.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtTelNo.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.txtTelNo.Location = new System.Drawing.Point(811, 77);
            this.txtTelNo.MaxLength = 13;
            this.txtTelNo.Name = "txtTelNo";
            this.txtTelNo.Size = new System.Drawing.Size(126, 31);
            this.txtTelNo.TabIndex = 16;
            // 
            // txtJigyosyoNameK
            // 
            this.txtJigyosyoNameK.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsKojoKihon, "JIGYOSYONAMEK", true, System.Windows.Forms.DataSourceUpdateMode.Never));
            this.txtJigyosyoNameK.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtJigyosyoNameK.ImeMode = System.Windows.Forms.ImeMode.Katakana;
            this.txtJigyosyoNameK.Location = new System.Drawing.Point(152, 109);
            this.txtJigyosyoNameK.MaxLength = 100;
            this.txtJigyosyoNameK.Name = "txtJigyosyoNameK";
            this.txtJigyosyoNameK.Size = new System.Drawing.Size(305, 31);
            this.txtJigyosyoNameK.TabIndex = 12;
            // 
            // lbltxtTelNo
            // 
            this.lbltxtTelNo.AutoSize = true;
            this.lbltxtTelNo.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lbltxtTelNo.Location = new System.Drawing.Point(731, 80);
            this.lbltxtTelNo.Name = "lbltxtTelNo";
            this.lbltxtTelNo.Size = new System.Drawing.Size(74, 24);
            this.lbltxtTelNo.TabIndex = 104;
            this.lbltxtTelNo.Text = "電話番号";
            // 
            // txtSyozaiYubinNo2
            // 
            this.txtSyozaiYubinNo2.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsKojoKihon, "SyozaiYubinNo2", true, System.Windows.Forms.DataSourceUpdateMode.Never));
            this.txtSyozaiYubinNo2.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtSyozaiYubinNo2.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.txtSyozaiYubinNo2.Location = new System.Drawing.Point(664, 77);
            this.txtSyozaiYubinNo2.MaxLength = 4;
            this.txtSyozaiYubinNo2.Name = "txtSyozaiYubinNo2";
            this.txtSyozaiYubinNo2.Size = new System.Drawing.Size(46, 31);
            this.txtSyozaiYubinNo2.TabIndex = 15;
            // 
            // txtSyozaiYubinNo1
            // 
            this.txtSyozaiYubinNo1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsKojoKihon, "SyozaiYubinNo1", true, System.Windows.Forms.DataSourceUpdateMode.Never));
            this.txtSyozaiYubinNo1.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtSyozaiYubinNo1.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.txtSyozaiYubinNo1.Location = new System.Drawing.Point(601, 77);
            this.txtSyozaiYubinNo1.MaxLength = 3;
            this.txtSyozaiYubinNo1.Name = "txtSyozaiYubinNo1";
            this.txtSyozaiYubinNo1.Size = new System.Drawing.Size(40, 31);
            this.txtSyozaiYubinNo1.TabIndex = 14;
            // 
            // lblJigyojoYubinNoHi
            // 
            this.lblJigyojoYubinNoHi.AutoSize = true;
            this.lblJigyojoYubinNoHi.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblJigyojoYubinNoHi.Location = new System.Drawing.Point(645, 80);
            this.lblJigyojoYubinNoHi.Name = "lblJigyojoYubinNoHi";
            this.lblJigyojoYubinNoHi.Size = new System.Drawing.Size(17, 24);
            this.lblJigyojoYubinNoHi.TabIndex = 94;
            this.lblJigyojoYubinNoHi.Text = "-";
            // 
            // tabTodokedeRireki
            // 
            this.tabTodokedeRireki.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.tabTodokedeRireki.Controls.Add(this.lblCountNumberTodokedeRireki);
            this.tabTodokedeRireki.Controls.Add(this.dgvTodokedeRireki);
            this.tabTodokedeRireki.Controls.Add(this.lblCountRecordTodokedeRireki);
            this.tabTodokedeRireki.Controls.Add(this.lblTodokedeRireki);
            this.tabTodokedeRireki.Controls.Add(this.btnCopyTodokedeRireki);
            this.tabTodokedeRireki.Controls.Add(this.btnSelectTodokedeRireki);
            this.tabTodokedeRireki.Controls.Add(this.btnAddTodokedeRireki);
            this.tabTodokedeRireki.Location = new System.Drawing.Point(4, 36);
            this.tabTodokedeRireki.Name = "tabTodokedeRireki";
            this.tabTodokedeRireki.Padding = new System.Windows.Forms.Padding(3);
            this.tabTodokedeRireki.Size = new System.Drawing.Size(970, 521);
            this.tabTodokedeRireki.TabIndex = 1;
            this.tabTodokedeRireki.Text = "届出履歴";
            // 
            // lblCountNumberTodokedeRireki
            // 
            this.lblCountNumberTodokedeRireki.AutoSize = true;
            this.lblCountNumberTodokedeRireki.Location = new System.Drawing.Point(15, 25);
            this.lblCountNumberTodokedeRireki.Name = "lblCountNumberTodokedeRireki";
            this.lblCountNumberTodokedeRireki.Size = new System.Drawing.Size(60, 24);
            this.lblCountNumberTodokedeRireki.TabIndex = 49;
            this.lblCountNumberTodokedeRireki.Text = "件数 =";
            // 
            // dgvTodokedeRireki
            // 
            this.dgvTodokedeRireki.AllowUserToAddRows = false;
            this.dgvTodokedeRireki.AllowUserToDeleteRows = false;
            this.dgvTodokedeRireki.AllowUserToResizeColumns = false;
            this.dgvTodokedeRireki.AllowUserToResizeRows = false;
            this.dgvTodokedeRireki.AutoGenerateColumns = false;
            this.dgvTodokedeRireki.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvTodokedeRireki.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.TdkdNo,
            this.TdkdKbn,
            this.TodokedeDateShortW,
            this.UketukeNo,
            this.TdkdSyubetu,
            this.TdkdSyubetuS,
            this.Biko1,
            this.Biko2,
            this.Biko3});
            this.dgvTodokedeRireki.DataSource = this.bsTodokedeRireki;
            this.dgvTodokedeRireki.Location = new System.Drawing.Point(15, 49);
            this.dgvTodokedeRireki.MultiSelect = false;
            this.dgvTodokedeRireki.Name = "dgvTodokedeRireki";
            this.dgvTodokedeRireki.ReadOnly = true;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvTodokedeRireki.RowHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvTodokedeRireki.RowHeadersVisible = false;
            this.dgvTodokedeRireki.RowTemplate.Height = 21;
            this.dgvTodokedeRireki.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvTodokedeRireki.Size = new System.Drawing.Size(938, 411);
            this.dgvTodokedeRireki.TabIndex = 1;
            this.dgvTodokedeRireki.TabStop = false;
            this.dgvTodokedeRireki.CellMouseDoubleClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgvTodokedeRireki_CellMouseDoubleClick);
            // 
            // lblCountRecordTodokedeRireki
            // 
            this.lblCountRecordTodokedeRireki.AutoSize = true;
            this.lblCountRecordTodokedeRireki.Location = new System.Drawing.Point(75, 25);
            this.lblCountRecordTodokedeRireki.Name = "lblCountRecordTodokedeRireki";
            this.lblCountRecordTodokedeRireki.Size = new System.Drawing.Size(20, 24);
            this.lblCountRecordTodokedeRireki.TabIndex = 48;
            this.lblCountRecordTodokedeRireki.Text = "0";
            // 
            // lblTodokedeRireki
            // 
            this.lblTodokedeRireki.AutoSize = true;
            this.lblTodokedeRireki.Font = new System.Drawing.Font("メイリオ", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblTodokedeRireki.Location = new System.Drawing.Point(415, 15);
            this.lblTodokedeRireki.Name = "lblTodokedeRireki";
            this.lblTodokedeRireki.Size = new System.Drawing.Size(140, 31);
            this.lblTodokedeRireki.TabIndex = 47;
            this.lblTodokedeRireki.Text = "届出履歴一覧";
            // 
            // btnCopyTodokedeRireki
            // 
            this.btnCopyTodokedeRireki.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnCopyTodokedeRireki.Location = new System.Drawing.Point(748, 475);
            this.btnCopyTodokedeRireki.Name = "btnCopyTodokedeRireki";
            this.btnCopyTodokedeRireki.Size = new System.Drawing.Size(100, 30);
            this.btnCopyTodokedeRireki.TabIndex = 3;
            this.btnCopyTodokedeRireki.Text = "複写";
            this.btnCopyTodokedeRireki.UseVisualStyleBackColor = true;
            this.btnCopyTodokedeRireki.Click += new System.EventHandler(this.btnCopyTodokedeRireki_Click);
            // 
            // btnSelectTodokedeRireki
            // 
            this.btnSelectTodokedeRireki.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnSelectTodokedeRireki.Location = new System.Drawing.Point(853, 475);
            this.btnSelectTodokedeRireki.Name = "btnSelectTodokedeRireki";
            this.btnSelectTodokedeRireki.Size = new System.Drawing.Size(100, 30);
            this.btnSelectTodokedeRireki.TabIndex = 4;
            this.btnSelectTodokedeRireki.Text = "選択";
            this.btnSelectTodokedeRireki.UseVisualStyleBackColor = true;
            this.btnSelectTodokedeRireki.Click += new System.EventHandler(this.btnSelect_Click);
            // 
            // btnAddTodokedeRireki
            // 
            this.btnAddTodokedeRireki.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnAddTodokedeRireki.Location = new System.Drawing.Point(642, 475);
            this.btnAddTodokedeRireki.Name = "btnAddTodokedeRireki";
            this.btnAddTodokedeRireki.Size = new System.Drawing.Size(100, 30);
            this.btnAddTodokedeRireki.TabIndex = 2;
            this.btnAddTodokedeRireki.Text = "追加";
            this.btnAddTodokedeRireki.UseVisualStyleBackColor = true;
            this.btnAddTodokedeRireki.Click += new System.EventHandler(this.btnAddTodokedeRireki_Click);
            // 
            // tabTokuteiSisetu
            // 
            this.tabTokuteiSisetu.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.tabTokuteiSisetu.Controls.Add(this.lblCountRecordTokuteiSisetuTou);
            this.tabTokuteiSisetu.Controls.Add(this.lblCountNumberTokuteiSisetu);
            this.tabTokuteiSisetu.Controls.Add(this.lblTokuteiSisetu);
            this.tabTokuteiSisetu.Controls.Add(this.btnCopyTokuteiSisetuTou);
            this.tabTokuteiSisetu.Controls.Add(this.btnSelectTokuteiSisetuTou);
            this.tabTokuteiSisetu.Controls.Add(this.btnAddTokuteiSisetuTou);
            this.tabTokuteiSisetu.Controls.Add(this.dgvTokuteiSisetuTou);
            this.tabTokuteiSisetu.Location = new System.Drawing.Point(4, 36);
            this.tabTokuteiSisetu.Name = "tabTokuteiSisetu";
            this.tabTokuteiSisetu.Padding = new System.Windows.Forms.Padding(3);
            this.tabTokuteiSisetu.Size = new System.Drawing.Size(970, 521);
            this.tabTokuteiSisetu.TabIndex = 2;
            this.tabTokuteiSisetu.Text = "特定施設等";
            // 
            // lblCountRecordTokuteiSisetuTou
            // 
            this.lblCountRecordTokuteiSisetuTou.AutoSize = true;
            this.lblCountRecordTokuteiSisetuTou.Location = new System.Drawing.Point(75, 25);
            this.lblCountRecordTokuteiSisetuTou.Name = "lblCountRecordTokuteiSisetuTou";
            this.lblCountRecordTokuteiSisetuTou.Size = new System.Drawing.Size(20, 24);
            this.lblCountRecordTokuteiSisetuTou.TabIndex = 49;
            this.lblCountRecordTokuteiSisetuTou.Text = "0";
            // 
            // lblCountNumberTokuteiSisetu
            // 
            this.lblCountNumberTokuteiSisetu.AutoSize = true;
            this.lblCountNumberTokuteiSisetu.Location = new System.Drawing.Point(15, 25);
            this.lblCountNumberTokuteiSisetu.Name = "lblCountNumberTokuteiSisetu";
            this.lblCountNumberTokuteiSisetu.Size = new System.Drawing.Size(60, 24);
            this.lblCountNumberTokuteiSisetu.TabIndex = 48;
            this.lblCountNumberTokuteiSisetu.Text = "件数 =";
            // 
            // lblTokuteiSisetu
            // 
            this.lblTokuteiSisetu.AutoSize = true;
            this.lblTokuteiSisetu.Font = new System.Drawing.Font("メイリオ", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblTokuteiSisetu.Location = new System.Drawing.Point(405, 15);
            this.lblTokuteiSisetu.Name = "lblTokuteiSisetu";
            this.lblTokuteiSisetu.Size = new System.Drawing.Size(161, 31);
            this.lblTokuteiSisetu.TabIndex = 47;
            this.lblTokuteiSisetu.Text = "特定施設等一覧";
            // 
            // btnCopyTokuteiSisetuTou
            // 
            this.btnCopyTokuteiSisetuTou.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCopyTokuteiSisetuTou.Location = new System.Drawing.Point(747, 475);
            this.btnCopyTokuteiSisetuTou.Name = "btnCopyTokuteiSisetuTou";
            this.btnCopyTokuteiSisetuTou.Size = new System.Drawing.Size(100, 30);
            this.btnCopyTokuteiSisetuTou.TabIndex = 3;
            this.btnCopyTokuteiSisetuTou.Text = "複写";
            this.btnCopyTokuteiSisetuTou.UseVisualStyleBackColor = true;
            this.btnCopyTokuteiSisetuTou.Click += new System.EventHandler(this.btnCopyTokuteiSisetu_Click);
            // 
            // btnSelectTokuteiSisetuTou
            // 
            this.btnSelectTokuteiSisetuTou.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSelectTokuteiSisetuTou.Location = new System.Drawing.Point(853, 475);
            this.btnSelectTokuteiSisetuTou.Name = "btnSelectTokuteiSisetuTou";
            this.btnSelectTokuteiSisetuTou.Size = new System.Drawing.Size(100, 30);
            this.btnSelectTokuteiSisetuTou.TabIndex = 4;
            this.btnSelectTokuteiSisetuTou.Text = "選択";
            this.btnSelectTokuteiSisetuTou.UseVisualStyleBackColor = true;
            this.btnSelectTokuteiSisetuTou.Click += new System.EventHandler(this.btnSelectTokuteiSisetu_Click);
            // 
            // btnAddTokuteiSisetuTou
            // 
            this.btnAddTokuteiSisetuTou.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddTokuteiSisetuTou.Location = new System.Drawing.Point(641, 475);
            this.btnAddTokuteiSisetuTou.Name = "btnAddTokuteiSisetuTou";
            this.btnAddTokuteiSisetuTou.Size = new System.Drawing.Size(100, 30);
            this.btnAddTokuteiSisetuTou.TabIndex = 2;
            this.btnAddTokuteiSisetuTou.Text = "追加";
            this.btnAddTokuteiSisetuTou.UseVisualStyleBackColor = true;
            this.btnAddTokuteiSisetuTou.Click += new System.EventHandler(this.btnAddTokuteiSisetu_Click);
            // 
            // dgvTokuteiSisetuTou
            // 
            this.dgvTokuteiSisetuTou.AllowUserToAddRows = false;
            this.dgvTokuteiSisetuTou.AllowUserToDeleteRows = false;
            this.dgvTokuteiSisetuTou.AllowUserToResizeColumns = false;
            this.dgvTokuteiSisetuTou.AllowUserToResizeRows = false;
            this.dgvTokuteiSisetuTou.AutoGenerateColumns = false;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvTokuteiSisetuTou.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dgvTokuteiSisetuTou.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvTokuteiSisetuTou.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.HaisiFlag,
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn11,
            this.dataGridViewTextBoxColumn12,
            this.dataGridViewTextBoxColumn13,
            this.dataGridViewTextBoxColumn14,
            this.dataGridViewTextBoxColumn9,
            this.dataGridViewTextBoxColumn10,
            this.dataGridViewTextBoxColumn15,
            this.dataGridViewTextBoxColumn24});
            this.dgvTokuteiSisetuTou.DataSource = this.bsTokuteiSisetuTou;
            this.dgvTokuteiSisetuTou.Location = new System.Drawing.Point(15, 49);
            this.dgvTokuteiSisetuTou.MultiSelect = false;
            this.dgvTokuteiSisetuTou.Name = "dgvTokuteiSisetuTou";
            this.dgvTokuteiSisetuTou.ReadOnly = true;
            this.dgvTokuteiSisetuTou.RowHeadersVisible = false;
            this.dgvTokuteiSisetuTou.RowTemplate.Height = 21;
            this.dgvTokuteiSisetuTou.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvTokuteiSisetuTou.Size = new System.Drawing.Size(938, 411);
            this.dgvTokuteiSisetuTou.TabIndex = 1;
            this.dgvTokuteiSisetuTou.TabStop = false;
            this.dgvTokuteiSisetuTou.CellMouseDoubleClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgvTokuteiSisetu_CellMouseDoubleClick);
            // 
            // tabFutaisetubi
            // 
            this.tabFutaisetubi.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.tabFutaisetubi.Controls.Add(this.lblCountRecordFutaiSetubiTou);
            this.tabFutaisetubi.Controls.Add(this.lblCountNumberFutaiSetubiTou);
            this.tabFutaisetubi.Controls.Add(this.lblFutaiSetubiTou);
            this.tabFutaisetubi.Controls.Add(this.btnCopyFutaiSetubiTou);
            this.tabFutaisetubi.Controls.Add(this.btnSelectFutaiSetubiTou);
            this.tabFutaisetubi.Controls.Add(this.btnAddFutaiSetubiTou);
            this.tabFutaisetubi.Controls.Add(this.dgvFutaiSetubiTou);
            this.tabFutaisetubi.Location = new System.Drawing.Point(4, 36);
            this.tabFutaisetubi.Name = "tabFutaisetubi";
            this.tabFutaisetubi.Padding = new System.Windows.Forms.Padding(3);
            this.tabFutaisetubi.Size = new System.Drawing.Size(970, 521);
            this.tabFutaisetubi.TabIndex = 7;
            this.tabFutaisetubi.Text = "付帯設備等";
            // 
            // lblCountRecordFutaiSetubiTou
            // 
            this.lblCountRecordFutaiSetubiTou.AutoSize = true;
            this.lblCountRecordFutaiSetubiTou.Location = new System.Drawing.Point(75, 25);
            this.lblCountRecordFutaiSetubiTou.Name = "lblCountRecordFutaiSetubiTou";
            this.lblCountRecordFutaiSetubiTou.Size = new System.Drawing.Size(20, 24);
            this.lblCountRecordFutaiSetubiTou.TabIndex = 49;
            this.lblCountRecordFutaiSetubiTou.Text = "0";
            // 
            // lblCountNumberFutaiSetubiTou
            // 
            this.lblCountNumberFutaiSetubiTou.AutoSize = true;
            this.lblCountNumberFutaiSetubiTou.Location = new System.Drawing.Point(15, 25);
            this.lblCountNumberFutaiSetubiTou.Name = "lblCountNumberFutaiSetubiTou";
            this.lblCountNumberFutaiSetubiTou.Size = new System.Drawing.Size(60, 24);
            this.lblCountNumberFutaiSetubiTou.TabIndex = 48;
            this.lblCountNumberFutaiSetubiTou.Text = "件数 =";
            // 
            // lblFutaiSetubiTou
            // 
            this.lblFutaiSetubiTou.AutoSize = true;
            this.lblFutaiSetubiTou.Font = new System.Drawing.Font("メイリオ", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblFutaiSetubiTou.Location = new System.Drawing.Point(405, 15);
            this.lblFutaiSetubiTou.Name = "lblFutaiSetubiTou";
            this.lblFutaiSetubiTou.Size = new System.Drawing.Size(161, 31);
            this.lblFutaiSetubiTou.TabIndex = 47;
            this.lblFutaiSetubiTou.Text = "付帯設備等一覧";
            // 
            // btnCopyFutaiSetubiTou
            // 
            this.btnCopyFutaiSetubiTou.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCopyFutaiSetubiTou.Location = new System.Drawing.Point(747, 475);
            this.btnCopyFutaiSetubiTou.Name = "btnCopyFutaiSetubiTou";
            this.btnCopyFutaiSetubiTou.Size = new System.Drawing.Size(100, 30);
            this.btnCopyFutaiSetubiTou.TabIndex = 3;
            this.btnCopyFutaiSetubiTou.Text = "複写";
            this.btnCopyFutaiSetubiTou.UseVisualStyleBackColor = true;
            this.btnCopyFutaiSetubiTou.Click += new System.EventHandler(this.btnCopyFutaisetubi_Click);
            // 
            // btnSelectFutaiSetubiTou
            // 
            this.btnSelectFutaiSetubiTou.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSelectFutaiSetubiTou.Location = new System.Drawing.Point(853, 475);
            this.btnSelectFutaiSetubiTou.Name = "btnSelectFutaiSetubiTou";
            this.btnSelectFutaiSetubiTou.Size = new System.Drawing.Size(100, 30);
            this.btnSelectFutaiSetubiTou.TabIndex = 4;
            this.btnSelectFutaiSetubiTou.Text = "選択";
            this.btnSelectFutaiSetubiTou.UseVisualStyleBackColor = true;
            this.btnSelectFutaiSetubiTou.Click += new System.EventHandler(this.btnSelectFutaisetubi_Click);
            // 
            // btnAddFutaiSetubiTou
            // 
            this.btnAddFutaiSetubiTou.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddFutaiSetubiTou.Location = new System.Drawing.Point(641, 475);
            this.btnAddFutaiSetubiTou.Name = "btnAddFutaiSetubiTou";
            this.btnAddFutaiSetubiTou.Size = new System.Drawing.Size(100, 30);
            this.btnAddFutaiSetubiTou.TabIndex = 2;
            this.btnAddFutaiSetubiTou.Text = "追加";
            this.btnAddFutaiSetubiTou.UseVisualStyleBackColor = true;
            this.btnAddFutaiSetubiTou.Click += new System.EventHandler(this.btnAddFutaisetubi_Click);
            // 
            // dgvFutaiSetubiTou
            // 
            this.dgvFutaiSetubiTou.AllowUserToAddRows = false;
            this.dgvFutaiSetubiTou.AllowUserToDeleteRows = false;
            this.dgvFutaiSetubiTou.AllowUserToResizeColumns = false;
            this.dgvFutaiSetubiTou.AllowUserToResizeRows = false;
            this.dgvFutaiSetubiTou.AutoGenerateColumns = false;
            dataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvFutaiSetubiTou.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle5;
            this.dgvFutaiSetubiTou.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvFutaiSetubiTou.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.fsNoDataGridViewTextBoxColumn,
            this.torimatomeFlagVDataGridViewTextBoxColumn,
            this.tsNoDataGridViewTextBoxColumn,
            this.sisetuNameNDataGridViewTextBoxColumn,
            this.setubiUmuFlag1VDataGridViewTextBoxColumn,
            this.setubiUmuFlag2VDataGridViewTextBoxColumn,
            this.setubiUmuFlag3VDataGridViewTextBoxColumn,
            this.setubiUmuFlag4VDataGridViewTextBoxColumn,
            this.setubiUmuFlag5VDataGridViewTextBoxColumn,
            this.setubiUmuFlag6VDataGridViewTextBoxColumn,
            this.setubiUmuFlag7VDataGridViewTextBoxColumn});
            this.dgvFutaiSetubiTou.DataSource = this.bsFutaiSetubiTou;
            this.dgvFutaiSetubiTou.Location = new System.Drawing.Point(15, 49);
            this.dgvFutaiSetubiTou.MultiSelect = false;
            this.dgvFutaiSetubiTou.Name = "dgvFutaiSetubiTou";
            this.dgvFutaiSetubiTou.ReadOnly = true;
            this.dgvFutaiSetubiTou.RowHeadersVisible = false;
            this.dgvFutaiSetubiTou.RowTemplate.Height = 21;
            this.dgvFutaiSetubiTou.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvFutaiSetubiTou.Size = new System.Drawing.Size(938, 411);
            this.dgvFutaiSetubiTou.TabIndex = 1;
            this.dgvFutaiSetubiTou.TabStop = false;
            this.dgvFutaiSetubiTou.CellMouseDoubleClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgvFutaiSetubiTou_CellMouseDoubleClick);
            // 
            // tabShoriSisetu
            // 
            this.tabShoriSisetu.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.tabShoriSisetu.Controls.Add(this.lblCountRecordShoriSisetu);
            this.tabShoriSisetu.Controls.Add(this.lblCountNumberShoriSisetu);
            this.tabShoriSisetu.Controls.Add(this.lblShoriSisetu);
            this.tabShoriSisetu.Controls.Add(this.btnCopyShoriSisetu);
            this.tabShoriSisetu.Controls.Add(this.btnSelectShoriSisetu);
            this.tabShoriSisetu.Controls.Add(this.btnAddShoriSisetu);
            this.tabShoriSisetu.Controls.Add(this.dgvShoriSisetu);
            this.tabShoriSisetu.Location = new System.Drawing.Point(4, 36);
            this.tabShoriSisetu.Name = "tabShoriSisetu";
            this.tabShoriSisetu.Padding = new System.Windows.Forms.Padding(3);
            this.tabShoriSisetu.Size = new System.Drawing.Size(970, 521);
            this.tabShoriSisetu.TabIndex = 3;
            this.tabShoriSisetu.Text = "処理施設";
            // 
            // lblCountRecordShoriSisetu
            // 
            this.lblCountRecordShoriSisetu.AutoSize = true;
            this.lblCountRecordShoriSisetu.Location = new System.Drawing.Point(75, 25);
            this.lblCountRecordShoriSisetu.Name = "lblCountRecordShoriSisetu";
            this.lblCountRecordShoriSisetu.Size = new System.Drawing.Size(20, 24);
            this.lblCountRecordShoriSisetu.TabIndex = 50;
            this.lblCountRecordShoriSisetu.Text = "0";
            // 
            // lblCountNumberShoriSisetu
            // 
            this.lblCountNumberShoriSisetu.AutoSize = true;
            this.lblCountNumberShoriSisetu.Location = new System.Drawing.Point(15, 25);
            this.lblCountNumberShoriSisetu.Name = "lblCountNumberShoriSisetu";
            this.lblCountNumberShoriSisetu.Size = new System.Drawing.Size(60, 24);
            this.lblCountNumberShoriSisetu.TabIndex = 49;
            this.lblCountNumberShoriSisetu.Text = "件数 =";
            // 
            // lblShoriSisetu
            // 
            this.lblShoriSisetu.AutoSize = true;
            this.lblShoriSisetu.Font = new System.Drawing.Font("メイリオ", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblShoriSisetu.Location = new System.Drawing.Point(384, 15);
            this.lblShoriSisetu.Name = "lblShoriSisetu";
            this.lblShoriSisetu.Size = new System.Drawing.Size(203, 31);
            this.lblShoriSisetu.TabIndex = 48;
            this.lblShoriSisetu.Text = "汚水等処理施設一覧";
            // 
            // btnCopyShoriSisetu
            // 
            this.btnCopyShoriSisetu.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnCopyShoriSisetu.Location = new System.Drawing.Point(747, 475);
            this.btnCopyShoriSisetu.Name = "btnCopyShoriSisetu";
            this.btnCopyShoriSisetu.Size = new System.Drawing.Size(100, 30);
            this.btnCopyShoriSisetu.TabIndex = 3;
            this.btnCopyShoriSisetu.Text = "複写";
            this.btnCopyShoriSisetu.UseVisualStyleBackColor = true;
            this.btnCopyShoriSisetu.Click += new System.EventHandler(this.btnCopyShoriSisetu_Click);
            // 
            // btnSelectShoriSisetu
            // 
            this.btnSelectShoriSisetu.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnSelectShoriSisetu.Location = new System.Drawing.Point(853, 475);
            this.btnSelectShoriSisetu.Name = "btnSelectShoriSisetu";
            this.btnSelectShoriSisetu.Size = new System.Drawing.Size(100, 30);
            this.btnSelectShoriSisetu.TabIndex = 4;
            this.btnSelectShoriSisetu.Text = "選択";
            this.btnSelectShoriSisetu.UseVisualStyleBackColor = true;
            this.btnSelectShoriSisetu.Click += new System.EventHandler(this.btnSelectShoriSisetu_Click);
            // 
            // btnAddShoriSisetu
            // 
            this.btnAddShoriSisetu.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnAddShoriSisetu.Location = new System.Drawing.Point(641, 475);
            this.btnAddShoriSisetu.Name = "btnAddShoriSisetu";
            this.btnAddShoriSisetu.Size = new System.Drawing.Size(100, 30);
            this.btnAddShoriSisetu.TabIndex = 2;
            this.btnAddShoriSisetu.Text = "追加";
            this.btnAddShoriSisetu.UseVisualStyleBackColor = true;
            this.btnAddShoriSisetu.Click += new System.EventHandler(this.btnAddShoriSisetu_Click);
            // 
            // dgvShoriSisetu
            // 
            this.dgvShoriSisetu.AllowUserToAddRows = false;
            this.dgvShoriSisetu.AllowUserToDeleteRows = false;
            this.dgvShoriSisetu.AllowUserToResizeColumns = false;
            this.dgvShoriSisetu.AllowUserToResizeRows = false;
            this.dgvShoriSisetu.AutoGenerateColumns = false;
            this.dgvShoriSisetu.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvShoriSisetu.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.SisetuNameN,
            this.TdkdjuriDateShortW,
            this.Biko,
            this.SsNo});
            this.dgvShoriSisetu.DataSource = this.bsShoriSisetu;
            this.dgvShoriSisetu.Location = new System.Drawing.Point(15, 49);
            this.dgvShoriSisetu.MultiSelect = false;
            this.dgvShoriSisetu.Name = "dgvShoriSisetu";
            this.dgvShoriSisetu.ReadOnly = true;
            this.dgvShoriSisetu.RowHeadersVisible = false;
            this.dgvShoriSisetu.RowTemplate.Height = 21;
            this.dgvShoriSisetu.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvShoriSisetu.Size = new System.Drawing.Size(938, 411);
            this.dgvShoriSisetu.TabIndex = 1;
            this.dgvShoriSisetu.TabStop = false;
            this.dgvShoriSisetu.CellMouseDoubleClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgvShoriSisetu_CellMouseDoubleClick);
            // 
            // TdkdjuriDateShortW
            // 
            this.TdkdjuriDateShortW.DataPropertyName = "TdkdjuriDateShortW";
            this.TdkdjuriDateShortW.HeaderText = "最新届出等受理日";
            this.TdkdjuriDateShortW.Name = "TdkdjuriDateShortW";
            this.TdkdjuriDateShortW.ReadOnly = true;
            this.TdkdjuriDateShortW.Width = 180;
            // 
            // SsNo
            // 
            this.SsNo.DataPropertyName = "SsNo";
            this.SsNo.HeaderText = "処理施設番号";
            this.SsNo.Name = "SsNo";
            this.SsNo.ReadOnly = true;
            this.SsNo.Width = 148;
            // 
            // tabHaisuiko
            // 
            this.tabHaisuiko.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.tabHaisuiko.Controls.Add(this.chkHaisuikijyunTekiyo);
            this.tabHaisuiko.Controls.Add(this.chkKojimaKoRyuiki);
            this.tabHaisuiko.Controls.Add(this.chkKaisuiGanyuFlag);
            this.tabHaisuiko.Controls.Add(this.txtTdkdhsMax);
            this.tabHaisuiko.Controls.Add(this.txtUsuiHaisuikoSu);
            this.tabHaisuiko.Controls.Add(this.txtTdkdhsAve);
            this.tabHaisuiko.Controls.Add(this.lblTdkdHsMax);
            this.tabHaisuiko.Controls.Add(this.lblTdkdHsMaxUnit);
            this.tabHaisuiko.Controls.Add(this.lblTdkdHsAveUnit);
            this.tabHaisuiko.Controls.Add(this.lblUsuiHaisuikoSu);
            this.tabHaisuiko.Controls.Add(this.lblTdkdHsAve);
            this.tabHaisuiko.Controls.Add(this.lblCountRecordHaisuiko);
            this.tabHaisuiko.Controls.Add(this.lblCountNumberHaisuiko);
            this.tabHaisuiko.Controls.Add(this.lblHaisuiko);
            this.tabHaisuiko.Controls.Add(this.btnCopyHaisuiko);
            this.tabHaisuiko.Controls.Add(this.btnSelectHaisuiko);
            this.tabHaisuiko.Controls.Add(this.btnHaisuikijyunTou);
            this.tabHaisuiko.Controls.Add(this.btnHaisuikoJyoho);
            this.tabHaisuiko.Controls.Add(this.btnAddHaisuiko);
            this.tabHaisuiko.Controls.Add(this.dgvHaisuiko);
            this.tabHaisuiko.Location = new System.Drawing.Point(4, 36);
            this.tabHaisuiko.Name = "tabHaisuiko";
            this.tabHaisuiko.Padding = new System.Windows.Forms.Padding(3);
            this.tabHaisuiko.Size = new System.Drawing.Size(970, 521);
            this.tabHaisuiko.TabIndex = 4;
            this.tabHaisuiko.Text = "排水口";
            // 
            // chkHaisuikijyunTekiyo
            // 
            this.chkHaisuikijyunTekiyo.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.chkHaisuikijyunTekiyo.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.chkHaisuikijyunTekiyo.Location = new System.Drawing.Point(705, 57);
            this.chkHaisuikijyunTekiyo.Name = "chkHaisuikijyunTekiyo";
            this.chkHaisuikijyunTekiyo.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.chkHaisuikijyunTekiyo.Size = new System.Drawing.Size(145, 22);
            this.chkHaisuikijyunTekiyo.TabIndex = 6;
            this.chkHaisuikijyunTekiyo.Text = "排水基準適用";
            this.chkHaisuikijyunTekiyo.UseVisualStyleBackColor = true;
            // 
            // chkKojimaKoRyuiki
            // 
            this.chkKojimaKoRyuiki.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.chkKojimaKoRyuiki.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.chkKojimaKoRyuiki.Location = new System.Drawing.Point(705, 90);
            this.chkKojimaKoRyuiki.Name = "chkKojimaKoRyuiki";
            this.chkKojimaKoRyuiki.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.chkKojimaKoRyuiki.Size = new System.Drawing.Size(145, 22);
            this.chkKojimaKoRyuiki.TabIndex = 7;
            this.chkKojimaKoRyuiki.Text = "児島湖流域";
            this.chkKojimaKoRyuiki.UseVisualStyleBackColor = true;
            // 
            // chkKaisuiGanyuFlag
            // 
            this.chkKaisuiGanyuFlag.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.chkKaisuiGanyuFlag.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.chkKaisuiGanyuFlag.Location = new System.Drawing.Point(500, 88);
            this.chkKaisuiGanyuFlag.Name = "chkKaisuiGanyuFlag";
            this.chkKaisuiGanyuFlag.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.chkKaisuiGanyuFlag.Size = new System.Drawing.Size(159, 22);
            this.chkKaisuiGanyuFlag.TabIndex = 5;
            this.chkKaisuiGanyuFlag.Text = "海水の含有";
            this.chkKaisuiGanyuFlag.UseVisualStyleBackColor = true;
            // 
            // txtTdkdhsMax
            // 
            this.txtTdkdhsMax.Location = new System.Drawing.Point(322, 85);
            this.txtTdkdhsMax.Name = "txtTdkdhsMax";
            this.txtTdkdhsMax.Size = new System.Drawing.Size(120, 31);
            this.txtTdkdhsMax.TabIndex = 3;
            // 
            // txtUsuiHaisuikoSu
            // 
            this.txtUsuiHaisuikoSu.Location = new System.Drawing.Point(644, 52);
            this.txtUsuiHaisuikoSu.Name = "txtUsuiHaisuikoSu";
            this.txtUsuiHaisuikoSu.Size = new System.Drawing.Size(40, 31);
            this.txtUsuiHaisuikoSu.TabIndex = 4;
            // 
            // txtTdkdhsAve
            // 
            this.txtTdkdhsAve.Location = new System.Drawing.Point(322, 52);
            this.txtTdkdhsAve.Name = "txtTdkdhsAve";
            this.txtTdkdhsAve.Size = new System.Drawing.Size(120, 31);
            this.txtTdkdhsAve.TabIndex = 2;
            // 
            // lblTdkdHsMax
            // 
            this.lblTdkdHsMax.AutoSize = true;
            this.lblTdkdHsMax.Location = new System.Drawing.Point(203, 88);
            this.lblTdkdHsMax.Name = "lblTdkdHsMax";
            this.lblTdkdHsMax.Size = new System.Drawing.Size(122, 24);
            this.lblTdkdHsMax.TabIndex = 84;
            this.lblTdkdHsMax.Text = "　　　（最大）";
            // 
            // lblTdkdHsMaxUnit
            // 
            this.lblTdkdHsMaxUnit.AutoSize = true;
            this.lblTdkdHsMaxUnit.Location = new System.Drawing.Point(445, 88);
            this.lblTdkdHsMaxUnit.Name = "lblTdkdHsMaxUnit";
            this.lblTdkdHsMaxUnit.Size = new System.Drawing.Size(55, 24);
            this.lblTdkdHsMaxUnit.TabIndex = 85;
            this.lblTdkdHsMaxUnit.Text = "m³/日";
            // 
            // lblTdkdHsAveUnit
            // 
            this.lblTdkdHsAveUnit.AutoSize = true;
            this.lblTdkdHsAveUnit.Location = new System.Drawing.Point(445, 55);
            this.lblTdkdHsAveUnit.Name = "lblTdkdHsAveUnit";
            this.lblTdkdHsAveUnit.Size = new System.Drawing.Size(55, 24);
            this.lblTdkdHsAveUnit.TabIndex = 86;
            this.lblTdkdHsAveUnit.Text = "m³/日";
            // 
            // lblUsuiHaisuikoSu
            // 
            this.lblUsuiHaisuikoSu.AutoSize = true;
            this.lblUsuiHaisuikoSu.Location = new System.Drawing.Point(500, 55);
            this.lblUsuiHaisuikoSu.Name = "lblUsuiHaisuikoSu";
            this.lblUsuiHaisuikoSu.Size = new System.Drawing.Size(138, 24);
            this.lblUsuiHaisuikoSu.TabIndex = 88;
            this.lblUsuiHaisuikoSu.Text = "雨水専用排水口数";
            // 
            // lblTdkdHsAve
            // 
            this.lblTdkdHsAve.AutoSize = true;
            this.lblTdkdHsAve.Location = new System.Drawing.Point(187, 55);
            this.lblTdkdHsAve.Name = "lblTdkdHsAve";
            this.lblTdkdHsAve.Size = new System.Drawing.Size(138, 24);
            this.lblTdkdHsAve.TabIndex = 87;
            this.lblTdkdHsAve.Text = "総排水量（通常）";
            // 
            // lblCountRecordHaisuiko
            // 
            this.lblCountRecordHaisuiko.AutoSize = true;
            this.lblCountRecordHaisuiko.Location = new System.Drawing.Point(75, 107);
            this.lblCountRecordHaisuiko.Name = "lblCountRecordHaisuiko";
            this.lblCountRecordHaisuiko.Size = new System.Drawing.Size(20, 24);
            this.lblCountRecordHaisuiko.TabIndex = 83;
            this.lblCountRecordHaisuiko.Text = "0";
            // 
            // lblCountNumberHaisuiko
            // 
            this.lblCountNumberHaisuiko.AutoSize = true;
            this.lblCountNumberHaisuiko.Location = new System.Drawing.Point(15, 107);
            this.lblCountNumberHaisuiko.Name = "lblCountNumberHaisuiko";
            this.lblCountNumberHaisuiko.Size = new System.Drawing.Size(60, 24);
            this.lblCountNumberHaisuiko.TabIndex = 82;
            this.lblCountNumberHaisuiko.Text = "件数 =";
            // 
            // lblHaisuiko
            // 
            this.lblHaisuiko.AutoSize = true;
            this.lblHaisuiko.Font = new System.Drawing.Font("メイリオ", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblHaisuiko.Location = new System.Drawing.Point(426, 15);
            this.lblHaisuiko.Name = "lblHaisuiko";
            this.lblHaisuiko.Size = new System.Drawing.Size(119, 31);
            this.lblHaisuiko.TabIndex = 81;
            this.lblHaisuiko.Text = "排水口一覧";
            // 
            // btnCopyHaisuiko
            // 
            this.btnCopyHaisuiko.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnCopyHaisuiko.Location = new System.Drawing.Point(747, 475);
            this.btnCopyHaisuiko.Name = "btnCopyHaisuiko";
            this.btnCopyHaisuiko.Size = new System.Drawing.Size(100, 30);
            this.btnCopyHaisuiko.TabIndex = 11;
            this.btnCopyHaisuiko.Text = "複写";
            this.btnCopyHaisuiko.UseVisualStyleBackColor = true;
            this.btnCopyHaisuiko.Click += new System.EventHandler(this.btnCopyHaisuiko_Click);
            // 
            // btnSelectHaisuiko
            // 
            this.btnSelectHaisuiko.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnSelectHaisuiko.Location = new System.Drawing.Point(853, 475);
            this.btnSelectHaisuiko.Name = "btnSelectHaisuiko";
            this.btnSelectHaisuiko.Size = new System.Drawing.Size(100, 30);
            this.btnSelectHaisuiko.TabIndex = 12;
            this.btnSelectHaisuiko.Text = "選択";
            this.btnSelectHaisuiko.UseVisualStyleBackColor = true;
            this.btnSelectHaisuiko.Click += new System.EventHandler(this.btnSelectHaisuiko_Click);
            // 
            // btnHaisuikijyunTou
            // 
            this.btnHaisuikijyunTou.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnHaisuikijyunTou.Location = new System.Drawing.Point(20, 52);
            this.btnHaisuikijyunTou.Name = "btnHaisuikijyunTou";
            this.btnHaisuikijyunTou.Size = new System.Drawing.Size(130, 30);
            this.btnHaisuikijyunTou.TabIndex = 1;
            this.btnHaisuikijyunTou.Text = "排水基準等入力";
            this.btnHaisuikijyunTou.UseVisualStyleBackColor = true;
            this.btnHaisuikijyunTou.Click += new System.EventHandler(this.btnHaisuikijyunTou_Click);
            // 
            // btnHaisuikoJyoho
            // 
            this.btnHaisuikoJyoho.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnHaisuikoJyoho.Location = new System.Drawing.Point(15, 475);
            this.btnHaisuikoJyoho.Name = "btnHaisuikoJyoho";
            this.btnHaisuikoJyoho.Size = new System.Drawing.Size(130, 30);
            this.btnHaisuikoJyoho.TabIndex = 9;
            this.btnHaisuikoJyoho.Text = "排水口情報一覧";
            this.btnHaisuikoJyoho.UseVisualStyleBackColor = true;
            this.btnHaisuikoJyoho.Click += new System.EventHandler(this.btnHaisuikoJyoho_Click);
            // 
            // btnAddHaisuiko
            // 
            this.btnAddHaisuiko.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnAddHaisuiko.Location = new System.Drawing.Point(641, 475);
            this.btnAddHaisuiko.Name = "btnAddHaisuiko";
            this.btnAddHaisuiko.Size = new System.Drawing.Size(100, 30);
            this.btnAddHaisuiko.TabIndex = 10;
            this.btnAddHaisuiko.Text = "追加";
            this.btnAddHaisuiko.UseVisualStyleBackColor = true;
            this.btnAddHaisuiko.Click += new System.EventHandler(this.btnAddHaisuiko_Click);
            // 
            // dgvHaisuiko
            // 
            this.dgvHaisuiko.AllowUserToAddRows = false;
            this.dgvHaisuiko.AllowUserToDeleteRows = false;
            this.dgvHaisuiko.AllowUserToResizeColumns = false;
            this.dgvHaisuiko.AllowUserToResizeRows = false;
            this.dgvHaisuiko.AutoGenerateColumns = false;
            this.dgvHaisuiko.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvHaisuiko.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.HaisuikoNo,
            this.SetiDateShortW,
            this.HaisiDateShortW,
            this.dataGridViewTextBoxColumn21,
            this.dataGridViewTextBoxColumn22,
            this.dataGridViewTextBoxColumn23});
            this.dgvHaisuiko.DataSource = this.bsHaisuiko;
            this.dgvHaisuiko.Location = new System.Drawing.Point(12, 134);
            this.dgvHaisuiko.MultiSelect = false;
            this.dgvHaisuiko.Name = "dgvHaisuiko";
            this.dgvHaisuiko.ReadOnly = true;
            this.dgvHaisuiko.RowHeadersVisible = false;
            this.dgvHaisuiko.RowTemplate.Height = 21;
            this.dgvHaisuiko.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvHaisuiko.Size = new System.Drawing.Size(938, 328);
            this.dgvHaisuiko.TabIndex = 8;
            this.dgvHaisuiko.TabStop = false;
            this.dgvHaisuiko.CellMouseDoubleClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgvHaisuiko_CellMouseDoubleClick);
            // 
            // tabOdakuFukaryo
            // 
            this.tabOdakuFukaryo.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.tabOdakuFukaryo.Controls.Add(this.tblOdakuFukaryo);
            this.tabOdakuFukaryo.Controls.Add(this.btnCancelOdakuFukaryo);
            this.tabOdakuFukaryo.Controls.Add(this.btnRegistOdakuFukaryo);
            this.tabOdakuFukaryo.Controls.Add(this.lblOdakuFukaryo);
            this.tabOdakuFukaryo.Location = new System.Drawing.Point(4, 36);
            this.tabOdakuFukaryo.Name = "tabOdakuFukaryo";
            this.tabOdakuFukaryo.Padding = new System.Windows.Forms.Padding(3);
            this.tabOdakuFukaryo.Size = new System.Drawing.Size(970, 521);
            this.tabOdakuFukaryo.TabIndex = 5;
            this.tabOdakuFukaryo.Text = "汚濁負荷量";
            // 
            // tblOdakuFukaryo
            // 
            this.tblOdakuFukaryo.AutoSize = true;
            this.tblOdakuFukaryo.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.tblOdakuFukaryo.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tblOdakuFukaryo.ColumnCount = 5;
            this.tblOdakuFukaryo.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 245F));
            this.tblOdakuFukaryo.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tblOdakuFukaryo.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tblOdakuFukaryo.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tblOdakuFukaryo.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tblOdakuFukaryo.Controls.Add(this.lblSpaceOdakuFukaryo, 0, 0);
            this.tblOdakuFukaryo.Controls.Add(this.lblCodOdakuFukaryo, 1, 0);
            this.tblOdakuFukaryo.Controls.Add(this.lblTdkdFukaryo, 0, 2);
            this.tblOdakuFukaryo.Controls.Add(this.lblTdkdhsAveOdakuFukaryo, 0, 3);
            this.tblOdakuFukaryo.Controls.Add(this.lblTdkdhsMaxOdakuFukaryo, 0, 4);
            this.tblOdakuFukaryo.Controls.Add(this.lblBikoOdakuFukaryo, 0, 5);
            this.tblOdakuFukaryo.Controls.Add(this.lblTnOdakuFukaryo, 2, 0);
            this.tblOdakuFukaryo.Controls.Add(this.lblTpOdakuFukaryo, 3, 0);
            this.tblOdakuFukaryo.Controls.Add(this.lblSonotaOdakuFukaryo, 4, 0);
            this.tblOdakuFukaryo.Controls.Add(this.lblKyoyoFukaryo, 0, 1);
            this.tblOdakuFukaryo.Controls.Add(this.txtCodKyoyoFukaryo, 1, 1);
            this.tblOdakuFukaryo.Controls.Add(this.txtTnKyoyoFukaryo, 2, 1);
            this.tblOdakuFukaryo.Controls.Add(this.txtTpKyoyoFukaryo, 3, 1);
            this.tblOdakuFukaryo.Controls.Add(this.txtSonotaKyoyoFukaryo, 4, 1);
            this.tblOdakuFukaryo.Controls.Add(this.txtCodTdkdFukaryo, 1, 2);
            this.tblOdakuFukaryo.Controls.Add(this.txtTnTdkdFukaryo, 2, 2);
            this.tblOdakuFukaryo.Controls.Add(this.txtTpTdkdFukaryo, 3, 2);
            this.tblOdakuFukaryo.Controls.Add(this.txtSonotaTdkdFukaryo, 4, 2);
            this.tblOdakuFukaryo.Controls.Add(this.txtTdkdhsAveOdakuFukaryo, 1, 3);
            this.tblOdakuFukaryo.Controls.Add(this.txtTdkdhsMaxOdakuFukaryo, 1, 4);
            this.tblOdakuFukaryo.Controls.Add(this.txtBikoOdakuFukaryo, 1, 5);
            this.tblOdakuFukaryo.Location = new System.Drawing.Point(120, 60);
            this.tblOdakuFukaryo.Name = "tblOdakuFukaryo";
            this.tblOdakuFukaryo.RowCount = 6;
            this.tblOdakuFukaryo.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tblOdakuFukaryo.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tblOdakuFukaryo.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tblOdakuFukaryo.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tblOdakuFukaryo.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tblOdakuFukaryo.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 60F));
            this.tblOdakuFukaryo.Size = new System.Drawing.Size(731, 217);
            this.tblOdakuFukaryo.TabIndex = 3;
            // 
            // lblSpaceOdakuFukaryo
            // 
            this.lblSpaceOdakuFukaryo.BackColor = System.Drawing.SystemColors.Control;
            this.lblSpaceOdakuFukaryo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblSpaceOdakuFukaryo.Location = new System.Drawing.Point(1, 1);
            this.lblSpaceOdakuFukaryo.Margin = new System.Windows.Forms.Padding(0);
            this.lblSpaceOdakuFukaryo.Name = "lblSpaceOdakuFukaryo";
            this.lblSpaceOdakuFukaryo.Size = new System.Drawing.Size(245, 30);
            this.lblSpaceOdakuFukaryo.TabIndex = 4;
            this.lblSpaceOdakuFukaryo.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblCodOdakuFukaryo
            // 
            this.lblCodOdakuFukaryo.AutoSize = true;
            this.lblCodOdakuFukaryo.BackColor = System.Drawing.SystemColors.Control;
            this.lblCodOdakuFukaryo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblCodOdakuFukaryo.Location = new System.Drawing.Point(247, 1);
            this.lblCodOdakuFukaryo.Margin = new System.Windows.Forms.Padding(0);
            this.lblCodOdakuFukaryo.Name = "lblCodOdakuFukaryo";
            this.lblCodOdakuFukaryo.Size = new System.Drawing.Size(120, 30);
            this.lblCodOdakuFukaryo.TabIndex = 0;
            this.lblCodOdakuFukaryo.Text = "COD";
            this.lblCodOdakuFukaryo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblTdkdFukaryo
            // 
            this.lblTdkdFukaryo.AutoSize = true;
            this.lblTdkdFukaryo.BackColor = System.Drawing.SystemColors.Control;
            this.lblTdkdFukaryo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblTdkdFukaryo.Location = new System.Drawing.Point(1, 63);
            this.lblTdkdFukaryo.Margin = new System.Windows.Forms.Padding(0);
            this.lblTdkdFukaryo.Name = "lblTdkdFukaryo";
            this.lblTdkdFukaryo.Size = new System.Drawing.Size(245, 30);
            this.lblTdkdFukaryo.TabIndex = 0;
            this.lblTdkdFukaryo.Text = "届出等汚濁負荷量　　（㎏/日）";
            this.lblTdkdFukaryo.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblTdkdhsAveOdakuFukaryo
            // 
            this.lblTdkdhsAveOdakuFukaryo.AutoSize = true;
            this.lblTdkdhsAveOdakuFukaryo.BackColor = System.Drawing.SystemColors.Control;
            this.lblTdkdhsAveOdakuFukaryo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblTdkdhsAveOdakuFukaryo.Location = new System.Drawing.Point(1, 94);
            this.lblTdkdhsAveOdakuFukaryo.Margin = new System.Windows.Forms.Padding(0);
            this.lblTdkdhsAveOdakuFukaryo.Name = "lblTdkdhsAveOdakuFukaryo";
            this.lblTdkdhsAveOdakuFukaryo.Size = new System.Drawing.Size(245, 30);
            this.lblTdkdhsAveOdakuFukaryo.TabIndex = 0;
            this.lblTdkdhsAveOdakuFukaryo.Text = "総排水量（通常）  　（m³/日）";
            this.lblTdkdhsAveOdakuFukaryo.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblTdkdhsMaxOdakuFukaryo
            // 
            this.lblTdkdhsMaxOdakuFukaryo.AutoSize = true;
            this.lblTdkdhsMaxOdakuFukaryo.BackColor = System.Drawing.SystemColors.Control;
            this.lblTdkdhsMaxOdakuFukaryo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblTdkdhsMaxOdakuFukaryo.Location = new System.Drawing.Point(1, 125);
            this.lblTdkdhsMaxOdakuFukaryo.Margin = new System.Windows.Forms.Padding(0);
            this.lblTdkdhsMaxOdakuFukaryo.Name = "lblTdkdhsMaxOdakuFukaryo";
            this.lblTdkdhsMaxOdakuFukaryo.Size = new System.Drawing.Size(245, 30);
            this.lblTdkdhsMaxOdakuFukaryo.TabIndex = 0;
            this.lblTdkdhsMaxOdakuFukaryo.Text = "総排水量（最大）  　（m³/日）";
            this.lblTdkdhsMaxOdakuFukaryo.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblBikoOdakuFukaryo
            // 
            this.lblBikoOdakuFukaryo.AutoSize = true;
            this.lblBikoOdakuFukaryo.BackColor = System.Drawing.SystemColors.Control;
            this.lblBikoOdakuFukaryo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblBikoOdakuFukaryo.Location = new System.Drawing.Point(1, 156);
            this.lblBikoOdakuFukaryo.Margin = new System.Windows.Forms.Padding(0);
            this.lblBikoOdakuFukaryo.Name = "lblBikoOdakuFukaryo";
            this.lblBikoOdakuFukaryo.Size = new System.Drawing.Size(245, 60);
            this.lblBikoOdakuFukaryo.TabIndex = 0;
            this.lblBikoOdakuFukaryo.Text = "備考";
            // 
            // lblTnOdakuFukaryo
            // 
            this.lblTnOdakuFukaryo.AutoSize = true;
            this.lblTnOdakuFukaryo.BackColor = System.Drawing.SystemColors.Control;
            this.lblTnOdakuFukaryo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblTnOdakuFukaryo.Location = new System.Drawing.Point(368, 1);
            this.lblTnOdakuFukaryo.Margin = new System.Windows.Forms.Padding(0);
            this.lblTnOdakuFukaryo.Name = "lblTnOdakuFukaryo";
            this.lblTnOdakuFukaryo.Size = new System.Drawing.Size(120, 30);
            this.lblTnOdakuFukaryo.TabIndex = 0;
            this.lblTnOdakuFukaryo.Text = "全窒素";
            this.lblTnOdakuFukaryo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblTpOdakuFukaryo
            // 
            this.lblTpOdakuFukaryo.AutoSize = true;
            this.lblTpOdakuFukaryo.BackColor = System.Drawing.SystemColors.Control;
            this.lblTpOdakuFukaryo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblTpOdakuFukaryo.Location = new System.Drawing.Point(489, 1);
            this.lblTpOdakuFukaryo.Margin = new System.Windows.Forms.Padding(0);
            this.lblTpOdakuFukaryo.Name = "lblTpOdakuFukaryo";
            this.lblTpOdakuFukaryo.Size = new System.Drawing.Size(120, 30);
            this.lblTpOdakuFukaryo.TabIndex = 0;
            this.lblTpOdakuFukaryo.Text = "全りん";
            this.lblTpOdakuFukaryo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblSonotaOdakuFukaryo
            // 
            this.lblSonotaOdakuFukaryo.AutoSize = true;
            this.lblSonotaOdakuFukaryo.BackColor = System.Drawing.SystemColors.Control;
            this.lblSonotaOdakuFukaryo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblSonotaOdakuFukaryo.Location = new System.Drawing.Point(610, 1);
            this.lblSonotaOdakuFukaryo.Margin = new System.Windows.Forms.Padding(0);
            this.lblSonotaOdakuFukaryo.Name = "lblSonotaOdakuFukaryo";
            this.lblSonotaOdakuFukaryo.Size = new System.Drawing.Size(120, 30);
            this.lblSonotaOdakuFukaryo.TabIndex = 0;
            this.lblSonotaOdakuFukaryo.Text = "その他";
            this.lblSonotaOdakuFukaryo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblKyoyoFukaryo
            // 
            this.lblKyoyoFukaryo.BackColor = System.Drawing.SystemColors.Control;
            this.lblKyoyoFukaryo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblKyoyoFukaryo.Location = new System.Drawing.Point(1, 32);
            this.lblKyoyoFukaryo.Margin = new System.Windows.Forms.Padding(0);
            this.lblKyoyoFukaryo.Name = "lblKyoyoFukaryo";
            this.lblKyoyoFukaryo.Size = new System.Drawing.Size(245, 30);
            this.lblKyoyoFukaryo.TabIndex = 0;
            this.lblKyoyoFukaryo.Text = "許容汚濁負荷量　　　（㎏/日）";
            this.lblKyoyoFukaryo.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtCodKyoyoFukaryo
            // 
            this.txtCodKyoyoFukaryo.BackColor = System.Drawing.SystemColors.Window;
            this.txtCodKyoyoFukaryo.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtCodKyoyoFukaryo.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsOdakuFukaryo, "CodKyoyoFukaryo", true, System.Windows.Forms.DataSourceUpdateMode.Never, null, "########0.0"));
            this.txtCodKyoyoFukaryo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtCodKyoyoFukaryo.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.txtCodKyoyoFukaryo.Location = new System.Drawing.Point(247, 32);
            this.txtCodKyoyoFukaryo.Margin = new System.Windows.Forms.Padding(0);
            this.txtCodKyoyoFukaryo.MaxLength = 11;
            this.txtCodKyoyoFukaryo.Multiline = true;
            this.txtCodKyoyoFukaryo.Name = "txtCodKyoyoFukaryo";
            this.txtCodKyoyoFukaryo.Size = new System.Drawing.Size(120, 30);
            this.txtCodKyoyoFukaryo.TabIndex = 1;
            this.txtCodKyoyoFukaryo.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtTnKyoyoFukaryo
            // 
            this.txtTnKyoyoFukaryo.BackColor = System.Drawing.SystemColors.Window;
            this.txtTnKyoyoFukaryo.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtTnKyoyoFukaryo.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsOdakuFukaryo, "TnKyoyoFukaryo", true, System.Windows.Forms.DataSourceUpdateMode.Never, null, "########0.0"));
            this.txtTnKyoyoFukaryo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtTnKyoyoFukaryo.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.txtTnKyoyoFukaryo.Location = new System.Drawing.Point(368, 32);
            this.txtTnKyoyoFukaryo.Margin = new System.Windows.Forms.Padding(0);
            this.txtTnKyoyoFukaryo.MaxLength = 11;
            this.txtTnKyoyoFukaryo.Multiline = true;
            this.txtTnKyoyoFukaryo.Name = "txtTnKyoyoFukaryo";
            this.txtTnKyoyoFukaryo.Size = new System.Drawing.Size(120, 30);
            this.txtTnKyoyoFukaryo.TabIndex = 2;
            this.txtTnKyoyoFukaryo.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtTpKyoyoFukaryo
            // 
            this.txtTpKyoyoFukaryo.BackColor = System.Drawing.SystemColors.Window;
            this.txtTpKyoyoFukaryo.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtTpKyoyoFukaryo.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsOdakuFukaryo, "TpKyoyoFukaryo", true, System.Windows.Forms.DataSourceUpdateMode.Never, null, "########0.0"));
            this.txtTpKyoyoFukaryo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtTpKyoyoFukaryo.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.txtTpKyoyoFukaryo.Location = new System.Drawing.Point(489, 32);
            this.txtTpKyoyoFukaryo.Margin = new System.Windows.Forms.Padding(0);
            this.txtTpKyoyoFukaryo.MaxLength = 11;
            this.txtTpKyoyoFukaryo.Multiline = true;
            this.txtTpKyoyoFukaryo.Name = "txtTpKyoyoFukaryo";
            this.txtTpKyoyoFukaryo.Size = new System.Drawing.Size(120, 30);
            this.txtTpKyoyoFukaryo.TabIndex = 3;
            this.txtTpKyoyoFukaryo.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtSonotaKyoyoFukaryo
            // 
            this.txtSonotaKyoyoFukaryo.BackColor = System.Drawing.SystemColors.Window;
            this.txtSonotaKyoyoFukaryo.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtSonotaKyoyoFukaryo.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsOdakuFukaryo, "SonotaKyoyoFukaryo", true, System.Windows.Forms.DataSourceUpdateMode.Never, null, "########0.0"));
            this.txtSonotaKyoyoFukaryo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtSonotaKyoyoFukaryo.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.txtSonotaKyoyoFukaryo.Location = new System.Drawing.Point(610, 32);
            this.txtSonotaKyoyoFukaryo.Margin = new System.Windows.Forms.Padding(0);
            this.txtSonotaKyoyoFukaryo.MaxLength = 11;
            this.txtSonotaKyoyoFukaryo.Multiline = true;
            this.txtSonotaKyoyoFukaryo.Name = "txtSonotaKyoyoFukaryo";
            this.txtSonotaKyoyoFukaryo.Size = new System.Drawing.Size(120, 30);
            this.txtSonotaKyoyoFukaryo.TabIndex = 4;
            this.txtSonotaKyoyoFukaryo.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtCodTdkdFukaryo
            // 
            this.txtCodTdkdFukaryo.BackColor = System.Drawing.SystemColors.Window;
            this.txtCodTdkdFukaryo.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtCodTdkdFukaryo.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsOdakuFukaryo, "CodTdkdFukaryo", true, System.Windows.Forms.DataSourceUpdateMode.Never, null, "########0.0"));
            this.txtCodTdkdFukaryo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtCodTdkdFukaryo.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.txtCodTdkdFukaryo.Location = new System.Drawing.Point(247, 63);
            this.txtCodTdkdFukaryo.Margin = new System.Windows.Forms.Padding(0);
            this.txtCodTdkdFukaryo.MaxLength = 11;
            this.txtCodTdkdFukaryo.Multiline = true;
            this.txtCodTdkdFukaryo.Name = "txtCodTdkdFukaryo";
            this.txtCodTdkdFukaryo.Size = new System.Drawing.Size(120, 30);
            this.txtCodTdkdFukaryo.TabIndex = 5;
            this.txtCodTdkdFukaryo.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtTnTdkdFukaryo
            // 
            this.txtTnTdkdFukaryo.BackColor = System.Drawing.SystemColors.Window;
            this.txtTnTdkdFukaryo.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtTnTdkdFukaryo.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsOdakuFukaryo, "TnTdkdFukaryo", true, System.Windows.Forms.DataSourceUpdateMode.Never, null, "########0.0"));
            this.txtTnTdkdFukaryo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtTnTdkdFukaryo.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.txtTnTdkdFukaryo.Location = new System.Drawing.Point(368, 63);
            this.txtTnTdkdFukaryo.Margin = new System.Windows.Forms.Padding(0);
            this.txtTnTdkdFukaryo.MaxLength = 11;
            this.txtTnTdkdFukaryo.Multiline = true;
            this.txtTnTdkdFukaryo.Name = "txtTnTdkdFukaryo";
            this.txtTnTdkdFukaryo.Size = new System.Drawing.Size(120, 30);
            this.txtTnTdkdFukaryo.TabIndex = 6;
            this.txtTnTdkdFukaryo.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtTpTdkdFukaryo
            // 
            this.txtTpTdkdFukaryo.BackColor = System.Drawing.SystemColors.Window;
            this.txtTpTdkdFukaryo.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtTpTdkdFukaryo.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsOdakuFukaryo, "TpTdkdFukaryo", true, System.Windows.Forms.DataSourceUpdateMode.Never, null, "########0.0"));
            this.txtTpTdkdFukaryo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtTpTdkdFukaryo.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.txtTpTdkdFukaryo.Location = new System.Drawing.Point(489, 63);
            this.txtTpTdkdFukaryo.Margin = new System.Windows.Forms.Padding(0);
            this.txtTpTdkdFukaryo.MaxLength = 11;
            this.txtTpTdkdFukaryo.Multiline = true;
            this.txtTpTdkdFukaryo.Name = "txtTpTdkdFukaryo";
            this.txtTpTdkdFukaryo.Size = new System.Drawing.Size(120, 30);
            this.txtTpTdkdFukaryo.TabIndex = 7;
            this.txtTpTdkdFukaryo.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtSonotaTdkdFukaryo
            // 
            this.txtSonotaTdkdFukaryo.BackColor = System.Drawing.SystemColors.Window;
            this.txtSonotaTdkdFukaryo.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtSonotaTdkdFukaryo.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsOdakuFukaryo, "SonotaTdkdFukaryo", true, System.Windows.Forms.DataSourceUpdateMode.Never, null, "########0.0"));
            this.txtSonotaTdkdFukaryo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtSonotaTdkdFukaryo.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.txtSonotaTdkdFukaryo.Location = new System.Drawing.Point(610, 63);
            this.txtSonotaTdkdFukaryo.Margin = new System.Windows.Forms.Padding(0);
            this.txtSonotaTdkdFukaryo.MaxLength = 11;
            this.txtSonotaTdkdFukaryo.Multiline = true;
            this.txtSonotaTdkdFukaryo.Name = "txtSonotaTdkdFukaryo";
            this.txtSonotaTdkdFukaryo.Size = new System.Drawing.Size(120, 30);
            this.txtSonotaTdkdFukaryo.TabIndex = 8;
            this.txtSonotaTdkdFukaryo.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtTdkdhsAveOdakuFukaryo
            // 
            this.txtTdkdhsAveOdakuFukaryo.BackColor = System.Drawing.SystemColors.Window;
            this.txtTdkdhsAveOdakuFukaryo.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tblOdakuFukaryo.SetColumnSpan(this.txtTdkdhsAveOdakuFukaryo, 4);
            this.txtTdkdhsAveOdakuFukaryo.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsOdakuFukaryo, "SoryoAve", true, System.Windows.Forms.DataSourceUpdateMode.Never, null, "#######0.0"));
            this.txtTdkdhsAveOdakuFukaryo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtTdkdhsAveOdakuFukaryo.Location = new System.Drawing.Point(247, 94);
            this.txtTdkdhsAveOdakuFukaryo.Margin = new System.Windows.Forms.Padding(0);
            this.txtTdkdhsAveOdakuFukaryo.Multiline = true;
            this.txtTdkdhsAveOdakuFukaryo.Name = "txtTdkdhsAveOdakuFukaryo";
            this.txtTdkdhsAveOdakuFukaryo.Size = new System.Drawing.Size(483, 30);
            this.txtTdkdhsAveOdakuFukaryo.TabIndex = 9;
            this.txtTdkdhsAveOdakuFukaryo.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtTdkdhsMaxOdakuFukaryo
            // 
            this.txtTdkdhsMaxOdakuFukaryo.BackColor = System.Drawing.SystemColors.Window;
            this.txtTdkdhsMaxOdakuFukaryo.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tblOdakuFukaryo.SetColumnSpan(this.txtTdkdhsMaxOdakuFukaryo, 4);
            this.txtTdkdhsMaxOdakuFukaryo.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsOdakuFukaryo, "SoryoMax", true, System.Windows.Forms.DataSourceUpdateMode.Never, null, "#######0.0"));
            this.txtTdkdhsMaxOdakuFukaryo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtTdkdhsMaxOdakuFukaryo.Location = new System.Drawing.Point(247, 125);
            this.txtTdkdhsMaxOdakuFukaryo.Margin = new System.Windows.Forms.Padding(0);
            this.txtTdkdhsMaxOdakuFukaryo.Multiline = true;
            this.txtTdkdhsMaxOdakuFukaryo.Name = "txtTdkdhsMaxOdakuFukaryo";
            this.txtTdkdhsMaxOdakuFukaryo.Size = new System.Drawing.Size(483, 30);
            this.txtTdkdhsMaxOdakuFukaryo.TabIndex = 10;
            this.txtTdkdhsMaxOdakuFukaryo.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtBikoOdakuFukaryo
            // 
            this.txtBikoOdakuFukaryo.BackColor = System.Drawing.SystemColors.Window;
            this.txtBikoOdakuFukaryo.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tblOdakuFukaryo.SetColumnSpan(this.txtBikoOdakuFukaryo, 4);
            this.txtBikoOdakuFukaryo.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsOdakuFukaryo, "Biko", true, System.Windows.Forms.DataSourceUpdateMode.Never));
            this.txtBikoOdakuFukaryo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtBikoOdakuFukaryo.ImeMode = System.Windows.Forms.ImeMode.Hiragana;
            this.txtBikoOdakuFukaryo.Location = new System.Drawing.Point(247, 156);
            this.txtBikoOdakuFukaryo.Margin = new System.Windows.Forms.Padding(0);
            this.txtBikoOdakuFukaryo.MaxLength = 100;
            this.txtBikoOdakuFukaryo.Multiline = true;
            this.txtBikoOdakuFukaryo.Name = "txtBikoOdakuFukaryo";
            this.txtBikoOdakuFukaryo.Size = new System.Drawing.Size(483, 60);
            this.txtBikoOdakuFukaryo.TabIndex = 11;
            // 
            // btnCancelOdakuFukaryo
            // 
            this.btnCancelOdakuFukaryo.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnCancelOdakuFukaryo.Location = new System.Drawing.Point(846, 20);
            this.btnCancelOdakuFukaryo.Name = "btnCancelOdakuFukaryo";
            this.btnCancelOdakuFukaryo.Size = new System.Drawing.Size(100, 30);
            this.btnCancelOdakuFukaryo.TabIndex = 2;
            this.btnCancelOdakuFukaryo.Text = "キャンセル";
            this.btnCancelOdakuFukaryo.UseVisualStyleBackColor = true;
            this.btnCancelOdakuFukaryo.Click += new System.EventHandler(this.btnCancelOdakuFukaryo_Click);
            // 
            // btnRegistOdakuFukaryo
            // 
            this.btnRegistOdakuFukaryo.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnRegistOdakuFukaryo.Location = new System.Drawing.Point(740, 20);
            this.btnRegistOdakuFukaryo.Name = "btnRegistOdakuFukaryo";
            this.btnRegistOdakuFukaryo.Size = new System.Drawing.Size(100, 30);
            this.btnRegistOdakuFukaryo.TabIndex = 1;
            this.btnRegistOdakuFukaryo.Text = "登録";
            this.btnRegistOdakuFukaryo.UseVisualStyleBackColor = true;
            this.btnRegistOdakuFukaryo.Click += new System.EventHandler(this.btnRegistOdakuFukaryo_Click);
            // 
            // lblOdakuFukaryo
            // 
            this.lblOdakuFukaryo.AutoSize = true;
            this.lblOdakuFukaryo.Font = new System.Drawing.Font("メイリオ", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblOdakuFukaryo.Location = new System.Drawing.Point(405, 15);
            this.lblOdakuFukaryo.Name = "lblOdakuFukaryo";
            this.lblOdakuFukaryo.Size = new System.Drawing.Size(161, 31);
            this.lblOdakuFukaryo.TabIndex = 47;
            this.lblOdakuFukaryo.Text = "汚濁負荷量情報";
            // 
            // tabSoryoKise
            // 
            this.tabSoryoKise.AutoScroll = true;
            this.tabSoryoKise.AutoScrollMargin = new System.Drawing.Size(0, 20);
            this.tabSoryoKise.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.tabSoryoKise.Controls.Add(this.lblTpLine);
            this.tabSoryoKise.Controls.Add(this.lblTnLine);
            this.tabSoryoKise.Controls.Add(this.lblCodLine);
            this.tabSoryoKise.Controls.Add(this.tblTp);
            this.tabSoryoKise.Controls.Add(this.dgvTp);
            this.tabSoryoKise.Controls.Add(this.lblTp);
            this.tabSoryoKise.Controls.Add(this.btnDeleteMeisaiTp);
            this.tabSoryoKise.Controls.Add(this.btnAddMeisaiTp);
            this.tabSoryoKise.Controls.Add(this.TblTn);
            this.tabSoryoKise.Controls.Add(this.dgvTn);
            this.tabSoryoKise.Controls.Add(this.lblTn);
            this.tabSoryoKise.Controls.Add(this.btnDeleteMeisaiTn);
            this.tabSoryoKise.Controls.Add(this.btnAddMeisaiTn);
            this.tabSoryoKise.Controls.Add(this.tblCod);
            this.tabSoryoKise.Controls.Add(this.dgvCod);
            this.tabSoryoKise.Controls.Add(this.lblCod);
            this.tabSoryoKise.Controls.Add(this.btnDeleteMeisaiCod);
            this.tabSoryoKise.Controls.Add(this.btnAddMeisaiCod);
            this.tabSoryoKise.Controls.Add(this.btnCalcSoryoKise);
            this.tabSoryoKise.Controls.Add(this.btnCancelSoryoKise);
            this.tabSoryoKise.Controls.Add(this.btnRegistSoryoKise);
            this.tabSoryoKise.Controls.Add(this.lblSoryoKise);
            this.tabSoryoKise.Controls.Add(this.tblSoryoKise);
            this.tabSoryoKise.Location = new System.Drawing.Point(4, 36);
            this.tabSoryoKise.Name = "tabSoryoKise";
            this.tabSoryoKise.Padding = new System.Windows.Forms.Padding(3);
            this.tabSoryoKise.Size = new System.Drawing.Size(970, 521);
            this.tabSoryoKise.TabIndex = 6;
            this.tabSoryoKise.Text = "総量規制";
            // 
            // lblTpLine
            // 
            this.lblTpLine.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblTpLine.Font = new System.Drawing.Font("ＭＳ ゴシック", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblTpLine.Location = new System.Drawing.Point(104, 783);
            this.lblTpLine.Name = "lblTpLine";
            this.lblTpLine.Size = new System.Drawing.Size(841, 1);
            this.lblTpLine.TabIndex = 78;
            // 
            // lblTnLine
            // 
            this.lblTnLine.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblTnLine.Font = new System.Drawing.Font("ＭＳ ゴシック", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblTnLine.Location = new System.Drawing.Point(103, 536);
            this.lblTnLine.Name = "lblTnLine";
            this.lblTnLine.Size = new System.Drawing.Size(842, 1);
            this.lblTnLine.TabIndex = 77;
            // 
            // lblCodLine
            // 
            this.lblCodLine.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblCodLine.Font = new System.Drawing.Font("ＭＳ ゴシック", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblCodLine.Location = new System.Drawing.Point(130, 292);
            this.lblCodLine.Name = "lblCodLine";
            this.lblCodLine.Size = new System.Drawing.Size(815, 1);
            this.lblCodLine.TabIndex = 76;
            // 
            // tblTp
            // 
            this.tblTp.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.tblTp.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tblTp.ColumnCount = 15;
            this.tblTp.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 190F));
            this.tblTp.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tblTp.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tblTp.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tblTp.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tblTp.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tblTp.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 51F));
            this.tblTp.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 49F));
            this.tblTp.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tblTp.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tblTp.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tblTp.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tblTp.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tblTp.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.tblTp.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 16F));
            this.tblTp.Controls.Add(this.lblGyosyuKbnTp, 0, 0);
            this.tblTp.Controls.Add(this.lblTpTable, 1, 0);
            this.tblTp.Controls.Add(this.lblCpo, 1, 1);
            this.tblTp.Controls.Add(this.lblCpi, 2, 1);
            this.tblTp.Controls.Add(this.lblSpaceTp1, 3, 1);
            this.tblTp.Controls.Add(this.lblOsenJyotaiTp, 4, 0);
            this.tblTp.Controls.Add(this.lblOjAveTp, 4, 1);
            this.tblTp.Controls.Add(this.OjMaxTp, 5, 1);
            this.tblTp.Controls.Add(this.lblTSuiryoTp, 6, 0);
            this.tblTp.Controls.Add(this.lblTSuiryoAveTp, 6, 1);
            this.tblTp.Controls.Add(this.lblTSuiryoMaxTp, 7, 1);
            this.tblTp.Controls.Add(this.lblTSuiryoQpo, 8, 1);
            this.tblTp.Controls.Add(this.lblTSuiryoQpi, 9, 1);
            this.tblTp.Controls.Add(this.lblSpaceTp2, 10, 1);
            this.tblTp.Controls.Add(this.lblOdakuFukaryoTp, 11, 0);
            this.tblTp.Controls.Add(this.lblOdakuFukaryoAveTp, 11, 1);
            this.tblTp.Controls.Add(this.lblOdakuFukaryoMaxTp, 12, 1);
            this.tblTp.Controls.Add(this.lblKijyunTiTp, 13, 0);
            this.tblTp.Controls.Add(this.lblLp, 13, 1);
            this.tblTp.Controls.Add(this.lblScrolBerTp, 14, 0);
            this.tblTp.Location = new System.Drawing.Point(15, 801);
            this.tblTp.Name = "tblTp";
            this.tblTp.RowCount = 2;
            this.tblTp.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 66.66F));
            this.tblTp.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.34F));
            this.tblTp.Size = new System.Drawing.Size(922, 81);
            this.tblTp.TabIndex = 75;
            // 
            // lblGyosyuKbnTp
            // 
            this.lblGyosyuKbnTp.AutoSize = true;
            this.lblGyosyuKbnTp.BackColor = System.Drawing.SystemColors.Control;
            this.lblGyosyuKbnTp.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblGyosyuKbnTp.Location = new System.Drawing.Point(1, 1);
            this.lblGyosyuKbnTp.Margin = new System.Windows.Forms.Padding(0);
            this.lblGyosyuKbnTp.Name = "lblGyosyuKbnTp";
            this.tblTp.SetRowSpan(this.lblGyosyuKbnTp, 2);
            this.lblGyosyuKbnTp.Size = new System.Drawing.Size(190, 79);
            this.lblGyosyuKbnTp.TabIndex = 0;
            this.lblGyosyuKbnTp.Text = "業種その他区分";
            this.lblGyosyuKbnTp.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblTpTable
            // 
            this.lblTpTable.AutoSize = true;
            this.lblTpTable.BackColor = System.Drawing.SystemColors.Control;
            this.tblTp.SetColumnSpan(this.lblTpTable, 3);
            this.lblTpTable.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblTpTable.Location = new System.Drawing.Point(192, 1);
            this.lblTpTable.Margin = new System.Windows.Forms.Padding(0);
            this.lblTpTable.Name = "lblTpTable";
            this.lblTpTable.Size = new System.Drawing.Size(152, 51);
            this.lblTpTable.TabIndex = 0;
            this.lblTpTable.Text = "全りん含有量";
            this.lblTpTable.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblCpo
            // 
            this.lblCpo.AutoSize = true;
            this.lblCpo.BackColor = System.Drawing.SystemColors.Control;
            this.lblCpo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblCpo.Location = new System.Drawing.Point(192, 53);
            this.lblCpo.Margin = new System.Windows.Forms.Padding(0);
            this.lblCpo.Name = "lblCpo";
            this.lblCpo.Size = new System.Drawing.Size(50, 27);
            this.lblCpo.TabIndex = 0;
            this.lblCpo.Text = "Cpo";
            this.lblCpo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblCpi
            // 
            this.lblCpi.AutoSize = true;
            this.lblCpi.BackColor = System.Drawing.SystemColors.Control;
            this.lblCpi.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblCpi.Location = new System.Drawing.Point(243, 53);
            this.lblCpi.Margin = new System.Windows.Forms.Padding(0);
            this.lblCpi.Name = "lblCpi";
            this.lblCpi.Size = new System.Drawing.Size(50, 27);
            this.lblCpi.TabIndex = 0;
            this.lblCpi.Text = "Cpi";
            this.lblCpi.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblSpaceTp1
            // 
            this.lblSpaceTp1.AutoSize = true;
            this.lblSpaceTp1.BackColor = System.Drawing.SystemColors.Control;
            this.lblSpaceTp1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblSpaceTp1.Location = new System.Drawing.Point(294, 53);
            this.lblSpaceTp1.Margin = new System.Windows.Forms.Padding(0);
            this.lblSpaceTp1.Name = "lblSpaceTp1";
            this.lblSpaceTp1.Size = new System.Drawing.Size(50, 27);
            this.lblSpaceTp1.TabIndex = 0;
            this.lblSpaceTp1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblOsenJyotaiTp
            // 
            this.lblOsenJyotaiTp.AutoSize = true;
            this.lblOsenJyotaiTp.BackColor = System.Drawing.SystemColors.Control;
            this.tblTp.SetColumnSpan(this.lblOsenJyotaiTp, 2);
            this.lblOsenJyotaiTp.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblOsenJyotaiTp.Location = new System.Drawing.Point(345, 1);
            this.lblOsenJyotaiTp.Margin = new System.Windows.Forms.Padding(0);
            this.lblOsenJyotaiTp.Name = "lblOsenJyotaiTp";
            this.lblOsenJyotaiTp.Size = new System.Drawing.Size(101, 51);
            this.lblOsenJyotaiTp.TabIndex = 0;
            this.lblOsenJyotaiTp.Text = "汚染状態\r\n（㎎/L）";
            this.lblOsenJyotaiTp.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblOjAveTp
            // 
            this.lblOjAveTp.AutoSize = true;
            this.lblOjAveTp.BackColor = System.Drawing.SystemColors.Control;
            this.lblOjAveTp.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblOjAveTp.Location = new System.Drawing.Point(345, 53);
            this.lblOjAveTp.Margin = new System.Windows.Forms.Padding(0);
            this.lblOjAveTp.Name = "lblOjAveTp";
            this.lblOjAveTp.Size = new System.Drawing.Size(50, 27);
            this.lblOjAveTp.TabIndex = 0;
            this.lblOjAveTp.Text = "通常";
            this.lblOjAveTp.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // OjMaxTp
            // 
            this.OjMaxTp.AutoSize = true;
            this.OjMaxTp.BackColor = System.Drawing.SystemColors.Control;
            this.OjMaxTp.Dock = System.Windows.Forms.DockStyle.Fill;
            this.OjMaxTp.Location = new System.Drawing.Point(396, 53);
            this.OjMaxTp.Margin = new System.Windows.Forms.Padding(0);
            this.OjMaxTp.Name = "OjMaxTp";
            this.OjMaxTp.Size = new System.Drawing.Size(50, 27);
            this.OjMaxTp.TabIndex = 0;
            this.OjMaxTp.Text = "最大";
            this.OjMaxTp.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblTSuiryoTp
            // 
            this.lblTSuiryoTp.AutoSize = true;
            this.lblTSuiryoTp.BackColor = System.Drawing.SystemColors.Control;
            this.tblTp.SetColumnSpan(this.lblTSuiryoTp, 5);
            this.lblTSuiryoTp.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblTSuiryoTp.Location = new System.Drawing.Point(447, 1);
            this.lblTSuiryoTp.Margin = new System.Windows.Forms.Padding(0);
            this.lblTSuiryoTp.Name = "lblTSuiryoTp";
            this.lblTSuiryoTp.Size = new System.Drawing.Size(254, 51);
            this.lblTSuiryoTp.TabIndex = 0;
            this.lblTSuiryoTp.Text = "水量\r\n（m³/日）";
            this.lblTSuiryoTp.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblTSuiryoAveTp
            // 
            this.lblTSuiryoAveTp.AutoSize = true;
            this.lblTSuiryoAveTp.BackColor = System.Drawing.SystemColors.Control;
            this.lblTSuiryoAveTp.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblTSuiryoAveTp.Location = new System.Drawing.Point(447, 53);
            this.lblTSuiryoAveTp.Margin = new System.Windows.Forms.Padding(0);
            this.lblTSuiryoAveTp.Name = "lblTSuiryoAveTp";
            this.lblTSuiryoAveTp.Size = new System.Drawing.Size(51, 27);
            this.lblTSuiryoAveTp.TabIndex = 0;
            this.lblTSuiryoAveTp.Text = "通常";
            this.lblTSuiryoAveTp.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblTSuiryoMaxTp
            // 
            this.lblTSuiryoMaxTp.AutoSize = true;
            this.lblTSuiryoMaxTp.BackColor = System.Drawing.SystemColors.Control;
            this.lblTSuiryoMaxTp.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblTSuiryoMaxTp.Location = new System.Drawing.Point(499, 53);
            this.lblTSuiryoMaxTp.Margin = new System.Windows.Forms.Padding(0);
            this.lblTSuiryoMaxTp.Name = "lblTSuiryoMaxTp";
            this.lblTSuiryoMaxTp.Size = new System.Drawing.Size(49, 27);
            this.lblTSuiryoMaxTp.TabIndex = 0;
            this.lblTSuiryoMaxTp.Text = "最大";
            this.lblTSuiryoMaxTp.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblTSuiryoQpo
            // 
            this.lblTSuiryoQpo.AutoSize = true;
            this.lblTSuiryoQpo.BackColor = System.Drawing.SystemColors.Control;
            this.lblTSuiryoQpo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblTSuiryoQpo.Location = new System.Drawing.Point(549, 53);
            this.lblTSuiryoQpo.Margin = new System.Windows.Forms.Padding(0);
            this.lblTSuiryoQpo.Name = "lblTSuiryoQpo";
            this.lblTSuiryoQpo.Size = new System.Drawing.Size(50, 27);
            this.lblTSuiryoQpo.TabIndex = 0;
            this.lblTSuiryoQpo.Text = "Qpo";
            this.lblTSuiryoQpo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblTSuiryoQpi
            // 
            this.lblTSuiryoQpi.AutoSize = true;
            this.lblTSuiryoQpi.BackColor = System.Drawing.SystemColors.Control;
            this.lblTSuiryoQpi.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblTSuiryoQpi.Location = new System.Drawing.Point(600, 53);
            this.lblTSuiryoQpi.Margin = new System.Windows.Forms.Padding(0);
            this.lblTSuiryoQpi.Name = "lblTSuiryoQpi";
            this.lblTSuiryoQpi.Size = new System.Drawing.Size(50, 27);
            this.lblTSuiryoQpi.TabIndex = 0;
            this.lblTSuiryoQpi.Text = "Qpi";
            this.lblTSuiryoQpi.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblSpaceTp2
            // 
            this.lblSpaceTp2.AutoSize = true;
            this.lblSpaceTp2.BackColor = System.Drawing.SystemColors.Control;
            this.lblSpaceTp2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblSpaceTp2.Location = new System.Drawing.Point(651, 53);
            this.lblSpaceTp2.Margin = new System.Windows.Forms.Padding(0);
            this.lblSpaceTp2.Name = "lblSpaceTp2";
            this.lblSpaceTp2.Size = new System.Drawing.Size(50, 27);
            this.lblSpaceTp2.TabIndex = 0;
            this.lblSpaceTp2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblOdakuFukaryoTp
            // 
            this.lblOdakuFukaryoTp.AutoSize = true;
            this.lblOdakuFukaryoTp.BackColor = System.Drawing.SystemColors.Control;
            this.tblTp.SetColumnSpan(this.lblOdakuFukaryoTp, 2);
            this.lblOdakuFukaryoTp.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblOdakuFukaryoTp.Location = new System.Drawing.Point(702, 1);
            this.lblOdakuFukaryoTp.Margin = new System.Windows.Forms.Padding(0);
            this.lblOdakuFukaryoTp.Name = "lblOdakuFukaryoTp";
            this.lblOdakuFukaryoTp.Size = new System.Drawing.Size(101, 51);
            this.lblOdakuFukaryoTp.TabIndex = 0;
            this.lblOdakuFukaryoTp.Text = "汚濁負荷量\r\n（㎏/日）";
            this.lblOdakuFukaryoTp.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblOdakuFukaryoAveTp
            // 
            this.lblOdakuFukaryoAveTp.AutoSize = true;
            this.lblOdakuFukaryoAveTp.BackColor = System.Drawing.SystemColors.Control;
            this.lblOdakuFukaryoAveTp.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblOdakuFukaryoAveTp.Location = new System.Drawing.Point(702, 53);
            this.lblOdakuFukaryoAveTp.Margin = new System.Windows.Forms.Padding(0);
            this.lblOdakuFukaryoAveTp.Name = "lblOdakuFukaryoAveTp";
            this.lblOdakuFukaryoAveTp.Size = new System.Drawing.Size(50, 27);
            this.lblOdakuFukaryoAveTp.TabIndex = 0;
            this.lblOdakuFukaryoAveTp.Text = "通常";
            this.lblOdakuFukaryoAveTp.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblOdakuFukaryoMaxTp
            // 
            this.lblOdakuFukaryoMaxTp.AutoSize = true;
            this.lblOdakuFukaryoMaxTp.BackColor = System.Drawing.SystemColors.Control;
            this.lblOdakuFukaryoMaxTp.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblOdakuFukaryoMaxTp.Location = new System.Drawing.Point(753, 53);
            this.lblOdakuFukaryoMaxTp.Margin = new System.Windows.Forms.Padding(0);
            this.lblOdakuFukaryoMaxTp.Name = "lblOdakuFukaryoMaxTp";
            this.lblOdakuFukaryoMaxTp.Size = new System.Drawing.Size(50, 27);
            this.lblOdakuFukaryoMaxTp.TabIndex = 0;
            this.lblOdakuFukaryoMaxTp.Text = "最大";
            this.lblOdakuFukaryoMaxTp.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblKijyunTiTp
            // 
            this.lblKijyunTiTp.AutoSize = true;
            this.lblKijyunTiTp.BackColor = System.Drawing.SystemColors.Control;
            this.lblKijyunTiTp.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblKijyunTiTp.Location = new System.Drawing.Point(804, 1);
            this.lblKijyunTiTp.Margin = new System.Windows.Forms.Padding(0);
            this.lblKijyunTiTp.Name = "lblKijyunTiTp";
            this.lblKijyunTiTp.Size = new System.Drawing.Size(100, 51);
            this.lblKijyunTiTp.TabIndex = 0;
            this.lblKijyunTiTp.Text = "基準値\r\n（㎏/日）";
            this.lblKijyunTiTp.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblLp
            // 
            this.lblLp.AutoSize = true;
            this.lblLp.BackColor = System.Drawing.SystemColors.Control;
            this.lblLp.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblLp.Location = new System.Drawing.Point(804, 53);
            this.lblLp.Margin = new System.Windows.Forms.Padding(0);
            this.lblLp.Name = "lblLp";
            this.lblLp.Size = new System.Drawing.Size(100, 27);
            this.lblLp.TabIndex = 0;
            this.lblLp.Text = "Lp";
            this.lblLp.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblScrolBerTp
            // 
            this.lblScrolBerTp.BackColor = System.Drawing.SystemColors.Control;
            this.lblScrolBerTp.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblScrolBerTp.Location = new System.Drawing.Point(905, 1);
            this.lblScrolBerTp.Margin = new System.Windows.Forms.Padding(0);
            this.lblScrolBerTp.Name = "lblScrolBerTp";
            this.tblTp.SetRowSpan(this.lblScrolBerTp, 2);
            this.lblScrolBerTp.Size = new System.Drawing.Size(16, 79);
            this.lblScrolBerTp.TabIndex = 0;
            this.lblScrolBerTp.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // dgvTp
            // 
            this.dgvTp.AllowUserToAddRows = false;
            this.dgvTp.AllowUserToDeleteRows = false;
            this.dgvTp.AllowUserToResizeColumns = false;
            this.dgvTp.AllowUserToResizeRows = false;
            this.dgvTp.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvTp.ColumnHeadersVisible = false;
            this.dgvTp.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn39,
            this.dataGridViewTextBoxColumn40,
            this.dataGridViewTextBoxColumn41,
            this.dataGridViewTextBoxColumn42,
            this.dataGridViewTextBoxColumn43,
            this.dataGridViewTextBoxColumn44,
            this.dataGridViewTextBoxColumn45,
            this.dataGridViewTextBoxColumn46,
            this.dataGridViewTextBoxColumn47,
            this.dataGridViewTextBoxColumn48,
            this.dataGridViewTextBoxColumn49,
            this.dataGridViewTextBoxColumn50,
            this.dataGridViewTextBoxColumn51,
            this.dataGridViewTextBoxColumn52});
            this.dgvTp.Location = new System.Drawing.Point(15, 882);
            this.dgvTp.MultiSelect = false;
            this.dgvTp.Name = "dgvTp";
            this.dgvTp.ReadOnly = true;
            this.dgvTp.RowHeadersVisible = false;
            this.dgvTp.RowTemplate.Height = 21;
            this.dgvTp.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvTp.Size = new System.Drawing.Size(922, 87);
            this.dgvTp.TabIndex = 11;
            // 
            // dataGridViewTextBoxColumn39
            // 
            this.dataGridViewTextBoxColumn39.HeaderText = "業種";
            this.dataGridViewTextBoxColumn39.Name = "dataGridViewTextBoxColumn39";
            this.dataGridViewTextBoxColumn39.ReadOnly = true;
            this.dataGridViewTextBoxColumn39.Width = 190;
            // 
            // dataGridViewTextBoxColumn40
            // 
            this.dataGridViewTextBoxColumn40.HeaderText = "Cco";
            this.dataGridViewTextBoxColumn40.Name = "dataGridViewTextBoxColumn40";
            this.dataGridViewTextBoxColumn40.ReadOnly = true;
            this.dataGridViewTextBoxColumn40.Width = 51;
            // 
            // dataGridViewTextBoxColumn41
            // 
            this.dataGridViewTextBoxColumn41.HeaderText = "Cci";
            this.dataGridViewTextBoxColumn41.Name = "dataGridViewTextBoxColumn41";
            this.dataGridViewTextBoxColumn41.ReadOnly = true;
            this.dataGridViewTextBoxColumn41.Width = 51;
            // 
            // dataGridViewTextBoxColumn42
            // 
            this.dataGridViewTextBoxColumn42.HeaderText = "Ccj";
            this.dataGridViewTextBoxColumn42.Name = "dataGridViewTextBoxColumn42";
            this.dataGridViewTextBoxColumn42.ReadOnly = true;
            this.dataGridViewTextBoxColumn42.Width = 51;
            // 
            // dataGridViewTextBoxColumn43
            // 
            this.dataGridViewTextBoxColumn43.HeaderText = "通常";
            this.dataGridViewTextBoxColumn43.Name = "dataGridViewTextBoxColumn43";
            this.dataGridViewTextBoxColumn43.ReadOnly = true;
            this.dataGridViewTextBoxColumn43.Width = 51;
            // 
            // dataGridViewTextBoxColumn44
            // 
            this.dataGridViewTextBoxColumn44.HeaderText = "最大";
            this.dataGridViewTextBoxColumn44.Name = "dataGridViewTextBoxColumn44";
            this.dataGridViewTextBoxColumn44.ReadOnly = true;
            this.dataGridViewTextBoxColumn44.Width = 51;
            // 
            // dataGridViewTextBoxColumn45
            // 
            this.dataGridViewTextBoxColumn45.HeaderText = "通常";
            this.dataGridViewTextBoxColumn45.Name = "dataGridViewTextBoxColumn45";
            this.dataGridViewTextBoxColumn45.ReadOnly = true;
            this.dataGridViewTextBoxColumn45.Width = 51;
            // 
            // dataGridViewTextBoxColumn46
            // 
            this.dataGridViewTextBoxColumn46.HeaderText = "最大";
            this.dataGridViewTextBoxColumn46.Name = "dataGridViewTextBoxColumn46";
            this.dataGridViewTextBoxColumn46.ReadOnly = true;
            this.dataGridViewTextBoxColumn46.Width = 51;
            // 
            // dataGridViewTextBoxColumn47
            // 
            this.dataGridViewTextBoxColumn47.HeaderText = "Qco";
            this.dataGridViewTextBoxColumn47.Name = "dataGridViewTextBoxColumn47";
            this.dataGridViewTextBoxColumn47.ReadOnly = true;
            this.dataGridViewTextBoxColumn47.Width = 51;
            // 
            // dataGridViewTextBoxColumn48
            // 
            this.dataGridViewTextBoxColumn48.HeaderText = "Qci";
            this.dataGridViewTextBoxColumn48.Name = "dataGridViewTextBoxColumn48";
            this.dataGridViewTextBoxColumn48.ReadOnly = true;
            this.dataGridViewTextBoxColumn48.Width = 51;
            // 
            // dataGridViewTextBoxColumn49
            // 
            this.dataGridViewTextBoxColumn49.HeaderText = "Qcj";
            this.dataGridViewTextBoxColumn49.Name = "dataGridViewTextBoxColumn49";
            this.dataGridViewTextBoxColumn49.ReadOnly = true;
            this.dataGridViewTextBoxColumn49.Width = 51;
            // 
            // dataGridViewTextBoxColumn50
            // 
            this.dataGridViewTextBoxColumn50.HeaderText = "通常";
            this.dataGridViewTextBoxColumn50.Name = "dataGridViewTextBoxColumn50";
            this.dataGridViewTextBoxColumn50.ReadOnly = true;
            this.dataGridViewTextBoxColumn50.Width = 51;
            // 
            // dataGridViewTextBoxColumn51
            // 
            this.dataGridViewTextBoxColumn51.HeaderText = "最大";
            this.dataGridViewTextBoxColumn51.Name = "dataGridViewTextBoxColumn51";
            this.dataGridViewTextBoxColumn51.ReadOnly = true;
            this.dataGridViewTextBoxColumn51.Width = 51;
            // 
            // dataGridViewTextBoxColumn52
            // 
            this.dataGridViewTextBoxColumn52.HeaderText = "Ln";
            this.dataGridViewTextBoxColumn52.Name = "dataGridViewTextBoxColumn52";
            this.dataGridViewTextBoxColumn52.ReadOnly = true;
            // 
            // lblTp
            // 
            this.lblTp.AutoSize = true;
            this.lblTp.Font = new System.Drawing.Font("メイリオ", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblTp.Location = new System.Drawing.Point(14, 774);
            this.lblTp.Name = "lblTp";
            this.lblTp.Size = new System.Drawing.Size(87, 20);
            this.lblTp.TabIndex = 73;
            this.lblTp.Text = "全りん含有量";
            // 
            // btnDeleteMeisaiTp
            // 
            this.btnDeleteMeisaiTp.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnDeleteMeisaiTp.Location = new System.Drawing.Point(837, 984);
            this.btnDeleteMeisaiTp.Name = "btnDeleteMeisaiTp";
            this.btnDeleteMeisaiTp.Size = new System.Drawing.Size(100, 30);
            this.btnDeleteMeisaiTp.TabIndex = 13;
            this.btnDeleteMeisaiTp.Text = "明細削除";
            this.btnDeleteMeisaiTp.UseVisualStyleBackColor = true;
            // 
            // btnAddMeisaiTp
            // 
            this.btnAddMeisaiTp.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnAddMeisaiTp.Location = new System.Drawing.Point(731, 984);
            this.btnAddMeisaiTp.Name = "btnAddMeisaiTp";
            this.btnAddMeisaiTp.Size = new System.Drawing.Size(100, 30);
            this.btnAddMeisaiTp.TabIndex = 12;
            this.btnAddMeisaiTp.Text = "明細追加";
            this.btnAddMeisaiTp.UseVisualStyleBackColor = true;
            // 
            // TblTn
            // 
            this.TblTn.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.TblTn.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.TblTn.ColumnCount = 15;
            this.TblTn.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 190F));
            this.TblTn.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.TblTn.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.TblTn.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.TblTn.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.TblTn.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.TblTn.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.TblTn.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.TblTn.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.TblTn.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.TblTn.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.TblTn.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.TblTn.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.TblTn.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.TblTn.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 16F));
            this.TblTn.Controls.Add(this.lblGyosyuKbnTn, 0, 0);
            this.TblTn.Controls.Add(this.lblTnTable, 1, 0);
            this.TblTn.Controls.Add(this.lblCno, 1, 1);
            this.TblTn.Controls.Add(this.lblCni, 2, 1);
            this.TblTn.Controls.Add(this.lblSpaceTn1, 3, 1);
            this.TblTn.Controls.Add(this.lblOsenJyotaiTn, 4, 0);
            this.TblTn.Controls.Add(this.lblOjAveTn, 4, 1);
            this.TblTn.Controls.Add(this.OjMaxTn, 5, 1);
            this.TblTn.Controls.Add(this.lblTSuiryoTn, 6, 0);
            this.TblTn.Controls.Add(this.lblTSuiryoAveTn, 6, 1);
            this.TblTn.Controls.Add(this.lblTSuiryoMaxTn, 7, 1);
            this.TblTn.Controls.Add(this.lblTSuiryoQno, 8, 1);
            this.TblTn.Controls.Add(this.lblTSuiryoQni, 9, 1);
            this.TblTn.Controls.Add(this.lblSpaceTn2, 10, 1);
            this.TblTn.Controls.Add(this.lblOdakuFukaryoTn, 11, 0);
            this.TblTn.Controls.Add(this.lblOdakuFukaryoAveTn, 11, 1);
            this.TblTn.Controls.Add(this.lblOdakuFukaryoMaxTn, 12, 1);
            this.TblTn.Controls.Add(this.lblKijyunTiTn, 13, 0);
            this.TblTn.Controls.Add(this.lblLn, 13, 1);
            this.TblTn.Controls.Add(this.lblScrolBerTn, 14, 0);
            this.TblTn.Location = new System.Drawing.Point(15, 555);
            this.TblTn.Name = "TblTn";
            this.TblTn.RowCount = 2;
            this.TblTn.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 66.66F));
            this.TblTn.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.34F));
            this.TblTn.Size = new System.Drawing.Size(922, 81);
            this.TblTn.TabIndex = 70;
            // 
            // lblGyosyuKbnTn
            // 
            this.lblGyosyuKbnTn.AutoSize = true;
            this.lblGyosyuKbnTn.BackColor = System.Drawing.SystemColors.Control;
            this.lblGyosyuKbnTn.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblGyosyuKbnTn.Location = new System.Drawing.Point(1, 1);
            this.lblGyosyuKbnTn.Margin = new System.Windows.Forms.Padding(0);
            this.lblGyosyuKbnTn.Name = "lblGyosyuKbnTn";
            this.TblTn.SetRowSpan(this.lblGyosyuKbnTn, 2);
            this.lblGyosyuKbnTn.Size = new System.Drawing.Size(190, 79);
            this.lblGyosyuKbnTn.TabIndex = 0;
            this.lblGyosyuKbnTn.Text = "業種その他区分";
            this.lblGyosyuKbnTn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblTnTable
            // 
            this.lblTnTable.AutoSize = true;
            this.lblTnTable.BackColor = System.Drawing.SystemColors.Control;
            this.TblTn.SetColumnSpan(this.lblTnTable, 3);
            this.lblTnTable.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblTnTable.Location = new System.Drawing.Point(192, 1);
            this.lblTnTable.Margin = new System.Windows.Forms.Padding(0);
            this.lblTnTable.Name = "lblTnTable";
            this.lblTnTable.Size = new System.Drawing.Size(152, 51);
            this.lblTnTable.TabIndex = 0;
            this.lblTnTable.Text = "全窒素含有量";
            this.lblTnTable.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblCno
            // 
            this.lblCno.AutoSize = true;
            this.lblCno.BackColor = System.Drawing.SystemColors.Control;
            this.lblCno.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblCno.Location = new System.Drawing.Point(192, 53);
            this.lblCno.Margin = new System.Windows.Forms.Padding(0);
            this.lblCno.Name = "lblCno";
            this.lblCno.Size = new System.Drawing.Size(50, 27);
            this.lblCno.TabIndex = 0;
            this.lblCno.Text = "Cno";
            this.lblCno.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblCni
            // 
            this.lblCni.AutoSize = true;
            this.lblCni.BackColor = System.Drawing.SystemColors.Control;
            this.lblCni.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblCni.Location = new System.Drawing.Point(243, 53);
            this.lblCni.Margin = new System.Windows.Forms.Padding(0);
            this.lblCni.Name = "lblCni";
            this.lblCni.Size = new System.Drawing.Size(50, 27);
            this.lblCni.TabIndex = 0;
            this.lblCni.Text = "Cni";
            this.lblCni.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblSpaceTn1
            // 
            this.lblSpaceTn1.AutoSize = true;
            this.lblSpaceTn1.BackColor = System.Drawing.SystemColors.Control;
            this.lblSpaceTn1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblSpaceTn1.Location = new System.Drawing.Point(294, 53);
            this.lblSpaceTn1.Margin = new System.Windows.Forms.Padding(0);
            this.lblSpaceTn1.Name = "lblSpaceTn1";
            this.lblSpaceTn1.Size = new System.Drawing.Size(50, 27);
            this.lblSpaceTn1.TabIndex = 0;
            this.lblSpaceTn1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblOsenJyotaiTn
            // 
            this.lblOsenJyotaiTn.AutoSize = true;
            this.lblOsenJyotaiTn.BackColor = System.Drawing.SystemColors.Control;
            this.TblTn.SetColumnSpan(this.lblOsenJyotaiTn, 2);
            this.lblOsenJyotaiTn.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblOsenJyotaiTn.Location = new System.Drawing.Point(345, 1);
            this.lblOsenJyotaiTn.Margin = new System.Windows.Forms.Padding(0);
            this.lblOsenJyotaiTn.Name = "lblOsenJyotaiTn";
            this.lblOsenJyotaiTn.Size = new System.Drawing.Size(101, 51);
            this.lblOsenJyotaiTn.TabIndex = 0;
            this.lblOsenJyotaiTn.Text = "汚染状態\r\n（㎎/L）";
            this.lblOsenJyotaiTn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblOjAveTn
            // 
            this.lblOjAveTn.AutoSize = true;
            this.lblOjAveTn.BackColor = System.Drawing.SystemColors.Control;
            this.lblOjAveTn.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblOjAveTn.Location = new System.Drawing.Point(345, 53);
            this.lblOjAveTn.Margin = new System.Windows.Forms.Padding(0);
            this.lblOjAveTn.Name = "lblOjAveTn";
            this.lblOjAveTn.Size = new System.Drawing.Size(50, 27);
            this.lblOjAveTn.TabIndex = 0;
            this.lblOjAveTn.Text = "通常";
            this.lblOjAveTn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // OjMaxTn
            // 
            this.OjMaxTn.AutoSize = true;
            this.OjMaxTn.BackColor = System.Drawing.SystemColors.Control;
            this.OjMaxTn.Dock = System.Windows.Forms.DockStyle.Fill;
            this.OjMaxTn.Location = new System.Drawing.Point(396, 53);
            this.OjMaxTn.Margin = new System.Windows.Forms.Padding(0);
            this.OjMaxTn.Name = "OjMaxTn";
            this.OjMaxTn.Size = new System.Drawing.Size(50, 27);
            this.OjMaxTn.TabIndex = 0;
            this.OjMaxTn.Text = "最大";
            this.OjMaxTn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblTSuiryoTn
            // 
            this.lblTSuiryoTn.AutoSize = true;
            this.lblTSuiryoTn.BackColor = System.Drawing.SystemColors.Control;
            this.TblTn.SetColumnSpan(this.lblTSuiryoTn, 5);
            this.lblTSuiryoTn.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblTSuiryoTn.Location = new System.Drawing.Point(447, 1);
            this.lblTSuiryoTn.Margin = new System.Windows.Forms.Padding(0);
            this.lblTSuiryoTn.Name = "lblTSuiryoTn";
            this.lblTSuiryoTn.Size = new System.Drawing.Size(254, 51);
            this.lblTSuiryoTn.TabIndex = 0;
            this.lblTSuiryoTn.Text = "水量\r\n（m³/日）";
            this.lblTSuiryoTn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblTSuiryoAveTn
            // 
            this.lblTSuiryoAveTn.AutoSize = true;
            this.lblTSuiryoAveTn.BackColor = System.Drawing.SystemColors.Control;
            this.lblTSuiryoAveTn.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblTSuiryoAveTn.Location = new System.Drawing.Point(447, 53);
            this.lblTSuiryoAveTn.Margin = new System.Windows.Forms.Padding(0);
            this.lblTSuiryoAveTn.Name = "lblTSuiryoAveTn";
            this.lblTSuiryoAveTn.Size = new System.Drawing.Size(50, 27);
            this.lblTSuiryoAveTn.TabIndex = 0;
            this.lblTSuiryoAveTn.Text = "通常";
            this.lblTSuiryoAveTn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblTSuiryoMaxTn
            // 
            this.lblTSuiryoMaxTn.AutoSize = true;
            this.lblTSuiryoMaxTn.BackColor = System.Drawing.SystemColors.Control;
            this.lblTSuiryoMaxTn.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblTSuiryoMaxTn.Location = new System.Drawing.Point(498, 53);
            this.lblTSuiryoMaxTn.Margin = new System.Windows.Forms.Padding(0);
            this.lblTSuiryoMaxTn.Name = "lblTSuiryoMaxTn";
            this.lblTSuiryoMaxTn.Size = new System.Drawing.Size(50, 27);
            this.lblTSuiryoMaxTn.TabIndex = 0;
            this.lblTSuiryoMaxTn.Text = "最大";
            this.lblTSuiryoMaxTn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblTSuiryoQno
            // 
            this.lblTSuiryoQno.AutoSize = true;
            this.lblTSuiryoQno.BackColor = System.Drawing.SystemColors.Control;
            this.lblTSuiryoQno.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblTSuiryoQno.Location = new System.Drawing.Point(549, 53);
            this.lblTSuiryoQno.Margin = new System.Windows.Forms.Padding(0);
            this.lblTSuiryoQno.Name = "lblTSuiryoQno";
            this.lblTSuiryoQno.Size = new System.Drawing.Size(50, 27);
            this.lblTSuiryoQno.TabIndex = 0;
            this.lblTSuiryoQno.Text = "Qno";
            this.lblTSuiryoQno.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblTSuiryoQni
            // 
            this.lblTSuiryoQni.AutoSize = true;
            this.lblTSuiryoQni.BackColor = System.Drawing.SystemColors.Control;
            this.lblTSuiryoQni.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblTSuiryoQni.Location = new System.Drawing.Point(600, 53);
            this.lblTSuiryoQni.Margin = new System.Windows.Forms.Padding(0);
            this.lblTSuiryoQni.Name = "lblTSuiryoQni";
            this.lblTSuiryoQni.Size = new System.Drawing.Size(50, 27);
            this.lblTSuiryoQni.TabIndex = 0;
            this.lblTSuiryoQni.Text = "Qni";
            this.lblTSuiryoQni.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblSpaceTn2
            // 
            this.lblSpaceTn2.AutoSize = true;
            this.lblSpaceTn2.BackColor = System.Drawing.SystemColors.Control;
            this.lblSpaceTn2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblSpaceTn2.Location = new System.Drawing.Point(651, 53);
            this.lblSpaceTn2.Margin = new System.Windows.Forms.Padding(0);
            this.lblSpaceTn2.Name = "lblSpaceTn2";
            this.lblSpaceTn2.Size = new System.Drawing.Size(50, 27);
            this.lblSpaceTn2.TabIndex = 0;
            this.lblSpaceTn2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblOdakuFukaryoTn
            // 
            this.lblOdakuFukaryoTn.AutoSize = true;
            this.lblOdakuFukaryoTn.BackColor = System.Drawing.SystemColors.Control;
            this.TblTn.SetColumnSpan(this.lblOdakuFukaryoTn, 2);
            this.lblOdakuFukaryoTn.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblOdakuFukaryoTn.Location = new System.Drawing.Point(702, 1);
            this.lblOdakuFukaryoTn.Margin = new System.Windows.Forms.Padding(0);
            this.lblOdakuFukaryoTn.Name = "lblOdakuFukaryoTn";
            this.lblOdakuFukaryoTn.Size = new System.Drawing.Size(101, 51);
            this.lblOdakuFukaryoTn.TabIndex = 0;
            this.lblOdakuFukaryoTn.Text = "汚濁負荷量\r\n（㎏/日）";
            this.lblOdakuFukaryoTn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblOdakuFukaryoAveTn
            // 
            this.lblOdakuFukaryoAveTn.AutoSize = true;
            this.lblOdakuFukaryoAveTn.BackColor = System.Drawing.SystemColors.Control;
            this.lblOdakuFukaryoAveTn.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblOdakuFukaryoAveTn.Location = new System.Drawing.Point(702, 53);
            this.lblOdakuFukaryoAveTn.Margin = new System.Windows.Forms.Padding(0);
            this.lblOdakuFukaryoAveTn.Name = "lblOdakuFukaryoAveTn";
            this.lblOdakuFukaryoAveTn.Size = new System.Drawing.Size(50, 27);
            this.lblOdakuFukaryoAveTn.TabIndex = 0;
            this.lblOdakuFukaryoAveTn.Text = "通常";
            this.lblOdakuFukaryoAveTn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblOdakuFukaryoMaxTn
            // 
            this.lblOdakuFukaryoMaxTn.AutoSize = true;
            this.lblOdakuFukaryoMaxTn.BackColor = System.Drawing.SystemColors.Control;
            this.lblOdakuFukaryoMaxTn.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblOdakuFukaryoMaxTn.Location = new System.Drawing.Point(753, 53);
            this.lblOdakuFukaryoMaxTn.Margin = new System.Windows.Forms.Padding(0);
            this.lblOdakuFukaryoMaxTn.Name = "lblOdakuFukaryoMaxTn";
            this.lblOdakuFukaryoMaxTn.Size = new System.Drawing.Size(50, 27);
            this.lblOdakuFukaryoMaxTn.TabIndex = 0;
            this.lblOdakuFukaryoMaxTn.Text = "最大";
            this.lblOdakuFukaryoMaxTn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblKijyunTiTn
            // 
            this.lblKijyunTiTn.AutoSize = true;
            this.lblKijyunTiTn.BackColor = System.Drawing.SystemColors.Control;
            this.lblKijyunTiTn.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblKijyunTiTn.Location = new System.Drawing.Point(804, 1);
            this.lblKijyunTiTn.Margin = new System.Windows.Forms.Padding(0);
            this.lblKijyunTiTn.Name = "lblKijyunTiTn";
            this.lblKijyunTiTn.Size = new System.Drawing.Size(100, 51);
            this.lblKijyunTiTn.TabIndex = 0;
            this.lblKijyunTiTn.Text = "基準値\r\n（㎏/日）";
            this.lblKijyunTiTn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblLn
            // 
            this.lblLn.AutoSize = true;
            this.lblLn.BackColor = System.Drawing.SystemColors.Control;
            this.lblLn.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblLn.Location = new System.Drawing.Point(804, 53);
            this.lblLn.Margin = new System.Windows.Forms.Padding(0);
            this.lblLn.Name = "lblLn";
            this.lblLn.Size = new System.Drawing.Size(100, 27);
            this.lblLn.TabIndex = 0;
            this.lblLn.Text = "Ln";
            this.lblLn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblScrolBerTn
            // 
            this.lblScrolBerTn.BackColor = System.Drawing.SystemColors.Control;
            this.lblScrolBerTn.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblScrolBerTn.Location = new System.Drawing.Point(905, 1);
            this.lblScrolBerTn.Margin = new System.Windows.Forms.Padding(0);
            this.lblScrolBerTn.Name = "lblScrolBerTn";
            this.TblTn.SetRowSpan(this.lblScrolBerTn, 2);
            this.lblScrolBerTn.Size = new System.Drawing.Size(16, 79);
            this.lblScrolBerTn.TabIndex = 0;
            this.lblScrolBerTn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // dgvTn
            // 
            this.dgvTn.AllowUserToAddRows = false;
            this.dgvTn.AllowUserToDeleteRows = false;
            this.dgvTn.AllowUserToResizeColumns = false;
            this.dgvTn.AllowUserToResizeRows = false;
            this.dgvTn.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvTn.ColumnHeadersVisible = false;
            this.dgvTn.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn25,
            this.dataGridViewTextBoxColumn26,
            this.dataGridViewTextBoxColumn27,
            this.dataGridViewTextBoxColumn28,
            this.dataGridViewTextBoxColumn29,
            this.dataGridViewTextBoxColumn30,
            this.dataGridViewTextBoxColumn31,
            this.dataGridViewTextBoxColumn32,
            this.dataGridViewTextBoxColumn33,
            this.dataGridViewTextBoxColumn34,
            this.dataGridViewTextBoxColumn35,
            this.dataGridViewTextBoxColumn36,
            this.dataGridViewTextBoxColumn37,
            this.dataGridViewTextBoxColumn38});
            this.dgvTn.Location = new System.Drawing.Point(15, 636);
            this.dgvTn.MultiSelect = false;
            this.dgvTn.Name = "dgvTn";
            this.dgvTn.ReadOnly = true;
            this.dgvTn.RowHeadersVisible = false;
            this.dgvTn.RowTemplate.Height = 21;
            this.dgvTn.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvTn.Size = new System.Drawing.Size(922, 87);
            this.dgvTn.TabIndex = 8;
            // 
            // dataGridViewTextBoxColumn25
            // 
            this.dataGridViewTextBoxColumn25.HeaderText = "業種";
            this.dataGridViewTextBoxColumn25.Name = "dataGridViewTextBoxColumn25";
            this.dataGridViewTextBoxColumn25.ReadOnly = true;
            this.dataGridViewTextBoxColumn25.Width = 190;
            // 
            // dataGridViewTextBoxColumn26
            // 
            this.dataGridViewTextBoxColumn26.HeaderText = "Cco";
            this.dataGridViewTextBoxColumn26.Name = "dataGridViewTextBoxColumn26";
            this.dataGridViewTextBoxColumn26.ReadOnly = true;
            this.dataGridViewTextBoxColumn26.Width = 51;
            // 
            // dataGridViewTextBoxColumn27
            // 
            this.dataGridViewTextBoxColumn27.HeaderText = "Cci";
            this.dataGridViewTextBoxColumn27.Name = "dataGridViewTextBoxColumn27";
            this.dataGridViewTextBoxColumn27.ReadOnly = true;
            this.dataGridViewTextBoxColumn27.Width = 51;
            // 
            // dataGridViewTextBoxColumn28
            // 
            this.dataGridViewTextBoxColumn28.HeaderText = "Ccj";
            this.dataGridViewTextBoxColumn28.Name = "dataGridViewTextBoxColumn28";
            this.dataGridViewTextBoxColumn28.ReadOnly = true;
            this.dataGridViewTextBoxColumn28.Width = 51;
            // 
            // dataGridViewTextBoxColumn29
            // 
            this.dataGridViewTextBoxColumn29.HeaderText = "通常";
            this.dataGridViewTextBoxColumn29.Name = "dataGridViewTextBoxColumn29";
            this.dataGridViewTextBoxColumn29.ReadOnly = true;
            this.dataGridViewTextBoxColumn29.Width = 51;
            // 
            // dataGridViewTextBoxColumn30
            // 
            this.dataGridViewTextBoxColumn30.HeaderText = "最大";
            this.dataGridViewTextBoxColumn30.Name = "dataGridViewTextBoxColumn30";
            this.dataGridViewTextBoxColumn30.ReadOnly = true;
            this.dataGridViewTextBoxColumn30.Width = 51;
            // 
            // dataGridViewTextBoxColumn31
            // 
            this.dataGridViewTextBoxColumn31.HeaderText = "通常";
            this.dataGridViewTextBoxColumn31.Name = "dataGridViewTextBoxColumn31";
            this.dataGridViewTextBoxColumn31.ReadOnly = true;
            this.dataGridViewTextBoxColumn31.Width = 51;
            // 
            // dataGridViewTextBoxColumn32
            // 
            this.dataGridViewTextBoxColumn32.HeaderText = "最大";
            this.dataGridViewTextBoxColumn32.Name = "dataGridViewTextBoxColumn32";
            this.dataGridViewTextBoxColumn32.ReadOnly = true;
            this.dataGridViewTextBoxColumn32.Width = 51;
            // 
            // dataGridViewTextBoxColumn33
            // 
            this.dataGridViewTextBoxColumn33.HeaderText = "Qco";
            this.dataGridViewTextBoxColumn33.Name = "dataGridViewTextBoxColumn33";
            this.dataGridViewTextBoxColumn33.ReadOnly = true;
            this.dataGridViewTextBoxColumn33.Width = 51;
            // 
            // dataGridViewTextBoxColumn34
            // 
            this.dataGridViewTextBoxColumn34.HeaderText = "Qci";
            this.dataGridViewTextBoxColumn34.Name = "dataGridViewTextBoxColumn34";
            this.dataGridViewTextBoxColumn34.ReadOnly = true;
            this.dataGridViewTextBoxColumn34.Width = 51;
            // 
            // dataGridViewTextBoxColumn35
            // 
            this.dataGridViewTextBoxColumn35.HeaderText = "Qcj";
            this.dataGridViewTextBoxColumn35.Name = "dataGridViewTextBoxColumn35";
            this.dataGridViewTextBoxColumn35.ReadOnly = true;
            this.dataGridViewTextBoxColumn35.Width = 51;
            // 
            // dataGridViewTextBoxColumn36
            // 
            this.dataGridViewTextBoxColumn36.HeaderText = "通常";
            this.dataGridViewTextBoxColumn36.Name = "dataGridViewTextBoxColumn36";
            this.dataGridViewTextBoxColumn36.ReadOnly = true;
            this.dataGridViewTextBoxColumn36.Width = 51;
            // 
            // dataGridViewTextBoxColumn37
            // 
            this.dataGridViewTextBoxColumn37.HeaderText = "最大";
            this.dataGridViewTextBoxColumn37.Name = "dataGridViewTextBoxColumn37";
            this.dataGridViewTextBoxColumn37.ReadOnly = true;
            this.dataGridViewTextBoxColumn37.Width = 51;
            // 
            // dataGridViewTextBoxColumn38
            // 
            this.dataGridViewTextBoxColumn38.HeaderText = "Ln";
            this.dataGridViewTextBoxColumn38.Name = "dataGridViewTextBoxColumn38";
            this.dataGridViewTextBoxColumn38.ReadOnly = true;
            // 
            // lblTn
            // 
            this.lblTn.AutoSize = true;
            this.lblTn.Font = new System.Drawing.Font("メイリオ", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblTn.Location = new System.Drawing.Point(14, 528);
            this.lblTn.Name = "lblTn";
            this.lblTn.Size = new System.Drawing.Size(87, 20);
            this.lblTn.TabIndex = 68;
            this.lblTn.Text = "全窒素含有量";
            // 
            // btnDeleteMeisaiTn
            // 
            this.btnDeleteMeisaiTn.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnDeleteMeisaiTn.Location = new System.Drawing.Point(837, 738);
            this.btnDeleteMeisaiTn.Name = "btnDeleteMeisaiTn";
            this.btnDeleteMeisaiTn.Size = new System.Drawing.Size(100, 30);
            this.btnDeleteMeisaiTn.TabIndex = 10;
            this.btnDeleteMeisaiTn.Text = "明細削除";
            this.btnDeleteMeisaiTn.UseVisualStyleBackColor = true;
            // 
            // btnAddMeisaiTn
            // 
            this.btnAddMeisaiTn.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnAddMeisaiTn.Location = new System.Drawing.Point(731, 738);
            this.btnAddMeisaiTn.Name = "btnAddMeisaiTn";
            this.btnAddMeisaiTn.Size = new System.Drawing.Size(100, 30);
            this.btnAddMeisaiTn.TabIndex = 9;
            this.btnAddMeisaiTn.Text = "明細追加";
            this.btnAddMeisaiTn.UseVisualStyleBackColor = true;
            // 
            // tblCod
            // 
            this.tblCod.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.tblCod.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tblCod.ColumnCount = 15;
            this.tblCod.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 190F));
            this.tblCod.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tblCod.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tblCod.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tblCod.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tblCod.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tblCod.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tblCod.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tblCod.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tblCod.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tblCod.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tblCod.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tblCod.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tblCod.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.tblCod.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 16F));
            this.tblCod.Controls.Add(this.lblGyosyuKbnCod, 0, 0);
            this.tblCod.Controls.Add(this.lblCodTable, 1, 0);
            this.tblCod.Controls.Add(this.lblCco, 1, 1);
            this.tblCod.Controls.Add(this.lblCci, 2, 1);
            this.tblCod.Controls.Add(this.lblCcj, 3, 1);
            this.tblCod.Controls.Add(this.lblOsenJyotaiCod, 4, 0);
            this.tblCod.Controls.Add(this.lblOjAveCod, 4, 1);
            this.tblCod.Controls.Add(this.OjMaxCod, 5, 1);
            this.tblCod.Controls.Add(this.lblTSuiryoCod, 6, 0);
            this.tblCod.Controls.Add(this.lblTSuiryoAveCod, 6, 1);
            this.tblCod.Controls.Add(this.lblTSuiryoMaxCod, 7, 1);
            this.tblCod.Controls.Add(this.lblTSuiryoQco, 8, 1);
            this.tblCod.Controls.Add(this.lblTSuiryoQci, 9, 1);
            this.tblCod.Controls.Add(this.lblTSuiryoQcj, 10, 1);
            this.tblCod.Controls.Add(this.lblOdakuFukaryoCod, 11, 0);
            this.tblCod.Controls.Add(this.lblOdakuFukaryoAveCod, 11, 1);
            this.tblCod.Controls.Add(this.lblOdakuFukaryoMaxCod, 12, 1);
            this.tblCod.Controls.Add(this.lblKijyunTiCod, 13, 0);
            this.tblCod.Controls.Add(this.lblLc, 13, 1);
            this.tblCod.Controls.Add(this.lblScrolBerCod, 14, 0);
            this.tblCod.Location = new System.Drawing.Point(15, 308);
            this.tblCod.Name = "tblCod";
            this.tblCod.RowCount = 2;
            this.tblCod.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 66.66F));
            this.tblCod.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.34F));
            this.tblCod.Size = new System.Drawing.Size(922, 81);
            this.tblCod.TabIndex = 64;
            // 
            // lblGyosyuKbnCod
            // 
            this.lblGyosyuKbnCod.AutoSize = true;
            this.lblGyosyuKbnCod.BackColor = System.Drawing.SystemColors.Control;
            this.lblGyosyuKbnCod.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblGyosyuKbnCod.Location = new System.Drawing.Point(1, 1);
            this.lblGyosyuKbnCod.Margin = new System.Windows.Forms.Padding(0);
            this.lblGyosyuKbnCod.Name = "lblGyosyuKbnCod";
            this.tblCod.SetRowSpan(this.lblGyosyuKbnCod, 2);
            this.lblGyosyuKbnCod.Size = new System.Drawing.Size(190, 79);
            this.lblGyosyuKbnCod.TabIndex = 0;
            this.lblGyosyuKbnCod.Text = "業種その他区分";
            this.lblGyosyuKbnCod.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblCodTable
            // 
            this.lblCodTable.AutoSize = true;
            this.lblCodTable.BackColor = System.Drawing.SystemColors.Control;
            this.tblCod.SetColumnSpan(this.lblCodTable, 3);
            this.lblCodTable.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblCodTable.Location = new System.Drawing.Point(192, 1);
            this.lblCodTable.Margin = new System.Windows.Forms.Padding(0);
            this.lblCodTable.Name = "lblCodTable";
            this.lblCodTable.Size = new System.Drawing.Size(152, 51);
            this.lblCodTable.TabIndex = 0;
            this.lblCodTable.Text = "化学的\r\n酸素要求量";
            this.lblCodTable.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblCco
            // 
            this.lblCco.AutoSize = true;
            this.lblCco.BackColor = System.Drawing.SystemColors.Control;
            this.lblCco.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblCco.Location = new System.Drawing.Point(192, 53);
            this.lblCco.Margin = new System.Windows.Forms.Padding(0);
            this.lblCco.Name = "lblCco";
            this.lblCco.Size = new System.Drawing.Size(50, 27);
            this.lblCco.TabIndex = 0;
            this.lblCco.Text = "Cco";
            this.lblCco.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblCci
            // 
            this.lblCci.AutoSize = true;
            this.lblCci.BackColor = System.Drawing.SystemColors.Control;
            this.lblCci.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblCci.Location = new System.Drawing.Point(243, 53);
            this.lblCci.Margin = new System.Windows.Forms.Padding(0);
            this.lblCci.Name = "lblCci";
            this.lblCci.Size = new System.Drawing.Size(50, 27);
            this.lblCci.TabIndex = 0;
            this.lblCci.Text = "Cci";
            this.lblCci.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblCcj
            // 
            this.lblCcj.AutoSize = true;
            this.lblCcj.BackColor = System.Drawing.SystemColors.Control;
            this.lblCcj.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblCcj.Location = new System.Drawing.Point(294, 53);
            this.lblCcj.Margin = new System.Windows.Forms.Padding(0);
            this.lblCcj.Name = "lblCcj";
            this.lblCcj.Size = new System.Drawing.Size(50, 27);
            this.lblCcj.TabIndex = 0;
            this.lblCcj.Text = "Ccj";
            this.lblCcj.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblOsenJyotaiCod
            // 
            this.lblOsenJyotaiCod.AutoSize = true;
            this.lblOsenJyotaiCod.BackColor = System.Drawing.SystemColors.Control;
            this.tblCod.SetColumnSpan(this.lblOsenJyotaiCod, 2);
            this.lblOsenJyotaiCod.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblOsenJyotaiCod.Location = new System.Drawing.Point(345, 1);
            this.lblOsenJyotaiCod.Margin = new System.Windows.Forms.Padding(0);
            this.lblOsenJyotaiCod.Name = "lblOsenJyotaiCod";
            this.lblOsenJyotaiCod.Size = new System.Drawing.Size(101, 51);
            this.lblOsenJyotaiCod.TabIndex = 0;
            this.lblOsenJyotaiCod.Text = "汚染状態\r\n（㎎/L）";
            this.lblOsenJyotaiCod.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblOjAveCod
            // 
            this.lblOjAveCod.AutoSize = true;
            this.lblOjAveCod.BackColor = System.Drawing.SystemColors.Control;
            this.lblOjAveCod.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblOjAveCod.Location = new System.Drawing.Point(345, 53);
            this.lblOjAveCod.Margin = new System.Windows.Forms.Padding(0);
            this.lblOjAveCod.Name = "lblOjAveCod";
            this.lblOjAveCod.Size = new System.Drawing.Size(50, 27);
            this.lblOjAveCod.TabIndex = 0;
            this.lblOjAveCod.Text = "通常";
            this.lblOjAveCod.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // OjMaxCod
            // 
            this.OjMaxCod.AutoSize = true;
            this.OjMaxCod.BackColor = System.Drawing.SystemColors.Control;
            this.OjMaxCod.Dock = System.Windows.Forms.DockStyle.Fill;
            this.OjMaxCod.Location = new System.Drawing.Point(396, 53);
            this.OjMaxCod.Margin = new System.Windows.Forms.Padding(0);
            this.OjMaxCod.Name = "OjMaxCod";
            this.OjMaxCod.Size = new System.Drawing.Size(50, 27);
            this.OjMaxCod.TabIndex = 0;
            this.OjMaxCod.Text = "最大";
            this.OjMaxCod.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblTSuiryoCod
            // 
            this.lblTSuiryoCod.AutoSize = true;
            this.lblTSuiryoCod.BackColor = System.Drawing.SystemColors.Control;
            this.tblCod.SetColumnSpan(this.lblTSuiryoCod, 5);
            this.lblTSuiryoCod.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblTSuiryoCod.Location = new System.Drawing.Point(447, 1);
            this.lblTSuiryoCod.Margin = new System.Windows.Forms.Padding(0);
            this.lblTSuiryoCod.Name = "lblTSuiryoCod";
            this.lblTSuiryoCod.Size = new System.Drawing.Size(254, 51);
            this.lblTSuiryoCod.TabIndex = 0;
            this.lblTSuiryoCod.Text = "水量\r\n（m³/日）";
            this.lblTSuiryoCod.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblTSuiryoAveCod
            // 
            this.lblTSuiryoAveCod.AutoSize = true;
            this.lblTSuiryoAveCod.BackColor = System.Drawing.SystemColors.Control;
            this.lblTSuiryoAveCod.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblTSuiryoAveCod.Location = new System.Drawing.Point(447, 53);
            this.lblTSuiryoAveCod.Margin = new System.Windows.Forms.Padding(0);
            this.lblTSuiryoAveCod.Name = "lblTSuiryoAveCod";
            this.lblTSuiryoAveCod.Size = new System.Drawing.Size(50, 27);
            this.lblTSuiryoAveCod.TabIndex = 0;
            this.lblTSuiryoAveCod.Text = "通常";
            this.lblTSuiryoAveCod.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblTSuiryoMaxCod
            // 
            this.lblTSuiryoMaxCod.AutoSize = true;
            this.lblTSuiryoMaxCod.BackColor = System.Drawing.SystemColors.Control;
            this.lblTSuiryoMaxCod.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblTSuiryoMaxCod.Location = new System.Drawing.Point(498, 53);
            this.lblTSuiryoMaxCod.Margin = new System.Windows.Forms.Padding(0);
            this.lblTSuiryoMaxCod.Name = "lblTSuiryoMaxCod";
            this.lblTSuiryoMaxCod.Size = new System.Drawing.Size(50, 27);
            this.lblTSuiryoMaxCod.TabIndex = 0;
            this.lblTSuiryoMaxCod.Text = "最大";
            this.lblTSuiryoMaxCod.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblTSuiryoQco
            // 
            this.lblTSuiryoQco.AutoSize = true;
            this.lblTSuiryoQco.BackColor = System.Drawing.SystemColors.Control;
            this.lblTSuiryoQco.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblTSuiryoQco.Location = new System.Drawing.Point(549, 53);
            this.lblTSuiryoQco.Margin = new System.Windows.Forms.Padding(0);
            this.lblTSuiryoQco.Name = "lblTSuiryoQco";
            this.lblTSuiryoQco.Size = new System.Drawing.Size(50, 27);
            this.lblTSuiryoQco.TabIndex = 0;
            this.lblTSuiryoQco.Text = "Qco";
            this.lblTSuiryoQco.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblTSuiryoQci
            // 
            this.lblTSuiryoQci.AutoSize = true;
            this.lblTSuiryoQci.BackColor = System.Drawing.SystemColors.Control;
            this.lblTSuiryoQci.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblTSuiryoQci.Location = new System.Drawing.Point(600, 53);
            this.lblTSuiryoQci.Margin = new System.Windows.Forms.Padding(0);
            this.lblTSuiryoQci.Name = "lblTSuiryoQci";
            this.lblTSuiryoQci.Size = new System.Drawing.Size(50, 27);
            this.lblTSuiryoQci.TabIndex = 0;
            this.lblTSuiryoQci.Text = "Qci";
            this.lblTSuiryoQci.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblTSuiryoQcj
            // 
            this.lblTSuiryoQcj.AutoSize = true;
            this.lblTSuiryoQcj.BackColor = System.Drawing.SystemColors.Control;
            this.lblTSuiryoQcj.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblTSuiryoQcj.Location = new System.Drawing.Point(651, 53);
            this.lblTSuiryoQcj.Margin = new System.Windows.Forms.Padding(0);
            this.lblTSuiryoQcj.Name = "lblTSuiryoQcj";
            this.lblTSuiryoQcj.Size = new System.Drawing.Size(50, 27);
            this.lblTSuiryoQcj.TabIndex = 0;
            this.lblTSuiryoQcj.Text = "Qcj";
            this.lblTSuiryoQcj.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblOdakuFukaryoCod
            // 
            this.lblOdakuFukaryoCod.AutoSize = true;
            this.lblOdakuFukaryoCod.BackColor = System.Drawing.SystemColors.Control;
            this.tblCod.SetColumnSpan(this.lblOdakuFukaryoCod, 2);
            this.lblOdakuFukaryoCod.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblOdakuFukaryoCod.Location = new System.Drawing.Point(702, 1);
            this.lblOdakuFukaryoCod.Margin = new System.Windows.Forms.Padding(0);
            this.lblOdakuFukaryoCod.Name = "lblOdakuFukaryoCod";
            this.lblOdakuFukaryoCod.Size = new System.Drawing.Size(101, 51);
            this.lblOdakuFukaryoCod.TabIndex = 0;
            this.lblOdakuFukaryoCod.Text = "汚濁負荷量\r\n（㎏/日）";
            this.lblOdakuFukaryoCod.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblOdakuFukaryoAveCod
            // 
            this.lblOdakuFukaryoAveCod.AutoSize = true;
            this.lblOdakuFukaryoAveCod.BackColor = System.Drawing.SystemColors.Control;
            this.lblOdakuFukaryoAveCod.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblOdakuFukaryoAveCod.Location = new System.Drawing.Point(702, 53);
            this.lblOdakuFukaryoAveCod.Margin = new System.Windows.Forms.Padding(0);
            this.lblOdakuFukaryoAveCod.Name = "lblOdakuFukaryoAveCod";
            this.lblOdakuFukaryoAveCod.Size = new System.Drawing.Size(50, 27);
            this.lblOdakuFukaryoAveCod.TabIndex = 0;
            this.lblOdakuFukaryoAveCod.Text = "通常";
            this.lblOdakuFukaryoAveCod.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblOdakuFukaryoMaxCod
            // 
            this.lblOdakuFukaryoMaxCod.AutoSize = true;
            this.lblOdakuFukaryoMaxCod.BackColor = System.Drawing.SystemColors.Control;
            this.lblOdakuFukaryoMaxCod.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblOdakuFukaryoMaxCod.Location = new System.Drawing.Point(753, 53);
            this.lblOdakuFukaryoMaxCod.Margin = new System.Windows.Forms.Padding(0);
            this.lblOdakuFukaryoMaxCod.Name = "lblOdakuFukaryoMaxCod";
            this.lblOdakuFukaryoMaxCod.Size = new System.Drawing.Size(50, 27);
            this.lblOdakuFukaryoMaxCod.TabIndex = 0;
            this.lblOdakuFukaryoMaxCod.Text = "最大";
            this.lblOdakuFukaryoMaxCod.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblKijyunTiCod
            // 
            this.lblKijyunTiCod.AutoSize = true;
            this.lblKijyunTiCod.BackColor = System.Drawing.SystemColors.Control;
            this.lblKijyunTiCod.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblKijyunTiCod.Location = new System.Drawing.Point(804, 1);
            this.lblKijyunTiCod.Margin = new System.Windows.Forms.Padding(0);
            this.lblKijyunTiCod.Name = "lblKijyunTiCod";
            this.lblKijyunTiCod.Size = new System.Drawing.Size(100, 51);
            this.lblKijyunTiCod.TabIndex = 0;
            this.lblKijyunTiCod.Text = "基準値\r\n（㎏/日）";
            this.lblKijyunTiCod.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblLc
            // 
            this.lblLc.AutoSize = true;
            this.lblLc.BackColor = System.Drawing.SystemColors.Control;
            this.lblLc.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblLc.Location = new System.Drawing.Point(804, 53);
            this.lblLc.Margin = new System.Windows.Forms.Padding(0);
            this.lblLc.Name = "lblLc";
            this.lblLc.Size = new System.Drawing.Size(100, 27);
            this.lblLc.TabIndex = 0;
            this.lblLc.Text = "Lc";
            this.lblLc.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblScrolBerCod
            // 
            this.lblScrolBerCod.BackColor = System.Drawing.SystemColors.Control;
            this.lblScrolBerCod.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblScrolBerCod.Location = new System.Drawing.Point(905, 1);
            this.lblScrolBerCod.Margin = new System.Windows.Forms.Padding(0);
            this.lblScrolBerCod.Name = "lblScrolBerCod";
            this.tblCod.SetRowSpan(this.lblScrolBerCod, 2);
            this.lblScrolBerCod.Size = new System.Drawing.Size(16, 79);
            this.lblScrolBerCod.TabIndex = 0;
            this.lblScrolBerCod.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // dgvCod
            // 
            this.dgvCod.AllowUserToAddRows = false;
            this.dgvCod.AllowUserToDeleteRows = false;
            this.dgvCod.AllowUserToResizeColumns = false;
            this.dgvCod.AllowUserToResizeRows = false;
            this.dgvCod.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvCod.ColumnHeadersVisible = false;
            this.dgvCod.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column3,
            this.Column4,
            this.Column5,
            this.Column6,
            this.Column7,
            this.Column8,
            this.Column9,
            this.Column10,
            this.Column11,
            this.Column12,
            this.Column13,
            this.Column14});
            this.dgvCod.Location = new System.Drawing.Point(15, 389);
            this.dgvCod.MultiSelect = false;
            this.dgvCod.Name = "dgvCod";
            this.dgvCod.ReadOnly = true;
            this.dgvCod.RowHeadersVisible = false;
            this.dgvCod.RowTemplate.Height = 21;
            this.dgvCod.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvCod.Size = new System.Drawing.Size(922, 87);
            this.dgvCod.TabIndex = 5;
            // 
            // Column1
            // 
            this.Column1.HeaderText = "業種";
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            this.Column1.Width = 190;
            // 
            // Column2
            // 
            this.Column2.HeaderText = "Cco";
            this.Column2.Name = "Column2";
            this.Column2.ReadOnly = true;
            this.Column2.Width = 51;
            // 
            // Column3
            // 
            this.Column3.HeaderText = "Cci";
            this.Column3.Name = "Column3";
            this.Column3.ReadOnly = true;
            this.Column3.Width = 51;
            // 
            // Column4
            // 
            this.Column4.HeaderText = "Ccj";
            this.Column4.Name = "Column4";
            this.Column4.ReadOnly = true;
            this.Column4.Width = 51;
            // 
            // Column5
            // 
            this.Column5.HeaderText = "通常";
            this.Column5.Name = "Column5";
            this.Column5.ReadOnly = true;
            this.Column5.Width = 51;
            // 
            // Column6
            // 
            this.Column6.HeaderText = "最大";
            this.Column6.Name = "Column6";
            this.Column6.ReadOnly = true;
            this.Column6.Width = 51;
            // 
            // Column7
            // 
            this.Column7.HeaderText = "通常";
            this.Column7.Name = "Column7";
            this.Column7.ReadOnly = true;
            this.Column7.Width = 51;
            // 
            // Column8
            // 
            this.Column8.HeaderText = "最大";
            this.Column8.Name = "Column8";
            this.Column8.ReadOnly = true;
            this.Column8.Width = 51;
            // 
            // Column9
            // 
            this.Column9.HeaderText = "Qco";
            this.Column9.Name = "Column9";
            this.Column9.ReadOnly = true;
            this.Column9.Width = 51;
            // 
            // Column10
            // 
            this.Column10.HeaderText = "Qci";
            this.Column10.Name = "Column10";
            this.Column10.ReadOnly = true;
            this.Column10.Width = 51;
            // 
            // Column11
            // 
            this.Column11.HeaderText = "Qcj";
            this.Column11.Name = "Column11";
            this.Column11.ReadOnly = true;
            this.Column11.Width = 51;
            // 
            // Column12
            // 
            this.Column12.HeaderText = "通常";
            this.Column12.Name = "Column12";
            this.Column12.ReadOnly = true;
            this.Column12.Width = 51;
            // 
            // Column13
            // 
            this.Column13.HeaderText = "最大";
            this.Column13.Name = "Column13";
            this.Column13.ReadOnly = true;
            this.Column13.Width = 51;
            // 
            // Column14
            // 
            this.Column14.HeaderText = "Ln";
            this.Column14.Name = "Column14";
            this.Column14.ReadOnly = true;
            // 
            // lblCod
            // 
            this.lblCod.AutoSize = true;
            this.lblCod.Font = new System.Drawing.Font("メイリオ", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblCod.Location = new System.Drawing.Point(14, 282);
            this.lblCod.Name = "lblCod";
            this.lblCod.Size = new System.Drawing.Size(113, 20);
            this.lblCod.TabIndex = 62;
            this.lblCod.Text = "化学的酸素要求量";
            // 
            // btnDeleteMeisaiCod
            // 
            this.btnDeleteMeisaiCod.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnDeleteMeisaiCod.Location = new System.Drawing.Point(837, 491);
            this.btnDeleteMeisaiCod.Name = "btnDeleteMeisaiCod";
            this.btnDeleteMeisaiCod.Size = new System.Drawing.Size(100, 30);
            this.btnDeleteMeisaiCod.TabIndex = 7;
            this.btnDeleteMeisaiCod.Text = "明細削除";
            this.btnDeleteMeisaiCod.UseVisualStyleBackColor = true;
            // 
            // btnAddMeisaiCod
            // 
            this.btnAddMeisaiCod.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnAddMeisaiCod.Location = new System.Drawing.Point(731, 491);
            this.btnAddMeisaiCod.Name = "btnAddMeisaiCod";
            this.btnAddMeisaiCod.Size = new System.Drawing.Size(100, 30);
            this.btnAddMeisaiCod.TabIndex = 6;
            this.btnAddMeisaiCod.Text = "明細追加";
            this.btnAddMeisaiCod.UseVisualStyleBackColor = true;
            // 
            // btnCalcSoryoKise
            // 
            this.btnCalcSoryoKise.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnCalcSoryoKise.Location = new System.Drawing.Point(846, 56);
            this.btnCalcSoryoKise.Name = "btnCalcSoryoKise";
            this.btnCalcSoryoKise.Size = new System.Drawing.Size(100, 30);
            this.btnCalcSoryoKise.TabIndex = 4;
            this.btnCalcSoryoKise.Text = "計算";
            this.btnCalcSoryoKise.UseVisualStyleBackColor = true;
            // 
            // btnCancelSoryoKise
            // 
            this.btnCancelSoryoKise.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnCancelSoryoKise.Location = new System.Drawing.Point(846, 20);
            this.btnCancelSoryoKise.Name = "btnCancelSoryoKise";
            this.btnCancelSoryoKise.Size = new System.Drawing.Size(100, 30);
            this.btnCancelSoryoKise.TabIndex = 2;
            this.btnCancelSoryoKise.Text = "キャンセル";
            this.btnCancelSoryoKise.UseVisualStyleBackColor = true;
            // 
            // btnRegistSoryoKise
            // 
            this.btnRegistSoryoKise.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnRegistSoryoKise.Location = new System.Drawing.Point(740, 20);
            this.btnRegistSoryoKise.Name = "btnRegistSoryoKise";
            this.btnRegistSoryoKise.Size = new System.Drawing.Size(100, 30);
            this.btnRegistSoryoKise.TabIndex = 1;
            this.btnRegistSoryoKise.Text = "登録";
            this.btnRegistSoryoKise.UseVisualStyleBackColor = true;
            // 
            // lblSoryoKise
            // 
            this.lblSoryoKise.AutoSize = true;
            this.lblSoryoKise.Font = new System.Drawing.Font("メイリオ", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblSoryoKise.Location = new System.Drawing.Point(415, 15);
            this.lblSoryoKise.Name = "lblSoryoKise";
            this.lblSoryoKise.Size = new System.Drawing.Size(140, 31);
            this.lblSoryoKise.TabIndex = 46;
            this.lblSoryoKise.Text = "総量規制情報";
            // 
            // tblSoryoKise
            // 
            this.tblSoryoKise.AutoSize = true;
            this.tblSoryoKise.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.tblSoryoKise.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tblSoryoKise.ColumnCount = 5;
            this.tblSoryoKise.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 245F));
            this.tblSoryoKise.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 96F));
            this.tblSoryoKise.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 96F));
            this.tblSoryoKise.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 96F));
            this.tblSoryoKise.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 96F));
            this.tblSoryoKise.Controls.Add(this.lblSpaceSoryoKise, 0, 0);
            this.tblSoryoKise.Controls.Add(this.lblCodSoryoKise, 1, 0);
            this.tblSoryoKise.Controls.Add(this.lblTdkdFukaryoSoryoKise, 0, 2);
            this.tblSoryoKise.Controls.Add(this.lblTdkdhsAveSoryoKise, 0, 3);
            this.tblSoryoKise.Controls.Add(this.lblTdkdhsMaxSoryoKise, 0, 4);
            this.tblSoryoKise.Controls.Add(this.lblBikoSoryoKise, 0, 5);
            this.tblSoryoKise.Controls.Add(this.lblTnSoryoKise, 2, 0);
            this.tblSoryoKise.Controls.Add(this.lblTpSoryoKise, 3, 0);
            this.tblSoryoKise.Controls.Add(this.lblSonotaSoryoKise, 4, 0);
            this.tblSoryoKise.Controls.Add(this.lblKyoyoFukaryoSoryoKise, 0, 1);
            this.tblSoryoKise.Controls.Add(this.txtCodKyoyoFukaryoSoryoKise, 1, 1);
            this.tblSoryoKise.Controls.Add(this.textBtxtTnKyoyoFukaryoSoryoKiseox15, 2, 1);
            this.tblSoryoKise.Controls.Add(this.txtTpKyoyoFukaryoSoryoKise, 3, 1);
            this.tblSoryoKise.Controls.Add(this.txtSonotaKyoyoFukarySoryoKise, 4, 1);
            this.tblSoryoKise.Controls.Add(this.txtCodTdkdFukaryoSoryoKise, 1, 2);
            this.tblSoryoKise.Controls.Add(this.txtTnTdkdFukaryoSoryoKise, 2, 2);
            this.tblSoryoKise.Controls.Add(this.txtTpTdkdFukaryoSoryoKise, 3, 2);
            this.tblSoryoKise.Controls.Add(this.txtSonotaTdkdFukaryoSoryoKise, 4, 2);
            this.tblSoryoKise.Controls.Add(this.txtTdkdhsAveSoryoKise, 1, 3);
            this.tblSoryoKise.Controls.Add(this.txtTdkdhsMaxSoryoKise, 1, 4);
            this.tblSoryoKise.Controls.Add(this.txtBikoSoryoKise, 1, 5);
            this.tblSoryoKise.Location = new System.Drawing.Point(168, 60);
            this.tblSoryoKise.Name = "tblSoryoKise";
            this.tblSoryoKise.RowCount = 6;
            this.tblSoryoKise.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tblSoryoKise.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tblSoryoKise.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tblSoryoKise.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tblSoryoKise.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tblSoryoKise.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 60F));
            this.tblSoryoKise.Size = new System.Drawing.Size(635, 217);
            this.tblSoryoKise.TabIndex = 3;
            // 
            // lblSpaceSoryoKise
            // 
            this.lblSpaceSoryoKise.BackColor = System.Drawing.SystemColors.Control;
            this.lblSpaceSoryoKise.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblSpaceSoryoKise.Location = new System.Drawing.Point(1, 1);
            this.lblSpaceSoryoKise.Margin = new System.Windows.Forms.Padding(0);
            this.lblSpaceSoryoKise.Name = "lblSpaceSoryoKise";
            this.lblSpaceSoryoKise.Size = new System.Drawing.Size(245, 30);
            this.lblSpaceSoryoKise.TabIndex = 4;
            this.lblSpaceSoryoKise.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblCodSoryoKise
            // 
            this.lblCodSoryoKise.AutoSize = true;
            this.lblCodSoryoKise.BackColor = System.Drawing.SystemColors.Control;
            this.lblCodSoryoKise.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblCodSoryoKise.Location = new System.Drawing.Point(247, 1);
            this.lblCodSoryoKise.Margin = new System.Windows.Forms.Padding(0);
            this.lblCodSoryoKise.Name = "lblCodSoryoKise";
            this.lblCodSoryoKise.Size = new System.Drawing.Size(96, 30);
            this.lblCodSoryoKise.TabIndex = 0;
            this.lblCodSoryoKise.Text = "COD";
            this.lblCodSoryoKise.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblTdkdFukaryoSoryoKise
            // 
            this.lblTdkdFukaryoSoryoKise.AutoSize = true;
            this.lblTdkdFukaryoSoryoKise.BackColor = System.Drawing.SystemColors.Control;
            this.lblTdkdFukaryoSoryoKise.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblTdkdFukaryoSoryoKise.Location = new System.Drawing.Point(1, 63);
            this.lblTdkdFukaryoSoryoKise.Margin = new System.Windows.Forms.Padding(0);
            this.lblTdkdFukaryoSoryoKise.Name = "lblTdkdFukaryoSoryoKise";
            this.lblTdkdFukaryoSoryoKise.Size = new System.Drawing.Size(245, 30);
            this.lblTdkdFukaryoSoryoKise.TabIndex = 0;
            this.lblTdkdFukaryoSoryoKise.Text = "届出等汚濁負荷量　　（㎏/日）";
            this.lblTdkdFukaryoSoryoKise.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblTdkdhsAveSoryoKise
            // 
            this.lblTdkdhsAveSoryoKise.AutoSize = true;
            this.lblTdkdhsAveSoryoKise.BackColor = System.Drawing.SystemColors.Control;
            this.lblTdkdhsAveSoryoKise.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblTdkdhsAveSoryoKise.Location = new System.Drawing.Point(1, 94);
            this.lblTdkdhsAveSoryoKise.Margin = new System.Windows.Forms.Padding(0);
            this.lblTdkdhsAveSoryoKise.Name = "lblTdkdhsAveSoryoKise";
            this.lblTdkdhsAveSoryoKise.Size = new System.Drawing.Size(245, 30);
            this.lblTdkdhsAveSoryoKise.TabIndex = 0;
            this.lblTdkdhsAveSoryoKise.Text = "総排水量（通常）  　（m³/日）";
            this.lblTdkdhsAveSoryoKise.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblTdkdhsMaxSoryoKise
            // 
            this.lblTdkdhsMaxSoryoKise.AutoSize = true;
            this.lblTdkdhsMaxSoryoKise.BackColor = System.Drawing.SystemColors.Control;
            this.lblTdkdhsMaxSoryoKise.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblTdkdhsMaxSoryoKise.Location = new System.Drawing.Point(1, 125);
            this.lblTdkdhsMaxSoryoKise.Margin = new System.Windows.Forms.Padding(0);
            this.lblTdkdhsMaxSoryoKise.Name = "lblTdkdhsMaxSoryoKise";
            this.lblTdkdhsMaxSoryoKise.Size = new System.Drawing.Size(245, 30);
            this.lblTdkdhsMaxSoryoKise.TabIndex = 0;
            this.lblTdkdhsMaxSoryoKise.Text = "総排水量（最大）　  （m³/日）";
            this.lblTdkdhsMaxSoryoKise.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblBikoSoryoKise
            // 
            this.lblBikoSoryoKise.AutoSize = true;
            this.lblBikoSoryoKise.BackColor = System.Drawing.SystemColors.Control;
            this.lblBikoSoryoKise.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblBikoSoryoKise.Location = new System.Drawing.Point(1, 156);
            this.lblBikoSoryoKise.Margin = new System.Windows.Forms.Padding(0);
            this.lblBikoSoryoKise.Name = "lblBikoSoryoKise";
            this.lblBikoSoryoKise.Size = new System.Drawing.Size(245, 60);
            this.lblBikoSoryoKise.TabIndex = 0;
            this.lblBikoSoryoKise.Text = "備考";
            // 
            // lblTnSoryoKise
            // 
            this.lblTnSoryoKise.AutoSize = true;
            this.lblTnSoryoKise.BackColor = System.Drawing.SystemColors.Control;
            this.lblTnSoryoKise.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblTnSoryoKise.Location = new System.Drawing.Point(344, 1);
            this.lblTnSoryoKise.Margin = new System.Windows.Forms.Padding(0);
            this.lblTnSoryoKise.Name = "lblTnSoryoKise";
            this.lblTnSoryoKise.Size = new System.Drawing.Size(96, 30);
            this.lblTnSoryoKise.TabIndex = 0;
            this.lblTnSoryoKise.Text = "全窒素";
            this.lblTnSoryoKise.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblTpSoryoKise
            // 
            this.lblTpSoryoKise.AutoSize = true;
            this.lblTpSoryoKise.BackColor = System.Drawing.SystemColors.Control;
            this.lblTpSoryoKise.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblTpSoryoKise.Location = new System.Drawing.Point(441, 1);
            this.lblTpSoryoKise.Margin = new System.Windows.Forms.Padding(0);
            this.lblTpSoryoKise.Name = "lblTpSoryoKise";
            this.lblTpSoryoKise.Size = new System.Drawing.Size(96, 30);
            this.lblTpSoryoKise.TabIndex = 0;
            this.lblTpSoryoKise.Text = "全りん";
            this.lblTpSoryoKise.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblSonotaSoryoKise
            // 
            this.lblSonotaSoryoKise.AutoSize = true;
            this.lblSonotaSoryoKise.BackColor = System.Drawing.SystemColors.Control;
            this.lblSonotaSoryoKise.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblSonotaSoryoKise.Location = new System.Drawing.Point(538, 1);
            this.lblSonotaSoryoKise.Margin = new System.Windows.Forms.Padding(0);
            this.lblSonotaSoryoKise.Name = "lblSonotaSoryoKise";
            this.lblSonotaSoryoKise.Size = new System.Drawing.Size(96, 30);
            this.lblSonotaSoryoKise.TabIndex = 0;
            this.lblSonotaSoryoKise.Text = "その他";
            this.lblSonotaSoryoKise.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblKyoyoFukaryoSoryoKise
            // 
            this.lblKyoyoFukaryoSoryoKise.BackColor = System.Drawing.SystemColors.Control;
            this.lblKyoyoFukaryoSoryoKise.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblKyoyoFukaryoSoryoKise.Location = new System.Drawing.Point(1, 32);
            this.lblKyoyoFukaryoSoryoKise.Margin = new System.Windows.Forms.Padding(0);
            this.lblKyoyoFukaryoSoryoKise.Name = "lblKyoyoFukaryoSoryoKise";
            this.lblKyoyoFukaryoSoryoKise.Size = new System.Drawing.Size(245, 30);
            this.lblKyoyoFukaryoSoryoKise.TabIndex = 0;
            this.lblKyoyoFukaryoSoryoKise.Text = "許容汚濁負荷量　　　（㎏/日）";
            this.lblKyoyoFukaryoSoryoKise.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtCodKyoyoFukaryoSoryoKise
            // 
            this.txtCodKyoyoFukaryoSoryoKise.BackColor = System.Drawing.SystemColors.Window;
            this.txtCodKyoyoFukaryoSoryoKise.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtCodKyoyoFukaryoSoryoKise.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtCodKyoyoFukaryoSoryoKise.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.txtCodKyoyoFukaryoSoryoKise.Location = new System.Drawing.Point(247, 32);
            this.txtCodKyoyoFukaryoSoryoKise.Margin = new System.Windows.Forms.Padding(0);
            this.txtCodKyoyoFukaryoSoryoKise.MaxLength = 11;
            this.txtCodKyoyoFukaryoSoryoKise.Multiline = true;
            this.txtCodKyoyoFukaryoSoryoKise.Name = "txtCodKyoyoFukaryoSoryoKise";
            this.txtCodKyoyoFukaryoSoryoKise.Size = new System.Drawing.Size(96, 30);
            this.txtCodKyoyoFukaryoSoryoKise.TabIndex = 1;
            // 
            // textBtxtTnKyoyoFukaryoSoryoKiseox15
            // 
            this.textBtxtTnKyoyoFukaryoSoryoKiseox15.BackColor = System.Drawing.SystemColors.Window;
            this.textBtxtTnKyoyoFukaryoSoryoKiseox15.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBtxtTnKyoyoFukaryoSoryoKiseox15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBtxtTnKyoyoFukaryoSoryoKiseox15.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.textBtxtTnKyoyoFukaryoSoryoKiseox15.Location = new System.Drawing.Point(344, 32);
            this.textBtxtTnKyoyoFukaryoSoryoKiseox15.Margin = new System.Windows.Forms.Padding(0);
            this.textBtxtTnKyoyoFukaryoSoryoKiseox15.MaxLength = 11;
            this.textBtxtTnKyoyoFukaryoSoryoKiseox15.Multiline = true;
            this.textBtxtTnKyoyoFukaryoSoryoKiseox15.Name = "textBtxtTnKyoyoFukaryoSoryoKiseox15";
            this.textBtxtTnKyoyoFukaryoSoryoKiseox15.Size = new System.Drawing.Size(96, 30);
            this.textBtxtTnKyoyoFukaryoSoryoKiseox15.TabIndex = 2;
            // 
            // txtTpKyoyoFukaryoSoryoKise
            // 
            this.txtTpKyoyoFukaryoSoryoKise.BackColor = System.Drawing.SystemColors.Window;
            this.txtTpKyoyoFukaryoSoryoKise.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtTpKyoyoFukaryoSoryoKise.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtTpKyoyoFukaryoSoryoKise.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.txtTpKyoyoFukaryoSoryoKise.Location = new System.Drawing.Point(441, 32);
            this.txtTpKyoyoFukaryoSoryoKise.Margin = new System.Windows.Forms.Padding(0);
            this.txtTpKyoyoFukaryoSoryoKise.MaxLength = 11;
            this.txtTpKyoyoFukaryoSoryoKise.Multiline = true;
            this.txtTpKyoyoFukaryoSoryoKise.Name = "txtTpKyoyoFukaryoSoryoKise";
            this.txtTpKyoyoFukaryoSoryoKise.Size = new System.Drawing.Size(96, 30);
            this.txtTpKyoyoFukaryoSoryoKise.TabIndex = 3;
            // 
            // txtSonotaKyoyoFukarySoryoKise
            // 
            this.txtSonotaKyoyoFukarySoryoKise.BackColor = System.Drawing.SystemColors.Window;
            this.txtSonotaKyoyoFukarySoryoKise.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtSonotaKyoyoFukarySoryoKise.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtSonotaKyoyoFukarySoryoKise.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.txtSonotaKyoyoFukarySoryoKise.Location = new System.Drawing.Point(538, 32);
            this.txtSonotaKyoyoFukarySoryoKise.Margin = new System.Windows.Forms.Padding(0);
            this.txtSonotaKyoyoFukarySoryoKise.MaxLength = 11;
            this.txtSonotaKyoyoFukarySoryoKise.Multiline = true;
            this.txtSonotaKyoyoFukarySoryoKise.Name = "txtSonotaKyoyoFukarySoryoKise";
            this.txtSonotaKyoyoFukarySoryoKise.Size = new System.Drawing.Size(96, 30);
            this.txtSonotaKyoyoFukarySoryoKise.TabIndex = 4;
            // 
            // txtCodTdkdFukaryoSoryoKise
            // 
            this.txtCodTdkdFukaryoSoryoKise.BackColor = System.Drawing.SystemColors.Window;
            this.txtCodTdkdFukaryoSoryoKise.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtCodTdkdFukaryoSoryoKise.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtCodTdkdFukaryoSoryoKise.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.txtCodTdkdFukaryoSoryoKise.Location = new System.Drawing.Point(247, 63);
            this.txtCodTdkdFukaryoSoryoKise.Margin = new System.Windows.Forms.Padding(0);
            this.txtCodTdkdFukaryoSoryoKise.MaxLength = 11;
            this.txtCodTdkdFukaryoSoryoKise.Multiline = true;
            this.txtCodTdkdFukaryoSoryoKise.Name = "txtCodTdkdFukaryoSoryoKise";
            this.txtCodTdkdFukaryoSoryoKise.Size = new System.Drawing.Size(96, 30);
            this.txtCodTdkdFukaryoSoryoKise.TabIndex = 5;
            // 
            // txtTnTdkdFukaryoSoryoKise
            // 
            this.txtTnTdkdFukaryoSoryoKise.BackColor = System.Drawing.SystemColors.Window;
            this.txtTnTdkdFukaryoSoryoKise.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtTnTdkdFukaryoSoryoKise.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtTnTdkdFukaryoSoryoKise.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.txtTnTdkdFukaryoSoryoKise.Location = new System.Drawing.Point(344, 63);
            this.txtTnTdkdFukaryoSoryoKise.Margin = new System.Windows.Forms.Padding(0);
            this.txtTnTdkdFukaryoSoryoKise.MaxLength = 11;
            this.txtTnTdkdFukaryoSoryoKise.Multiline = true;
            this.txtTnTdkdFukaryoSoryoKise.Name = "txtTnTdkdFukaryoSoryoKise";
            this.txtTnTdkdFukaryoSoryoKise.Size = new System.Drawing.Size(96, 30);
            this.txtTnTdkdFukaryoSoryoKise.TabIndex = 6;
            // 
            // txtTpTdkdFukaryoSoryoKise
            // 
            this.txtTpTdkdFukaryoSoryoKise.BackColor = System.Drawing.SystemColors.Window;
            this.txtTpTdkdFukaryoSoryoKise.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtTpTdkdFukaryoSoryoKise.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtTpTdkdFukaryoSoryoKise.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.txtTpTdkdFukaryoSoryoKise.Location = new System.Drawing.Point(441, 63);
            this.txtTpTdkdFukaryoSoryoKise.Margin = new System.Windows.Forms.Padding(0);
            this.txtTpTdkdFukaryoSoryoKise.MaxLength = 11;
            this.txtTpTdkdFukaryoSoryoKise.Multiline = true;
            this.txtTpTdkdFukaryoSoryoKise.Name = "txtTpTdkdFukaryoSoryoKise";
            this.txtTpTdkdFukaryoSoryoKise.Size = new System.Drawing.Size(96, 30);
            this.txtTpTdkdFukaryoSoryoKise.TabIndex = 7;
            // 
            // txtSonotaTdkdFukaryoSoryoKise
            // 
            this.txtSonotaTdkdFukaryoSoryoKise.BackColor = System.Drawing.SystemColors.Window;
            this.txtSonotaTdkdFukaryoSoryoKise.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtSonotaTdkdFukaryoSoryoKise.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtSonotaTdkdFukaryoSoryoKise.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.txtSonotaTdkdFukaryoSoryoKise.Location = new System.Drawing.Point(538, 63);
            this.txtSonotaTdkdFukaryoSoryoKise.Margin = new System.Windows.Forms.Padding(0);
            this.txtSonotaTdkdFukaryoSoryoKise.MaxLength = 11;
            this.txtSonotaTdkdFukaryoSoryoKise.Multiline = true;
            this.txtSonotaTdkdFukaryoSoryoKise.Name = "txtSonotaTdkdFukaryoSoryoKise";
            this.txtSonotaTdkdFukaryoSoryoKise.Size = new System.Drawing.Size(96, 30);
            this.txtSonotaTdkdFukaryoSoryoKise.TabIndex = 8;
            // 
            // txtTdkdhsAveSoryoKise
            // 
            this.txtTdkdhsAveSoryoKise.BackColor = System.Drawing.SystemColors.Window;
            this.txtTdkdhsAveSoryoKise.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tblSoryoKise.SetColumnSpan(this.txtTdkdhsAveSoryoKise, 4);
            this.txtTdkdhsAveSoryoKise.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtTdkdhsAveSoryoKise.Location = new System.Drawing.Point(247, 94);
            this.txtTdkdhsAveSoryoKise.Margin = new System.Windows.Forms.Padding(0);
            this.txtTdkdhsAveSoryoKise.Multiline = true;
            this.txtTdkdhsAveSoryoKise.Name = "txtTdkdhsAveSoryoKise";
            this.txtTdkdhsAveSoryoKise.Size = new System.Drawing.Size(387, 30);
            this.txtTdkdhsAveSoryoKise.TabIndex = 9;
            // 
            // txtTdkdhsMaxSoryoKise
            // 
            this.txtTdkdhsMaxSoryoKise.BackColor = System.Drawing.SystemColors.Window;
            this.txtTdkdhsMaxSoryoKise.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tblSoryoKise.SetColumnSpan(this.txtTdkdhsMaxSoryoKise, 4);
            this.txtTdkdhsMaxSoryoKise.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtTdkdhsMaxSoryoKise.Location = new System.Drawing.Point(247, 125);
            this.txtTdkdhsMaxSoryoKise.Margin = new System.Windows.Forms.Padding(0);
            this.txtTdkdhsMaxSoryoKise.Multiline = true;
            this.txtTdkdhsMaxSoryoKise.Name = "txtTdkdhsMaxSoryoKise";
            this.txtTdkdhsMaxSoryoKise.Size = new System.Drawing.Size(387, 30);
            this.txtTdkdhsMaxSoryoKise.TabIndex = 10;
            // 
            // txtBikoSoryoKise
            // 
            this.txtBikoSoryoKise.BackColor = System.Drawing.SystemColors.Window;
            this.txtBikoSoryoKise.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tblSoryoKise.SetColumnSpan(this.txtBikoSoryoKise, 4);
            this.txtBikoSoryoKise.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtBikoSoryoKise.ImeMode = System.Windows.Forms.ImeMode.Hiragana;
            this.txtBikoSoryoKise.Location = new System.Drawing.Point(247, 156);
            this.txtBikoSoryoKise.Margin = new System.Windows.Forms.Padding(0);
            this.txtBikoSoryoKise.MaxLength = 100;
            this.txtBikoSoryoKise.Multiline = true;
            this.txtBikoSoryoKise.Name = "txtBikoSoryoKise";
            this.txtBikoSoryoKise.Size = new System.Drawing.Size(387, 60);
            this.txtBikoSoryoKise.TabIndex = 11;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(0, 0);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 0;
            // 
            // label17
            // 
            this.label17.Location = new System.Drawing.Point(0, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(100, 23);
            this.label17.TabIndex = 0;
            // 
            // label16
            // 
            this.label16.Location = new System.Drawing.Point(0, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(100, 23);
            this.label16.TabIndex = 0;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(0, 0);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(100, 19);
            this.textBox3.TabIndex = 0;
            // 
            // label15
            // 
            this.label15.Location = new System.Drawing.Point(0, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(100, 23);
            this.label15.TabIndex = 0;
            // 
            // label14
            // 
            this.label14.Location = new System.Drawing.Point(0, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(100, 23);
            this.label14.TabIndex = 0;
            // 
            // label13
            // 
            this.label13.Location = new System.Drawing.Point(0, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(100, 23);
            this.label13.TabIndex = 0;
            // 
            // label19
            // 
            this.label19.Location = new System.Drawing.Point(0, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(100, 23);
            this.label19.TabIndex = 0;
            // 
            // label12
            // 
            this.label12.Location = new System.Drawing.Point(0, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(100, 23);
            this.label12.TabIndex = 0;
            // 
            // label11
            // 
            this.label11.Location = new System.Drawing.Point(0, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(100, 23);
            this.label11.TabIndex = 0;
            // 
            // label10
            // 
            this.label10.Location = new System.Drawing.Point(0, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(100, 23);
            this.label10.TabIndex = 0;
            // 
            // checkBox10
            // 
            this.checkBox10.Location = new System.Drawing.Point(0, 0);
            this.checkBox10.Name = "checkBox10";
            this.checkBox10.Size = new System.Drawing.Size(104, 24);
            this.checkBox10.TabIndex = 0;
            // 
            // checkBox6
            // 
            this.checkBox6.Location = new System.Drawing.Point(0, 0);
            this.checkBox6.Name = "checkBox6";
            this.checkBox6.Size = new System.Drawing.Size(104, 24);
            this.checkBox6.TabIndex = 0;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("ＭＳ ゴシック", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.button1.Location = new System.Drawing.Point(18, 20);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(92, 26);
            this.button1.TabIndex = 62;
            this.button1.Text = "②を複写";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(0, 0);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 19);
            this.textBox2.TabIndex = 0;
            // 
            // label18
            // 
            this.label18.Location = new System.Drawing.Point(0, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(100, 23);
            this.label18.TabIndex = 0;
            // 
            // txtJigyojoSeriNo2
            // 
            this.txtJigyojoSeriNo2.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsTodokedeKanri, "SeiriNo_Siyo", true, System.Windows.Forms.DataSourceUpdateMode.Never));
            this.txtJigyojoSeriNo2.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtJigyojoSeriNo2.Location = new System.Drawing.Point(505, 44);
            this.txtJigyojoSeriNo2.MaxLength = 8;
            this.txtJigyojoSeriNo2.Name = "txtJigyojoSeriNo2";
            this.txtJigyojoSeriNo2.Size = new System.Drawing.Size(96, 31);
            this.txtJigyojoSeriNo2.TabIndex = 36;
            // 
            // lblJigyojoSeriNo2
            // 
            this.lblJigyojoSeriNo2.AutoSize = true;
            this.lblJigyojoSeriNo2.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblJigyojoSeriNo2.Location = new System.Drawing.Point(451, 47);
            this.lblJigyojoSeriNo2.Name = "lblJigyojoSeriNo2";
            this.lblJigyojoSeriNo2.Size = new System.Drawing.Size(56, 24);
            this.lblJigyojoSeriNo2.TabIndex = 35;
            this.lblJigyojoSeriNo2.Text = "(使用)";
            // 
            // txtJigyojoSeriNo1
            // 
            this.txtJigyojoSeriNo1.BackColor = System.Drawing.SystemColors.Window;
            this.txtJigyojoSeriNo1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsTodokedeKanri, "SeiriNo", true, System.Windows.Forms.DataSourceUpdateMode.Never));
            this.txtJigyojoSeriNo1.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtJigyojoSeriNo1.Location = new System.Drawing.Point(345, 44);
            this.txtJigyojoSeriNo1.MaxLength = 8;
            this.txtJigyojoSeriNo1.Name = "txtJigyojoSeriNo1";
            this.txtJigyojoSeriNo1.Size = new System.Drawing.Size(96, 31);
            this.txtJigyojoSeriNo1.TabIndex = 26;
            // 
            // lblJigyojoSeriNo1
            // 
            this.lblJigyojoSeriNo1.AutoSize = true;
            this.lblJigyojoSeriNo1.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblJigyojoSeriNo1.Location = new System.Drawing.Point(270, 47);
            this.lblJigyojoSeriNo1.Name = "lblJigyojoSeriNo1";
            this.lblJigyojoSeriNo1.Size = new System.Drawing.Size(74, 24);
            this.lblJigyojoSeriNo1.TabIndex = 25;
            this.lblJigyojoSeriNo1.Text = "整理番号";
            // 
            // pnlTodokedeKanri
            // 
            this.pnlTodokedeKanri.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlTodokedeKanri.Controls.Add(this.txtJigyojoSeriNo3);
            this.pnlTodokedeKanri.Controls.Add(this.txtJigyojoSeriNo2);
            this.pnlTodokedeKanri.Controls.Add(this.lblJigyojoSeriNo3);
            this.pnlTodokedeKanri.Controls.Add(this.chkTadasigaki);
            this.pnlTodokedeKanri.Controls.Add(this.lblJigyojoSeriNo2);
            this.pnlTodokedeKanri.Controls.Add(this.chkKyote);
            this.pnlTodokedeKanri.Controls.Add(this.btnItiran);
            this.pnlTodokedeKanri.Controls.Add(this.txtJigyojoAdrs);
            this.pnlTodokedeKanri.Controls.Add(this.txtJigyojoName);
            this.pnlTodokedeKanri.Controls.Add(this.txtNendo);
            this.pnlTodokedeKanri.Controls.Add(this.txtKanriNo);
            this.pnlTodokedeKanri.Controls.Add(this.lblAdrs);
            this.pnlTodokedeKanri.Controls.Add(this.lblName);
            this.pnlTodokedeKanri.Controls.Add(this.lblNendo);
            this.pnlTodokedeKanri.Controls.Add(this.lblKanriNo);
            this.pnlTodokedeKanri.Controls.Add(this.lblJigyojoSeriNo1);
            this.pnlTodokedeKanri.Controls.Add(this.txtJigyojoSeriNo1);
            this.pnlTodokedeKanri.Location = new System.Drawing.Point(15, 15);
            this.pnlTodokedeKanri.Name = "pnlTodokedeKanri";
            this.pnlTodokedeKanri.Size = new System.Drawing.Size(978, 152);
            this.pnlTodokedeKanri.TabIndex = 2;
            // 
            // txtJigyojoSeriNo3
            // 
            this.txtJigyojoSeriNo3.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsTodokedeKanri, "SeiriNo_Chozo", true, System.Windows.Forms.DataSourceUpdateMode.Never));
            this.txtJigyojoSeriNo3.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtJigyojoSeriNo3.Location = new System.Drawing.Point(660, 44);
            this.txtJigyojoSeriNo3.MaxLength = 8;
            this.txtJigyojoSeriNo3.Name = "txtJigyojoSeriNo3";
            this.txtJigyojoSeriNo3.Size = new System.Drawing.Size(96, 31);
            this.txtJigyojoSeriNo3.TabIndex = 36;
            // 
            // lblJigyojoSeriNo3
            // 
            this.lblJigyojoSeriNo3.AutoSize = true;
            this.lblJigyojoSeriNo3.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblJigyojoSeriNo3.Location = new System.Drawing.Point(606, 47);
            this.lblJigyojoSeriNo3.Name = "lblJigyojoSeriNo3";
            this.lblJigyojoSeriNo3.Size = new System.Drawing.Size(56, 24);
            this.lblJigyojoSeriNo3.TabIndex = 35;
            this.lblJigyojoSeriNo3.Text = "(貯蔵)";
            // 
            // chkTadasigaki
            // 
            this.chkTadasigaki.AutoSize = true;
            this.chkTadasigaki.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bsTodokedeKanri, "DotaiHo3Jo1Ko", true, System.Windows.Forms.DataSourceUpdateMode.Never));
            this.chkTadasigaki.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.chkTadasigaki.Location = new System.Drawing.Point(625, 110);
            this.chkTadasigaki.Name = "chkTadasigaki";
            this.chkTadasigaki.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.chkTadasigaki.Size = new System.Drawing.Size(177, 28);
            this.chkTadasigaki.TabIndex = 58;
            this.chkTadasigaki.Text = "法3条1項ただし書き";
            this.chkTadasigaki.UseVisualStyleBackColor = true;
            // 
            // chkKyote
            // 
            this.chkKyote.AutoSize = true;
            this.chkKyote.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bsTodokedeKanri, "KyoteiFlagChk", true, System.Windows.Forms.DataSourceUpdateMode.Never));
            this.chkKyote.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.chkKyote.Location = new System.Drawing.Point(625, 78);
            this.chkKyote.Name = "chkKyote";
            this.chkKyote.Size = new System.Drawing.Size(61, 28);
            this.chkKyote.TabIndex = 57;
            this.chkKyote.Text = "協定";
            this.chkKyote.UseVisualStyleBackColor = true;
            // 
            // btnItiran
            // 
            this.btnItiran.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnItiran.Location = new System.Drawing.Point(849, 108);
            this.btnItiran.Name = "btnItiran";
            this.btnItiran.Size = new System.Drawing.Size(100, 30);
            this.btnItiran.TabIndex = 56;
            this.btnItiran.Text = "一覧";
            this.btnItiran.UseVisualStyleBackColor = true;
            this.btnItiran.Click += new System.EventHandler(this.btnItiran_Click);
            // 
            // txtJigyojoAdrs
            // 
            this.txtJigyojoAdrs.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsTodokedeKanri, "SyozaiJyusyo", true, System.Windows.Forms.DataSourceUpdateMode.Never));
            this.txtJigyojoAdrs.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtJigyojoAdrs.Location = new System.Drawing.Point(155, 108);
            this.txtJigyojoAdrs.MaxLength = 100;
            this.txtJigyojoAdrs.Name = "txtJigyojoAdrs";
            this.txtJigyojoAdrs.Size = new System.Drawing.Size(446, 31);
            this.txtJigyojoAdrs.TabIndex = 54;
            // 
            // txtJigyojoName
            // 
            this.txtJigyojoName.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsTodokedeKanri, "JigyosyoNameN", true, System.Windows.Forms.DataSourceUpdateMode.Never));
            this.txtJigyojoName.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtJigyojoName.Location = new System.Drawing.Point(155, 76);
            this.txtJigyojoName.MaxLength = 100;
            this.txtJigyojoName.Name = "txtJigyojoName";
            this.txtJigyojoName.Size = new System.Drawing.Size(446, 31);
            this.txtJigyojoName.TabIndex = 53;
            // 
            // txtNendo
            // 
            this.txtNendo.BackColor = System.Drawing.SystemColors.Window;
            this.txtNendo.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsTodokedeKanri, "NendoW", true, System.Windows.Forms.DataSourceUpdateMode.Never));
            this.txtNendo.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtNendo.Location = new System.Drawing.Point(155, 12);
            this.txtNendo.MaxLength = 4;
            this.txtNendo.Name = "txtNendo";
            this.txtNendo.Size = new System.Drawing.Size(96, 31);
            this.txtNendo.TabIndex = 52;
            // 
            // txtKanriNo
            // 
            this.txtKanriNo.BackColor = System.Drawing.SystemColors.Window;
            this.txtKanriNo.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsTodokedeKanri, "KanriNo", true, System.Windows.Forms.DataSourceUpdateMode.Never));
            this.txtKanriNo.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtKanriNo.Location = new System.Drawing.Point(155, 44);
            this.txtKanriNo.MaxLength = 8;
            this.txtKanriNo.Name = "txtKanriNo";
            this.txtKanriNo.Size = new System.Drawing.Size(96, 31);
            this.txtKanriNo.TabIndex = 52;
            // 
            // lblAdrs
            // 
            this.lblAdrs.AutoSize = true;
            this.lblAdrs.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblAdrs.Location = new System.Drawing.Point(15, 111);
            this.lblAdrs.Name = "lblAdrs";
            this.lblAdrs.Size = new System.Drawing.Size(138, 24);
            this.lblAdrs.TabIndex = 51;
            this.lblAdrs.Text = "工場事業場所在地";
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblName.Location = new System.Drawing.Point(15, 79);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(122, 24);
            this.lblName.TabIndex = 50;
            this.lblName.Text = "工場事業場名称";
            // 
            // lblNendo
            // 
            this.lblNendo.AutoSize = true;
            this.lblNendo.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblNendo.Location = new System.Drawing.Point(15, 15);
            this.lblNendo.Name = "lblNendo";
            this.lblNendo.Size = new System.Drawing.Size(42, 24);
            this.lblNendo.TabIndex = 49;
            this.lblNendo.Text = "年度";
            // 
            // lblKanriNo
            // 
            this.lblKanriNo.AutoSize = true;
            this.lblKanriNo.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblKanriNo.Location = new System.Drawing.Point(15, 47);
            this.lblKanriNo.Name = "lblKanriNo";
            this.lblKanriNo.Size = new System.Drawing.Size(74, 24);
            this.lblKanriNo.TabIndex = 49;
            this.lblKanriNo.Text = "管理番号";
            // 
            // TSNO
            // 
            this.TSNO.DataPropertyName = "TSNO";
            this.TSNO.HeaderText = "施設区分";
            this.TSNO.Name = "TSNO";
            // 
            // cboGesuikbn
            // 
            this.cboGesuikbn.Location = new System.Drawing.Point(601, 455);
            this.cboGesuikbn.MaxLength = 1;
            this.cboGesuikbn.Name = "cboGesuikbn";
            this.cboGesuikbn.Size = new System.Drawing.Size(335, 31);
            this.cboGesuikbn.TabIndex = 41;
            this.cboGesuikbn.Value = "-1";
            // 
            // cboRyuikiCode
            // 
            this.cboRyuikiCode.Location = new System.Drawing.Point(152, 487);
            this.cboRyuikiCode.MaxLength = 8;
            this.cboRyuikiCode.Name = "cboRyuikiCode";
            this.cboRyuikiCode.Size = new System.Drawing.Size(304, 31);
            this.cboRyuikiCode.TabIndex = 36;
            this.cboRyuikiCode.Value = "-1";
            // 
            // cboSikibetuCode
            // 
            this.cboSikibetuCode.Location = new System.Drawing.Point(152, 455);
            this.cboSikibetuCode.Name = "cboSikibetuCode";
            this.cboSikibetuCode.Size = new System.Drawing.Size(304, 31);
            this.cboSikibetuCode.TabIndex = 35;
            this.cboSikibetuCode.Value = "-1";
            // 
            // cboHoKbnCode
            // 
            this.cboHoKbnCode.Location = new System.Drawing.Point(152, 423);
            this.cboHoKbnCode.MaxLength = 1;
            this.cboHoKbnCode.Name = "cboHoKbnCode";
            this.cboHoKbnCode.Size = new System.Drawing.Size(304, 31);
            this.cboHoKbnCode.TabIndex = 34;
            this.cboHoKbnCode.Value = "-1";
            // 
            // cboSangyoBS
            // 
            this.cboSangyoBS.Location = new System.Drawing.Point(152, 359);
            this.cboSangyoBS.Name = "cboSangyoBS";
            this.cboSangyoBS.Size = new System.Drawing.Size(304, 31);
            this.cboSangyoBS.TabIndex = 32;
            this.cboSangyoBS.Value = "-1";
            // 
            // cboSangyoBC
            // 
            this.cboSangyoBC.Location = new System.Drawing.Point(152, 327);
            this.cboSangyoBC.Name = "cboSangyoBC";
            this.cboSangyoBC.Size = new System.Drawing.Size(304, 31);
            this.cboSangyoBC.TabIndex = 31;
            this.cboSangyoBC.Value = "-1";
            this.cboSangyoBC.SelectedIndexChanged += new Suisitu.Components.Controls.ValueCombo.SelectedIndexChangedHandler(this.cboSangyoBC_SelectedIndexChanged);
            // 
            // backColorChangeOnFocusProvider1
            // 
            this.backColorChangeOnFocusProvider1.Target = this;
            // 
            // bsTodokedeKanri
            // 
            this.bsTodokedeKanri.DataSource = typeof(Suisitu.Entity.TodokedeKanriEntity);
            // 
            // bsKojoKihon
            // 
            this.bsKojoKihon.DataSource = typeof(Suisitu.Entity.KojoKihonEntity);
            // 
            // TdkdNo
            // 
            this.TdkdNo.DataPropertyName = "TdkdNo";
            this.TdkdNo.HeaderText = "管理 番号";
            this.TdkdNo.Name = "TdkdNo";
            this.TdkdNo.ReadOnly = true;
            this.TdkdNo.Width = 65;
            // 
            // TdkdKbn
            // 
            this.TdkdKbn.DataPropertyName = "TdkdKbn";
            this.TdkdKbn.HeaderText = "届出 区分";
            this.TdkdKbn.Name = "TdkdKbn";
            this.TdkdKbn.ReadOnly = true;
            this.TdkdKbn.Width = 65;
            // 
            // TodokedeDateShortW
            // 
            this.TodokedeDateShortW.DataPropertyName = "TodokedeDateShortW";
            this.TodokedeDateShortW.HeaderText = "届出年月日";
            this.TodokedeDateShortW.Name = "TodokedeDateShortW";
            this.TodokedeDateShortW.ReadOnly = true;
            this.TodokedeDateShortW.Width = 120;
            // 
            // UketukeNo
            // 
            this.UketukeNo.DataPropertyName = "UketukeNo";
            this.UketukeNo.HeaderText = "受付 番号";
            this.UketukeNo.Name = "UketukeNo";
            this.UketukeNo.ReadOnly = true;
            this.UketukeNo.Width = 65;
            // 
            // TdkdSyubetu
            // 
            this.TdkdSyubetu.DataPropertyName = "TdkdSyubetu";
            this.TdkdSyubetu.HeaderText = "届出代表 施設種別";
            this.TdkdSyubetu.Name = "TdkdSyubetu";
            this.TdkdSyubetu.ReadOnly = true;
            this.TdkdSyubetu.Width = 97;
            // 
            // TdkdSyubetuS
            // 
            this.TdkdSyubetuS.DataPropertyName = "TdkdSyubetuS";
            this.TdkdSyubetuS.HeaderText = "細区分";
            this.TdkdSyubetuS.Name = "TdkdSyubetuS";
            this.TdkdSyubetuS.ReadOnly = true;
            this.TdkdSyubetuS.Width = 85;
            // 
            // Biko1
            // 
            this.Biko1.DataPropertyName = "Biko1";
            this.Biko1.HeaderText = "申請、届出内容１";
            this.Biko1.Name = "Biko1";
            this.Biko1.ReadOnly = true;
            this.Biko1.Width = 230;
            // 
            // Biko2
            // 
            this.Biko2.DataPropertyName = "Biko2";
            this.Biko2.HeaderText = "申請、届出内容２";
            this.Biko2.Name = "Biko2";
            this.Biko2.ReadOnly = true;
            this.Biko2.Width = 220;
            // 
            // Biko3
            // 
            this.Biko3.DataPropertyName = "Biko3";
            this.Biko3.HeaderText = "備考";
            this.Biko3.Name = "Biko3";
            this.Biko3.ReadOnly = true;
            this.Biko3.Width = 220;
            // 
            // bsTodokedeRireki
            // 
            this.bsTodokedeRireki.DataSource = typeof(Suisitu.Entity.TodokedeRirekiEntity);
            // 
            // bsTokuteiSisetuTou
            // 
            this.bsTokuteiSisetuTou.DataSource = typeof(Suisitu.Entity.TokuteiSisetuTouEntity);
            // 
            // fsNoDataGridViewTextBoxColumn
            // 
            this.fsNoDataGridViewTextBoxColumn.DataPropertyName = "FsNo";
            this.fsNoDataGridViewTextBoxColumn.HeaderText = "付帯設備番号";
            this.fsNoDataGridViewTextBoxColumn.Name = "fsNoDataGridViewTextBoxColumn";
            this.fsNoDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // torimatomeFlagVDataGridViewTextBoxColumn
            // 
            this.torimatomeFlagVDataGridViewTextBoxColumn.DataPropertyName = "TorimatomeFlagV";
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.torimatomeFlagVDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle6;
            this.torimatomeFlagVDataGridViewTextBoxColumn.HeaderText = "とりまとめ";
            this.torimatomeFlagVDataGridViewTextBoxColumn.Name = "torimatomeFlagVDataGridViewTextBoxColumn";
            this.torimatomeFlagVDataGridViewTextBoxColumn.ReadOnly = true;
            this.torimatomeFlagVDataGridViewTextBoxColumn.Width = 120;
            // 
            // tsNoDataGridViewTextBoxColumn
            // 
            this.tsNoDataGridViewTextBoxColumn.DataPropertyName = "TsNo";
            this.tsNoDataGridViewTextBoxColumn.HeaderText = "施設番号";
            this.tsNoDataGridViewTextBoxColumn.Name = "tsNoDataGridViewTextBoxColumn";
            this.tsNoDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // sisetuNameNDataGridViewTextBoxColumn
            // 
            this.sisetuNameNDataGridViewTextBoxColumn.DataPropertyName = "SisetuNameN";
            this.sisetuNameNDataGridViewTextBoxColumn.HeaderText = "施設名称";
            this.sisetuNameNDataGridViewTextBoxColumn.Name = "sisetuNameNDataGridViewTextBoxColumn";
            this.sisetuNameNDataGridViewTextBoxColumn.ReadOnly = true;
            this.sisetuNameNDataGridViewTextBoxColumn.Width = 200;
            // 
            // setubiUmuFlag1VDataGridViewTextBoxColumn
            // 
            this.setubiUmuFlag1VDataGridViewTextBoxColumn.DataPropertyName = "SetubiUmuFlag1V";
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.setubiUmuFlag1VDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle7;
            this.setubiUmuFlag1VDataGridViewTextBoxColumn.HeaderText = "床面及び周囲";
            this.setubiUmuFlag1VDataGridViewTextBoxColumn.Name = "setubiUmuFlag1VDataGridViewTextBoxColumn";
            this.setubiUmuFlag1VDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // setubiUmuFlag2VDataGridViewTextBoxColumn
            // 
            this.setubiUmuFlag2VDataGridViewTextBoxColumn.DataPropertyName = "SetubiUmuFlag2V";
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.setubiUmuFlag2VDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle8;
            this.setubiUmuFlag2VDataGridViewTextBoxColumn.HeaderText = "施設 本体";
            this.setubiUmuFlag2VDataGridViewTextBoxColumn.Name = "setubiUmuFlag2VDataGridViewTextBoxColumn";
            this.setubiUmuFlag2VDataGridViewTextBoxColumn.ReadOnly = true;
            this.setubiUmuFlag2VDataGridViewTextBoxColumn.Width = 65;
            // 
            // setubiUmuFlag3VDataGridViewTextBoxColumn
            // 
            this.setubiUmuFlag3VDataGridViewTextBoxColumn.DataPropertyName = "SetubiUmuFlag3V";
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.setubiUmuFlag3VDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle9;
            this.setubiUmuFlag3VDataGridViewTextBoxColumn.HeaderText = "地上 配管";
            this.setubiUmuFlag3VDataGridViewTextBoxColumn.Name = "setubiUmuFlag3VDataGridViewTextBoxColumn";
            this.setubiUmuFlag3VDataGridViewTextBoxColumn.ReadOnly = true;
            this.setubiUmuFlag3VDataGridViewTextBoxColumn.Width = 65;
            // 
            // setubiUmuFlag4VDataGridViewTextBoxColumn
            // 
            this.setubiUmuFlag4VDataGridViewTextBoxColumn.DataPropertyName = "SetubiUmuFlag4V";
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.setubiUmuFlag4VDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle10;
            this.setubiUmuFlag4VDataGridViewTextBoxColumn.HeaderText = "地下 配管";
            this.setubiUmuFlag4VDataGridViewTextBoxColumn.Name = "setubiUmuFlag4VDataGridViewTextBoxColumn";
            this.setubiUmuFlag4VDataGridViewTextBoxColumn.ReadOnly = true;
            this.setubiUmuFlag4VDataGridViewTextBoxColumn.Width = 65;
            // 
            // setubiUmuFlag5VDataGridViewTextBoxColumn
            // 
            this.setubiUmuFlag5VDataGridViewTextBoxColumn.DataPropertyName = "SetubiUmuFlag5V";
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.setubiUmuFlag5VDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle11;
            this.setubiUmuFlag5VDataGridViewTextBoxColumn.HeaderText = "排水口等";
            this.setubiUmuFlag5VDataGridViewTextBoxColumn.Name = "setubiUmuFlag5VDataGridViewTextBoxColumn";
            this.setubiUmuFlag5VDataGridViewTextBoxColumn.ReadOnly = true;
            this.setubiUmuFlag5VDataGridViewTextBoxColumn.Width = 65;
            // 
            // setubiUmuFlag6VDataGridViewTextBoxColumn
            // 
            this.setubiUmuFlag6VDataGridViewTextBoxColumn.DataPropertyName = "SetubiUmuFlag6V";
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.setubiUmuFlag6VDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle12;
            this.setubiUmuFlag6VDataGridViewTextBoxColumn.HeaderText = "予備1";
            this.setubiUmuFlag6VDataGridViewTextBoxColumn.Name = "setubiUmuFlag6VDataGridViewTextBoxColumn";
            this.setubiUmuFlag6VDataGridViewTextBoxColumn.ReadOnly = true;
            this.setubiUmuFlag6VDataGridViewTextBoxColumn.Width = 80;
            // 
            // setubiUmuFlag7VDataGridViewTextBoxColumn
            // 
            this.setubiUmuFlag7VDataGridViewTextBoxColumn.DataPropertyName = "SetubiUmuFlag7V";
            dataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.setubiUmuFlag7VDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle13;
            this.setubiUmuFlag7VDataGridViewTextBoxColumn.HeaderText = "予備2";
            this.setubiUmuFlag7VDataGridViewTextBoxColumn.Name = "setubiUmuFlag7VDataGridViewTextBoxColumn";
            this.setubiUmuFlag7VDataGridViewTextBoxColumn.ReadOnly = true;
            this.setubiUmuFlag7VDataGridViewTextBoxColumn.Width = 80;
            // 
            // bsFutaiSetubiTou
            // 
            this.bsFutaiSetubiTou.DataSource = typeof(Suisitu.Entity.FutaiSetubiTouEntity);
            // 
            // SisetuNameN
            // 
            this.SisetuNameN.DataPropertyName = "SisetuNameN";
            this.SisetuNameN.HeaderText = "施設名称";
            this.SisetuNameN.Name = "SisetuNameN";
            this.SisetuNameN.ReadOnly = true;
            this.SisetuNameN.Width = 300;
            // 
            // Biko
            // 
            this.Biko.DataPropertyName = "Biko";
            this.Biko.HeaderText = "備考";
            this.Biko.Name = "Biko";
            this.Biko.ReadOnly = true;
            this.Biko.Width = 300;
            // 
            // bsShoriSisetu
            // 
            this.bsShoriSisetu.DataSource = typeof(Suisitu.Entity.SyoriSisetuEntity);
            // 
            // HaisuikoNo
            // 
            this.HaisuikoNo.DataPropertyName = "HaisuikoNo";
            this.HaisuikoNo.HeaderText = "排水口番号";
            this.HaisuikoNo.Name = "HaisuikoNo";
            this.HaisuikoNo.ReadOnly = true;
            this.HaisuikoNo.Width = 117;
            // 
            // SetiDateShortW
            // 
            this.SetiDateShortW.DataPropertyName = "SetiDateShortW";
            this.SetiDateShortW.HeaderText = "設置年月日";
            this.SetiDateShortW.Name = "SetiDateShortW";
            this.SetiDateShortW.ReadOnly = true;
            this.SetiDateShortW.Width = 120;
            // 
            // HaisiDateShortW
            // 
            this.HaisiDateShortW.DataPropertyName = "HaisiDateShortW";
            this.HaisiDateShortW.HeaderText = "廃止年月日";
            this.HaisiDateShortW.Name = "HaisiDateShortW";
            this.HaisiDateShortW.ReadOnly = true;
            this.HaisiDateShortW.Width = 120;
            // 
            // dataGridViewTextBoxColumn21
            // 
            this.dataGridViewTextBoxColumn21.DataPropertyName = "TdkdHsAve";
            this.dataGridViewTextBoxColumn21.HeaderText = "届出排水量（通常）";
            this.dataGridViewTextBoxColumn21.Name = "dataGridViewTextBoxColumn21";
            this.dataGridViewTextBoxColumn21.ReadOnly = true;
            this.dataGridViewTextBoxColumn21.Width = 180;
            // 
            // dataGridViewTextBoxColumn22
            // 
            this.dataGridViewTextBoxColumn22.DataPropertyName = "TdkdHsMax";
            this.dataGridViewTextBoxColumn22.HeaderText = "届出排水量（最大）";
            this.dataGridViewTextBoxColumn22.Name = "dataGridViewTextBoxColumn22";
            this.dataGridViewTextBoxColumn22.ReadOnly = true;
            this.dataGridViewTextBoxColumn22.Width = 180;
            // 
            // dataGridViewTextBoxColumn23
            // 
            this.dataGridViewTextBoxColumn23.DataPropertyName = "Biko";
            this.dataGridViewTextBoxColumn23.HeaderText = "備考";
            this.dataGridViewTextBoxColumn23.Name = "dataGridViewTextBoxColumn23";
            this.dataGridViewTextBoxColumn23.ReadOnly = true;
            this.dataGridViewTextBoxColumn23.Width = 200;
            // 
            // bsHaisuiko
            // 
            this.bsHaisuiko.DataSource = typeof(Suisitu.Entity.HaisuikoEntity);
            // 
            // bsOdakuFukaryo
            // 
            this.bsOdakuFukaryo.DataSource = typeof(Suisitu.Entity.OdakuFukaryoEntity);
            // 
            // bsKubunName
            // 
            this.bsKubunName.DataSource = typeof(Suisitu.Entity.KubunNameEntity);
            // 
            // HaisiFlag
            // 
            this.HaisiFlag.DataPropertyName = "HaisiFlagV";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.HaisiFlag.DefaultCellStyle = dataGridViewCellStyle3;
            this.HaisiFlag.HeaderText = "廃止";
            this.HaisiFlag.Name = "HaisiFlag";
            this.HaisiFlag.ReadOnly = true;
            this.HaisiFlag.Width = 70;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "SisetuKbn";
            this.dataGridViewTextBoxColumn1.HeaderText = "施設区分";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn11
            // 
            this.dataGridViewTextBoxColumn11.DataPropertyName = "TsSyubetu";
            this.dataGridViewTextBoxColumn11.HeaderText = "特定施設種別";
            this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            this.dataGridViewTextBoxColumn11.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn12
            // 
            this.dataGridViewTextBoxColumn12.DataPropertyName = "TsSyubetuSai";
            this.dataGridViewTextBoxColumn12.HeaderText = "細区分";
            this.dataGridViewTextBoxColumn12.Name = "dataGridViewTextBoxColumn12";
            this.dataGridViewTextBoxColumn12.ReadOnly = true;
            this.dataGridViewTextBoxColumn12.Width = 85;
            // 
            // dataGridViewTextBoxColumn13
            // 
            this.dataGridViewTextBoxColumn13.DataPropertyName = "DaihyoFlagV";
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn13.DefaultCellStyle = dataGridViewCellStyle4;
            this.dataGridViewTextBoxColumn13.HeaderText = "代表 フラグ";
            this.dataGridViewTextBoxColumn13.Name = "dataGridViewTextBoxColumn13";
            this.dataGridViewTextBoxColumn13.ReadOnly = true;
            this.dataGridViewTextBoxColumn13.Width = 85;
            // 
            // dataGridViewTextBoxColumn14
            // 
            this.dataGridViewTextBoxColumn14.DataPropertyName = "Sisetusu";
            this.dataGridViewTextBoxColumn14.HeaderText = "設置 基数";
            this.dataGridViewTextBoxColumn14.Name = "dataGridViewTextBoxColumn14";
            this.dataGridViewTextBoxColumn14.ReadOnly = true;
            this.dataGridViewTextBoxColumn14.Width = 65;
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.DataPropertyName = "SetiDateW";
            this.dataGridViewTextBoxColumn9.HeaderText = "設置年月日";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            this.dataGridViewTextBoxColumn9.ReadOnly = true;
            this.dataGridViewTextBoxColumn9.Width = 120;
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.DataPropertyName = "HaisiDateW";
            this.dataGridViewTextBoxColumn10.HeaderText = "廃止年月日";
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            this.dataGridViewTextBoxColumn10.ReadOnly = true;
            this.dataGridViewTextBoxColumn10.Width = 120;
            // 
            // dataGridViewTextBoxColumn15
            // 
            this.dataGridViewTextBoxColumn15.DataPropertyName = "Biko";
            this.dataGridViewTextBoxColumn15.HeaderText = "備考";
            this.dataGridViewTextBoxColumn15.Name = "dataGridViewTextBoxColumn15";
            this.dataGridViewTextBoxColumn15.ReadOnly = true;
            this.dataGridViewTextBoxColumn15.Width = 210;
            // 
            // dataGridViewTextBoxColumn24
            // 
            this.dataGridViewTextBoxColumn24.DataPropertyName = "TsNo";
            this.dataGridViewTextBoxColumn24.HeaderText = "施設番号";
            this.dataGridViewTextBoxColumn24.Name = "dataGridViewTextBoxColumn24";
            this.dataGridViewTextBoxColumn24.ReadOnly = true;
            // 
            // TodokedeKanri
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.ClientSize = new System.Drawing.Size(1008, 730);
            this.Controls.Add(this.pnlTodokedeKanri);
            this.Controls.Add(this.tabTodokedeKanri);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "TodokedeKanri";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "水質届出入出力";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.TodokedeKanri_FormClosing);
            this.Load += new System.EventHandler(this.TodokedeKanri_Load);
            this.tabTodokedeKanri.ResumeLayout(false);
            this.tabKojyoKihon.ResumeLayout(false);
            this.tabKojyoKihon.PerformLayout();
            this.tabTodokedeRireki.ResumeLayout(false);
            this.tabTodokedeRireki.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTodokedeRireki)).EndInit();
            this.tabTokuteiSisetu.ResumeLayout(false);
            this.tabTokuteiSisetu.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTokuteiSisetuTou)).EndInit();
            this.tabFutaisetubi.ResumeLayout(false);
            this.tabFutaisetubi.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvFutaiSetubiTou)).EndInit();
            this.tabShoriSisetu.ResumeLayout(false);
            this.tabShoriSisetu.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvShoriSisetu)).EndInit();
            this.tabHaisuiko.ResumeLayout(false);
            this.tabHaisuiko.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvHaisuiko)).EndInit();
            this.tabOdakuFukaryo.ResumeLayout(false);
            this.tabOdakuFukaryo.PerformLayout();
            this.tblOdakuFukaryo.ResumeLayout(false);
            this.tblOdakuFukaryo.PerformLayout();
            this.tabSoryoKise.ResumeLayout(false);
            this.tabSoryoKise.PerformLayout();
            this.tblTp.ResumeLayout(false);
            this.tblTp.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTp)).EndInit();
            this.TblTn.ResumeLayout(false);
            this.TblTn.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTn)).EndInit();
            this.tblCod.ResumeLayout(false);
            this.tblCod.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCod)).EndInit();
            this.tblSoryoKise.ResumeLayout(false);
            this.tblSoryoKise.PerformLayout();
            this.pnlTodokedeKanri.ResumeLayout(false);
            this.pnlTodokedeKanri.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bsTodokedeKanri)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsKojoKihon)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsTodokedeRireki)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsTokuteiSisetuTou)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsFutaiSetubiTou)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsShoriSisetu)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsHaisuiko)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsOdakuFukaryo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsKubunName)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.TabControl tabTodokedeKanri;
        private System.Windows.Forms.TabPage tabKojyoKihon;
        private System.Windows.Forms.TabPage tabTodokedeRireki;
        private System.Windows.Forms.TabPage tabTokuteiSisetu;
        private System.Windows.Forms.TabPage tabShoriSisetu;
        private System.Windows.Forms.TabPage tabHaisuiko;
        private System.Windows.Forms.TabPage tabOdakuFukaryo;
        private System.Windows.Forms.TextBox txtJigyojoSeriNo2;
        private System.Windows.Forms.Label lblJigyojoSeriNo2;
        private System.Windows.Forms.TextBox txtJigyojoSeriNo1;
        private System.Windows.Forms.Label lblJigyojoSeriNo1;
        private System.Windows.Forms.Panel pnlTodokedeKanri;
        public System.Windows.Forms.CheckBox chkTadasigaki;
        public System.Windows.Forms.CheckBox chkKyote;
        public System.Windows.Forms.Button btnItiran;
        public System.Windows.Forms.TextBox txtJigyojoAdrs;
        public System.Windows.Forms.TextBox txtJigyojoName;
        //public System.Windows.Forms.MaskedTextBox txtSeriNo;
        public System.Windows.Forms.TextBox txtKanriNo;
        public System.Windows.Forms.Label lblAdrs;
        public System.Windows.Forms.Label lblName;
        public System.Windows.Forms.Label lblKanriNo;
        private System.Windows.Forms.BindingSource bsTodokedeRireki;
        private System.Windows.Forms.BindingSource bsTokuteiSisetuTou;
        private System.Windows.Forms.BindingSource bsShoriSisetu;
        private System.Windows.Forms.BindingSource bsHaisuiko;
        private System.Windows.Forms.BindingSource bsKubunName;
        private System.Windows.Forms.BindingSource bsKojoKihon;
        private System.Windows.Forms.TextBox txtJigyojoSeriNo3;
        private System.Windows.Forms.Label lblJigyojoSeriNo3;
        public System.Windows.Forms.TextBox txtNendo;
        public System.Windows.Forms.Label lblNendo;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.CheckBox checkBox10;
        private System.Windows.Forms.CheckBox checkBox6;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label19;
        public System.Windows.Forms.Button button2;
        public System.Windows.Forms.Button button1;
        private System.Windows.Forms.DataGridViewTextBoxColumn TSNO;
        private System.Windows.Forms.BindingSource bsTodokedeKanri;
        private System.Windows.Forms.TabPage tabFutaisetubi;
        private System.Windows.Forms.Label lblCountRecordFutaiSetubiTou;
        private System.Windows.Forms.Label lblCountNumberFutaiSetubiTou;
        private System.Windows.Forms.Label lblFutaiSetubiTou;
        private System.Windows.Forms.Button btnCopyFutaiSetubiTou;
        private System.Windows.Forms.Button btnSelectFutaiSetubiTou;
        private System.Windows.Forms.Button btnAddFutaiSetubiTou;
        private System.Windows.Forms.DataGridView dgvFutaiSetubiTou;
        private Component.BackColorChangeOnFocusProvider backColorChangeOnFocusProvider1;
        private Components.Controls.ValueCombo cboGesuikbn;
        private System.Windows.Forms.Label lblGesuikbn;
        private Components.Controls.ValueCombo cboRyuikiCode;
        private Components.Controls.ValueCombo cboSikibetuCode;
        private Components.Controls.ValueCombo cboHoKbnCode;
        private Components.Controls.ValueCombo cboSangyoBS;
        private Components.Controls.ValueCombo cboSangyoBC;
        public System.Windows.Forms.Button btnCopy2;
        private System.Windows.Forms.Label lblSaisuiLine;
        private System.Windows.Forms.Label lblOdakuCopName;
        private System.Windows.Forms.TextBox txtBiko4;
        private System.Windows.Forms.Label lblSaisui;
        private System.Windows.Forms.TextBox txtOdakuNameN;
        private System.Windows.Forms.Label lblSaisuiNameN;
        private System.Windows.Forms.Label lblOdakuYubinNo;
        private System.Windows.Forms.Label lblSaisuiFaxNo;
        private System.Windows.Forms.Label lblBiko4;
        private System.Windows.Forms.Label lblOdakuFkaryoSofusakiLine;
        private System.Windows.Forms.Label lblOdakuNameN;
        private System.Windows.Forms.TextBox txtSaisuiNameN;
        private System.Windows.Forms.TextBox txtOdakuCopName;
        private System.Windows.Forms.Label lblOdakuFukaryoSofusaki;
        private System.Windows.Forms.TextBox txtOdakuYubinNo1;
        private System.Windows.Forms.TextBox txtSaisuiFaxNo;
        private System.Windows.Forms.TextBox txtOdakuJyusyo;
        public System.Windows.Forms.Button btnSiyoJokyo;
        private System.Windows.Forms.Label lblSofusakiYubinNoHi;
        private System.Windows.Forms.TextBox txtBiko5;
        private System.Windows.Forms.Label lblOdakuJyusyo;
        private System.Windows.Forms.Label lblKihonkomoku2Line;
        private System.Windows.Forms.TextBox txtOdakuYubinNo2;
        private System.Windows.Forms.Label lblBiko5;
        private System.Windows.Forms.Label lblKihonkomoku2;
        private System.Windows.Forms.TextBox txtKankyosyoCode;
        private System.Windows.Forms.Label lblKihonkomoku1Line;
        private System.Windows.Forms.Label lblKihonkomoku1;
        private System.Windows.Forms.Label lblChozoSite;
        private System.Windows.Forms.Label lblKankyosyoCode;
        public System.Windows.Forms.Button btnCopy1;
        private System.Windows.Forms.Label lblSiyoTokute2;
        private System.Windows.Forms.Label lblSiyoTokute1;
        private System.Windows.Forms.Label lblYugaiUm;
        private System.Windows.Forms.TextBox txtBiko2;
        private System.Windows.Forms.CheckBox chkYokakunin;
        private System.Windows.Forms.CheckBox chkYugaiUm;
        private System.Windows.Forms.Label lblTodokedeSinseishaLine;
        private System.Windows.Forms.CheckBox chkChosataisho;
        private System.Windows.Forms.CheckBox chkKosyohoJunyoSite;
        private System.Windows.Forms.Label lblSinseiCopName;
        private System.Windows.Forms.CheckBox chkKosyohoSite;
        private System.Windows.Forms.CheckBox chkKosyoTokute;
        private System.Windows.Forms.Label lblTodokedeSinseisha;
        private System.Windows.Forms.CheckBox chkChozoSiteKakosiyo;
        public System.Windows.Forms.CheckBox chkKyote2;
        private System.Windows.Forms.CheckBox chkChozoSite;
        private System.Windows.Forms.Label lblBiko2;
        private System.Windows.Forms.CheckBox chkSiyoTokute2Kakosiyo;
        public System.Windows.Forms.CheckBox chkZanteiKijunFlag;
        private System.Windows.Forms.CheckBox chkSiyoTokute2;
        private System.Windows.Forms.TextBox txtSyozaiJyusyo;
        private System.Windows.Forms.CheckBox chkSiyoTokute1Kakosiyo;
        public System.Windows.Forms.CheckBox chkHaisuiKijun;
        private System.Windows.Forms.CheckBox chkSiyoTokute1;
        private System.Windows.Forms.TextBox txtSinseiNameN;
        public System.Windows.Forms.CheckBox chkTadasigaki2;
        private System.Windows.Forms.Button btnCancelKojoKihon;
        private System.Windows.Forms.Label lblSoryoKiseiNo;
        private System.Windows.Forms.Label lblSinseiYubinNo;
        private System.Windows.Forms.TextBox txtSoryoKiseiNo;
        private System.Windows.Forms.Label lblSyozaiJyusyo;
        private System.Windows.Forms.TextBox txtBiko3;
        private System.Windows.Forms.Label lblSinseiNameN;
        private System.Windows.Forms.Label lblSangyoBC;
        private System.Windows.Forms.Label lblBiko3;
        private System.Windows.Forms.Button btnRegistKojoKihon;
        private System.Windows.Forms.Label lblSangyoBS;
        private System.Windows.Forms.TextBox txtSinseiCopName;
        private System.Windows.Forms.TextBox txtBiko1;
        private System.Windows.Forms.Label lblHoKbnCode;
        private System.Windows.Forms.TextBox txtSinseiTelNo;
        private System.Windows.Forms.Label lblKojoKihon;
        private System.Windows.Forms.Label lblSinseiTelNo;
        private System.Windows.Forms.Label lblJigyosyoNameN;
        private System.Windows.Forms.TextBox txtSinseiYubinNo1;
        private System.Windows.Forms.Label lblBiko1;
        private System.Windows.Forms.TextBox txtSinseiJyusyo;
        private System.Windows.Forms.Label lblRyuikiCode;
        private System.Windows.Forms.Label lblJigyojoLine;
        private System.Windows.Forms.Label lblSikibetuCode;
        private System.Windows.Forms.Label lblTodokedeYubinNoHi;
        private System.Windows.Forms.Label lblJigyosyoNameK;
        private System.Windows.Forms.Label lblSinseiJyusyo;
        private System.Windows.Forms.Label lblJigyojo;
        private System.Windows.Forms.TextBox txtSinseiYubinNo2;
        private System.Windows.Forms.TextBox txtKTantoNameN;
        private System.Windows.Forms.Label lbltxtSyozaiYubinNo;
        private System.Windows.Forms.Label lblKTantoNameN;
        private System.Windows.Forms.TextBox txtJigyosyoNameN;
        private System.Windows.Forms.TextBox txtTelNo;
        private System.Windows.Forms.TextBox txtJigyosyoNameK;
        private System.Windows.Forms.Label lbltxtTelNo;
        private System.Windows.Forms.TextBox txtSyozaiYubinNo2;
        private System.Windows.Forms.TextBox txtSyozaiYubinNo1;
        private System.Windows.Forms.Label lblJigyojoYubinNoHi;
        private System.Windows.Forms.Label lblCountNumberTodokedeRireki;
        public System.Windows.Forms.DataGridView dgvTodokedeRireki;
        private System.Windows.Forms.Label lblCountRecordTodokedeRireki;
        private System.Windows.Forms.Label lblTodokedeRireki;
        private System.Windows.Forms.Button btnCopyTodokedeRireki;
        private System.Windows.Forms.Button btnSelectTodokedeRireki;
        private System.Windows.Forms.Button btnAddTodokedeRireki;
        private System.Windows.Forms.Label lblCountRecordTokuteiSisetuTou;
        private System.Windows.Forms.Label lblCountNumberTokuteiSisetu;
        private System.Windows.Forms.Label lblTokuteiSisetu;
        private System.Windows.Forms.Button btnCopyTokuteiSisetuTou;
        private System.Windows.Forms.Button btnSelectTokuteiSisetuTou;
        private System.Windows.Forms.Button btnAddTokuteiSisetuTou;
        private System.Windows.Forms.DataGridView dgvTokuteiSisetuTou;
        private System.Windows.Forms.Label lblCountRecordShoriSisetu;
        private System.Windows.Forms.Label lblCountNumberShoriSisetu;
        private System.Windows.Forms.Label lblShoriSisetu;
        private System.Windows.Forms.Button btnCopyShoriSisetu;
        private System.Windows.Forms.Button btnSelectShoriSisetu;
        private System.Windows.Forms.Button btnAddShoriSisetu;
        private System.Windows.Forms.DataGridView dgvShoriSisetu;
        private System.Windows.Forms.TableLayoutPanel tblOdakuFukaryo;
        private System.Windows.Forms.Label lblSpaceOdakuFukaryo;
        private System.Windows.Forms.Label lblCodOdakuFukaryo;
        private System.Windows.Forms.Label lblTdkdFukaryo;
        private System.Windows.Forms.Label lblTdkdhsAveOdakuFukaryo;
        private System.Windows.Forms.Label lblTdkdhsMaxOdakuFukaryo;
        private System.Windows.Forms.Label lblBikoOdakuFukaryo;
        private System.Windows.Forms.Label lblTnOdakuFukaryo;
        private System.Windows.Forms.Label lblTpOdakuFukaryo;
        private System.Windows.Forms.Label lblSonotaOdakuFukaryo;
        private System.Windows.Forms.Label lblKyoyoFukaryo;
        private System.Windows.Forms.TextBox txtCodKyoyoFukaryo;
        private System.Windows.Forms.TextBox txtTnKyoyoFukaryo;
        private System.Windows.Forms.TextBox txtTpKyoyoFukaryo;
        private System.Windows.Forms.TextBox txtSonotaKyoyoFukaryo;
        private System.Windows.Forms.TextBox txtCodTdkdFukaryo;
        private System.Windows.Forms.TextBox txtTnTdkdFukaryo;
        private System.Windows.Forms.TextBox txtTpTdkdFukaryo;
        private System.Windows.Forms.TextBox txtSonotaTdkdFukaryo;
        private System.Windows.Forms.TextBox txtTdkdhsAveOdakuFukaryo;
        private System.Windows.Forms.TextBox txtTdkdhsMaxOdakuFukaryo;
        private System.Windows.Forms.TextBox txtBikoOdakuFukaryo;
        private System.Windows.Forms.Button btnCancelOdakuFukaryo;
        private System.Windows.Forms.Button btnRegistOdakuFukaryo;
        private System.Windows.Forms.Label lblOdakuFukaryo;
        private System.Windows.Forms.TabPage tabSoryoKise;
        private System.Windows.Forms.Label lblTpLine;
        private System.Windows.Forms.Label lblTnLine;
        private System.Windows.Forms.Label lblCodLine;
        private System.Windows.Forms.TableLayoutPanel tblTp;
        private System.Windows.Forms.Label lblGyosyuKbnTp;
        private System.Windows.Forms.Label lblTpTable;
        private System.Windows.Forms.Label lblCpo;
        private System.Windows.Forms.Label lblCpi;
        private System.Windows.Forms.Label lblSpaceTp1;
        private System.Windows.Forms.Label lblOsenJyotaiTp;
        private System.Windows.Forms.Label lblOjAveTp;
        private System.Windows.Forms.Label OjMaxTp;
        private System.Windows.Forms.Label lblTSuiryoTp;
        private System.Windows.Forms.Label lblTSuiryoAveTp;
        private System.Windows.Forms.Label lblTSuiryoMaxTp;
        private System.Windows.Forms.Label lblTSuiryoQpo;
        private System.Windows.Forms.Label lblTSuiryoQpi;
        private System.Windows.Forms.Label lblSpaceTp2;
        private System.Windows.Forms.Label lblOdakuFukaryoTp;
        private System.Windows.Forms.Label lblOdakuFukaryoAveTp;
        private System.Windows.Forms.Label lblOdakuFukaryoMaxTp;
        private System.Windows.Forms.Label lblKijyunTiTp;
        private System.Windows.Forms.Label lblLp;
        private System.Windows.Forms.Label lblScrolBerTp;
        private System.Windows.Forms.DataGridView dgvTp;
        private System.Windows.Forms.Label lblTp;
        private System.Windows.Forms.Button btnDeleteMeisaiTp;
        private System.Windows.Forms.Button btnAddMeisaiTp;
        private System.Windows.Forms.TableLayoutPanel TblTn;
        private System.Windows.Forms.Label lblGyosyuKbnTn;
        private System.Windows.Forms.Label lblTnTable;
        private System.Windows.Forms.Label lblCno;
        private System.Windows.Forms.Label lblCni;
        private System.Windows.Forms.Label lblSpaceTn1;
        private System.Windows.Forms.Label lblOsenJyotaiTn;
        private System.Windows.Forms.Label lblOjAveTn;
        private System.Windows.Forms.Label OjMaxTn;
        private System.Windows.Forms.Label lblTSuiryoTn;
        private System.Windows.Forms.Label lblTSuiryoAveTn;
        private System.Windows.Forms.Label lblTSuiryoMaxTn;
        private System.Windows.Forms.Label lblTSuiryoQno;
        private System.Windows.Forms.Label lblTSuiryoQni;
        private System.Windows.Forms.Label lblSpaceTn2;
        private System.Windows.Forms.Label lblOdakuFukaryoTn;
        private System.Windows.Forms.Label lblOdakuFukaryoAveTn;
        private System.Windows.Forms.Label lblOdakuFukaryoMaxTn;
        private System.Windows.Forms.Label lblKijyunTiTn;
        private System.Windows.Forms.Label lblLn;
        private System.Windows.Forms.Label lblScrolBerTn;
        private System.Windows.Forms.DataGridView dgvTn;
        private System.Windows.Forms.Label lblTn;
        private System.Windows.Forms.Button btnDeleteMeisaiTn;
        private System.Windows.Forms.Button btnAddMeisaiTn;
        private System.Windows.Forms.TableLayoutPanel tblCod;
        private System.Windows.Forms.Label lblGyosyuKbnCod;
        private System.Windows.Forms.Label lblCodTable;
        private System.Windows.Forms.Label lblCco;
        private System.Windows.Forms.Label lblCci;
        private System.Windows.Forms.Label lblCcj;
        private System.Windows.Forms.Label lblOsenJyotaiCod;
        private System.Windows.Forms.Label lblOjAveCod;
        private System.Windows.Forms.Label OjMaxCod;
        private System.Windows.Forms.Label lblTSuiryoCod;
        private System.Windows.Forms.Label lblTSuiryoAveCod;
        private System.Windows.Forms.Label lblTSuiryoMaxCod;
        private System.Windows.Forms.Label lblTSuiryoQco;
        private System.Windows.Forms.Label lblTSuiryoQci;
        private System.Windows.Forms.Label lblTSuiryoQcj;
        private System.Windows.Forms.Label lblOdakuFukaryoCod;
        private System.Windows.Forms.Label lblOdakuFukaryoAveCod;
        private System.Windows.Forms.Label lblOdakuFukaryoMaxCod;
        private System.Windows.Forms.Label lblKijyunTiCod;
        private System.Windows.Forms.Label lblLc;
        private System.Windows.Forms.Label lblScrolBerCod;
        private System.Windows.Forms.DataGridView dgvCod;
        private System.Windows.Forms.Label lblCod;
        private System.Windows.Forms.Button btnDeleteMeisaiCod;
        private System.Windows.Forms.Button btnAddMeisaiCod;
        private System.Windows.Forms.Button btnCalcSoryoKise;
        private System.Windows.Forms.Button btnCancelSoryoKise;
        private System.Windows.Forms.Button btnRegistSoryoKise;
        private System.Windows.Forms.Label lblSoryoKise;
        private System.Windows.Forms.TableLayoutPanel tblSoryoKise;
        private System.Windows.Forms.Label lblSpaceSoryoKise;
        private System.Windows.Forms.Label lblCodSoryoKise;
        private System.Windows.Forms.Label lblTdkdFukaryoSoryoKise;
        private System.Windows.Forms.Label lblTdkdhsAveSoryoKise;
        private System.Windows.Forms.Label lblTdkdhsMaxSoryoKise;
        private System.Windows.Forms.Label lblBikoSoryoKise;
        private System.Windows.Forms.Label lblTnSoryoKise;
        private System.Windows.Forms.Label lblTpSoryoKise;
        private System.Windows.Forms.Label lblSonotaSoryoKise;
        private System.Windows.Forms.Label lblKyoyoFukaryoSoryoKise;
        private System.Windows.Forms.TextBox txtCodKyoyoFukaryoSoryoKise;
        private System.Windows.Forms.TextBox textBtxtTnKyoyoFukaryoSoryoKiseox15;
        private System.Windows.Forms.TextBox txtTpKyoyoFukaryoSoryoKise;
        private System.Windows.Forms.TextBox txtSonotaKyoyoFukarySoryoKise;
        private System.Windows.Forms.TextBox txtCodTdkdFukaryoSoryoKise;
        private System.Windows.Forms.TextBox txtTnTdkdFukaryoSoryoKise;
        private System.Windows.Forms.TextBox txtTpTdkdFukaryoSoryoKise;
        private System.Windows.Forms.TextBox txtSonotaTdkdFukaryoSoryoKise;
        private System.Windows.Forms.TextBox txtTdkdhsAveSoryoKise;
        private System.Windows.Forms.TextBox txtTdkdhsMaxSoryoKise;
        private System.Windows.Forms.TextBox txtBikoSoryoKise;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn39;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn40;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn41;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn42;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn43;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn44;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn45;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn46;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn47;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn48;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn49;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn50;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn51;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn52;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn25;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn26;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn27;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn28;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn29;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn30;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn31;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn32;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn33;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn34;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn35;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn36;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn37;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn38;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column6;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column7;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column8;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column9;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column10;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column11;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column12;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column13;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column14;
        public System.Windows.Forms.CheckBox chkHaisuikijyunTekiyo;
        public System.Windows.Forms.CheckBox chkKojimaKoRyuiki;
        public System.Windows.Forms.CheckBox chkKaisuiGanyuFlag;
        private System.Windows.Forms.TextBox txtTdkdhsMax;
        private System.Windows.Forms.TextBox txtUsuiHaisuikoSu;
        private System.Windows.Forms.TextBox txtTdkdhsAve;
        private System.Windows.Forms.Label lblTdkdHsMax;
        private System.Windows.Forms.Label lblTdkdHsMaxUnit;
        private System.Windows.Forms.Label lblTdkdHsAveUnit;
        private System.Windows.Forms.Label lblUsuiHaisuikoSu;
        private System.Windows.Forms.Label lblTdkdHsAve;
        private System.Windows.Forms.Label lblCountRecordHaisuiko;
        private System.Windows.Forms.Label lblCountNumberHaisuiko;
        private System.Windows.Forms.Label lblHaisuiko;
        private System.Windows.Forms.Button btnCopyHaisuiko;
        private System.Windows.Forms.Button btnSelectHaisuiko;
        private System.Windows.Forms.Button btnHaisuikijyunTou;
        private System.Windows.Forms.Button btnHaisuikoJyoho;
        private System.Windows.Forms.Button btnAddHaisuiko;
        private System.Windows.Forms.DataGridView dgvHaisuiko;
        private System.Windows.Forms.DataGridViewTextBoxColumn SisetuNameN;
        private System.Windows.Forms.DataGridViewTextBoxColumn TdkdjuriDateShortW;
        private System.Windows.Forms.DataGridViewTextBoxColumn Biko;
        private System.Windows.Forms.DataGridViewTextBoxColumn SsNo;
        private System.Windows.Forms.BindingSource bsFutaiSetubiTou;
        private System.Windows.Forms.BindingSource bsOdakuFukaryo;
        private System.Windows.Forms.DataGridViewTextBoxColumn HaisuikoNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn SetiDateShortW;
        private System.Windows.Forms.DataGridViewTextBoxColumn HaisiDateShortW;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn21;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn22;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn23;
        private System.Windows.Forms.DataGridViewTextBoxColumn TdkdNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn TdkdKbn;
        private System.Windows.Forms.DataGridViewTextBoxColumn TodokedeDateShortW;
        private System.Windows.Forms.DataGridViewTextBoxColumn UketukeNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn TdkdSyubetu;
        private System.Windows.Forms.DataGridViewTextBoxColumn TdkdSyubetuS;
        private System.Windows.Forms.DataGridViewTextBoxColumn Biko1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Biko2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Biko3;
        private System.Windows.Forms.DataGridViewTextBoxColumn fsNoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn torimatomeFlagVDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn tsNoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sisetuNameNDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn setubiUmuFlag1VDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn setubiUmuFlag2VDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn setubiUmuFlag3VDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn setubiUmuFlag4VDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn setubiUmuFlag5VDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn setubiUmuFlag6VDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn setubiUmuFlag7VDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn HaisiFlag;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn12;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn13;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn14;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn15;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn24;
    }
}