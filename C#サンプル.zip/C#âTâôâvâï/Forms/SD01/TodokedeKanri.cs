﻿using Suisitu.Common;
using Suisitu.Dao;
using Suisitu.Entity;
using Suisitu.Enum;
using System;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace Suisitu.Forms.SD01
{
    #pragma warning disable 168

    using CommonEvents = Suisitu.Common.Events;

    /// <summary>
    /// 水質届出入出力画面クラス
    /// </summary>
    public partial class TodokedeKanri : Form
    {
        // アクションモード
        private EnumActionKbn actionMode_;

        // 工場事業場情報
        public JigyojoItiranEntity selectedItem_;

        public KojoKihonEntity beforeEditedEntity_;

        public OdakuFukaryoEntity beforeEditedOdakuFukaryoEntity_;

        #region コンストラクタ

        /// <summary>
        /// コンストラクタ
        /// </summary>
        /// <param name="key">工場事業場情報</param>
        public TodokedeKanri(JigyojoItiranEntity key = null)
        {
            //logger.Debug(Constant.LOG_METHOD_START);

            InitializeComponent();

            selectedItem_ = key;

            // 工場基本画面
            txtSyozaiYubinNo1.KeyPress += new KeyPressEventHandler(CommonEvents.txtHalfNumber_KeyPress);
            txtSyozaiYubinNo2.KeyPress += new KeyPressEventHandler(CommonEvents.txtHalfNumber_KeyPress);
            txtSinseiYubinNo1.KeyPress += new KeyPressEventHandler(CommonEvents.txtHalfNumber_KeyPress);
            txtSinseiYubinNo2.KeyPress += new KeyPressEventHandler(CommonEvents.txtHalfNumber_KeyPress);
            txtOdakuYubinNo1.KeyPress += new KeyPressEventHandler(CommonEvents.txtHalfNumber_KeyPress);
            txtOdakuYubinNo2.KeyPress += new KeyPressEventHandler(CommonEvents.txtHalfNumber_KeyPress);
            cboSangyoBC.KeyPress += new KeyPressEventHandler(CommonEvents.txtHalfNumber_KeyPress);
            cboSangyoBS.KeyPress += new KeyPressEventHandler(CommonEvents.txtHalfNumber_KeyPress);
            txtSoryoKiseiNo.KeyPress += new KeyPressEventHandler(CommonEvents.txtHalfNumber_KeyPress);
            cboHoKbnCode.KeyPress += new KeyPressEventHandler(CommonEvents.txtHalfNumber_KeyPress);
            cboSikibetuCode.KeyPress += new KeyPressEventHandler(CommonEvents.txtHalfNumber_KeyPress);
            cboRyuikiCode.KeyPress += new KeyPressEventHandler(CommonEvents.txtHalfNumber_KeyPress);
            cboGesuikbn.KeyPress += new KeyPressEventHandler(CommonEvents.txtHalfNumber_KeyPress);
            txtKankyosyoCode.KeyPress += new KeyPressEventHandler(CommonEvents.txtHalfNumber_KeyPress);

            // 汚濁負荷量画面
            txtCodKyoyoFukaryo.KeyPress += new KeyPressEventHandler(CommonEvents.txtHalfDecimal_KeyPress);
            txtCodTdkdFukaryo.KeyPress += new KeyPressEventHandler(CommonEvents.txtHalfDecimal_KeyPress);
            txtTnKyoyoFukaryo.KeyPress += new KeyPressEventHandler(CommonEvents.txtHalfDecimal_KeyPress);
            txtTnTdkdFukaryo.KeyPress += new KeyPressEventHandler(CommonEvents.txtHalfDecimal_KeyPress);
            txtTpKyoyoFukaryo.KeyPress += new KeyPressEventHandler(CommonEvents.txtHalfDecimal_KeyPress);
            txtTpTdkdFukaryo.KeyPress += new KeyPressEventHandler(CommonEvents.txtHalfDecimal_KeyPress);
            txtSonotaKyoyoFukaryo.KeyPress += new KeyPressEventHandler(CommonEvents.txtHalfDecimal_KeyPress);
            txtSonotaTdkdFukaryo.KeyPress += new KeyPressEventHandler(CommonEvents.txtHalfDecimal_KeyPress);

            //logger.Debug(Constant.LOG_METHOD_END);
        }

        #endregion

        #region イベント

        #region 共通

        /// <summary>
        /// ＜共通＞
        /// 画面が表示されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void TodokedeKanri_Load(object sender, EventArgs e)
        {
            if (selectedItem_.KanriNo < 1)
            {
                // 管理番号を採番する
                selectedItem_.KanriNo = KojoKihonDao.GetNewKanriNo(selectedItem_.Nendo);
            }

            // 共通項目のデータソースを設定する
            bsTodokedeKanri.DataSource = TodokedeKanriDao.Select(
                new TodokedeKanriEntity { Nendo = selectedItem_.Nendo, KanriNo = selectedItem_.KanriNo });

            // 工場事業場基本情報を取得する
            InitializeData();
            
            // 画面ロックマトリックスを定義する
            SetLockMatrix();
        }

        /// <summary>
        /// ＜共通＞
        /// タブページ切り替え後の処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void tabTodokedeKanri_SelectedIndexChanged(object sender, EventArgs e)
        {
            int index = tabTodokedeKanri.SelectedIndex;

            switch (index)
            {
                // 工場基本タブ
                case 0:
                    // 工場事業場基本情報を取得する
                    InitializeData();
                    break;
                // 届出履歴タブ
                case 1:
                    // 届出履歴一覧を取得する
                    InitializeDataTodokedeRireki();
                    break;
                // 特定施設等タブ
                case 2:
                    // 特定施設等一覧を取得する
                    InitializeDataTokuteiSisetuTou();
                    break;
                // 付帯設備等タブ
                case 3:
                    // 付帯設備等一覧を取得する
                    InitializeDataFutaiSetubiTou();
                    break;
                // 処理施設タブ
                case 4:
                    // 処理施設一覧を取得する
                    InitializeDataSyoriSisetu();
                    break;
                // 排水口タブ
                case 5:
                    // 排水口一覧を取得する
                    InitializeDataHaisuiko();
                    break;
                // 汚濁負荷量タブ
                case 6:
                    // 汚濁負荷量情報を取得する
                    InitializeDataOdakuFukaryo();
                    break;
                // 総量規制タブ
                case 7:
                    break;
            }
        }

        /// <summary>
        /// ＜共通＞
        /// タブページが選択解除されているときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void tabTodokedeKanri_Deselecting(object sender, TabControlCancelEventArgs e)
        {
            
            // タブ切替によって汚濁負荷量画面が終了することを明示
            tabTodokedeKanri.Tag = true;

            // 工場基本タブから遷移する場合
            if (tabTodokedeKanri.SelectedIndex == 0)
            {
                // タブ切り替え可能かチェックする
                if (!IsValidSwitchTab())
                {
                    e.Cancel = true;

                    MessageBox.Show("工場事業場基本情報を登録してください。", Text, MessageBoxButtons.OK, MessageBoxIcon.Error);

                    return;
                }

                Return();
            }
            // 汚濁負荷量タブから遷移する場合
            else if (tabTodokedeKanri.SelectedIndex == 6)
            {
                ReturnOdakuFukaryo();
            }
            // 総量規制タブから遷移する場合
            else if (tabTodokedeKanri.SelectedIndex == 7)
            {

            }
        }

        /// <summary>
        /// ＜共通＞
        /// 一覧ボタンが押下されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnItiran_Click(object sender, EventArgs e)
        {
            // 一覧ボタンによって汚濁負荷量画面が終了することを明示
            tabTodokedeKanri.Tag = null;

            // 工場基本タブを開いている場合
            if (tabTodokedeKanri.SelectedIndex == 0)
            {
                Return();
            }
            // 汚濁負荷量タブを開いている場合
            else if (tabTodokedeKanri.SelectedIndex == 6)
            {
                ReturnOdakuFukaryo();
            }
            // 総量規制タブを開いている場合
            else if (tabTodokedeKanri.SelectedIndex == 7)
            {
                
            }
            // 上記以外のタブを開いている場合
            else
            {
                // 画面を閉じるときの前処理
                ClosingPreprocessing();

                Close();
            }
        }

        /// <summary>
        /// 画面を閉じるときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void TodokedeKanri_FormClosing(object sender, FormClosingEventArgs e)
        {
            // 各種ボタンイベントから画面を閉じる場合
            if (this.Tag == null)
            {
                // 工場基本タブを開いている場合
                if (tabTodokedeKanri.SelectedIndex == 0)
                {
                    Return(e);
                }
                // 汚濁負荷量タブを開いている場合
                else if (tabTodokedeKanri.SelectedIndex == 6)
                {
                    ReturnOdakuFukaryo(e);
                }
                // 総量規制タブを開いている場合
                else if (tabTodokedeKanri.SelectedIndex == 7)
                {

                }
                // 上記以外のタブを開いている場合
                else
                {
                    // 画面を閉じるときの前処理
                    ClosingPreprocessing();

                    Close();
                }
            }
        }

        #endregion

        #region 工場基本タブ


        /// <summary>
        /// ＜工場事業場基本情報＞
        /// 登録ボタンが押下されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnRegistKojoKihon_Click(object sender, EventArgs e)
        {
            // 郵便番号の複写処理
            if (string.IsNullOrEmpty(txtSinseiYubinNo1.Text) && string.IsNullOrEmpty(txtSinseiYubinNo2.Text))
            {
                txtSinseiYubinNo1.Text = txtSyozaiYubinNo1.Text;
                txtSinseiYubinNo2.Text = txtSyozaiYubinNo2.Text;
            }

            // 登録データを作成する
            KojoKihonEntity entity = CreateRegisterData();

            // バリデーションチェックする
            if (!Validation())
                return;

            // 工場事業場基本情報情報を登録する
            Register(entity);

            // 工場事業場基本情報を取得する(編集有無チェック用データを更新）
            beforeEditedEntity_ = KojoKihonDao.Select(
                new KojoKihonEntity { Nendo = selectedItem_.Nendo, KanriNo = selectedItem_.KanriNo });
        }

        /// <summary>
        /// ＜工場事業場基本情報＞
        /// キャンセルボタンが押下されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnCancelKojoKihon_Click(object sender, EventArgs e)
        {
            // 工場事業場基本情報を取得する
            InitializeData();
        }

        /// <summary>
        /// ＜工場事業場基本情報＞
        /// ①を複写ボタンが押下されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnCopy1_Click(object sender, EventArgs e)
        {
            txtSinseiCopName.Text = txtJigyosyoNameN.Text;
            txtSinseiNameN.Text = txtKTantoNameN.Text;
            txtSinseiYubinNo1.Text = txtSyozaiYubinNo1.Text;
            txtSinseiYubinNo2.Text = txtSyozaiYubinNo2.Text;
            txtSinseiTelNo.Text = txtTelNo.Text;
            txtSinseiJyusyo.Text = txtSyozaiJyusyo.Text;
        }

        /// <summary>
        /// ＜工場事業場基本情報＞
        /// ②を複写ボタンが押下されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        private void btnCopy2_Click(object sender, EventArgs e)
        {
            txtOdakuCopName.Text = txtSinseiCopName.Text;
            txtOdakuNameN.Text = txtSinseiNameN.Text;
            txtOdakuYubinNo1.Text = txtSinseiYubinNo1.Text;
            txtOdakuYubinNo2.Text = txtSinseiYubinNo2.Text;
            txtOdakuJyusyo.Text = txtSinseiJyusyo.Text;
        }

        /// <summary>
        /// ＜工場事業場基本情報＞
        /// 有害物質使用状況ボタンが押下されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        private void btnSiyoJokyo_Click(object sender, EventArgs e)
        {
            int nendo;
            int.TryParse(txtNendo.Text == "通年" ? "9999" : txtNendo.Text, out nendo);

            int kanriNo;
            int.TryParse(txtKanriNo.Text, out kanriNo);

            // 有害物質使用状況画面を表示する
            using (var dialog = new YugaiSiyoJyokyo(nendo, kanriNo))
            {
                dialog.ShowDialog();
            }
        }

        /// <summary>
        /// ＜工場事業場基本情報＞
        /// 産業分類中分類コンボボックスの値が変更されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void cboSangyoBC_SelectedIndexChanged(object sender, Components.Controls.ValueComboEventArgs e)
        {
            // 特定施設種別(細区分)コンボボックスの初期化
            string key = cboSangyoBC.SelectedKey;
            cboSangyoBS.InitCombo(SangyoBsDao.GetMasterData(key));
        }

        #endregion

        #region 届出履歴タブ

        /// <summary>
        /// ＜届出履歴一覧画面＞
        /// 追加ボタンが押下されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnAddTodokedeRireki_Click(object sender, EventArgs e)
        {
            actionMode_ = EnumActionKbn.Add;

            // 届出履歴情報画面を表示する
            ShowTodokedeRirekiJyoho(new TodokedeRirekiEntity { Nendo = selectedItem_.Nendo, KanriNo = selectedItem_.KanriNo }, actionMode_);
        }

        /// <summary>
        /// ＜届出履歴一覧画面＞
        /// 複写ボタンが押下されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnCopyTodokedeRireki_Click(object sender, EventArgs e)
        {
            actionMode_ = EnumActionKbn.Copy;

            // 届出履歴情報画面を表示する
            ShowTodokedeRirekiJyoho((TodokedeRirekiEntity)bsTodokedeRireki.Current, actionMode_);
        }

        /// <summary>
        /// ＜届出履歴一覧画面＞
        /// 選択ボタンが押下されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnSelect_Click(object sender, EventArgs e)
        {
            actionMode_ = EnumActionKbn.Select;

            // 届出履歴情報画面を表示する
            ShowTodokedeRirekiJyoho((TodokedeRirekiEntity)bsTodokedeRireki.Current, actionMode_);
        }

        /// <summary>
        /// ＜届出履歴一覧画面＞
        /// データグリッドビューのセルがダブルクリックされたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void dgvTodokedeRireki_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (bsTodokedeRireki.Current != null)
            {
                actionMode_ = EnumActionKbn.Select;

                // 届出履歴情報画面を表示する
                ShowTodokedeRirekiJyoho((TodokedeRirekiEntity)bsTodokedeRireki.Current, actionMode_);
            }
        }

        /// <summary>
        /// ＜届出履歴一覧画面＞
        /// 届出履歴情報画面が閉じられたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void TodokedeRirekiJyoho_FormClosed(object sender, FormClosedEventArgs e)
        {
            // 届出履歴一覧を取得する
            InitializeDataTodokedeRireki();

            TodokedeRirekiJyoho form = (TodokedeRirekiJyoho)sender;
            
            if ((actionMode_ == EnumActionKbn.Add || actionMode_ == EnumActionKbn.Copy)
                && !string.IsNullOrEmpty(form.addedTdkdNo_))
            {
                int rowIndex = 0;

                foreach (DataGridViewRow row in dgvTodokedeRireki.Rows)
                {
                    if (row.Cells[0].Value.ToString().Trim() == form.addedTdkdNo_)
                    {
                        break;
                    }
                    rowIndex++;
                }
                dgvTodokedeRireki.CurrentCell = dgvTodokedeRireki[0, rowIndex];
            }
        }

        #endregion

        #region 特定施設等タブ

        /// <summary>
        /// ＜特定施設等施設一覧＞
        /// 追加ボタンが押下されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnAddTokuteiSisetu_Click(object sender, EventArgs e)
        {
            actionMode_ = EnumActionKbn.Add;

            // 特定施設等情報画面を表示する
            ShowTokuteiSisetuTouJyoho(new TokuteiSisetuTouEntity { Nendo = selectedItem_.Nendo, KanriNo = selectedItem_.KanriNo }, actionMode_);
        }

        /// <summary>
        /// ＜特定施設等施設一覧＞
        /// 複写ボタンが押下されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnCopyTokuteiSisetu_Click(object sender, EventArgs e)
        {
            actionMode_ = EnumActionKbn.Copy;

            // 特定施設等情報画面を表示する
            ShowTokuteiSisetuTouJyoho((TokuteiSisetuTouEntity)bsTokuteiSisetuTou.Current, actionMode_);
        }

        /// <summary>
        /// ＜特定施設等施設一覧＞
        /// 選択ボタンが押下されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnSelectTokuteiSisetu_Click(object sender, EventArgs e)
        {
            actionMode_ = EnumActionKbn.Select;

            // 特定施設等情報画面を表示する
            ShowTokuteiSisetuTouJyoho((TokuteiSisetuTouEntity)bsTokuteiSisetuTou.Current, actionMode_);
        }
        
        /// <summary>
        /// ＜特定施設等施設一覧＞
        /// データグリッドビューのセルがダブルクリックされたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void dgvTokuteiSisetu_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (bsTokuteiSisetuTou.Current != null)
            {
                actionMode_ = EnumActionKbn.Select;

                // 特定施設等情報画面を表示する
                ShowTokuteiSisetuTouJyoho((TokuteiSisetuTouEntity)bsTokuteiSisetuTou.Current, actionMode_);
            }
        }

        /// <summary>
        /// ＜特定施設等施設一覧＞
        /// 特定施設情報画面が閉じられたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void TokuteiSisetuTouJyoho_FormClosed(object sender, FormClosedEventArgs e)
        {
            // 特定施設等一覧を取得する
            InitializeDataTokuteiSisetuTou();
            
            TokuteiSisetuTouJyoho form = (TokuteiSisetuTouJyoho)sender;

            if ((actionMode_ == EnumActionKbn.Add || actionMode_ == EnumActionKbn.Copy)
                && !string.IsNullOrEmpty(form.addedTsNo_))
            {
                int rowIndex = 0;

                foreach (DataGridViewRow row in dgvTokuteiSisetuTou.Rows)
                {
                    if (row.Cells[0].Value.ToString().Trim() == form.addedTsNo_)
                    {
                        break;
                    }
                    rowIndex++;
                }
                dgvTokuteiSisetuTou.CurrentCell = dgvTokuteiSisetuTou[0, rowIndex];
            }
        }

        #endregion

        #region 付帯設備等タブ

        /// <summary>
        /// ＜付帯設備等一覧画面＞
        /// 追加ボタンが押下されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnAddFutaisetubi_Click(object sender, EventArgs e)
        {
            actionMode_ = EnumActionKbn.Add;

            // 届出履歴情報画面を表示する
            ShowFutaiSetubiTouJyoho(new FutaiSetubiTouEntity { Nendo = selectedItem_.Nendo, KanriNo = selectedItem_.KanriNo }, actionMode_);
        }

        /// <summary>
        /// ＜付帯設備等一覧画面＞
        /// 複写ボタンが押下されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnCopyFutaisetubi_Click(object sender, EventArgs e)
        {
            actionMode_ = EnumActionKbn.Copy;

            // 付帯設備等情報画面を表示する
            ShowFutaiSetubiTouJyoho((FutaiSetubiTouEntity)bsFutaiSetubiTou.Current, actionMode_);
        }

        /// <summary>
        /// ＜付帯設備等一覧＞
        /// 選択ボタンが押下されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnSelectFutaisetubi_Click(object sender, EventArgs e)
        {
            actionMode_ = EnumActionKbn.Select;

            // 付帯設備等情報画面を表示する
            ShowFutaiSetubiTouJyoho((FutaiSetubiTouEntity)bsFutaiSetubiTou.Current, actionMode_);
        }

        /// <summary>
        /// ＜付帯設備等一覧＞
        /// データグリッドビューのセルがダブルクリックされたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void dgvFutaiSetubiTou_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (bsFutaiSetubiTou.Current != null)
            {
                actionMode_ = EnumActionKbn.Select;

                // 付帯設備等情報画面を表示する
                ShowFutaiSetubiTouJyoho((FutaiSetubiTouEntity)bsFutaiSetubiTou.Current, actionMode_);
            }
        }

        /// <summary>
        /// ＜付帯設備等一覧＞
        /// 付帯設備等情報画面が閉じられたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void FutaiSetubiTouJyoho_FormClosed(object sender, FormClosedEventArgs e)
        {
            // 付帯設備等一覧を取得する
            InitializeDataFutaiSetubiTou();

            FutaiSetubiTouJyoho form = (FutaiSetubiTouJyoho)sender;

            if ((actionMode_ == EnumActionKbn.Add || actionMode_ == EnumActionKbn.Copy)
                && !string.IsNullOrEmpty(form.addedFsNo_))
            {
                int rowIndex = 0;

                foreach (DataGridViewRow row in dgvFutaiSetubiTou.Rows)
                {
                    if (row.Cells[10].Value.ToString().Trim() == form.addedFsNo_)
                    {
                        break;
                    }
                    rowIndex++;
                }
                dgvFutaiSetubiTou.CurrentCell = dgvFutaiSetubiTou[0, rowIndex];
            }
        }

        #endregion

        #region 処理施設タブ

        /// <summary>
        /// ＜汚水等処理施設一覧＞
        /// 追加ボタンが押下されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnAddShoriSisetu_Click(object sender, EventArgs e)
        {
            actionMode_ = EnumActionKbn.Add;

            // 処理施設情報画面を表示する
            ShowSyoriSisetuJyoho(new SyoriSisetuEntity { Nendo = selectedItem_.Nendo, KanriNo = selectedItem_.KanriNo }, actionMode_);
        }

        /// <summary>
        /// ＜汚水等処理施設一覧＞
        /// 複写ボタンが押下されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnCopyShoriSisetu_Click(object sender, EventArgs e)
        {
            actionMode_ = EnumActionKbn.Copy;

            // 処理施設情報画面を表示する
            ShowSyoriSisetuJyoho((SyoriSisetuEntity)bsShoriSisetu.Current, actionMode_);
        }

        /// <summary>
        /// ＜汚水等処理施設一覧＞
        /// 選択ボタンが押下されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnSelectShoriSisetu_Click(object sender, EventArgs e)
        {
            //new SyoriSisetuJyoho().ShowDialog();

            actionMode_ = EnumActionKbn.Select;

            // 処理施設情報画面を表示する
            ShowSyoriSisetuJyoho((SyoriSisetuEntity)bsShoriSisetu.Current, actionMode_);
        }

        /// <summary>
        /// ＜汚水等処理施設一覧＞
        /// データグリッドビューのセルがダブルクリックされたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void dgvShoriSisetu_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (bsShoriSisetu.Current != null)
            {
                actionMode_ = EnumActionKbn.Select;

                // 処理施設情報画面を表示する
                ShowSyoriSisetuJyoho((SyoriSisetuEntity)bsShoriSisetu.Current, actionMode_);
            }
        }

        /// <summary>
        /// ＜汚水等処理施設一覧＞
        /// 処理施設情報画面が閉じられたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void SyoriSisetuJyoho_FormClosed(object sender, FormClosedEventArgs e)
        {
            // 処理施設一覧を取得する
            InitializeDataSyoriSisetu();

            SyoriSisetuJyoho form = (SyoriSisetuJyoho)sender;

            if ((actionMode_ == EnumActionKbn.Add || actionMode_ == EnumActionKbn.Copy)
                && !string.IsNullOrEmpty(form.addedSsNo_))
            {
                int rowIndex = 0;

                foreach (DataGridViewRow row in dgvShoriSisetu.Rows)
                {
                    if (row.Cells[3].Value.ToString().Trim() == form.addedSsNo_)
                    {
                        break;
                    }
                    rowIndex++;
                }
                dgvShoriSisetu.CurrentCell = dgvShoriSisetu[3, rowIndex];
            }
        }

        #endregion

        #region 排水口タブ

        /// <summary>
        /// ＜排水口一覧＞
        /// 追加ボタンが押下されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnAddHaisuiko_Click(object sender, EventArgs e)
        {
            actionMode_ = EnumActionKbn.Add;

            // 排水口情報画面を表示する
            ShowHaisuikoJyoho(new HaisuikoEntity { Nendo = selectedItem_.Nendo, KanriNo = selectedItem_.KanriNo }, actionMode_);
        }

        /// <summary>
        /// ＜排水口一覧＞
        /// 複写ボタンが押下されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnCopyHaisuiko_Click(object sender, EventArgs e)
        {
            actionMode_ = EnumActionKbn.Copy;

            // 排水口情報画面を表示する
            ShowHaisuikoJyoho((HaisuikoEntity)bsHaisuiko.Current, actionMode_);
        }

        /// <summary>
        /// ＜排水口一覧＞
        /// 選択ボタンが押下されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnSelectHaisuiko_Click(object sender, EventArgs e)
        {
            //new SyoriSisetuJyoho().ShowDialog();

            actionMode_ = EnumActionKbn.Select;

            // 排水口情報画面を表示する
            ShowHaisuikoJyoho((HaisuikoEntity)bsHaisuiko.Current, actionMode_);
        }

        /// <summary>
        /// ＜排水口一覧＞
        /// データグリッドビューのセルがダブルクリックされたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void dgvHaisuiko_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (bsHaisuiko.Current != null)
            {
                actionMode_ = EnumActionKbn.Select;

                // 排水口情報画面を表示する
                ShowHaisuikoJyoho((HaisuikoEntity)bsHaisuiko.Current, actionMode_);
            }
        }

        /// <summary>
        /// ＜排水口一覧＞
        /// 排水口情報画面が閉じられたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void HaisuikoJyoho_FormClosed(object sender, FormClosedEventArgs e)
        {
            // 排水口一覧を取得する
            InitializeDataHaisuiko();

            HaisuikoJyoho form = (HaisuikoJyoho)sender;

            if ((actionMode_ == EnumActionKbn.Add || actionMode_ == EnumActionKbn.Copy)
                && !string.IsNullOrEmpty(form.addedHaisuikoNo_))
            {
                int rowIndex = 0;

                foreach (DataGridViewRow row in dgvHaisuiko.Rows)
                {
                    if (row.Cells[0].Value.ToString().Trim() == form.addedHaisuikoNo_)
                    {
                        break;
                    }
                    rowIndex++;
                }
                dgvHaisuiko.CurrentCell = dgvHaisuiko[0, rowIndex];
            }
        }

        /// <summary>
        /// ＜排水口一覧＞
        /// 排水基準等入力ボタンが押下されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnHaisuikijyunTou_Click(object sender, EventArgs e)
        {
            // 排水口基準等情報画面を表示する
            using (var dialog = new HaisuikijunTouJyoho(new HaisuikoEntity { Nendo = selectedItem_.Nendo, KanriNo = selectedItem_.KanriNo }))
            {
                dialog.ShowDialog();
            }
        }

        /// <summary>
        /// ＜排水口一覧＞
        /// 排水口情報一覧入力ボタンが押下されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnHaisuikoJyoho_Click(object sender, EventArgs e)
        {

        }

        #endregion

        #region 汚濁負荷量

        /// <summary>
        /// ＜汚濁負荷量情報＞
        /// 登録ボタンが押下されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnRegistOdakuFukaryo_Click(object sender, EventArgs e)
        {
            // バリデーションチェックする
            if (!ValidationOdakuFukaryo())
                return;

            // 登録データを作成する
            OdakuFukaryoEntity entity = CreateOdakuFukaryoRegisterData();

            // 汚濁負荷量情報情報を登録する
            Register(entity);

            // 汚濁負荷量情報を取得する(編集有無チェック用データを更新）
            beforeEditedOdakuFukaryoEntity_ = OdakuFukaryoDao.Select(
                new OdakuFukaryoEntity { Nendo = selectedItem_.Nendo, KanriNo = selectedItem_.KanriNo });

            // 汚濁負荷量情報を取得する(画面の再描画)
            InitializeDataOdakuFukaryo();
        }

        /// <summary>
        /// ＜汚濁負荷量情報＞
        /// キャンセルボタンが押下されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnCancelOdakuFukaryo_Click(object sender, EventArgs e)
        {
            // 汚濁負荷量情報を取得する
            InitializeDataOdakuFukaryo();
        }
        #endregion

        #endregion

        #region プライベートメソッド


        #region 共通

        /// <summary>
        /// ＜共通＞
        /// ロックマトリックス定義
        /// </summary>
        private void SetLockMatrix()
        {
            // 共通
            txtNendo.Enabled = false;
            txtKanriNo.Enabled = false;
            txtJigyojoSeriNo1.Enabled = false;
            txtJigyojoSeriNo2.Enabled = false;
            txtJigyojoSeriNo3.Enabled = false;
            txtJigyojoName.Enabled = false;
            txtJigyojoAdrs.Enabled = false;
            chkKyote.Enabled = false;
            chkTadasigaki.Enabled = false;

            // 工場事業場基本情報
            chkHaisuiKijun.Enabled = false;
            chkZanteiKijunFlag.Enabled = false;
            chkKyote2.Enabled = false;
            chkTadasigaki2.Enabled = false;
            chkYugaiUm.Enabled = false;
            chkYokakunin.Enabled = false;
            chkSiyoTokute1.Enabled = false;
            chkSiyoTokute1Kakosiyo.Enabled = false;
            chkSiyoTokute2.Enabled = false;
            chkSiyoTokute2Kakosiyo.Enabled = false;
            chkChozoSite.Enabled = false;
            chkChozoSiteKakosiyo.Enabled = false;
            chkKosyoTokute.Enabled = false;
            chkKosyohoJunyoSite.Enabled = false;
            chkChosataisho.Enabled = false;

            if (selectedItem_ == null)
                return;

            // 年度が通年の場合
            if (selectedItem_.Nendo == 9999)
            {
                btnRegistKojoKihon.Enabled = true;
                btnCancelKojoKihon.Enabled = true;

                // 工場事業場情報
                txtJigyosyoNameN.Enabled = true;
                txtJigyosyoNameK.Enabled = true;
                txtKTantoNameN.Enabled = true;
                txtSyozaiYubinNo1.Enabled = true;
                txtSyozaiYubinNo2.Enabled = true;
                txtTelNo.Enabled = true;
                txtSyozaiJyusyo.Enabled = true;
                txtBiko1.Enabled = true;

                // 届出・申請者情報
                btnCopy1.Enabled = true;
                txtSinseiCopName.Enabled = true;
                txtSinseiNameN.Enabled = true;
                txtSinseiYubinNo1.Enabled = true;
                txtSinseiYubinNo2.Enabled = true;
                txtSinseiTelNo.Enabled = true;
                txtSinseiJyusyo.Enabled = true;
                txtBiko2.Enabled = true;

                // 基本項目1
                cboSangyoBC.Enabled = true;
                cboSangyoBS.Enabled = true;
                txtSoryoKiseiNo.Enabled = true;
                cboHoKbnCode.Enabled = true;
                cboSikibetuCode.Enabled = true;
                cboRyuikiCode.Enabled = true;

                // 基本項目2
                chkKosyohoSite.Enabled = true;

                // 水質汚濁物質総合調査対象事業場がチェックあり
                if (chkChosataisho.Checked)
                {
                    txtKankyosyoCode.Enabled = true;
                }
                else
                {
                    txtKankyosyoCode.Enabled = false;
                }

                // 汚濁負荷量報告送付先情報
                btnCopy2.Enabled = true;
                txtOdakuCopName.Enabled = true;
                txtOdakuNameN.Enabled = true;
                txtOdakuYubinNo1.Enabled = true;
                txtOdakuYubinNo2.Enabled = true;
                txtOdakuJyusyo.Enabled = true;
                txtBiko4.Enabled = true;

                // 採水情報
                txtSaisuiNameN.Enabled = true;
                txtSaisuiFaxNo.Enabled = true;
                txtBiko5.Enabled = true;


            }
            else
            {
                btnRegistKojoKihon.Enabled = false;
                btnCancelKojoKihon.Enabled = false;

                // 工場事業場情報
                txtJigyosyoNameN.Enabled = false;
                txtJigyosyoNameK.Enabled = false;
                txtKTantoNameN.Enabled = false;
                txtSyozaiYubinNo1.Enabled = false;
                txtSyozaiYubinNo2.Enabled = false;
                txtTelNo.Enabled = false;
                txtSyozaiJyusyo.Enabled = false;
                txtBiko1.Enabled = false;

                // 届出・申請者情報
                btnCopy1.Enabled = false;
                txtSinseiCopName.Enabled = false;
                txtSinseiNameN.Enabled = false;
                txtSinseiYubinNo1.Enabled = false;
                txtSinseiYubinNo2.Enabled = false;
                txtSinseiTelNo.Enabled = false;
                txtSinseiJyusyo.Enabled = false;
                txtBiko2.Enabled = false;

                // 基本項目1
                cboSangyoBC.Enabled = false;
                cboSangyoBS.Enabled = false;
                txtSoryoKiseiNo.Enabled = false;
                cboHoKbnCode.Enabled = false;
                cboSikibetuCode.Enabled = false;
                cboRyuikiCode.Enabled = false;
                cboGesuikbn.Enabled = false;
                txtBiko3.Enabled = false;

                // 基本項目2
                chkKosyohoSite.Enabled = false;
                txtKankyosyoCode.Enabled = false;

                // 汚濁負荷量報告送付先情報
                btnCopy2.Enabled = false;
                txtOdakuCopName.Enabled = false;
                txtOdakuNameN.Enabled = false;
                txtOdakuYubinNo1.Enabled = false;
                txtOdakuYubinNo2.Enabled = false;
                txtOdakuJyusyo.Enabled = false;
                txtBiko4.Enabled = false;

                // 採水情報
                txtSaisuiNameN.Enabled = false;
                txtSaisuiFaxNo.Enabled = false;
                txtBiko5.Enabled = false;
            }
        }

        /// <summary>
        /// ＜共通＞
        /// タブ切り替えが可能かチェックします。
        /// </summary>
        /// <returns>True:チェックOK / False:チェックNG</returns>
        private bool IsValidSwitchTab()
        {
            return !string.IsNullOrEmpty(selectedItem_.JigyosyoNameN) ? true : false;
        }

        #endregion

        #region 工場基本タブ

        /// <summary>
        /// ＜工場事業場基本情報＞
        /// 画面に表示するデータを初期化します。
        /// </summary>
        private void InitializeData()
        {
            Clear();

            // 産業分類中分類コンボボックスの初期化
            cboSangyoBC.InitCombo(SangyoBcDao.GetMasterData());

            // 法区分コードコンボボックスの初期化
            cboHoKbnCode.InitCombo(KubunNameDao.GetMasterData("HOKBN"));

            // 識別コードコンボボックスの値を初期化
            cboSikibetuCode.InitCombo(SikibetuCodeDao.GetMasterData());

            // 流域コードコンボボックスの値を初期化
            cboRyuikiCode.InitCombo(RyuikiCodeDao.GetMasterData());

            // 下水区分コンボボックスの初期化
            cboGesuikbn.InitCombo(KubunNameDao.GetMasterData("GESUI"));

            if (!string.IsNullOrEmpty(selectedItem_.JigyosyoNameN))
            {
                // 工場事業場基本情報を取得する(編集前のデータを保持）
                beforeEditedEntity_ = KojoKihonDao.Select(
                    new KojoKihonEntity { Nendo = selectedItem_.Nendo, KanriNo = selectedItem_.KanriNo });

                // 工場事業場基本情報を取得する
                KojoKihonEntity entity = KojoKihonDao.Select(
                    new KojoKihonEntity { Nendo = selectedItem_.Nendo, KanriNo = selectedItem_.KanriNo });

                // 工場事業場基本情報をデータソースに設定する
                bsKojoKihon.DataSource = entity;

                cboSangyoBC.SelectedKey = entity.SangyoBC;
                cboSangyoBS.SelectedKey = entity.SangyoBS;
                cboHoKbnCode.SelectedKey = entity.HokbnCode;
                cboSikibetuCode.SelectedKey = entity.SikibetuCode;
                cboRyuikiCode.SelectedKey = entity.RyuikiCode;
                cboGesuikbn.SelectedKey = entity.GesuiKbn;
            }
            else
            {
                // 工場事業場基本情報を取得する(編集前のデータをKey以外すべてnullで保持）
                beforeEditedEntity_ = new KojoKihonEntity { Nendo = selectedItem_.Nendo, KanriNo = selectedItem_.KanriNo };
            }
        }

        /// <summary>
        /// ＜工場事業場基本情報＞
        /// 画面のクリア処理
        /// </summary>
        private void Clear()
        {
            bsKojoKihon.Clear();

            cboSangyoBC.ClearItems();
            cboSangyoBS.ClearItems();
            cboHoKbnCode.ClearItems();
            cboSikibetuCode.ClearItems();
            cboRyuikiCode.ClearItems();
            cboGesuikbn.ClearItems();
        }

        /// <summary>
        /// ＜工場事業場基本情報＞
        /// 呼び出し元の画面に戻ります。
        /// </summary>
        private void Return(FormClosingEventArgs close = null)
        {
            try
            {
                if (actionMode_ == EnumActionKbn.Add || actionMode_ == EnumActionKbn.Copy
                    || !CompareToControlsAndObject(beforeEditedEntity_))
                {
                    DialogResult result = MessageBox.Show("編集中のデータを保存しますか？", Text,
                        MessageBoxButtons.YesNo, MessageBoxIcon.Information, MessageBoxDefaultButton.Button2);

                    if (result == DialogResult.Yes)
                    {
                        // 登録データを作成する
                        KojoKihonEntity entity = CreateRegisterData();

                        // バリデーションチェックする
                        if (!Validation())
                        {
                            // FormClosingイベントを中止
                            if (close != null)
                                close.Cancel = true;

                            return;
                        }

                        // 工場事業場基本情報を登録する
                        Register(entity);

                        // 工場事業場基本情報を取得する(編集有無チェック用データを更新）
                        beforeEditedEntity_ = KojoKihonDao.Select(
                            new KojoKihonEntity { Nendo = selectedItem_.Nendo, KanriNo = selectedItem_.KanriNo });
                    }
                }
            }
            catch (Exception ex)
            {
                // なにもしない
            }

            // 一覧ボタン押下時のみ画面を閉じる
            if (tabTodokedeKanri.Tag == null)
            {
                // 画面を閉じるときの前処理
                ClosingPreprocessing();

                Close();
            }
        }

        /// <summary>
        /// ＜工場事業場基本情報＞
        /// 編集前と編集後を比較します。
        /// (データソースとコントロール値を比較します。)
        /// </summary>
        /// <param name="source">編集前のオブジェクト</param>
        /// <returns>True:差異なし / False:差異あり</returns>
        private bool CompareToControlsAndObject(KojoKihonEntity source)
        {
            // 事業所名称(漢字)
            if (txtJigyosyoNameN.Text != source.JigyosyoNameN)
                return false;

            // 事業所名称(カナ)
            if (txtJigyosyoNameK.Text != source.JigyosyoNameK)
                return false;

            // 公害担当者職名・氏名
            if (txtKTantoNameN.Text != source.KTantoNameN) 
                return false;

            // 所在地(郵便番号)1
            if (txtSyozaiYubinNo1.Text != source.SyozaiYubinNo1)
                return false;

            // 所在地(郵便番号)2
            if (txtSyozaiYubinNo2.Text != source.SyozaiYubinNo2)
                return false;

            // 連絡先電話番号
            if (txtTelNo.Text != source.TelNo)
                return false;

            // 所在地(住所)
            if (txtSyozaiJyusyo.Text != source.SyozaiJyusyo)
                return false;

            // 備考1
            if (txtBiko1.Text != source.Biko1)
                return false;

            // 申請者会社名等
            if (txtSinseiCopName.Text != source.SinseiCopName)
                return false;

            // 申請者役職名・氏名
            if (txtSinseiNameN.Text != source.SinseiNameN)
                return false;

            // 申請者(郵便番号)1
            if (txtSinseiYubinNo1.Text != source.SinseiYubinNo1)
                return false;

            // 申請者(郵便番号)2
            if (txtSinseiYubinNo2.Text != source.SinseiYubinNo2)
                return false;

            // 申請者電話番号
            if (txtSinseiTelNo.Text != source.SinseiTelNo)
                return false;

            // 申請者(住所)
            if (txtSinseiJyusyo.Text != source.SinseiJyusyo)
                return false;

            // 備考2
            if (txtBiko2.Text != source.Biko2)
                return false;

            // 産業分類（中分類）
            if (DBUtils.ConvertDaoComboBoxFormat(cboSangyoBC.SelectedKey).Trim() != source.SangyoBC.Trim())
                return false;

            // 産業分類（細分類）
            if (DBUtils.ConvertDaoComboBoxFormat(cboSangyoBS.SelectedKey).Trim() != source.SangyoBS.Trim())
                return false;

            // 総量規制番号
            if (txtSoryoKiseiNo.Text.Trim() != source.SoryoKiseiNo.Trim())
                return false;

            // 法区分コード
            if (DBUtils.ConvertDaoComboBoxFormat(cboHoKbnCode.SelectedKey).Trim() != source.HokbnCode.Trim()) 
            return false;

            // 識別コード
            if (DBUtils.ConvertDaoComboBoxFormat(cboSikibetuCode.SelectedKey).Trim() != source.SikibetuCode.Trim())
                return false;

            // 流域コード
            if (DBUtils.ConvertDaoComboBoxFormat(cboRyuikiCode.SelectedKey).Trim() != source.RyuikiCode.Trim())
                return false;

            // 下水接続区分
            if (DBUtils.ConvertDaoComboBoxFormat(cboGesuikbn.SelectedKey).Trim() != source.GesuiKbn.Trim())
                return false;

            // 備考3
            if (txtBiko3.Text != source.Biko3) 
                return false;

            // 湖沼指定施設フラグ
            if (DBUtils.ConvertDaoCheckBoxFormat(chkKosyohoSite.Checked) != source.KosyoSiteiFlag)
                return false;

            // 環境省統一コード
            if (txtKankyosyoCode.Text != source.KankyosyoCode)
                return false;

            // 汚濁負荷量報告送付先（会社名等）
            if (txtOdakuCopName.Text != source.OdakuCopName)
                return false;

            // 汚濁負荷量報告送付先（役職名・氏名）
            if (txtOdakuNameN.Text != source.OdakuNameN)
                return false;

            // 汚濁負荷量報告送付先(郵便番号)1
            if (txtOdakuYubinNo1.Text != source.OdakuYubinNo1)
                return false;

            // 汚濁負荷量報告送付先(郵便番号)2
            if (txtOdakuYubinNo2.Text != source.OdakuYubinNo2)
                return false;

            // 汚濁負荷量報告送付先(住所)
            if (txtOdakuJyusyo.Text != source.OdakuJyusyo)
                return false;

            // 備考4
            if (txtBiko4.Text != source.Biko4)
                return false;

            // 採水結果報告者名
            if (txtSaisuiNameN.Text != source.SaisuiNameN)
                return false;

            // 採水FAX送付番号
            if (txtSaisuiFaxNo.Text != source.SaisuiFaxNo)
                return false;

            // 備考5
            if (txtBiko5.Text != source.Biko5)
                return false;

            return true;
        }

        /// <summary>
        /// ＜工場事業場基本情報＞
        /// バリデーションをチェックします。
        /// </summary>
        /// <returns>True:チェックOK / False:チェックNG</returns>
        private bool Validation()
        {
            // コンボボックス入力値チェック
            if (cboSangyoBC.IsInvalid)
            {
                MessageUtils.IncorrectInputComboBoxMessage(CommonUtils.Trim(lblSangyoBC.Text), Text);
                cboSangyoBC.Focus();
                return false;
            }

            if (cboSangyoBS.IsInvalid)
            {
                MessageUtils.IncorrectInputComboBoxMessage("産業分類" + CommonUtils.Trim(lblSangyoBS.Text), Text);
                cboSangyoBS.Focus();
                return false;
            }

            if (cboHoKbnCode.IsInvalid)
            {
                MessageUtils.IncorrectInputComboBoxMessage(CommonUtils.Trim(lblHoKbnCode.Text), Text);
                cboHoKbnCode.Focus();
                return false;
            }

            if (cboSikibetuCode.IsInvalid)
            {
                MessageUtils.IncorrectInputComboBoxMessage(CommonUtils.Trim(lblSikibetuCode.Text), Text);
                cboSikibetuCode.Focus();
                return false;
            }

            if (cboRyuikiCode.IsInvalid)
            {
                MessageUtils.IncorrectInputComboBoxMessage(CommonUtils.Trim(lblRyuikiCode.Text), Text);
                cboRyuikiCode.Focus();
                return false;
            }

            if (cboGesuikbn.IsInvalid)
            {
                MessageUtils.IncorrectInputComboBoxMessage(CommonUtils.Trim(lblGesuikbn.Text), Text);
                cboGesuikbn.Focus();
                return false;
            }

            // 必須入力チェック
            if (string.IsNullOrEmpty(txtJigyosyoNameN.Text))
            {
                MessageUtils.NoInputDataMessage(CommonUtils.Trim(lblJigyosyoNameN.Text), Text);
                txtJigyosyoNameN.Focus();
                return false;
            }

            if (string.IsNullOrEmpty(cboSangyoBC.Text))
            {
                MessageUtils.NoInputDataMessage(CommonUtils.Trim(lblSangyoBC.Text), Text);
                cboSangyoBC.Focus();
                return false;
            }

            if (string.IsNullOrEmpty(cboSangyoBS.Text))
            {
                MessageUtils.NoInputDataMessage("産業分類" + CommonUtils.Trim(lblSangyoBS.Text), Text);
                cboSangyoBS.Focus();
                return false;
            }

            if (string.IsNullOrEmpty(cboHoKbnCode.Text))
            {
                MessageUtils.NoInputDataMessage(CommonUtils.Trim(lblHoKbnCode.Text), Text);
                cboHoKbnCode.Focus();
                return false;
            }

            if (string.IsNullOrEmpty(cboSikibetuCode.Text))
            {
                MessageUtils.NoInputDataMessage(CommonUtils.Trim(lblSikibetuCode.Text), Text);
                cboSikibetuCode.Focus();
                return false;
            }

            if (string.IsNullOrEmpty(cboRyuikiCode.Text))
            {
                MessageUtils.NoInputDataMessage(CommonUtils.Trim(lblRyuikiCode.Text), Text);
                cboRyuikiCode.Focus();
                return false;
            }

            // 郵便番号入力チェック
            if (!(txtSyozaiYubinNo1.Text.Length == 3 && txtSyozaiYubinNo2.Text.Length == 4
                || string.IsNullOrEmpty(txtSyozaiYubinNo1.Text) && string.IsNullOrEmpty(txtSyozaiYubinNo2.Text)))
            {
                MessageUtils.ImproprietyDigit(CommonUtils.Trim(lbltxtSyozaiYubinNo.Text), Text);
                txtSyozaiYubinNo1.Focus();
                return false;
            }

            if (!(txtSinseiYubinNo1.Text.Length == 3 && txtSinseiYubinNo2.Text.Length == 4
                || string.IsNullOrEmpty(txtSinseiYubinNo1.Text) && string.IsNullOrEmpty(txtSinseiYubinNo2.Text)))
            {
                MessageUtils.ImproprietyDigit(CommonUtils.Trim(lblSinseiYubinNo.Text), Text);
                txtSinseiYubinNo1.Focus();
                return false;
            }

            if (!(txtOdakuYubinNo1.Text.Length == 3 && txtOdakuYubinNo2.Text.Length == 4
                || string.IsNullOrEmpty(txtOdakuYubinNo1.Text) && string.IsNullOrEmpty(txtOdakuYubinNo2.Text)))
            {
                MessageUtils.ImproprietyDigit(CommonUtils.Trim(lblOdakuYubinNo.Text), Text);
                txtOdakuYubinNo1.Focus();
                return false;
            }
            
            return true;
        }

        /// <summary>
        /// ＜工場事業場基本情報＞
        /// 登録用工場事業場基本情報を作成します。
        /// </summary>
        /// <returns>届出履歴情報</returns>
        private KojoKihonEntity CreateRegisterData()
        {
            int nendo = selectedItem_ == null ? 9999 : selectedItem_.Nendo;
            int kanriNo = selectedItem_ == null ? KojoKihonDao.GetNewKanriNo(nendo) : selectedItem_.KanriNo;

            // 登録データを作成する
            KojoKihonEntity entity = new KojoKihonEntity
            {
                Nendo = nendo,
                KanriNo = kanriNo,

                // 工場事業場情報
                JigyosyoNameN = txtJigyosyoNameN.Text,
                JigyosyoNameK = txtJigyosyoNameK.Text,
                KTantoNameN = txtKTantoNameN.Text,
                SyozaiYubinNo = CommonUtils.GetYubinNo(txtSyozaiYubinNo1.Text, txtSyozaiYubinNo2.Text),
                TelNo = txtTelNo.Text,
                SyozaiJyusyo = txtSyozaiJyusyo.Text,
                Biko1 = txtBiko1.Text,

                // 届出・申請者情報
                SinseiCopName = txtSinseiCopName.Text,
                SinseiNameN = txtSinseiNameN.Text,
                SinseiYubinNo = CommonUtils.GetYubinNo(txtSinseiYubinNo1.Text, txtSinseiYubinNo2.Text),
                SinseiTelNo = txtSinseiTelNo.Text,
                SinseiJyusyo = txtSinseiJyusyo.Text,
                Biko2 = txtBiko2.Text,

                // 基本項目1
                SangyoBC = DBUtils.ConvertDaoComboBoxFormat(cboSangyoBC.SelectedKey),
                SangyoBS = DBUtils.ConvertDaoComboBoxFormat(cboSangyoBS.SelectedKey.Substring(0, 2)),
                SoryoKiseiNo = txtSoryoKiseiNo.Text,
                HokbnCode = DBUtils.ConvertDaoComboBoxFormat(cboHoKbnCode.SelectedKey),
                SikibetuCode = DBUtils.ConvertDaoComboBoxFormat(cboSikibetuCode.SelectedKey),
                RyuikiCode = DBUtils.ConvertDaoComboBoxFormat(cboRyuikiCode.SelectedKey),
                KyoteiFlag = DBUtils.ConvertDaoCheckBoxFormat(chkKyote2.Checked),
                GesuiKbn = DBUtils.ConvertDaoComboBoxFormat(cboGesuikbn.SelectedKey),
                Biko3 = txtBiko3.Text,

                // 基本項目2
                YugaiUm = chkYugaiUm.Checked ? 1 : 2,
                YokakuninFlag = DBUtils.ConvertDaoCheckBoxFormat(chkYokakunin.Checked),
                KosyoSiteiFlag = DBUtils.ConvertDaoCheckBoxFormat(chkKosyohoSite.Checked),
                KankyosyoCode = txtKankyosyoCode.Text,

                // 汚濁負荷量報告送付先情報
                OdakuCopName = txtOdakuCopName.Text,
                OdakuNameN = txtOdakuNameN.Text,
                OdakuYubinNo = CommonUtils.GetYubinNo(txtOdakuYubinNo1.Text, txtOdakuYubinNo2.Text),
                OdakuJyusyo = txtOdakuJyusyo.Text,
                Biko4 = txtBiko4.Text,

                // 採水情報
                SaisuiNameN = txtSaisuiNameN.Text,
                SaisuiFaxNo = txtSaisuiFaxNo.Text,
                Biko5 = txtBiko5.Text,
                
                TorokuDate = DateTime.Now.ToString(),
                UpdDate = DateTime.Now.ToString(),
                Rev = 1,
            };

            return entity;
        }

        /// <summary>
        /// ＜工場事業場基本情報＞
        /// 工場事業場基本情報を登録します。
        /// </summary>
        /// <param name="entity">工場事業場基本情報</param>
        private void Register(KojoKihonEntity entity)
        {
            // 該当データが存在しない場合
            if (KojoKihonDao.Select(entity) == null)
            {
                // 工場事業場基本情報を登録する
                KojoKihonDao.Insert(entity);

                // 共通項目のデータソースを設定する
                bsTodokedeKanri.DataSource = TodokedeKanriDao.Select(
                    new TodokedeKanriEntity { Nendo = selectedItem_.Nendo, KanriNo = selectedItem_.KanriNo });

                // 工場事業場情報を再設定する
                selectedItem_ = JigyojoItiranDao.Select(
                    new JigyojoItiranEntity { Nendo = selectedItem_.Nendo, KanriNo = selectedItem_.KanriNo });
            }
            // 該当データが存在する場合
            else
            {
                // 工場事業場基本情報を更新する
                KojoKihonDao.Update(entity);
            }
        }

        /// <summary>
        /// 画面を閉じるときの前処理
        /// </summary>
        private void ClosingPreprocessing()
        {
            this.Tag = true;
        }


        #endregion

        #region 届出履歴タブ

        /// <summary>
        /// ＜届出履歴一覧画面＞
        /// 画面に表示するデータを初期化します。
        /// </summary>
        private void InitializeDataTodokedeRireki()
        {
            // 届出履歴一覧を取得する
            bsTodokedeRireki.DataSource = TodokedeRirekiDao.SelectList(new TodokedeRirekiEntity { Nendo = selectedItem_.Nendo, KanriNo = selectedItem_.KanriNo });

            // 届出履歴一覧レコードカウンタを更新する
            lblCountRecordTodokedeRireki.Text = bsTodokedeRireki.Count.ToString();

            // 年度が「通年」かつ一覧の件数が1件以上存在する場合
            if (selectedItem_.Nendo == 9999 && bsTodokedeRireki.Count > 0)
            {
                btnAddTodokedeRireki.Enabled = true;
                btnCopyTodokedeRireki.Enabled = true;
                btnSelectTodokedeRireki.Enabled = true;
            }
            // 年度が「通年」以外かつ一覧の件数が1件以上存在する場合
            else if (selectedItem_.Nendo != 9999 && bsTodokedeRireki.Count > 0)
            {
                btnAddTodokedeRireki.Enabled = false;
                btnCopyTodokedeRireki.Enabled = false;
                btnSelectTodokedeRireki.Enabled = true;
            }
            // 年度が「通年」かつ一覧の件数が0件の場合
            else if (selectedItem_.Nendo == 9999 && bsTodokedeRireki.Count == 0)
            {
                btnAddTodokedeRireki.Enabled = true;
                btnCopyTodokedeRireki.Enabled = false;
                btnSelectTodokedeRireki.Enabled = false;
            }
            // 年度が「通年」以外かつ一覧の件数が0件の場合
            else if (selectedItem_.Nendo != 9999 && bsTodokedeRireki.Count == 0)
            {
                btnAddTodokedeRireki.Enabled = false;
                btnCopyTodokedeRireki.Enabled = false;
                btnSelectTodokedeRireki.Enabled = false;
            }
        }

        /// <summary>
        /// ＜届出履歴一覧画面＞
        /// 届出履歴情報画面を表示します。
        /// </summary>
        /// <param name="entity">届出履歴情報</param>
        /// <param name="mode">アクションモード</param>
        private void ShowTodokedeRirekiJyoho(TodokedeRirekiEntity entity, EnumActionKbn mode)
        {
            // 届出履歴情報画面を表示する
            using (var dialog = new TodokedeRirekiJyoho(entity, mode))
            {
                // FormClosedイベントハンドラを追加
                dialog.FormClosed += new FormClosedEventHandler(TodokedeRirekiJyoho_FormClosed);
                dialog.ShowDialog();
            }
        }

        #endregion

        #region 特定施設等タブ

        /// <summary>
        /// ＜特定施設等一覧画面＞
        /// 画面に表示するデータを初期化します。
        /// </summary>
        private void InitializeDataTokuteiSisetuTou()
        {
            // 特定施設等一覧を取得する
            bsTokuteiSisetuTou.DataSource = TokuteiSisetuTouDao.SelectList(new TokuteiSisetuTouEntity { Nendo = selectedItem_.Nendo, KanriNo = selectedItem_.KanriNo });

            // 特定施設等一覧レコードカウンタを更新する
            lblCountRecordTokuteiSisetuTou.Text = bsTokuteiSisetuTou.Count.ToString();

            // 年度が「通年」かつ一覧の件数が1件以上存在する場合
            if (selectedItem_.Nendo == 9999 && bsTokuteiSisetuTou.Count > 0)
            {
                btnAddTokuteiSisetuTou.Enabled = true;
                btnCopyTokuteiSisetuTou.Enabled = true;
                btnSelectTokuteiSisetuTou.Enabled = true;
            }
            // 年度が「通年」以外かつ一覧の件数が1件以上存在する場合
            else if (selectedItem_.Nendo != 9999 && bsTokuteiSisetuTou.Count > 0)
            {
                btnAddTokuteiSisetuTou.Enabled = false;
                btnCopyTokuteiSisetuTou.Enabled = false;
                btnSelectTokuteiSisetuTou.Enabled = true;
            }
            // 年度が「通年」かつ一覧の件数が0件の場合
            else if (selectedItem_.Nendo == 9999 && bsTokuteiSisetuTou.Count == 0)
            {
                btnAddTokuteiSisetuTou.Enabled = true;
                btnCopyTokuteiSisetuTou.Enabled = false;
                btnSelectTokuteiSisetuTou.Enabled = false;
            }
            // 年度が「通年」以外かつ一覧の件数が0件の場合
            else if (selectedItem_.Nendo != 9999 && bsTokuteiSisetuTou.Count == 0)
            {
                btnAddTokuteiSisetuTou.Enabled = false;
                btnCopyTokuteiSisetuTou.Enabled = false;
                btnSelectTokuteiSisetuTou.Enabled = false;
            }
        }

        /// <summary>
        /// ＜特定施設等一覧画面＞
        /// 特定施設等情報画面を表示します。
        /// </summary>
        /// <param name="entity">特定施設等情報</param>
        /// <param name="mode">アクションモード</param>
        private void ShowTokuteiSisetuTouJyoho(TokuteiSisetuTouEntity entity, EnumActionKbn mode)
        {
            // 特定施設等情報画面を表示する
            using (var dialog = new TokuteiSisetuTouJyoho(entity, mode))
            {
                // FormClosedイベントハンドラを追加
                dialog.FormClosed += new FormClosedEventHandler(TokuteiSisetuTouJyoho_FormClosed);
                dialog.ShowDialog();
            }
        }

        #endregion

        #region 付帯設備等タブ

        /// <summary>
        /// ＜付帯設備等一覧画面＞
        /// 画面に表示するデータを初期化します。
        /// </summary>
        private void InitializeDataFutaiSetubiTou()
        {
            // 付帯設備等一覧を取得する
            bsFutaiSetubiTou.DataSource = FutaiSetubiTouDao.SelectList(new FutaiSetubiTouEntity { Nendo = selectedItem_.Nendo, KanriNo = selectedItem_.KanriNo });

            // 付帯設備等一覧レコードカウンタを更新する
            lblCountRecordFutaiSetubiTou.Text = bsFutaiSetubiTou.Count.ToString();

            // 年度が「通年」かつ一覧の件数が1件以上存在する場合
            if (selectedItem_.Nendo == 9999 && bsFutaiSetubiTou.Count > 0)
            {
                btnAddFutaiSetubiTou.Enabled = true;
                btnCopyFutaiSetubiTou.Enabled = true;
                btnSelectFutaiSetubiTou.Enabled = true;
            }
            // 年度が「通年」以外かつ一覧の件数が1件以上存在する場合
            else if (selectedItem_.Nendo != 9999 && bsFutaiSetubiTou.Count > 0)
            {
                btnAddFutaiSetubiTou.Enabled = false;
                btnCopyFutaiSetubiTou.Enabled = false;
                btnSelectFutaiSetubiTou.Enabled = true;
            }
            // 年度が「通年」かつ一覧の件数が0件の場合
            else if (selectedItem_.Nendo == 9999 && bsFutaiSetubiTou.Count == 0)
            {
                btnAddFutaiSetubiTou.Enabled = true;
                btnCopyFutaiSetubiTou.Enabled = false;
                btnSelectFutaiSetubiTou.Enabled = false;
            }
            // 年度が「通年」以外かつ一覧の件数が0件の場合
            else if (selectedItem_.Nendo != 9999 && bsFutaiSetubiTou.Count == 0)
            {
                btnAddFutaiSetubiTou.Enabled = false;
                btnCopyFutaiSetubiTou.Enabled = false;
                btnSelectFutaiSetubiTou.Enabled = false;
            }
        }

        /// <summary>
        /// ＜付帯設備等一覧画面＞
        /// 付帯設備等情報画面を表示します。
        /// </summary>
        /// <param name="entity">付帯設備等情報</param>
        /// <param name="mode">アクションモード</param>
        private void ShowFutaiSetubiTouJyoho(FutaiSetubiTouEntity entity, EnumActionKbn mode)
        {
            // 付帯設備等情報画面を表示する
            using (var dialog = new FutaiSetubiTouJyoho(entity, mode))
            {
                // FormClosedイベントハンドラを追加
                dialog.FormClosed += new FormClosedEventHandler(FutaiSetubiTouJyoho_FormClosed);
                dialog.ShowDialog();
            }
        }

        #endregion

        #region 処理施設タブ

        /// <summary>
        /// ＜処理施設一覧画面＞
        /// 画面に表示するデータを初期化します。
        /// </summary>
        private void InitializeDataSyoriSisetu()
        {
            // 処理施設一覧を取得する
            bsShoriSisetu.DataSource = SyoriSisetuDao.SelectList(new SyoriSisetuEntity { Nendo = selectedItem_.Nendo, KanriNo = selectedItem_.KanriNo });

            // 処理施設一覧レコードカウンタを更新する
            lblCountRecordShoriSisetu.Text = bsShoriSisetu.Count.ToString();

            // 年度が「通年」かつ一覧の件数が1件以上存在する場合
            if (selectedItem_.Nendo == 9999 && bsShoriSisetu.Count > 0)
            {
                btnAddShoriSisetu.Enabled = true;
                btnCopyShoriSisetu.Enabled = true;
                btnSelectShoriSisetu.Enabled = true;
            }
            // 年度が「通年」以外かつ一覧の件数が1件以上存在する場合
            else if (selectedItem_.Nendo != 9999 && bsShoriSisetu.Count > 0)
            {
                btnAddShoriSisetu.Enabled = false;
                btnCopyShoriSisetu.Enabled = false;
                btnSelectShoriSisetu.Enabled = true;
            }
            // 年度が「通年」かつ一覧の件数が0件の場合
            else if (selectedItem_.Nendo == 9999 && bsShoriSisetu.Count == 0)
            {
                btnAddShoriSisetu.Enabled = true;
                btnCopyShoriSisetu.Enabled = false;
                btnSelectShoriSisetu.Enabled = false;
            }
            // 年度が「通年」以外かつ一覧の件数が0件の場合
            else if (selectedItem_.Nendo != 9999 && bsShoriSisetu.Count == 0)
            {
                btnAddShoriSisetu.Enabled = false;
                btnCopyShoriSisetu.Enabled = false;
                btnSelectShoriSisetu.Enabled = false;
            }
        }

        /// <summary>
        /// ＜処理施設一覧画面＞
        /// 処理施設情報画面を表示します。
        /// </summary>
        /// <param name="entity">処理施設情報</param>
        /// <param name="mode">アクションモード</param>
        private void ShowSyoriSisetuJyoho(SyoriSisetuEntity entity, EnumActionKbn mode)
        {
            // 処理施設情報画面を表示する
            using (var dialog = new SyoriSisetuJyoho(entity, mode))
            {
                // FormClosedイベントハンドラを追加
                dialog.FormClosed += new FormClosedEventHandler(SyoriSisetuJyoho_FormClosed);
                dialog.ShowDialog();
            }
        }

        #endregion

        #region 排水口タブ

        /// <summary>
        /// ＜排水口一覧画面＞
        /// 画面に表示するデータを初期化します。
        /// </summary>
        private void InitializeDataHaisuiko()
        {
            // 排水口一覧を取得する
            bsHaisuiko.DataSource = HaisuikoDao.SelectList(selectedItem_.Nendo, selectedItem_.KanriNo);

            // 排水口一覧レコードカウンタを更新する
            lblCountRecordHaisuiko.Text = bsHaisuiko.Count.ToString();

            txtTdkdhsAve.Enabled = false;
            txtTdkdhsMax.Enabled = false;
            txtUsuiHaisuikoSu.Enabled = false;
            chkKaisuiGanyuFlag.Enabled = false;
            chkHaisuikijyunTekiyo.Enabled = false;
            chkKojimaKoRyuiki.Enabled = false;

            // 年度が「通年」かつ一覧の件数が1件以上存在する場合
            if (selectedItem_.Nendo == 9999 && bsHaisuiko.Count > 0)
            {
                btnAddHaisuiko.Enabled = true;
                btnCopyHaisuiko.Enabled = true;
                btnSelectHaisuiko.Enabled = true;
            }
            // 年度が「通年」以外かつ一覧の件数が1件以上存在する場合
            else if (selectedItem_.Nendo != 9999 && bsHaisuiko.Count > 0)
            {
                btnAddHaisuiko.Enabled = false;
                btnCopyHaisuiko.Enabled = false;
                btnSelectHaisuiko.Enabled = true;
            }
            // 年度が「通年」かつ一覧の件数が0件の場合
            else if (selectedItem_.Nendo == 9999 && bsHaisuiko.Count == 0)
            {
                btnAddHaisuiko.Enabled = true;
                btnCopyHaisuiko.Enabled = false;
                btnSelectHaisuiko.Enabled = false;
            }
            // 年度が「通年」以外かつ一覧の件数が0件の場合
            else if (selectedItem_.Nendo != 9999 && bsHaisuiko.Count == 0)
            {
                btnAddHaisuiko.Enabled = false;
                btnCopyHaisuiko.Enabled = false;
                btnSelectHaisuiko.Enabled = false;
            }
        }

        /// <summary>
        /// ＜排水口一覧画面＞
        /// 排水口情報画面を表示します。
        /// </summary>
        /// <param name="entity">排水口情報</param>
        /// <param name="mode">アクションモード</param>
        private void ShowHaisuikoJyoho(HaisuikoEntity entity, EnumActionKbn mode)
        {
            // 排水口情報画面を表示する
            using (var dialog = new HaisuikoJyoho(entity, mode))
            {
                // FormClosedイベントハンドラを追加
                dialog.FormClosed += new FormClosedEventHandler(HaisuikoJyoho_FormClosed);
                dialog.ShowDialog();
            }
        }

        #endregion

        #region 汚濁負荷量タブ

        /// <summary>
        /// ＜汚濁負荷量情報＞
        /// 画面に表示するデータを初期化します。
        /// </summary>
        private void InitializeDataOdakuFukaryo()
        {
            Clear();

            if (!string.IsNullOrEmpty(selectedItem_.JigyosyoNameN))
            {
                // 汚濁負荷量情報を取得する(編集前のデータを保持）
                beforeEditedOdakuFukaryoEntity_ = OdakuFukaryoDao.Select(
                    new OdakuFukaryoEntity { Nendo = selectedItem_.Nendo, KanriNo = selectedItem_.KanriNo });

                // 汚濁負荷量情報を取得する
                OdakuFukaryoEntity entity = OdakuFukaryoDao.Select(
                    new OdakuFukaryoEntity { Nendo = selectedItem_.Nendo, KanriNo = selectedItem_.KanriNo });

                // 汚濁負荷量情報をデータソースに設定する
                if(entity != null)
                {
                    bsOdakuFukaryo.DataSource = entity;
                }
            }
            
            txtTdkdhsAveOdakuFukaryo.Enabled = false;
            txtTdkdhsMaxOdakuFukaryo.Enabled = false;

            // 年度が通年以外の場合
            if (selectedItem_.Nendo != 9999)
            {
                btnRegistOdakuFukaryo.Enabled = false;
                btnCancelOdakuFukaryo.Enabled = false;
                txtCodKyoyoFukaryo.Enabled = false;
                txtCodTdkdFukaryo.Enabled = false;
                txtTnKyoyoFukaryo.Enabled = false;
                txtTnTdkdFukaryo.Enabled = false;
                txtTpKyoyoFukaryo.Enabled = false;
                txtTpTdkdFukaryo.Enabled = false;
                txtSonotaKyoyoFukaryo.Enabled = false;
                txtSonotaTdkdFukaryo.Enabled = false;
                txtBikoOdakuFukaryo.Enabled = false;
            }
        }

        /// <summary>
        /// ＜汚濁負荷量情報＞
        /// 画面のクリア処理
        /// </summary>
        private void ClearOdakuFukaryo()
        {
            bsOdakuFukaryo.Clear();
        }

        /// <summary>
        /// ＜汚濁負荷量情報＞
        /// 呼び出し元の画面に戻ります。
        /// </summary>
        private void ReturnOdakuFukaryo(FormClosingEventArgs close = null)
        {
            try
            {
                if (actionMode_ == EnumActionKbn.Add || actionMode_ == EnumActionKbn.Copy
                    || !CompareToOdakuFukaryoObject(beforeEditedOdakuFukaryoEntity_))
                {
                    DialogResult result = MessageBox.Show("編集中のデータを保存しますか？", Text,
                        MessageBoxButtons.YesNo, MessageBoxIcon.Information, MessageBoxDefaultButton.Button2);

                    if (result == DialogResult.Yes)
                    {

                        // バリデーションチェックする
                        if (!ValidationOdakuFukaryo())
                        {
                            // FormClosingイベントを中止
                            if(close != null)
                            close.Cancel = true;

                            return;
                        }

                        // 登録データを作成する
                        OdakuFukaryoEntity entity = CreateOdakuFukaryoRegisterData();
                        
                        // 汚濁負荷量情報を登録する
                        Register(entity);

                        // 汚濁負荷量情報を取得する(編集有無チェック用データを更新）
                        beforeEditedOdakuFukaryoEntity_ = OdakuFukaryoDao.Select(
                            new OdakuFukaryoEntity { Nendo = selectedItem_.Nendo, KanriNo = selectedItem_.KanriNo });
                    }
                }
            }
            catch (Exception ex)
            {
                // なにもしない
            }

            if (tabTodokedeKanri.Tag == null)
            {
                // 画面を閉じるときの前処理
                ClosingPreprocessing();

                Close();
            }
            
        }

        /// <summary>
        /// ＜汚濁負荷量情報＞
        /// 編集前と編集後を比較します。
        /// </summary>
        /// <returns>True:差異なし / False:差異あり</returns>
        private bool CompareToOdakuFukaryoObject(OdakuFukaryoEntity desc)
        {
            // COD許容汚濁負荷量
            if (txtCodKyoyoFukaryo.Text != string.Format("{0:f1}", desc.CodKyoyoFukaryo))
                return false;

            // COD届出等汚濁負荷量
            if (txtCodTdkdFukaryo.Text != string.Format("{0:f1}", desc.CodTdkdFukaryo))
                return false;

            // T-N許容汚濁負荷量
            if (txtTnKyoyoFukaryo.Text != string.Format("{0:f1}", desc.TnKyoyoFukaryo))
                return false;

            // T-N届出等汚濁負荷量
            if (txtTnTdkdFukaryo.Text != string.Format("{0:f1}", desc.TnTdkdFukaryo))
                return false;

            // T-P許容汚濁負荷量
            if (txtTpKyoyoFukaryo.Text != string.Format("{0:f1}", desc.TpKyoyoFukaryo))
                return false;

            // T-P届出等汚濁負荷量
            if (txtTpTdkdFukaryo.Text != string.Format("{0:f1}", desc.TpTdkdFukaryo))
                return false;

            // その他許容汚濁負荷量
            if (txtSonotaKyoyoFukaryo.Text != string.Format("{0:f1}", desc.SonotaKyoyoFukaryo))
                return false;

            // その他届出等汚濁負荷量
            if (txtSonotaTdkdFukaryo.Text != string.Format("{0:f1}", desc.SonotaTdkdFukaryo))
                return false;

            // 備考
            if (txtBikoOdakuFukaryo.Text != desc.Biko)
                return false;

            return true;
        }

        /// <summary>
        /// ＜汚濁負荷量情報＞
        /// バリデーションをチェックします。
        /// </summary>
        /// <returns>True:チェックOK / False:チェックNG</returns>
        private bool ValidationOdakuFukaryo()
        {
            string minValue = "0.0";
            string maxValue = "999999999.9";

            // 書式チェック
            string regExp = @"^[0-9]{1,9}(\.[0-9]{1,1})?$";
            if (!Regex.IsMatch(txtCodKyoyoFukaryo.Text, regExp) && !string.IsNullOrEmpty(txtCodKyoyoFukaryo.Text))
            {
                MessageUtils.TypeAndRangeErrorMessage(CommonUtils.Trim(lblCodOdakuFukaryo.Text) + "許容汚濁負荷量", minValue, maxValue, Text);
                txtCodKyoyoFukaryo.Focus();
                return false;
            }
            if (!Regex.IsMatch(txtCodTdkdFukaryo.Text, regExp) && !string.IsNullOrEmpty(txtCodTdkdFukaryo.Text))
            {
                MessageUtils.TypeAndRangeErrorMessage(CommonUtils.Trim(lblCodOdakuFukaryo.Text) + "届出等汚濁負荷量", minValue, maxValue, Text);
                txtCodTdkdFukaryo.Focus();
                return false;
            }
            if (!Regex.IsMatch(txtTnKyoyoFukaryo.Text, regExp) && !string.IsNullOrEmpty(txtTnKyoyoFukaryo.Text))
            {
                MessageUtils.TypeAndRangeErrorMessage(CommonUtils.Trim(lblTnOdakuFukaryo.Text) + "許容汚濁負荷量", minValue, maxValue, Text);
                txtTnKyoyoFukaryo.Focus();
                return false;
            }
            if (!Regex.IsMatch(txtTnTdkdFukaryo.Text, regExp) && !string.IsNullOrEmpty(txtTnTdkdFukaryo.Text))
            {
                MessageUtils.TypeAndRangeErrorMessage(CommonUtils.Trim(lblTnOdakuFukaryo.Text) + "届出等汚濁負荷量", minValue, maxValue, Text);
                txtTnTdkdFukaryo.Focus();
                return false;
            }
            if (!Regex.IsMatch(txtTpKyoyoFukaryo.Text, regExp) && !string.IsNullOrEmpty(txtTpKyoyoFukaryo.Text))
            {
                MessageUtils.TypeAndRangeErrorMessage(CommonUtils.Trim(lblTpOdakuFukaryo.Text) + "許容汚濁負荷量", minValue, maxValue, Text);
                txtTpKyoyoFukaryo.Focus();
                return false;
            }
            if (!Regex.IsMatch(txtTpTdkdFukaryo.Text, regExp) && !string.IsNullOrEmpty(txtTpTdkdFukaryo.Text))
            {
                MessageUtils.TypeAndRangeErrorMessage(CommonUtils.Trim(lblTpOdakuFukaryo.Text) + "届出等汚濁負荷量", minValue, maxValue, Text);
                txtTpTdkdFukaryo.Focus();
                return false;
            }
            if (!Regex.IsMatch(txtSonotaKyoyoFukaryo.Text, regExp) && !string.IsNullOrEmpty(txtSonotaKyoyoFukaryo.Text))
            {
                MessageUtils.TypeAndRangeErrorMessage(CommonUtils.Trim(lblSonotaOdakuFukaryo.Text) + "許容汚濁負荷量", minValue, maxValue, Text);
                txtSonotaKyoyoFukaryo.Focus();
                return false;
            }
            if (!Regex.IsMatch(txtSonotaTdkdFukaryo.Text, regExp) && !string.IsNullOrEmpty(txtSonotaTdkdFukaryo.Text))
            {
                MessageUtils.TypeAndRangeErrorMessage(CommonUtils.Trim(lblSonotaOdakuFukaryo.Text) + "届出等汚濁負荷量", minValue, maxValue, Text);
                txtSonotaTdkdFukaryo.Focus();
                return false;
            }
            
            return true;
        }
        
        /// <summary>
        /// ＜汚濁負荷量情報＞
        /// 登録用汚濁負荷量情報を作成します。
        /// </summary>
        /// <returns>汚濁負荷量情報</returns>
        private OdakuFukaryoEntity CreateOdakuFukaryoRegisterData()
        {
            int nendo = selectedItem_ == null ? 9999 : selectedItem_.Nendo;
            int kanriNo = selectedItem_ == null ? KojoKihonDao.GetNewKanriNo(nendo) : selectedItem_.KanriNo;

            // 登録データを作成する
            OdakuFukaryoEntity entity = new OdakuFukaryoEntity
            {
                Nendo = nendo,
                KanriNo = kanriNo,

                // 汚濁負荷量情報
                CodKyoyoFukaryo = string.IsNullOrEmpty(txtCodKyoyoFukaryo.Text) ? 0 : double.Parse(txtCodKyoyoFukaryo.Text),
                TnKyoyoFukaryo = string.IsNullOrEmpty(txtTnKyoyoFukaryo.Text) ? 0 : double.Parse(txtTnKyoyoFukaryo.Text),
                TpKyoyoFukaryo = string.IsNullOrEmpty(txtTpKyoyoFukaryo.Text) ? 0 : double.Parse(txtTpKyoyoFukaryo.Text),
                SonotaKyoyoFukaryo = string.IsNullOrEmpty(txtSonotaKyoyoFukaryo.Text) ? 0 : double.Parse(txtSonotaKyoyoFukaryo.Text),
                CodTdkdFukaryo = string.IsNullOrEmpty(txtCodTdkdFukaryo.Text) ? 0 : double.Parse(txtCodTdkdFukaryo.Text),
                TnTdkdFukaryo = string.IsNullOrEmpty(txtTnTdkdFukaryo.Text) ? 0 : double.Parse(txtTnTdkdFukaryo.Text),
                TpTdkdFukaryo = string.IsNullOrEmpty(txtTpTdkdFukaryo.Text) ? 0 : double.Parse(txtTpTdkdFukaryo.Text),
                SonotaTdkdFukaryo = string.IsNullOrEmpty(txtSonotaTdkdFukaryo.Text) ? 0 : double.Parse(txtSonotaTdkdFukaryo.Text),
                Biko = txtBikoOdakuFukaryo.Text,
                TorokuDate = DateTime.Now.ToString(),
                UpdDate = DateTime.Now.ToString(),
                Rev = 1,
            };

            return entity;
        }

        /// <summary>
        /// ＜汚濁負荷量情報＞
        /// 汚濁負荷量情報を登録します。
        /// </summary>
        /// <param name="entity">汚濁負荷量情報</param>
        private void Register(OdakuFukaryoEntity entity)
        {
            // 該当データが存在しない場合
            if (OdakuFukaryoDao.Select(entity) == null)
            {
                // 汚濁負荷量情報を登録する
                OdakuFukaryoDao.Insert(entity);
            }
            // 該当データが存在する場合
            else
            {
                // 汚濁負荷量情報を更新する
                OdakuFukaryoDao.Update(entity);
            }
        }

        #endregion

        #endregion

    }
}
