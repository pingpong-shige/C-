﻿namespace Suisitu.Forms.SD01
{
    partial class TodokedeRirekiJyoho
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.chkYugaiSiyoHaisiFlag = new System.Windows.Forms.CheckBox();
            this.bsTodokedeRireki = new System.Windows.Forms.BindingSource(this.components);
            this.chkKojimakoRyuikiFlag = new System.Windows.Forms.CheckBox();
            this.chkHaisui50IjoFlag = new System.Windows.Forms.CheckBox();
            this.chkYugaiChozoHaisiFlag = new System.Windows.Forms.CheckBox();
            this.chkTsHaisiFlag = new System.Windows.Forms.CheckBox();
            this.chkSinkiFlag = new System.Windows.Forms.CheckBox();
            this.chkSinseiTenpuFlag = new System.Windows.Forms.CheckBox();
            this.lblKessaiDate = new System.Windows.Forms.Label();
            this.txtBiko2 = new System.Windows.Forms.TextBox();
            this.lblBiko2 = new System.Windows.Forms.Label();
            this.txtBiko3 = new System.Windows.Forms.TextBox();
            this.lblBiko3 = new System.Windows.Forms.Label();
            this.lblTsSyubetuSai = new System.Windows.Forms.Label();
            this.txtBiko1 = new System.Windows.Forms.TextBox();
            this.lblBiko1 = new System.Windows.Forms.Label();
            this.lblTodokedeDate = new System.Windows.Forms.Label();
            this.lblTdkdNo = new System.Windows.Forms.Label();
            this.lblTdkdKbn = new System.Windows.Forms.Label();
            this.lblUketukeNo = new System.Windows.Forms.Label();
            this.txtTdkdNo = new System.Windows.Forms.TextBox();
            this.txtUketukeNo = new System.Windows.Forms.TextBox();
            this.lblTsSyubetu = new System.Windows.Forms.Label();
            this.btnReturn = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnRegist = new System.Windows.Forms.Button();
            this.lblSinsaKikan = new System.Windows.Forms.Label();
            this.btnDelete = new System.Windows.Forms.Button();
            this.wdKessaiDate = new Suisitu.Components.Controls.WarekiDate();
            this.wdTodokedeDate = new Suisitu.Components.Controls.WarekiDate();
            this.cboSinsaKikan = new Suisitu.Components.Controls.ValueCombo();
            this.cboTsSyubetu = new Suisitu.Components.Controls.ValueCombo();
            this.cboTsSyubetuSai = new Suisitu.Components.Controls.ValueCombo();
            this.cboTdkdKbn = new Suisitu.Components.Controls.ValueCombo();
            this.cboTdkdKbnSai = new Suisitu.Components.Controls.ValueCombo();
            this.backColorChangeOnFocusProvider1 = new Suisitu.Component.BackColorChangeOnFocusProvider();
            ((System.ComponentModel.ISupportInitialize)(this.bsTodokedeRireki)).BeginInit();
            this.SuspendLayout();
            // 
            // chkYugaiSiyoHaisiFlag
            // 
            this.chkYugaiSiyoHaisiFlag.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.chkYugaiSiyoHaisiFlag.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bsTodokedeRireki, "YugaiSiyoHaisiFlagChk", true, System.Windows.Forms.DataSourceUpdateMode.Never));
            this.chkYugaiSiyoHaisiFlag.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.chkYugaiSiyoHaisiFlag.Location = new System.Drawing.Point(523, 162);
            this.chkYugaiSiyoHaisiFlag.Name = "chkYugaiSiyoHaisiFlag";
            this.chkYugaiSiyoHaisiFlag.Size = new System.Drawing.Size(251, 22);
            this.chkYugaiSiyoHaisiFlag.TabIndex = 19;
            this.chkYugaiSiyoHaisiFlag.Text = "有害物質使用特定施設全廃止";
            this.chkYugaiSiyoHaisiFlag.UseVisualStyleBackColor = true;
            // 
            // bsTodokedeRireki
            // 
            this.bsTodokedeRireki.DataSource = typeof(Suisitu.Entity.TodokedeRirekiEntity);
            // 
            // chkKojimakoRyuikiFlag
            // 
            this.chkKojimakoRyuikiFlag.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.chkKojimakoRyuikiFlag.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bsTodokedeRireki, "KojimaKoryuikiFlagChk", true, System.Windows.Forms.DataSourceUpdateMode.Never));
            this.chkKojimakoRyuikiFlag.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.chkKojimakoRyuikiFlag.Location = new System.Drawing.Point(523, 261);
            this.chkKojimakoRyuikiFlag.Name = "chkKojimakoRyuikiFlag";
            this.chkKojimakoRyuikiFlag.Size = new System.Drawing.Size(251, 22);
            this.chkKojimakoRyuikiFlag.TabIndex = 22;
            this.chkKojimakoRyuikiFlag.Text = "児島湖流域";
            this.chkKojimakoRyuikiFlag.UseVisualStyleBackColor = true;
            // 
            // chkHaisui50IjoFlag
            // 
            this.chkHaisui50IjoFlag.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.chkHaisui50IjoFlag.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bsTodokedeRireki, "Haisui50IjoFlagChk", true, System.Windows.Forms.DataSourceUpdateMode.Never));
            this.chkHaisui50IjoFlag.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.chkHaisui50IjoFlag.Location = new System.Drawing.Point(523, 228);
            this.chkHaisui50IjoFlag.Name = "chkHaisui50IjoFlag";
            this.chkHaisui50IjoFlag.Size = new System.Drawing.Size(251, 22);
            this.chkHaisui50IjoFlag.TabIndex = 21;
            this.chkHaisui50IjoFlag.Text = "日平均排水量50㎥以上";
            this.chkHaisui50IjoFlag.UseVisualStyleBackColor = true;
            // 
            // chkYugaiChozoHaisiFlag
            // 
            this.chkYugaiChozoHaisiFlag.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.chkYugaiChozoHaisiFlag.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bsTodokedeRireki, "YugaiChozoHaisiFlagChk", true, System.Windows.Forms.DataSourceUpdateMode.Never));
            this.chkYugaiChozoHaisiFlag.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.chkYugaiChozoHaisiFlag.Location = new System.Drawing.Point(523, 195);
            this.chkYugaiChozoHaisiFlag.Name = "chkYugaiChozoHaisiFlag";
            this.chkYugaiChozoHaisiFlag.Size = new System.Drawing.Size(251, 22);
            this.chkYugaiChozoHaisiFlag.TabIndex = 20;
            this.chkYugaiChozoHaisiFlag.Text = "有害物質貯蔵指定施設全廃止";
            this.chkYugaiChozoHaisiFlag.UseVisualStyleBackColor = true;
            // 
            // chkTsHaisiFlag
            // 
            this.chkTsHaisiFlag.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.chkTsHaisiFlag.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bsTodokedeRireki, "TsHaisiFlagChk", true, System.Windows.Forms.DataSourceUpdateMode.Never));
            this.chkTsHaisiFlag.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.chkTsHaisiFlag.Location = new System.Drawing.Point(523, 129);
            this.chkTsHaisiFlag.Name = "chkTsHaisiFlag";
            this.chkTsHaisiFlag.Size = new System.Drawing.Size(251, 22);
            this.chkTsHaisiFlag.TabIndex = 18;
            this.chkTsHaisiFlag.Text = "特定施設全廃止";
            this.chkTsHaisiFlag.UseVisualStyleBackColor = true;
            // 
            // chkSinkiFlag
            // 
            this.chkSinkiFlag.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.chkSinkiFlag.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bsTodokedeRireki, "SinkiFlagChk", true, System.Windows.Forms.DataSourceUpdateMode.Never));
            this.chkSinkiFlag.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.chkSinkiFlag.Location = new System.Drawing.Point(523, 96);
            this.chkSinkiFlag.Name = "chkSinkiFlag";
            this.chkSinkiFlag.Size = new System.Drawing.Size(251, 22);
            this.chkSinkiFlag.TabIndex = 17;
            this.chkSinkiFlag.Text = "新規設置";
            this.chkSinkiFlag.UseVisualStyleBackColor = true;
            // 
            // chkSinseiTenpuFlag
            // 
            this.chkSinseiTenpuFlag.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.chkSinseiTenpuFlag.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bsTodokedeRireki, "SinseiTenpuFlagChk", true, System.Windows.Forms.DataSourceUpdateMode.Never));
            this.chkSinseiTenpuFlag.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.chkSinseiTenpuFlag.Location = new System.Drawing.Point(523, 63);
            this.chkSinseiTenpuFlag.Name = "chkSinseiTenpuFlag";
            this.chkSinseiTenpuFlag.Size = new System.Drawing.Size(251, 22);
            this.chkSinseiTenpuFlag.TabIndex = 16;
            this.chkSinseiTenpuFlag.Text = "実施期間短縮申請書添付有";
            this.chkSinseiTenpuFlag.UseVisualStyleBackColor = true;
            // 
            // lblKessaiDate
            // 
            this.lblKessaiDate.AutoSize = true;
            this.lblKessaiDate.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblKessaiDate.Location = new System.Drawing.Point(15, 226);
            this.lblKessaiDate.Name = "lblKessaiDate";
            this.lblKessaiDate.Size = new System.Drawing.Size(90, 24);
            this.lblKessaiDate.TabIndex = 128;
            this.lblKessaiDate.Text = "決裁年月日";
            this.lblKessaiDate.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtBiko2
            // 
            this.txtBiko2.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsTodokedeRireki, "BIKO2", true, System.Windows.Forms.DataSourceUpdateMode.Never));
            this.txtBiko2.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtBiko2.ImeMode = System.Windows.Forms.ImeMode.Hiragana;
            this.txtBiko2.Location = new System.Drawing.Point(169, 388);
            this.txtBiko2.MaxLength = 20;
            this.txtBiko2.Name = "txtBiko2";
            this.txtBiko2.Size = new System.Drawing.Size(316, 31);
            this.txtBiko2.TabIndex = 14;
            // 
            // lblBiko2
            // 
            this.lblBiko2.AutoSize = true;
            this.lblBiko2.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblBiko2.Location = new System.Drawing.Point(15, 391);
            this.lblBiko2.Name = "lblBiko2";
            this.lblBiko2.Size = new System.Drawing.Size(138, 24);
            this.lblBiko2.TabIndex = 126;
            this.lblBiko2.Text = "申請、届出内容２";
            this.lblBiko2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtBiko3
            // 
            this.txtBiko3.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsTodokedeRireki, "BIKO3", true, System.Windows.Forms.DataSourceUpdateMode.Never));
            this.txtBiko3.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtBiko3.ImeMode = System.Windows.Forms.ImeMode.Hiragana;
            this.txtBiko3.Location = new System.Drawing.Point(169, 421);
            this.txtBiko3.MaxLength = 100;
            this.txtBiko3.Multiline = true;
            this.txtBiko3.Name = "txtBiko3";
            this.txtBiko3.Size = new System.Drawing.Size(316, 60);
            this.txtBiko3.TabIndex = 15;
            // 
            // lblBiko3
            // 
            this.lblBiko3.AutoSize = true;
            this.lblBiko3.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblBiko3.Location = new System.Drawing.Point(15, 424);
            this.lblBiko3.Name = "lblBiko3";
            this.lblBiko3.Size = new System.Drawing.Size(42, 24);
            this.lblBiko3.TabIndex = 124;
            this.lblBiko3.Text = "備考";
            this.lblBiko3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblTsSyubetuSai
            // 
            this.lblTsSyubetuSai.AutoSize = true;
            this.lblTsSyubetuSai.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblTsSyubetuSai.Location = new System.Drawing.Point(15, 325);
            this.lblTsSyubetuSai.Name = "lblTsSyubetuSai";
            this.lblTsSyubetuSai.Size = new System.Drawing.Size(106, 24);
            this.lblTsSyubetuSai.TabIndex = 123;
            this.lblTsSyubetuSai.Text = "　　　細区分";
            this.lblTsSyubetuSai.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtBiko1
            // 
            this.txtBiko1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsTodokedeRireki, "BIKO1", true, System.Windows.Forms.DataSourceUpdateMode.Never));
            this.txtBiko1.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtBiko1.ImeMode = System.Windows.Forms.ImeMode.Hiragana;
            this.txtBiko1.Location = new System.Drawing.Point(169, 355);
            this.txtBiko1.MaxLength = 20;
            this.txtBiko1.Name = "txtBiko1";
            this.txtBiko1.Size = new System.Drawing.Size(316, 31);
            this.txtBiko1.TabIndex = 13;
            // 
            // lblBiko1
            // 
            this.lblBiko1.AutoSize = true;
            this.lblBiko1.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblBiko1.Location = new System.Drawing.Point(15, 358);
            this.lblBiko1.Name = "lblBiko1";
            this.lblBiko1.Size = new System.Drawing.Size(138, 24);
            this.lblBiko1.TabIndex = 116;
            this.lblBiko1.Text = "申請、届出内容１";
            this.lblBiko1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblTodokedeDate
            // 
            this.lblTodokedeDate.AutoSize = true;
            this.lblTodokedeDate.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblTodokedeDate.Location = new System.Drawing.Point(15, 193);
            this.lblTodokedeDate.Name = "lblTodokedeDate";
            this.lblTodokedeDate.Size = new System.Drawing.Size(90, 24);
            this.lblTodokedeDate.TabIndex = 114;
            this.lblTodokedeDate.Text = "届出年月日";
            this.lblTodokedeDate.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblTdkdNo
            // 
            this.lblTdkdNo.AutoSize = true;
            this.lblTdkdNo.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblTdkdNo.Location = new System.Drawing.Point(15, 61);
            this.lblTdkdNo.Name = "lblTdkdNo";
            this.lblTdkdNo.Size = new System.Drawing.Size(106, 24);
            this.lblTdkdNo.TabIndex = 107;
            this.lblTdkdNo.Text = "履歴管理番号";
            this.lblTdkdNo.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblTdkdKbn
            // 
            this.lblTdkdKbn.AutoSize = true;
            this.lblTdkdKbn.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblTdkdKbn.Location = new System.Drawing.Point(15, 94);
            this.lblTdkdKbn.Name = "lblTdkdKbn";
            this.lblTdkdKbn.Size = new System.Drawing.Size(74, 24);
            this.lblTdkdKbn.TabIndex = 109;
            this.lblTdkdKbn.Text = "届出区分";
            this.lblTdkdKbn.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblUketukeNo
            // 
            this.lblUketukeNo.AutoSize = true;
            this.lblUketukeNo.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblUketukeNo.Location = new System.Drawing.Point(15, 160);
            this.lblUketukeNo.Name = "lblUketukeNo";
            this.lblUketukeNo.Size = new System.Drawing.Size(74, 24);
            this.lblUketukeNo.TabIndex = 110;
            this.lblUketukeNo.Text = "受付番号";
            this.lblUketukeNo.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtTdkdNo
            // 
            this.txtTdkdNo.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsTodokedeRireki, "TdkdNo", true, System.Windows.Forms.DataSourceUpdateMode.Never));
            this.txtTdkdNo.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtTdkdNo.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.txtTdkdNo.Location = new System.Drawing.Point(169, 58);
            this.txtTdkdNo.MaxLength = 3;
            this.txtTdkdNo.Name = "txtTdkdNo";
            this.txtTdkdNo.Size = new System.Drawing.Size(57, 31);
            this.txtTdkdNo.TabIndex = 4;
            // 
            // txtUketukeNo
            // 
            this.txtUketukeNo.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsTodokedeRireki, "UketukeNo", true, System.Windows.Forms.DataSourceUpdateMode.Never));
            this.txtUketukeNo.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtUketukeNo.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.txtUketukeNo.Location = new System.Drawing.Point(169, 157);
            this.txtUketukeNo.MaxLength = 6;
            this.txtUketukeNo.Name = "txtUketukeNo";
            this.txtUketukeNo.Size = new System.Drawing.Size(72, 31);
            this.txtUketukeNo.TabIndex = 7;
            // 
            // lblTsSyubetu
            // 
            this.lblTsSyubetu.AutoSize = true;
            this.lblTsSyubetu.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblTsSyubetu.Location = new System.Drawing.Point(15, 292);
            this.lblTsSyubetu.Name = "lblTsSyubetu";
            this.lblTsSyubetu.Size = new System.Drawing.Size(106, 24);
            this.lblTsSyubetu.TabIndex = 112;
            this.lblTsSyubetu.Text = "特定施設種別";
            this.lblTsSyubetu.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // btnReturn
            // 
            this.btnReturn.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnReturn.Location = new System.Drawing.Point(759, 15);
            this.btnReturn.Name = "btnReturn";
            this.btnReturn.Size = new System.Drawing.Size(100, 30);
            this.btnReturn.TabIndex = 3;
            this.btnReturn.Text = "戻る";
            this.btnReturn.UseVisualStyleBackColor = true;
            this.btnReturn.Click += new System.EventHandler(this.btnReturn_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnCancel.Location = new System.Drawing.Point(653, 15);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(100, 30);
            this.btnCancel.TabIndex = 2;
            this.btnCancel.Text = "キャンセル";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnRegist
            // 
            this.btnRegist.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnRegist.Location = new System.Drawing.Point(547, 15);
            this.btnRegist.Name = "btnRegist";
            this.btnRegist.Size = new System.Drawing.Size(100, 30);
            this.btnRegist.TabIndex = 1;
            this.btnRegist.Text = "登録";
            this.btnRegist.UseVisualStyleBackColor = true;
            this.btnRegist.Click += new System.EventHandler(this.btnRegist_Click);
            // 
            // lblSinsaKikan
            // 
            this.lblSinsaKikan.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblSinsaKikan.Location = new System.Drawing.Point(15, 259);
            this.lblSinsaKikan.Name = "lblSinsaKikan";
            this.lblSinsaKikan.Size = new System.Drawing.Size(76, 20);
            this.lblSinsaKikan.TabIndex = 138;
            this.lblSinsaKikan.Text = "審査期間";
            this.lblSinsaKikan.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // btnDelete
            // 
            this.btnDelete.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnDelete.Location = new System.Drawing.Point(759, 494);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(100, 30);
            this.btnDelete.TabIndex = 23;
            this.btnDelete.Text = "削除";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // wdKessaiDate
            // 
            this.wdKessaiDate.Location = new System.Drawing.Point(169, 223);
            this.wdKessaiDate.Name = "wdKessaiDate";
            this.wdKessaiDate.Size = new System.Drawing.Size(103, 31);
            this.wdKessaiDate.TabIndex = 9;
            // 
            // wdTodokedeDate
            // 
            this.wdTodokedeDate.Location = new System.Drawing.Point(169, 190);
            this.wdTodokedeDate.Name = "wdTodokedeDate";
            this.wdTodokedeDate.Size = new System.Drawing.Size(103, 31);
            this.wdTodokedeDate.TabIndex = 8;
            // 
            // cboSinsaKikan
            // 
            this.cboSinsaKikan.Location = new System.Drawing.Point(169, 256);
            this.cboSinsaKikan.MaxLength = 1;
            this.cboSinsaKikan.Name = "cboSinsaKikan";
            this.cboSinsaKikan.Size = new System.Drawing.Size(316, 31);
            this.cboSinsaKikan.TabIndex = 10;
            this.cboSinsaKikan.Value = "-1";
            // 
            // cboTsSyubetu
            // 
            this.cboTsSyubetu.Location = new System.Drawing.Point(169, 289);
            this.cboTsSyubetu.MaxLength = 3;
            this.cboTsSyubetu.Name = "cboTsSyubetu";
            this.cboTsSyubetu.Size = new System.Drawing.Size(316, 31);
            this.cboTsSyubetu.TabIndex = 11;
            this.cboTsSyubetu.Value = "-1";
            this.cboTsSyubetu.SelectedIndexChanged += new Suisitu.Components.Controls.ValueCombo.SelectedIndexChangedHandler(this.cboTsSyubetu_SelectedIndexChanged);
            // 
            // cboTsSyubetuSai
            // 
            this.cboTsSyubetuSai.Location = new System.Drawing.Point(169, 322);
            this.cboTsSyubetuSai.MaxLength = 1;
            this.cboTsSyubetuSai.Name = "cboTsSyubetuSai";
            this.cboTsSyubetuSai.Size = new System.Drawing.Size(316, 31);
            this.cboTsSyubetuSai.TabIndex = 12;
            this.cboTsSyubetuSai.Value = "-1";
            this.cboTsSyubetuSai.SelectedIndexChanged += new Suisitu.Components.Controls.ValueCombo.SelectedIndexChangedHandler(this.cboTsSyubetuSai_SelectedIndexChanged);
            // 
            // cboTdkdKbn
            // 
            this.cboTdkdKbn.Location = new System.Drawing.Point(169, 91);
            this.cboTdkdKbn.MaxLength = 1;
            this.cboTdkdKbn.Name = "cboTdkdKbn";
            this.cboTdkdKbn.Size = new System.Drawing.Size(316, 31);
            this.cboTdkdKbn.TabIndex = 5;
            this.cboTdkdKbn.Value = "-1";
            this.cboTdkdKbn.SelectedIndexChanged += new Suisitu.Components.Controls.ValueCombo.SelectedIndexChangedHandler(this.cboTdkdKbn_SelectedIndexChanged);
            // 
            // cboTdkdKbnSai
            // 
            this.cboTdkdKbnSai.Location = new System.Drawing.Point(169, 124);
            this.cboTdkdKbnSai.MaxLength = 4;
            this.cboTdkdKbnSai.Name = "cboTdkdKbnSai";
            this.cboTdkdKbnSai.Size = new System.Drawing.Size(316, 31);
            this.cboTdkdKbnSai.TabIndex = 6;
            this.cboTdkdKbnSai.Value = "-1";
            // 
            // backColorChangeOnFocusProvider1
            // 
            this.backColorChangeOnFocusProvider1.Target = this;
            // 
            // TodokedeRirekiJyoho
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.ClientSize = new System.Drawing.Size(874, 542);
            this.Controls.Add(this.wdKessaiDate);
            this.Controls.Add(this.wdTodokedeDate);
            this.Controls.Add(this.btnReturn);
            this.Controls.Add(this.cboSinsaKikan);
            this.Controls.Add(this.btnRegist);
            this.Controls.Add(this.cboTsSyubetu);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.cboTsSyubetuSai);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.cboTdkdKbn);
            this.Controls.Add(this.lblTsSyubetu);
            this.Controls.Add(this.cboTdkdKbnSai);
            this.Controls.Add(this.txtUketukeNo);
            this.Controls.Add(this.lblSinsaKikan);
            this.Controls.Add(this.txtTdkdNo);
            this.Controls.Add(this.chkYugaiSiyoHaisiFlag);
            this.Controls.Add(this.lblUketukeNo);
            this.Controls.Add(this.chkKojimakoRyuikiFlag);
            this.Controls.Add(this.lblTdkdKbn);
            this.Controls.Add(this.chkHaisui50IjoFlag);
            this.Controls.Add(this.lblTdkdNo);
            this.Controls.Add(this.chkYugaiChozoHaisiFlag);
            this.Controls.Add(this.lblTodokedeDate);
            this.Controls.Add(this.chkTsHaisiFlag);
            this.Controls.Add(this.lblBiko1);
            this.Controls.Add(this.chkSinkiFlag);
            this.Controls.Add(this.txtBiko1);
            this.Controls.Add(this.chkSinseiTenpuFlag);
            this.Controls.Add(this.lblTsSyubetuSai);
            this.Controls.Add(this.lblKessaiDate);
            this.Controls.Add(this.lblBiko3);
            this.Controls.Add(this.txtBiko2);
            this.Controls.Add(this.txtBiko3);
            this.Controls.Add(this.lblBiko2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "TodokedeRirekiJyoho";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "届出履歴情報";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.TodokedeRirekiJyoho_FormClosing);
            this.Load += new System.EventHandler(this.TodokedeRirekiJyoho_Load);
            ((System.ComponentModel.ISupportInitialize)(this.bsTodokedeRireki)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.CheckBox chkYugaiSiyoHaisiFlag;
        private System.Windows.Forms.CheckBox chkKojimakoRyuikiFlag;
        private System.Windows.Forms.CheckBox chkHaisui50IjoFlag;
        private System.Windows.Forms.CheckBox chkYugaiChozoHaisiFlag;
        private System.Windows.Forms.CheckBox chkTsHaisiFlag;
        private System.Windows.Forms.CheckBox chkSinkiFlag;
        private System.Windows.Forms.CheckBox chkSinseiTenpuFlag;
        private System.Windows.Forms.Label lblKessaiDate;
        private System.Windows.Forms.TextBox txtBiko2;
        private System.Windows.Forms.Label lblBiko2;
        private System.Windows.Forms.TextBox txtBiko3;
        private System.Windows.Forms.Label lblBiko3;
        private System.Windows.Forms.Label lblTsSyubetuSai;
        private System.Windows.Forms.TextBox txtBiko1;
        private System.Windows.Forms.Label lblBiko1;
        private System.Windows.Forms.Label lblTodokedeDate;
        private System.Windows.Forms.Label lblTdkdNo;
        private System.Windows.Forms.Label lblTdkdKbn;
        private System.Windows.Forms.Label lblUketukeNo;
        private System.Windows.Forms.TextBox txtTdkdNo;
        private System.Windows.Forms.TextBox txtUketukeNo;
        private System.Windows.Forms.Label lblTsSyubetu;
        private System.Windows.Forms.Button btnReturn;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnRegist;
        private System.Windows.Forms.Label lblSinsaKikan;
        private System.Windows.Forms.BindingSource bsTodokedeRireki;
        private Components.Controls.ValueCombo cboTdkdKbnSai;
        private Components.Controls.ValueCombo cboTdkdKbn;
        private Components.Controls.ValueCombo cboTsSyubetu;
        private Components.Controls.ValueCombo cboTsSyubetuSai;
        private Components.Controls.ValueCombo cboSinsaKikan;
        private Components.Controls.WarekiDate wdKessaiDate;
        private Components.Controls.WarekiDate wdTodokedeDate;
        private System.Windows.Forms.Button btnDelete;
        private Component.BackColorChangeOnFocusProvider backColorChangeOnFocusProvider1;
    }
}