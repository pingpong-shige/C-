﻿using Suisitu.Common;
using Suisitu.Dao;
using Suisitu.Entity;
using Suisitu.Enum;
using System;
using System.Windows.Forms;

namespace Suisitu.Forms.SD01
{
    #pragma warning disable 168

    using CommonEvents = Suisitu.Common.Events;

    /// <summary>
    /// 届出履歴情報画面クラス
    /// </summary>
    public partial class TodokedeRirekiJyoho : Form
    {
        // 届出履歴情報
        private TodokedeRirekiEntity selectedItem_ ;

        // アクションモード
        private EnumActionKbn actionMode_;

        // 新規追加された届出履歴番号(届出履歴一覧のフォーカス用)
        public string addedTdkdNo_ = "";

        #region コンストラクタ

        /// <summary>
        /// コンストラクタ
        /// </summary>
        /// <param name="key">届出履歴情報</param>
        /// <param name="mode">アクションモード</param>
        public TodokedeRirekiJyoho(TodokedeRirekiEntity key, EnumActionKbn mode)
        {
            InitializeComponent();

            selectedItem_ = key;
            actionMode_ = mode;

            cboTdkdKbn.KeyPress += new KeyPressEventHandler(CommonEvents.txtHalfNumber_KeyPress);
            cboTdkdKbnSai.KeyPress += new KeyPressEventHandler(CommonEvents.txtHalfNumber_KeyPress);
            txtUketukeNo.KeyPress += new KeyPressEventHandler(CommonEvents.txtHalfAll_KeyPress);
            wdTodokedeDate.KeyPress += new KeyPressEventHandler(CommonEvents.txtHalfNumber_KeyPress);
            wdKessaiDate.KeyPress += new KeyPressEventHandler(CommonEvents.txtHalfNumber_KeyPress);
            cboSinsaKikan.KeyPress += new KeyPressEventHandler(CommonEvents.txtHalfNumber_KeyPress);
            cboTsSyubetu.KeyPress += new KeyPressEventHandler(CommonEvents.txtHalfNumber_KeyPress);
            cboTsSyubetuSai.KeyPress += new KeyPressEventHandler(CommonEvents.txtHalfNumber_KeyPress);
        }
        #endregion

        #region イベント

        /// <summary>
        /// 画面が表示されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void TodokedeRirekiJyoho_Load(object sender, EventArgs e)
        {
            // 画面ロックマトリックスを定義する
            SetLockMatrix();

            // データを画面表示する
            InitializeData();
        }

        /// <summary>
        /// 戻るボタンが選択されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnReturn_Click(object sender, EventArgs e)
        {
            Return();
        }

        /// <summary>
        /// キャンセルボタンが選択されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnCancel_Click(object sender, EventArgs e)
        {
            InitializeData();
        }

        /// <summary>
        /// 登録ボタンが選択されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnRegist_Click(object sender, EventArgs e)
        {
            // 登録データを作成する
            TodokedeRirekiEntity entity = CreateRegisterData();

            // バリデーションチェックする
            if (!Validation(entity))
                return;

            // 届出履歴情報を登録する
            Register(entity);

            // 画面を閉じるときの前処理
            ClosingPreprocessing();

            Close();
        }

        /// <summary>
        /// 削除ボタンが選択されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnDelete_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("表示中のデータを削除します。よろしいですか？", Text,
                MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button2);

            if (result == DialogResult.Yes)
            {
                TodokedeRirekiDao.Delete((TodokedeRirekiEntity)bsTodokedeRireki.Current);
            }

            // 画面を閉じるときの前処理
            ClosingPreprocessing();

            Close();
        }

        /// <summary>
        /// 届出区分(法区分)コンボボックスの値が変更されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void cboTdkdKbn_SelectedIndexChanged(object sender, Components.Controls.ValueComboEventArgs e)
        {
            // 届出区分(細区分)コンボボックスの初期化
            string key = cboTdkdKbn.SelectedKey;
            cboTdkdKbnSai.InitCombo(TodokedeKbnDao.GetMasterData(key));
        }

        /// <summary>
        /// 特定施設種別コンボボックスの値が変更されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void cboTsSyubetu_SelectedIndexChanged(object sender, Components.Controls.ValueComboEventArgs e)
        {
            // 特定施設種別(細区分)コンボボックスの初期化
            string key = cboTsSyubetu.SelectedKey;
            cboTsSyubetuSai.InitCombo(TsSyubetuSaiDao.GetMasterData(key));
        }

        /// <summary>
        /// 特定施設種細区分コンボボックスの値が変更されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void cboTsSyubetuSai_SelectedIndexChanged(object sender, Components.Controls.ValueComboEventArgs e)
        {
            if (string.IsNullOrEmpty(txtBiko3.Text))
            {
                txtBiko3.Text = cboTsSyubetuSai.SelectedValue;
                //bsTodokedeRireki.Current
            }
        }

        /// <summary>
        /// 画面を閉じるときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void TodokedeRirekiJyoho_FormClosing(object sender, FormClosingEventArgs e)
        {
            // 各種ボタンイベントから画面を閉じる場合
            if (this.Tag == null)
                Return(e);
        }

        #endregion

        #region プライベートメソッド

        /// <summary>
        /// 画面に表示するデータを初期化します。
        /// </summary>
        private void InitializeData()
        {
            Clear();

            // 届出区分(法区分)コンボボックスの初期化
            cboTdkdKbn.InitCombo(KubunNameDao.GetMasterData("HOKBN"));

            // 特定施設種別コンボボックスの初期化
            cboTsSyubetu.InitCombo(TsSyubetuDao.GetMasterData());

            // 審査期間コンボボックスの値を初期化
            cboSinsaKikan.InitCombo(KubunNameDao.GetMasterData("SINSA"));

            switch (actionMode_)
            {
                // 選択、複写の場合
                case EnumActionKbn.Select:
                case EnumActionKbn.Copy:

                    TodokedeRirekiEntity descEntity = new TodokedeRirekiEntity();
                    BeanUtils.CopyObjectProperties(selectedItem_, descEntity);

                    if (actionMode_ == EnumActionKbn.Copy)
                    {
                        descEntity.TdkdNo = TodokedeRirekiDao.GetNewTdkdNo(descEntity);
                    }

                    bsTodokedeRireki.DataSource = descEntity;

                    cboTdkdKbn.SelectedKey = descEntity.HokbnCode;
                    cboTdkdKbnSai.SelectedKey = descEntity.TdkdKbn;
                    wdTodokedeDate.Value = descEntity.TodokedeDate;
                    wdKessaiDate.Value = descEntity.KessaiDate;
                    cboTsSyubetu.SelectedKey = descEntity.TdkdSyubetu;
                    cboTsSyubetuSai.SelectedKey = descEntity.TdkdSyubetuS;
                    cboSinsaKikan.SelectedKey = descEntity.SinsaKikan;

                    break;

                // 追加の場合
                case EnumActionKbn.Add:
                    KojoKihonEntity kojoKihonEntity = KojoKihonDao.Select(
                        new KojoKihonEntity { Nendo = selectedItem_.Nendo, KanriNo = selectedItem_.KanriNo });

                    txtTdkdNo.Text = TodokedeRirekiDao.GetNewTdkdNo(selectedItem_);
                    chkHaisui50IjoFlag.Checked = StoredProcDao.IsHaisuiryo50m3ijo(selectedItem_.Nendo,selectedItem_.KanriNo);
                    chkKojimakoRyuikiFlag.Checked = StoredProcDao.FNC_IsKojimakoRyuiki(kojoKihonEntity.RyuikiCode);

                    break;
            }
        }

        /// <summary>
        /// ロックマトリックス定義
        /// </summary>
        private void SetLockMatrix()
        {
            txtTdkdNo.Enabled = false;

            // 追加と複写の場合は削除ボタンを入力不可にする
            if (actionMode_ == EnumActionKbn.Add || actionMode_ == EnumActionKbn.Copy)
            {
                btnDelete.Enabled = false;
            }

            // 年度が通年以外の場合
            if (selectedItem_.Nendo != 9999)
            {
                btnRegist.Enabled = false;
                btnCancel.Enabled = false;
                btnDelete.Enabled = false;
                cboTdkdKbn.Enabled = false;
                cboTdkdKbnSai.Enabled = false;
                txtUketukeNo.Enabled = false;
                wdTodokedeDate.Enabled = false;
                wdKessaiDate.Enabled = false;
                cboSinsaKikan.Enabled = false;
                cboTsSyubetu.Enabled = false;
                cboTsSyubetuSai.Enabled = false;
                txtBiko1.Enabled = false;
                txtBiko2.Enabled = false;
                txtBiko3.Enabled = false;
                chkSinseiTenpuFlag.Enabled = false;
                chkSinkiFlag.Enabled = false;
                chkTsHaisiFlag.Enabled = false;
                chkYugaiSiyoHaisiFlag.Enabled = false;
                chkYugaiChozoHaisiFlag.Enabled = false;
                chkHaisui50IjoFlag.Enabled = false;
                chkKojimakoRyuikiFlag.Enabled = false;
            }
        }

        /// <summary>
        /// 画面のクリア処理
        /// </summary>
        private void Clear()
        {
            bsTodokedeRireki.Clear();

            cboTdkdKbn.ClearItems();
            cboTdkdKbnSai.ClearItems();
            wdTodokedeDate.Value = null;
            wdKessaiDate.Value = null;
            cboSinsaKikan.ClearItems();
            cboTsSyubetu.ClearItems();
            cboTsSyubetuSai.ClearItems();
        }

        /// <summary>
        /// 呼び出し元の画面に戻ります。
        /// </summary>
        private void Return(FormClosingEventArgs close = null)
        {
            try
            {
                if (actionMode_ == EnumActionKbn.Add || actionMode_ == EnumActionKbn.Copy
                    || !CompareToControlsAndObject(selectedItem_))
                {
                    DialogResult result = MessageBox.Show("編集中のデータを保存しますか？", Text,
                        MessageBoxButtons.YesNo, MessageBoxIcon.Information, MessageBoxDefaultButton.Button2);

                    if (result == DialogResult.Yes)
                    {
                        // 登録データを作成する
                        TodokedeRirekiEntity entity = CreateRegisterData();

                        // バリデーションチェックする
                        if (!Validation(entity))
                        {
                            // FormClosingイベントを中止
                            if(close != null)
                            close.Cancel = true;

                            return;
                        }

                        // 届出履歴情報を登録する
                        Register(entity);
                    }
                }
            }
            catch (Exception ex)
            {
                // なにもしない
            }

            // 画面を閉じるときの前処理
            ClosingPreprocessing();

            Close();
        }

        /// <summary>
        /// 編集前と編集後を比較します。
        /// (データソースとコントロール値を比較します。)
        /// </summary>
        /// <param name="source">編集前のオブジェクト</param>
        /// <returns>True:差異なし / False:差異あり</returns>
        private bool CompareToControlsAndObject(TodokedeRirekiEntity source)
        {
            // 届出履歴管理番号
            if (txtTdkdNo.Text != source.TdkdNo)
                return false;

            // 届出区分(法区分)
            if (DBUtils.ConvertDaoComboBoxFormat(cboTdkdKbn.SelectedKey) != source.HokbnCode.Trim())
                return false;

            // 届出区分(条項)
            if (DBUtils.ConvertDaoComboBoxFormat(cboTdkdKbnSai.SelectedKey) != source.TdkdKbn.Trim())
                return false;

            // 受付番号
            if (txtUketukeNo.Text != source.UketukeNo)
                return false;

            // 届出年月日
            if (CommonUtils.FormatToDate(wdTodokedeDate.Value) != source.TodokedeDate)
                return false;

            // 決裁年月日
            if (CommonUtils.FormatToDate(wdKessaiDate.Value) != source.KessaiDate)
                return false;

            // 審査期間
            if (DBUtils.ConvertDaoComboBoxFormat(cboSinsaKikan.SelectedKey) != source.SinsaKikan.Trim())
                return false;

            // 特定施設種別
            if (DBUtils.ConvertDaoComboBoxFormat(cboTsSyubetu.SelectedKey) != source.TdkdSyubetu.Trim())
                return false;

            // 特定施設種別細区分
            if (DBUtils.ConvertDaoComboBoxFormat(cboTsSyubetuSai.SelectedKey) != source.TdkdSyubetuS.Trim())
                return false;

            // 申請、届出内容1
            if (txtBiko1.Text != source.Biko1)
                return false;

            // 申請、届出内容2
            if (txtBiko2.Text != source.Biko2)
                return false;

            // 備考
            if (txtBiko3.Text != source.Biko3)
                return false;

            // 実施機関短縮申請書添付有
            if (DBUtils.ConvertDaoCheckBoxFormat(chkSinseiTenpuFlag.Checked) != source.SinseiTenpuFlag)
                return false;

            // 新規設置
            if (DBUtils.ConvertDaoCheckBoxFormat(chkSinkiFlag.Checked) != source.SinkiFlag)
                    return false;

            // 特定施設全廃止
            if (DBUtils.ConvertDaoCheckBoxFormat(chkTsHaisiFlag.Checked) != source.TsHaisiFlag)
                return false;

            // 有害物質使用特定施設全廃止
            if (DBUtils.ConvertDaoCheckBoxFormat(chkYugaiSiyoHaisiFlag.Checked) != source.YugaiSiyoHaisiFlag)
                return false;

            // 有害物質貯蔵特定施設全廃止
            if (DBUtils.ConvertDaoCheckBoxFormat(chkYugaiChozoHaisiFlag.Checked) != source.YugaiChozoHaisiFlag)
                return false;

            // 日平均排水量50㎥
            if (DBUtils.ConvertDaoCheckBoxFormat(chkHaisui50IjoFlag.Checked) != source.Haisui50IjoFlag)
                return false;

            // 児島湖流域
            if (DBUtils.ConvertDaoCheckBoxFormat(chkKojimakoRyuikiFlag.Checked) != source.KojimaKoryuikiFlag)
                return false;

            return true;
        }

        /// <summary>
        /// バリデーションをチェックします。
        /// </summary>
        /// <returns>True:チェックOK / False:チェックNG</returns>
        private bool Validation(TodokedeRirekiEntity entity)
        {
            // コンボボックス入力値チェック
            if (cboTdkdKbn.IsInvalid)
            {
                MessageUtils.IncorrectInputComboBoxMessage(CommonUtils.Trim(lblTdkdKbn.Text) + "(法区分)", Text);
                cboTdkdKbn.Focus();
                return false;
            }

            if (cboTdkdKbnSai.IsInvalid)
            {
                MessageUtils.IncorrectInputComboBoxMessage(CommonUtils.Trim(lblTdkdKbn.Text) + "(条項)", Text);
                cboTdkdKbnSai.Focus();
                return false;
            }

            if (cboSinsaKikan.IsInvalid)
            {
                MessageUtils.IncorrectInputComboBoxMessage(CommonUtils.Trim(lblSinsaKikan.Text), Text);
                cboSinsaKikan.Focus();
                return false;
            }

            if (cboTsSyubetu.IsInvalid)
            {
                MessageUtils.IncorrectInputComboBoxMessage(CommonUtils.Trim(lblTsSyubetu.Text), Text);
                cboTsSyubetu.Focus();
                return false;
            }

            if (cboTsSyubetuSai.IsInvalid)
            {
                MessageUtils.IncorrectInputComboBoxMessage(CommonUtils.Trim(lblTsSyubetu.Text) + CommonUtils.Trim(lblTsSyubetuSai.Text), Text);
                cboTsSyubetuSai.Focus();
                return false;
            }

            // 必須入力チェック
            if (string.IsNullOrEmpty(cboTdkdKbn.Text))
            {
                MessageUtils.NoInputDataMessage(CommonUtils.Trim(lblTdkdKbn.Text) + "(法区分)", Text);
                cboTdkdKbn.Focus();
                return false;
            }

            if (string.IsNullOrEmpty(cboTdkdKbnSai.Text))
            {
                MessageUtils.NoInputDataMessage(CommonUtils.Trim(lblTdkdKbn.Text) + "(条項)", Text);
                cboTdkdKbnSai.Focus();
                return false;
            }

            if (string.IsNullOrEmpty(wdTodokedeDate.Value))
            {
                MessageUtils.NoInputDataMessage(CommonUtils.Trim(lblTodokedeDate.Text), Text);
                wdTodokedeDate.Focus();
                return false;
            }

            // 日付整合性チェック
            if (!ValidationUtils.ValidateConcistencyDate(wdTodokedeDate.Value, wdKessaiDate.Value))
            {
                MessageUtils.NotConcistencyDate(CommonUtils.Trim(lblTodokedeDate.Text), CommonUtils.Trim(lblKessaiDate.Text), Text);
                wdKessaiDate.Focus();
                return false;
            }

            // 条件つき必須入力チェック
            // 法区分が1（水濁法）で届出区分が"1111（第５条第１項）"、"1112（第５条第２項）"、"1113（第５条第３項）"、"112（第７条）"のいずれか
            if (cboTdkdKbn.SelectedKey == "1"&& (
                cboTdkdKbnSai.SelectedKey == "1111" || cboTdkdKbnSai.SelectedKey == "1112"
                || cboTdkdKbnSai.SelectedKey == "1113" || cboTdkdKbnSai.SelectedKey == "112"))
            {
                if (string.IsNullOrEmpty(cboSinsaKikan.Text))
                {
                    MessageUtils.NoInputDataMessage(CommonUtils.Trim(lblSinsaKikan.Text), Text);
                    cboSinsaKikan.Focus();
                    return false;
                }
            }
            return true;
        }

        /// <summary>
        /// 登録用届出履歴情報を作成します。
        /// </summary>
        /// <returns>届出履歴情報</returns>
        private TodokedeRirekiEntity CreateRegisterData()
        {
            // 登録データを作成する
            TodokedeRirekiEntity entity = new TodokedeRirekiEntity
            {
                Nendo = selectedItem_.Nendo,
                KanriNo = selectedItem_.KanriNo,
                TdkdNo = txtTdkdNo.Text,
                TodokedeDate = CommonUtils.FormatToDate(wdTodokedeDate.Value),
                KessaiDate = CommonUtils.FormatToDate(wdKessaiDate.Value),
                UketukeNo = txtUketukeNo.Text,
                HokbnCode = DBUtils.ConvertDaoComboBoxFormat(cboTdkdKbn.SelectedKey),
                TdkdSyubetu = DBUtils.ConvertDaoComboBoxFormat(cboTsSyubetu.SelectedKey),
                TdkdSyubetuS = DBUtils.ConvertDaoComboBoxFormat(cboTsSyubetuSai.SelectedKey),
                TdkdKbn = DBUtils.ConvertDaoComboBoxFormat(cboTdkdKbnSai.SelectedKey),
                Biko1 = txtBiko1.Text,
                Biko2 = txtBiko2.Text,
                Biko3 = txtBiko3.Text,
                SinsaKikan = DBUtils.ConvertDaoComboBoxFormat(cboSinsaKikan.SelectedKey),
                SinseiTenpuFlag = DBUtils.ConvertDaoCheckBoxFormat(chkSinseiTenpuFlag.Checked),
                SinkiFlag = DBUtils.ConvertDaoCheckBoxFormat(chkSinkiFlag.Checked),
                TsHaisiFlag = DBUtils.ConvertDaoCheckBoxFormat(chkTsHaisiFlag.Checked),
                YugaiSiyoHaisiFlag = DBUtils.ConvertDaoCheckBoxFormat(chkYugaiSiyoHaisiFlag.Checked),
                YugaiChozoHaisiFlag = DBUtils.ConvertDaoCheckBoxFormat(chkYugaiChozoHaisiFlag.Checked),
                Haisui50IjoFlag = DBUtils.ConvertDaoCheckBoxFormat(chkHaisui50IjoFlag.Checked),
                KojimaKoryuikiFlag = DBUtils.ConvertDaoCheckBoxFormat(chkKojimakoRyuikiFlag.Checked),
                TorokuDate = DateTime.Now.ToString(),
                UpdDate = DateTime.Now.ToString(),
                Rev = 1,
            };

            return entity;
        }

        /// <summary>
        /// 届出履歴情報を登録します。
        /// </summary>
        /// <param name="entity">届出履歴情報</param>
        private void Register(TodokedeRirekiEntity entity)
        {
            // 該当データが存在しない場合
            if (TodokedeRirekiDao.Select(entity) == null)
            {
                // 届出履歴情報を登録する
                TodokedeRirekiDao.Insert(entity);

                // 登録された届出履歴番号を保持する
                addedTdkdNo_ = entity.TdkdNo;
            }
            // 該当データが存在する場合
            else
            {
                // 届出履歴情報を更新する
                TodokedeRirekiDao.Update(entity);
            }
        }

        /// <summary>
        /// 画面を閉じるときの前処理
        /// </summary>
        private void ClosingPreprocessing()
        {
            this.Tag = true;
        }

        #endregion
    }
}
