﻿namespace Suisitu.Forms.SD01
{
    partial class TokuteiSisetuTouItiranJyoho
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.dgvTokuteiSisetu = new System.Windows.Forms.DataGridView();
            this.HaisiFlag = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn24 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.設置基数 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.設置年月日 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.廃止年月日 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnReturn = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTokuteiSisetu)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvTokuteiSisetu
            // 
            this.dgvTokuteiSisetu.AllowUserToAddRows = false;
            this.dgvTokuteiSisetu.AllowUserToDeleteRows = false;
            this.dgvTokuteiSisetu.AllowUserToResizeColumns = false;
            this.dgvTokuteiSisetu.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvTokuteiSisetu.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvTokuteiSisetu.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvTokuteiSisetu.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.HaisiFlag,
            this.dataGridViewTextBoxColumn24,
            this.Column1,
            this.Column2,
            this.Column3,
            this.設置基数,
            this.設置年月日,
            this.廃止年月日,
            this.Column4,
            this.Column5});
            this.dgvTokuteiSisetu.Location = new System.Drawing.Point(15, 60);
            this.dgvTokuteiSisetu.MultiSelect = false;
            this.dgvTokuteiSisetu.Name = "dgvTokuteiSisetu";
            this.dgvTokuteiSisetu.ReadOnly = true;
            this.dgvTokuteiSisetu.RowHeadersVisible = false;
            this.dgvTokuteiSisetu.RowTemplate.Height = 21;
            this.dgvTokuteiSisetu.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvTokuteiSisetu.Size = new System.Drawing.Size(933, 411);
            this.dgvTokuteiSisetu.TabIndex = 0;
            // 
            // HaisiFlag
            // 
            this.HaisiFlag.DataPropertyName = "HaisiFlag";
            this.HaisiFlag.HeaderText = "廃止";
            this.HaisiFlag.Name = "HaisiFlag";
            this.HaisiFlag.ReadOnly = true;
            this.HaisiFlag.Width = 70;
            // 
            // dataGridViewTextBoxColumn24
            // 
            this.dataGridViewTextBoxColumn24.DataPropertyName = "TsNo";
            this.dataGridViewTextBoxColumn24.HeaderText = "施設番号";
            this.dataGridViewTextBoxColumn24.Name = "dataGridViewTextBoxColumn24";
            this.dataGridViewTextBoxColumn24.ReadOnly = true;
            // 
            // Column1
            // 
            this.Column1.HeaderText = "特定施設種別";
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            // 
            // Column2
            // 
            this.Column2.HeaderText = "細区分";
            this.Column2.Name = "Column2";
            this.Column2.ReadOnly = true;
            this.Column2.Width = 85;
            // 
            // Column3
            // 
            this.Column3.HeaderText = "代表フラグ";
            this.Column3.Name = "Column3";
            this.Column3.ReadOnly = true;
            this.Column3.Width = 85;
            // 
            // 設置基数
            // 
            this.設置基数.HeaderText = "設置 基数";
            this.設置基数.Name = "設置基数";
            this.設置基数.ReadOnly = true;
            this.設置基数.Width = 65;
            // 
            // 設置年月日
            // 
            this.設置年月日.HeaderText = "設置年月日";
            this.設置年月日.Name = "設置年月日";
            this.設置年月日.ReadOnly = true;
            this.設置年月日.Width = 120;
            // 
            // 廃止年月日
            // 
            this.廃止年月日.HeaderText = "廃止年月日";
            this.廃止年月日.Name = "廃止年月日";
            this.廃止年月日.ReadOnly = true;
            this.廃止年月日.Width = 120;
            // 
            // Column4
            // 
            this.Column4.HeaderText = "備考";
            this.Column4.Name = "Column4";
            this.Column4.ReadOnly = true;
            this.Column4.Width = 220;
            // 
            // Column5
            // 
            this.Column5.HeaderText = "施設番号";
            this.Column5.Name = "Column5";
            this.Column5.ReadOnly = true;
            // 
            // btnReturn
            // 
            this.btnReturn.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnReturn.Location = new System.Drawing.Point(848, 15);
            this.btnReturn.Name = "btnReturn";
            this.btnReturn.Size = new System.Drawing.Size(100, 30);
            this.btnReturn.TabIndex = 1;
            this.btnReturn.Text = "戻る";
            this.btnReturn.UseVisualStyleBackColor = true;
            // 
            // TokuteiSisetuTouItiranJyoho
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.ClientSize = new System.Drawing.Size(963, 487);
            this.Controls.Add(this.btnReturn);
            this.Controls.Add(this.dgvTokuteiSisetu);
            this.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "TokuteiSisetuTouItiranJyoho";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "特定施設等一覧情報";
            ((System.ComponentModel.ISupportInitialize)(this.dgvTokuteiSisetu)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvTokuteiSisetu;
        private System.Windows.Forms.Button btnReturn;
        private System.Windows.Forms.DataGridViewTextBoxColumn HaisiFlag;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn24;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn 設置基数;
        private System.Windows.Forms.DataGridViewTextBoxColumn 設置年月日;
        private System.Windows.Forms.DataGridViewTextBoxColumn 廃止年月日;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
    }
}