﻿using System.Windows.Forms;

namespace Suisitu.Forms.SD01
{
    /// <summary>
    /// 特定施設等一覧情報画面クラス
    /// </summary>
    public partial class TokuteiSisetuTouItiranJyoho : Form
    {
        public TokuteiSisetuTouItiranJyoho()
        {
            InitializeComponent();
        }
    }
}
