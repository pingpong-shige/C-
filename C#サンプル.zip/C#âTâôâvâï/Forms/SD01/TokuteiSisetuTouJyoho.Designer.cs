﻿namespace Suisitu.Forms.SD01
{
    partial class TokuteiSisetuTouJyoho
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lblSeiriNo = new System.Windows.Forms.Label();
            this.txtSeiriNo2 = new System.Windows.Forms.TextBox();
            this.bsTokuteiSisetuTou = new System.Windows.Forms.BindingSource(this.components);
            this.txtSeiriNo1 = new System.Windows.Forms.TextBox();
            this.lblSeiriNoHi = new System.Windows.Forms.Label();
            this.chkYugaiTikaSintouFlag = new System.Windows.Forms.CheckBox();
            this.chkYugaiSiyoFlag = new System.Windows.Forms.CheckBox();
            this.lblTsSyubetu = new System.Windows.Forms.Label();
            this.lblSisetuNameN = new System.Windows.Forms.Label();
            this.txtSisetuNameN = new System.Windows.Forms.TextBox();
            this.txtSisetuSu = new System.Windows.Forms.TextBox();
            this.lblSisetuKbn = new System.Windows.Forms.Label();
            this.chkDaihyoFlag = new System.Windows.Forms.CheckBox();
            this.lblSetiDate = new System.Windows.Forms.Label();
            this.txtBiko = new System.Windows.Forms.TextBox();
            this.lblBiko = new System.Windows.Forms.Label();
            this.lblSisetuSu = new System.Windows.Forms.Label();
            this.lblTsNo = new System.Windows.Forms.Label();
            this.lblTsSyubetuSai = new System.Windows.Forms.Label();
            this.lblDaihyoFlag = new System.Windows.Forms.Label();
            this.txtTsNo = new System.Windows.Forms.TextBox();
            this.lblHaisiDate = new System.Windows.Forms.Label();
            this.btnReturn = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnGetSeiriNo = new System.Windows.Forms.Button();
            this.btnRegist = new System.Windows.Forms.Button();
            this.dgvYugaiSiyoJyokyo = new System.Windows.Forms.DataGridView();
            this.komokuNameNDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.GsiyoFlagChk = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.KsiyoFlagChk = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.bikoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bsTsYugaiSiyo = new System.Windows.Forms.BindingSource(this.components);
            this.wrkHaisiDate = new Suisitu.Components.Controls.WarekiDate();
            this.wrkSetiDate = new Suisitu.Components.Controls.WarekiDate();
            this.cboSisetuKbn = new Suisitu.Components.Controls.ValueCombo();
            this.cboTsSyubetuSai = new Suisitu.Components.Controls.ValueCombo();
            this.cboTsSyubetu = new Suisitu.Components.Controls.ValueCombo();
            this.backColorChangeOnFocusProvider1 = new Suisitu.Component.BackColorChangeOnFocusProvider();
            this.bsKomokuCode = new System.Windows.Forms.BindingSource(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.bsTokuteiSisetuTou)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvYugaiSiyoJyokyo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsTsYugaiSiyo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsKomokuCode)).BeginInit();
            this.SuspendLayout();
            // 
            // lblSeiriNo
            // 
            this.lblSeiriNo.AutoSize = true;
            this.lblSeiriNo.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblSeiriNo.Location = new System.Drawing.Point(15, 258);
            this.lblSeiriNo.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblSeiriNo.Name = "lblSeiriNo";
            this.lblSeiriNo.Size = new System.Drawing.Size(74, 24);
            this.lblSeiriNo.TabIndex = 125;
            this.lblSeiriNo.Text = "整理番号";
            // 
            // txtSeiriNo2
            // 
            this.txtSeiriNo2.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsTokuteiSisetuTou, "SeiriNo2", true));
            this.txtSeiriNo2.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtSeiriNo2.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.txtSeiriNo2.Location = new System.Drawing.Point(186, 255);
            this.txtSeiriNo2.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.txtSeiriNo2.MaxLength = 4;
            this.txtSeiriNo2.Name = "txtSeiriNo2";
            this.txtSeiriNo2.Size = new System.Drawing.Size(46, 31);
            this.txtSeiriNo2.TabIndex = 11;
            // 
            // bsTokuteiSisetuTou
            // 
            this.bsTokuteiSisetuTou.DataSource = typeof(Suisitu.Entity.TokuteiSisetuTouEntity);
            // 
            // txtSeiriNo1
            // 
            this.txtSeiriNo1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsTokuteiSisetuTou, "SeiriNo1", true));
            this.txtSeiriNo1.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtSeiriNo1.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.txtSeiriNo1.Location = new System.Drawing.Point(123, 255);
            this.txtSeiriNo1.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.txtSeiriNo1.MaxLength = 3;
            this.txtSeiriNo1.Name = "txtSeiriNo1";
            this.txtSeiriNo1.Size = new System.Drawing.Size(40, 31);
            this.txtSeiriNo1.TabIndex = 10;
            // 
            // lblSeiriNoHi
            // 
            this.lblSeiriNoHi.AutoSize = true;
            this.lblSeiriNoHi.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblSeiriNoHi.Location = new System.Drawing.Point(167, 258);
            this.lblSeiriNoHi.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblSeiriNoHi.Name = "lblSeiriNoHi";
            this.lblSeiriNoHi.Size = new System.Drawing.Size(17, 24);
            this.lblSeiriNoHi.TabIndex = 127;
            this.lblSeiriNoHi.Text = "-";
            // 
            // chkYugaiTikaSintouFlag
            // 
            this.chkYugaiTikaSintouFlag.AutoSize = true;
            this.chkYugaiTikaSintouFlag.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.chkYugaiTikaSintouFlag.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bsTokuteiSisetuTou, "YugaiTikasintouFlagChk", true));
            this.chkYugaiTikaSintouFlag.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.chkYugaiTikaSintouFlag.Location = new System.Drawing.Point(13, 423);
            this.chkYugaiTikaSintouFlag.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.chkYugaiTikaSintouFlag.Name = "chkYugaiTikaSintouFlag";
            this.chkYugaiTikaSintouFlag.Size = new System.Drawing.Size(125, 28);
            this.chkYugaiTikaSintouFlag.TabIndex = 17;
            this.chkYugaiTikaSintouFlag.Text = "有害地下浸透";
            this.chkYugaiTikaSintouFlag.UseVisualStyleBackColor = true;
            // 
            // chkYugaiSiyoFlag
            // 
            this.chkYugaiSiyoFlag.AutoSize = true;
            this.chkYugaiSiyoFlag.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.chkYugaiSiyoFlag.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bsTokuteiSisetuTou, "YugaiSiyoFlagChk", true));
            this.chkYugaiSiyoFlag.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.chkYugaiSiyoFlag.Location = new System.Drawing.Point(13, 390);
            this.chkYugaiSiyoFlag.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.chkYugaiSiyoFlag.Name = "chkYugaiSiyoFlag";
            this.chkYugaiSiyoFlag.Size = new System.Drawing.Size(125, 28);
            this.chkYugaiSiyoFlag.TabIndex = 16;
            this.chkYugaiSiyoFlag.Text = "有害物質使用";
            this.chkYugaiSiyoFlag.UseVisualStyleBackColor = true;
            // 
            // lblTsSyubetu
            // 
            this.lblTsSyubetu.AutoSize = true;
            this.lblTsSyubetu.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblTsSyubetu.Location = new System.Drawing.Point(15, 159);
            this.lblTsSyubetu.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblTsSyubetu.Name = "lblTsSyubetu";
            this.lblTsSyubetu.Size = new System.Drawing.Size(106, 24);
            this.lblTsSyubetu.TabIndex = 113;
            this.lblTsSyubetu.Text = "特定施設種別";
            this.lblTsSyubetu.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblSisetuNameN
            // 
            this.lblSisetuNameN.AutoSize = true;
            this.lblSisetuNameN.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblSisetuNameN.Location = new System.Drawing.Point(15, 126);
            this.lblSisetuNameN.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblSisetuNameN.Name = "lblSisetuNameN";
            this.lblSisetuNameN.Size = new System.Drawing.Size(74, 24);
            this.lblSisetuNameN.TabIndex = 111;
            this.lblSisetuNameN.Text = "施設名称";
            this.lblSisetuNameN.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtSisetuNameN
            // 
            this.txtSisetuNameN.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsTokuteiSisetuTou, "SISETUNAMEN", true, System.Windows.Forms.DataSourceUpdateMode.Never));
            this.txtSisetuNameN.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtSisetuNameN.ImeMode = System.Windows.Forms.ImeMode.Hiragana;
            this.txtSisetuNameN.Location = new System.Drawing.Point(123, 123);
            this.txtSisetuNameN.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.txtSisetuNameN.Name = "txtSisetuNameN";
            this.txtSisetuNameN.Size = new System.Drawing.Size(283, 31);
            this.txtSisetuNameN.TabIndex = 6;
            // 
            // txtSisetuSu
            // 
            this.txtSisetuSu.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsTokuteiSisetuTou, "SISETUSU", true, System.Windows.Forms.DataSourceUpdateMode.Never));
            this.txtSisetuSu.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtSisetuSu.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.txtSisetuSu.Location = new System.Drawing.Point(123, 288);
            this.txtSisetuSu.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.txtSisetuSu.Name = "txtSisetuSu";
            this.txtSisetuSu.Size = new System.Drawing.Size(59, 31);
            this.txtSisetuSu.TabIndex = 13;
            // 
            // lblSisetuKbn
            // 
            this.lblSisetuKbn.AutoSize = true;
            this.lblSisetuKbn.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblSisetuKbn.Location = new System.Drawing.Point(15, 93);
            this.lblSisetuKbn.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblSisetuKbn.Name = "lblSisetuKbn";
            this.lblSisetuKbn.Size = new System.Drawing.Size(74, 24);
            this.lblSisetuKbn.TabIndex = 105;
            this.lblSisetuKbn.Text = "施設区分";
            this.lblSisetuKbn.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // chkDaihyoFlag
            // 
            this.chkDaihyoFlag.AutoSize = true;
            this.chkDaihyoFlag.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bsTokuteiSisetuTou, "DaihyoFlagChk", true));
            this.chkDaihyoFlag.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkDaihyoFlag.Location = new System.Drawing.Point(123, 224);
            this.chkDaihyoFlag.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.chkDaihyoFlag.Name = "chkDaihyoFlag";
            this.chkDaihyoFlag.Size = new System.Drawing.Size(61, 28);
            this.chkDaihyoFlag.TabIndex = 9;
            this.chkDaihyoFlag.Text = "代表";
            this.chkDaihyoFlag.UseVisualStyleBackColor = true;
            this.chkDaihyoFlag.CheckedChanged += new System.EventHandler(this.chkDaihyoFlag_CheckedChanged);
            // 
            // lblSetiDate
            // 
            this.lblSetiDate.AutoSize = true;
            this.lblSetiDate.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblSetiDate.Location = new System.Drawing.Point(15, 324);
            this.lblSetiDate.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblSetiDate.Name = "lblSetiDate";
            this.lblSetiDate.Size = new System.Drawing.Size(90, 24);
            this.lblSetiDate.TabIndex = 94;
            this.lblSetiDate.Text = "届出年月日";
            this.lblSetiDate.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtBiko
            // 
            this.txtBiko.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsTokuteiSisetuTou, "BIKO", true, System.Windows.Forms.DataSourceUpdateMode.Never));
            this.txtBiko.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtBiko.ImeMode = System.Windows.Forms.ImeMode.Hiragana;
            this.txtBiko.Location = new System.Drawing.Point(123, 453);
            this.txtBiko.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.txtBiko.Multiline = true;
            this.txtBiko.Name = "txtBiko";
            this.txtBiko.Size = new System.Drawing.Size(283, 60);
            this.txtBiko.TabIndex = 18;
            // 
            // lblBiko
            // 
            this.lblBiko.AutoSize = true;
            this.lblBiko.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblBiko.Location = new System.Drawing.Point(15, 456);
            this.lblBiko.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblBiko.Name = "lblBiko";
            this.lblBiko.Size = new System.Drawing.Size(42, 24);
            this.lblBiko.TabIndex = 90;
            this.lblBiko.Text = "備考";
            this.lblBiko.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblSisetuSu
            // 
            this.lblSisetuSu.AutoSize = true;
            this.lblSisetuSu.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblSisetuSu.Location = new System.Drawing.Point(15, 291);
            this.lblSisetuSu.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblSisetuSu.Name = "lblSisetuSu";
            this.lblSisetuSu.Size = new System.Drawing.Size(74, 24);
            this.lblSisetuSu.TabIndex = 76;
            this.lblSisetuSu.Text = "設置基数";
            this.lblSisetuSu.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblTsNo
            // 
            this.lblTsNo.AutoSize = true;
            this.lblTsNo.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblTsNo.Location = new System.Drawing.Point(15, 60);
            this.lblTsNo.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblTsNo.Name = "lblTsNo";
            this.lblTsNo.Size = new System.Drawing.Size(74, 24);
            this.lblTsNo.TabIndex = 69;
            this.lblTsNo.Text = "施設番号";
            this.lblTsNo.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblTsSyubetuSai
            // 
            this.lblTsSyubetuSai.AutoSize = true;
            this.lblTsSyubetuSai.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblTsSyubetuSai.Location = new System.Drawing.Point(15, 192);
            this.lblTsSyubetuSai.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblTsSyubetuSai.Name = "lblTsSyubetuSai";
            this.lblTsSyubetuSai.Size = new System.Drawing.Size(106, 24);
            this.lblTsSyubetuSai.TabIndex = 71;
            this.lblTsSyubetuSai.Text = "　　　細区分";
            this.lblTsSyubetuSai.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblDaihyoFlag
            // 
            this.lblDaihyoFlag.AutoSize = true;
            this.lblDaihyoFlag.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblDaihyoFlag.Location = new System.Drawing.Point(15, 225);
            this.lblDaihyoFlag.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblDaihyoFlag.Name = "lblDaihyoFlag";
            this.lblDaihyoFlag.Size = new System.Drawing.Size(90, 24);
            this.lblDaihyoFlag.TabIndex = 72;
            this.lblDaihyoFlag.Text = "代表フラグ";
            this.lblDaihyoFlag.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtTsNo
            // 
            this.txtTsNo.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsTokuteiSisetuTou, "TSNO", true, System.Windows.Forms.DataSourceUpdateMode.Never));
            this.txtTsNo.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtTsNo.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.txtTsNo.Location = new System.Drawing.Point(123, 57);
            this.txtTsNo.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.txtTsNo.Name = "txtTsNo";
            this.txtTsNo.Size = new System.Drawing.Size(57, 31);
            this.txtTsNo.TabIndex = 4;
            // 
            // lblHaisiDate
            // 
            this.lblHaisiDate.AutoSize = true;
            this.lblHaisiDate.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblHaisiDate.Location = new System.Drawing.Point(15, 357);
            this.lblHaisiDate.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblHaisiDate.Name = "lblHaisiDate";
            this.lblHaisiDate.Size = new System.Drawing.Size(90, 24);
            this.lblHaisiDate.TabIndex = 74;
            this.lblHaisiDate.Text = "廃止年月日";
            this.lblHaisiDate.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // btnReturn
            // 
            this.btnReturn.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnReturn.Location = new System.Drawing.Point(889, 15);
            this.btnReturn.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.btnReturn.Name = "btnReturn";
            this.btnReturn.Size = new System.Drawing.Size(100, 30);
            this.btnReturn.TabIndex = 3;
            this.btnReturn.Text = "戻る";
            this.btnReturn.UseVisualStyleBackColor = true;
            this.btnReturn.Click += new System.EventHandler(this.btnReturnTokuteiSisetu_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnDelete.Location = new System.Drawing.Point(891, 571);
            this.btnDelete.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(100, 30);
            this.btnDelete.TabIndex = 19;
            this.btnDelete.Text = "削除";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnCancel.Location = new System.Drawing.Point(779, 15);
            this.btnCancel.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(100, 30);
            this.btnCancel.TabIndex = 2;
            this.btnCancel.Text = "キャンセル";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnGetSeiriNo
            // 
            this.btnGetSeiriNo.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnGetSeiriNo.Location = new System.Drawing.Point(242, 255);
            this.btnGetSeiriNo.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.btnGetSeiriNo.Name = "btnGetSeiriNo";
            this.btnGetSeiriNo.Size = new System.Drawing.Size(100, 30);
            this.btnGetSeiriNo.TabIndex = 12;
            this.btnGetSeiriNo.Text = "採番";
            this.btnGetSeiriNo.UseVisualStyleBackColor = true;
            this.btnGetSeiriNo.Click += new System.EventHandler(this.btnGetSeiriNo_Click);
            // 
            // btnRegist
            // 
            this.btnRegist.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnRegist.Location = new System.Drawing.Point(669, 15);
            this.btnRegist.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.btnRegist.Name = "btnRegist";
            this.btnRegist.Size = new System.Drawing.Size(100, 30);
            this.btnRegist.TabIndex = 1;
            this.btnRegist.Text = "登録";
            this.btnRegist.UseVisualStyleBackColor = true;
            this.btnRegist.Click += new System.EventHandler(this.btnRegist_Click);
            // 
            // dgvYugaiSiyoJyokyo
            // 
            this.dgvYugaiSiyoJyokyo.AllowUserToAddRows = false;
            this.dgvYugaiSiyoJyokyo.AllowUserToDeleteRows = false;
            this.dgvYugaiSiyoJyokyo.AllowUserToResizeColumns = false;
            this.dgvYugaiSiyoJyokyo.AllowUserToResizeRows = false;
            this.dgvYugaiSiyoJyokyo.AutoGenerateColumns = false;
            this.dgvYugaiSiyoJyokyo.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvYugaiSiyoJyokyo.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.komokuNameNDataGridViewTextBoxColumn,
            this.GsiyoFlagChk,
            this.KsiyoFlagChk,
            this.bikoDataGridViewTextBoxColumn});
            this.dgvYugaiSiyoJyokyo.DataSource = this.bsTsYugaiSiyo;
            this.dgvYugaiSiyoJyokyo.Location = new System.Drawing.Point(429, 60);
            this.dgvYugaiSiyoJyokyo.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.dgvYugaiSiyoJyokyo.MultiSelect = false;
            this.dgvYugaiSiyoJyokyo.Name = "dgvYugaiSiyoJyokyo";
            this.dgvYugaiSiyoJyokyo.RowHeadersVisible = false;
            this.dgvYugaiSiyoJyokyo.RowTemplate.Height = 21;
            this.dgvYugaiSiyoJyokyo.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvYugaiSiyoJyokyo.Size = new System.Drawing.Size(560, 496);
            this.dgvYugaiSiyoJyokyo.TabIndex = 0;
            // 
            // komokuNameNDataGridViewTextBoxColumn
            // 
            this.komokuNameNDataGridViewTextBoxColumn.DataPropertyName = "KomokuNameN";
            this.komokuNameNDataGridViewTextBoxColumn.HeaderText = "項目";
            this.komokuNameNDataGridViewTextBoxColumn.Name = "komokuNameNDataGridViewTextBoxColumn";
            this.komokuNameNDataGridViewTextBoxColumn.Width = 200;
            // 
            // GsiyoFlagChk
            // 
            this.GsiyoFlagChk.DataPropertyName = "GsiyoFlag";
            this.GsiyoFlagChk.HeaderText = "現在 使用";
            this.GsiyoFlagChk.Name = "GsiyoFlagChk";
            this.GsiyoFlagChk.Width = 65;
            // 
            // KsiyoFlagChk
            // 
            this.KsiyoFlagChk.DataPropertyName = "KsiyoFlag";
            this.KsiyoFlagChk.HeaderText = "過去 使用";
            this.KsiyoFlagChk.Name = "KsiyoFlagChk";
            this.KsiyoFlagChk.Width = 65;
            // 
            // bikoDataGridViewTextBoxColumn
            // 
            this.bikoDataGridViewTextBoxColumn.DataPropertyName = "Biko";
            this.bikoDataGridViewTextBoxColumn.HeaderText = "備考";
            this.bikoDataGridViewTextBoxColumn.Name = "bikoDataGridViewTextBoxColumn";
            this.bikoDataGridViewTextBoxColumn.Width = 200;
            // 
            // bsTsYugaiSiyo
            // 
            this.bsTsYugaiSiyo.DataSource = typeof(Suisitu.Entity.TsYugaiSiyoEntity);
            // 
            // wrkHaisiDate
            // 
            this.wrkHaisiDate.Location = new System.Drawing.Point(123, 354);
            this.wrkHaisiDate.Name = "wrkHaisiDate";
            this.wrkHaisiDate.Size = new System.Drawing.Size(102, 31);
            this.wrkHaisiDate.TabIndex = 15;
            // 
            // wrkSetiDate
            // 
            this.wrkSetiDate.Location = new System.Drawing.Point(123, 321);
            this.wrkSetiDate.Name = "wrkSetiDate";
            this.wrkSetiDate.Size = new System.Drawing.Size(102, 31);
            this.wrkSetiDate.TabIndex = 14;
            // 
            // cboSisetuKbn
            // 
            this.cboSisetuKbn.Location = new System.Drawing.Point(123, 90);
            this.cboSisetuKbn.MaxLength = 1;
            this.cboSisetuKbn.Name = "cboSisetuKbn";
            this.cboSisetuKbn.Size = new System.Drawing.Size(159, 31);
            this.cboSisetuKbn.TabIndex = 5;
            this.cboSisetuKbn.Value = "-1";
            this.cboSisetuKbn.SelectedIndexChanged += new Suisitu.Components.Controls.ValueCombo.SelectedIndexChangedHandler(this.cboSisetuKbn_SelectedIndexChanged);
            // 
            // cboTsSyubetuSai
            // 
            this.cboTsSyubetuSai.ImeMode = System.Windows.Forms.ImeMode.KatakanaHalf;
            this.cboTsSyubetuSai.Location = new System.Drawing.Point(123, 189);
            this.cboTsSyubetuSai.MaxLength = 1;
            this.cboTsSyubetuSai.Name = "cboTsSyubetuSai";
            this.cboTsSyubetuSai.Size = new System.Drawing.Size(282, 31);
            this.cboTsSyubetuSai.TabIndex = 8;
            this.cboTsSyubetuSai.Value = "-1";
            // 
            // cboTsSyubetu
            // 
            this.cboTsSyubetu.Location = new System.Drawing.Point(123, 156);
            this.cboTsSyubetu.MaxLength = 3;
            this.cboTsSyubetu.Name = "cboTsSyubetu";
            this.cboTsSyubetu.Size = new System.Drawing.Size(282, 31);
            this.cboTsSyubetu.TabIndex = 7;
            this.cboTsSyubetu.Value = "-1";
            this.cboTsSyubetu.SelectedIndexChanged += new Suisitu.Components.Controls.ValueCombo.SelectedIndexChangedHandler(this.cboTsSyubetu_SelectedIndexChanged);
            // 
            // backColorChangeOnFocusProvider1
            // 
            this.backColorChangeOnFocusProvider1.Target = this;
            // 
            // bsKomokuCode
            // 
            this.bsKomokuCode.DataSource = typeof(Suisitu.Entity.KomokuCodeEntity);
            // 
            // TokuteiSisetuTouJyoho
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.ClientSize = new System.Drawing.Size(1008, 616);
            this.Controls.Add(this.lblSeiriNo);
            this.Controls.Add(this.txtSeiriNo2);
            this.Controls.Add(this.btnReturn);
            this.Controls.Add(this.txtSeiriNo1);
            this.Controls.Add(this.btnRegist);
            this.Controls.Add(this.lblSeiriNoHi);
            this.Controls.Add(this.btnGetSeiriNo);
            this.Controls.Add(this.wrkHaisiDate);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.wrkSetiDate);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.cboSisetuKbn);
            this.Controls.Add(this.lblHaisiDate);
            this.Controls.Add(this.cboTsSyubetuSai);
            this.Controls.Add(this.txtTsNo);
            this.Controls.Add(this.cboTsSyubetu);
            this.Controls.Add(this.lblDaihyoFlag);
            this.Controls.Add(this.chkYugaiTikaSintouFlag);
            this.Controls.Add(this.lblTsSyubetuSai);
            this.Controls.Add(this.chkYugaiSiyoFlag);
            this.Controls.Add(this.lblTsNo);
            this.Controls.Add(this.lblTsSyubetu);
            this.Controls.Add(this.lblSisetuSu);
            this.Controls.Add(this.lblSisetuNameN);
            this.Controls.Add(this.txtSisetuNameN);
            this.Controls.Add(this.lblBiko);
            this.Controls.Add(this.dgvYugaiSiyoJyokyo);
            this.Controls.Add(this.txtSisetuSu);
            this.Controls.Add(this.txtBiko);
            this.Controls.Add(this.lblSisetuKbn);
            this.Controls.Add(this.lblSetiDate);
            this.Controls.Add(this.chkDaihyoFlag);
            this.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.MaximizeBox = false;
            this.Name = "TokuteiSisetuTouJyoho";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "特定施設情報";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.TokuteiSisetuTouJyoho_FormClosing);
            this.Load += new System.EventHandler(this.TokuteiSisetuJyoho_Load);
            ((System.ComponentModel.ISupportInitialize)(this.bsTokuteiSisetuTou)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvYugaiSiyoJyokyo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsTsYugaiSiyo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsKomokuCode)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.CheckBox chkDaihyoFlag;
        private System.Windows.Forms.Label lblSetiDate;
        private System.Windows.Forms.TextBox txtBiko;
        private System.Windows.Forms.Label lblBiko;
        private System.Windows.Forms.Label lblSisetuSu;
        private System.Windows.Forms.Label lblTsNo;
        private System.Windows.Forms.Label lblTsSyubetuSai;
        private System.Windows.Forms.Label lblDaihyoFlag;
        private System.Windows.Forms.TextBox txtTsNo;
        private System.Windows.Forms.Label lblHaisiDate;
        private System.Windows.Forms.Button btnReturn;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnRegist;
        private System.Windows.Forms.Label lblSisetuKbn;
        private System.Windows.Forms.TextBox txtSisetuSu;
        private System.Windows.Forms.Label lblTsSyubetu;
        private System.Windows.Forms.Label lblSisetuNameN;
        private System.Windows.Forms.TextBox txtSisetuNameN;
        private System.Windows.Forms.BindingSource bsKomokuCode;
        private System.Windows.Forms.BindingSource bsTokuteiSisetuTou;
        private System.Windows.Forms.CheckBox chkYugaiTikaSintouFlag;
        private System.Windows.Forms.CheckBox chkYugaiSiyoFlag;
        private Components.Controls.ValueCombo cboTsSyubetu;
        private Components.Controls.ValueCombo cboTsSyubetuSai;
        private Components.Controls.ValueCombo cboSisetuKbn;
        private Components.Controls.WarekiDate wrkSetiDate;
        private Components.Controls.WarekiDate wrkHaisiDate;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Label lblSeiriNo;
        private System.Windows.Forms.TextBox txtSeiriNo2;
        private System.Windows.Forms.TextBox txtSeiriNo1;
        private System.Windows.Forms.Label lblSeiriNoHi;
        private System.Windows.Forms.Button btnGetSeiriNo;
        private Component.BackColorChangeOnFocusProvider backColorChangeOnFocusProvider1;
        private System.Windows.Forms.DataGridView dgvYugaiSiyoJyokyo;
        private System.Windows.Forms.BindingSource bsTsYugaiSiyo;
        private System.Windows.Forms.DataGridViewTextBoxColumn komokuNameNDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewCheckBoxColumn GsiyoFlagChk;
        private System.Windows.Forms.DataGridViewCheckBoxColumn KsiyoFlagChk;
        private System.Windows.Forms.DataGridViewTextBoxColumn bikoDataGridViewTextBoxColumn;
    }
}