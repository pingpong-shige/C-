﻿using Suisitu.Common;
using Suisitu.Components.Controls;
using Suisitu.Dao;
using Suisitu.Entity;
using System;
using System.Windows.Forms;

namespace Suisitu.Forms.SD01
{
    using Enum;
    using System.Collections.Generic;
    using CommonEvents = Suisitu.Common.Events;

    /// <summary>
    /// 特定施設等情報画面クラス
    /// </summary>
    public partial class TokuteiSisetuTouJyoho : Form
    {
        //private bool? isInsert_;
        //private TokuteiSisetuTouEntity selectedItem_;
        //public static string txtSeiriNo1_;
        //public static string txtSeiriNo2_;

        // 特定施設等情報
        private TokuteiSisetuTouEntity selectedItem_;

        // アクションモード
        private EnumActionKbn actionMode_;

        // 新規追加された施設番号(特定施設等一覧のフォーカス用)
        public string addedTsNo_ = "";

        private IEnumerable<TsYugaiSiyoEntity> originDataList_;

        #region コンストラクタ

        /// <summary>
        /// コンストラクタ
        /// </summary>
        /// <param name="key">特定施設等情報</param>
        /// <param name="mode">アクションモード</param>
        public TokuteiSisetuTouJyoho(TokuteiSisetuTouEntity key, EnumActionKbn mode)
        {
            InitializeComponent();
            
            selectedItem_ = key;
            actionMode_ = mode;

            txtTsNo.KeyPress += new KeyPressEventHandler(CommonEvents.txtHalfNumber_KeyPress);
            cboSisetuKbn.KeyPress += new KeyPressEventHandler(CommonEvents.txtHalfNumber_KeyPress);
            cboTsSyubetu.KeyPress += new KeyPressEventHandler(CommonEvents.txtHalfNumber_KeyPress);
            txtSeiriNo1.KeyPress += new KeyPressEventHandler(CommonEvents.txtHalfAll_KeyPress);
            txtSeiriNo2.KeyPress += new KeyPressEventHandler(CommonEvents.txtHalfNumber_KeyPress);
            txtSisetuSu.KeyPress += new KeyPressEventHandler(CommonEvents.txtHalfNumber_KeyPress);
            wrkSetiDate.KeyPress += new KeyPressEventHandler(CommonEvents.txtHalfNumber_KeyPress);
            wrkHaisiDate.KeyPress += new KeyPressEventHandler(CommonEvents.txtHalfNumber_KeyPress);
        }

        #endregion

        #region イベント

        /// <summary>
        /// 画面が表示されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void TokuteiSisetuJyoho_Load(object sender, EventArgs e)
        {
            // データを画面表示する
            InitializeData();

            // 画面ロックマトリックスを定義する
            SetLockMatrix();
        }

        /// <summary>
        /// 戻るボタンが選択されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnReturnTokuteiSisetu_Click(object sender, EventArgs e)
        {
            Return();
        }

        /// <summary>
        /// キャンセルボタンが選択されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnCancel_Click(object sender, EventArgs e)
        {
            InitializeData();
        }
        
        /// <summary>
        /// 登録ボタンが選択されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnRegist_Click(object sender, EventArgs e)
        {
            // 登録データを作成する（特定施設等表）
            TokuteiSisetuTouEntity entity = CreateRegisterData();

            // 登録データを作成する(特定施設等有害物質使用状況表)
            List<TsYugaiSiyoEntity> list = CreateRegisterDataYugaiSiyo();

            // バリデーションチェックする
            if (!Validation(entity))
                return;

            // データを登録する(特定施設等情報)
            Register(entity);

            // データを登録する(特定施設等有害物質使用状況情報)
            Register(list);

            // 画面を閉じるときの前処理
            ClosingPreprocessing();

            Close();
        }

        /// <summary>
        /// 採番ボタンが選択されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnGetSeiriNo_Click(object sender, EventArgs e)
        {
            //整理番号一覧画面の施設種別テキストボックスに表示する値をセット
            string key = "";
            if (cboSisetuKbn.SelectedKey == "1")
            {
                //施設区分が「特定施設」の場合、特定施設種別コンボボックスの値をセット
                key = DBUtils.ConvertDaoComboBoxFormat(cboTsSyubetu.SelectedKey);
            }
            else if(cboSisetuKbn.SelectedKey == "2" || cboSisetuKbn.SelectedKey == "3")
            {
                //施設区分が「E01」か「E02」の場合、施設区分コンボボックスの値をセット
                key = cboSisetuKbn.SelectedItem.Value;
            }

            //整理番号一覧画面を表示
            using (var dialog = new SeiriNoItiran(key, (TokuteiSisetuTouEntity)bsTokuteiSisetuTou.Current))
            {
                // FormClosedイベントハンドラを追加
                dialog.FormClosed += new FormClosedEventHandler(SeiriNoItiran_FormClosed);
                dialog.ShowDialog();
            }
        }

        /// <summary>
        /// 削除ボタンが選択されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnDelete_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("表示中のデータを削除します。よろしいですか？", Text,
                MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button2);

            if (result == DialogResult.Yes)
            {
                TokuteiSisetuTouDao.Delete((TokuteiSisetuTouEntity)bsTokuteiSisetuTou.Current);
            }

            // 画面を閉じるときの前処理
            ClosingPreprocessing();

            Close();
        }

        /// <summary>
        /// 施設区分コンボボックスの値が変更されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void cboSisetuKbn_SelectedIndexChanged(object sender, ValueComboEventArgs e)
        {
            if (cboSisetuKbn.SelectedKey != "1")
            {
                cboTsSyubetu.Clear();
                cboTsSyubetuSai.Clear();
                cboTsSyubetu.Enabled = false;
                cboTsSyubetuSai.Enabled = false;
                //txtSisetuSu.Enabled = false;
                //chkYugaiSiyoFlag.Enabled = false;
                //chkYugaiTikaSintouFlag.Enabled = false;
            }
            else
            {
                cboTsSyubetu.Enabled = true;
                cboTsSyubetuSai.Enabled = true;
                //txtSisetuSu.Enabled = true;
                //chkYugaiSiyoFlag.Enabled = true;
                //chkYugaiTikaSintouFlag.Enabled = true;
            }
        }

        /// <summary>
        /// 特定施設種別コンボボックスの値が変更されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void cboTsSyubetu_SelectedIndexChanged(object sender, ValueComboEventArgs e)
        {
            // 特定施設種別(細区分)コンボボックスの初期化
            string key = cboTsSyubetu.SelectedKey;
            cboTsSyubetuSai.InitCombo(TsSyubetuSaiDao.GetMasterData(key));
        }

        /// <summary>
        /// 整理番号一覧画面が閉じられたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void SeiriNoItiran_FormClosed(object sender, FormClosedEventArgs e)
        {
            //更新・複写モードの場合、一覧画面で選択されたレコード情報を表示（画面上部）
            bsTokuteiSisetuTou.DataSource = TokuteiSisetuTouDao.Select(this.selectedItem_);
            //更新・複写モードの場合、一覧画面で選択されたレコード情報を表示（DataGridView）
            //bsViewYugaiSiyoJyokyo.DataSource = ViewYugaiSiyoJyokyoDao.SelectList(this.selectedItem_);

            // 整理番号を更新
            bsTokuteiSisetuTou.DataSource = SeiriNoItiran.selectedItem_;
        }

        /// <summary>
        /// 代表者フラグの値が変更されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void chkDaihyoFlag_CheckedChanged(object sender, EventArgs e)
        {
            if (chkDaihyoFlag.Checked == true)
            {
                txtSeiriNo1.Enabled = true;
                txtSeiriNo2.Enabled = true;
                btnGetSeiriNo.Enabled = true;
            }
            else
            {
                txtSeiriNo1.Clear();
                txtSeiriNo2.Clear();
                txtSeiriNo1.Enabled = false;
                txtSeiriNo2.Enabled = false;
                btnGetSeiriNo.Enabled = false;
            }
        }

        /// <summary>
        /// 画面を閉じるときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void TokuteiSisetuTouJyoho_FormClosing(object sender, FormClosingEventArgs e)
        {
            // 各種ボタンイベントから画面を閉じる場合
            if (this.Tag == null)
                Return(e);
        }
        #endregion

        #region プライベートメソッド

        /// <summary>
        /// 画面に表示するデータを初期化します。
        /// </summary>
        private void InitializeData()
        {
            Clear();
            
            // オリジナルの特定施設等有害物質使用状況を保持する
            originDataList_ = TsYugaiSiyoDao.SelectList(new TsYugaiSiyoEntity { Nendo = selectedItem_.Nendo, KanriNo = selectedItem_.KanriNo, TsNo = selectedItem_.TsNo });
            
            // 特定施設等有害物質使用状況をデータソースに設定する
            bsTsYugaiSiyo.DataSource = TsYugaiSiyoDao.SelectList(new TsYugaiSiyoEntity { Nendo = selectedItem_.Nendo, KanriNo = selectedItem_.KanriNo, TsNo = selectedItem_.TsNo });

            // 施設区分コンボボックスの初期化
            cboSisetuKbn.InitCombo(KubunNameDao.GetMasterData("SISETU"));

            // 特定施設種別コンボボックスの初期化
            cboTsSyubetu.InitCombo(TsSyubetuDao.GetMasterData());

            switch (actionMode_)
            {
                // 選択、複写の場合
                case EnumActionKbn.Select:
                case EnumActionKbn.Copy:

                    TokuteiSisetuTouEntity descEntity = new TokuteiSisetuTouEntity();
                    BeanUtils.CopyObjectProperties(selectedItem_, descEntity);

                    if (actionMode_ == EnumActionKbn.Copy)
                    {
                        descEntity.TsNo = TokuteiSisetuTouDao.GetNewTsNo(descEntity);
                    }

                    bsTokuteiSisetuTou.DataSource = descEntity;

                    cboSisetuKbn.SelectedKey = descEntity.SisetuKbn;
                    cboTsSyubetu.SelectedKey = descEntity.TsSyubetu;
                    cboTsSyubetuSai.Value = descEntity.TsSyubetuSai;
                    wrkSetiDate.Value = descEntity.SetiDate;
                    wrkHaisiDate.Value = descEntity.HaisiDate;

                    break;

                // 追加の場合
                case EnumActionKbn.Add:

                    txtTsNo.Text = TokuteiSisetuTouDao.GetNewTsNo(selectedItem_);

                    break;
            }
        }

        /// <summary>
        /// ロックマトリックス定義
        /// </summary>
        private void SetLockMatrix()
        {
            txtTsNo.Enabled = false;

            // 追加と複写の場合は削除ボタンを入力不可にする
            if (actionMode_ == EnumActionKbn.Add || actionMode_ == EnumActionKbn.Copy)
            {
                btnDelete.Enabled = false;
            }

            // 年度が通年以外の場合
            if (selectedItem_.Nendo != 9999)
            {
                btnRegist.Enabled = false;
                btnCancel.Enabled = false;
                btnDelete.Enabled = false;
                cboSisetuKbn.Enabled = false;
                txtSisetuNameN.Enabled = false;
                cboTsSyubetu.Enabled = false;
                cboTsSyubetuSai.Enabled = false;
                chkDaihyoFlag.Enabled = false;
                txtSeiriNo1.Enabled = false;
                txtSeiriNo2.Enabled = false;
                btnGetSeiriNo.Enabled = false;
                txtSisetuSu.Enabled = false;
                wrkSetiDate.Enabled = false;
                wrkHaisiDate.Enabled = false;
                chkYugaiSiyoFlag.Enabled = false;
                chkYugaiTikaSintouFlag.Enabled = false;
                txtBiko.Enabled = false;
                dgvYugaiSiyoJyokyo.Enabled = false;
            }
            else
            {
                if (cboSisetuKbn.SelectedKey != "1")
                {
                    cboTsSyubetu.Clear();
                    cboTsSyubetuSai.Clear();
                    cboTsSyubetu.Enabled = false;
                    cboTsSyubetuSai.Enabled = false;
                }

                if (!chkDaihyoFlag.Checked)
                {
                    txtSeiriNo1.Enabled = false;
                    txtSeiriNo2.Enabled = false;
                    btnGetSeiriNo.Enabled = false;
                }
            }
        }

        /// <summary>
        /// 画面のクリア処理
        /// </summary>
        private void Clear()
        {
            bsTokuteiSisetuTou.Clear();

            cboSisetuKbn.ClearItems();
            cboTsSyubetu.ClearItems();
            cboTsSyubetuSai.ClearItems();
            wrkSetiDate.Value = null;
            wrkHaisiDate.Value = null;
        }

        /// <summary>
        /// 呼び出し元の画面に戻ります。
        /// </summary>
        private void Return(FormClosingEventArgs close =null)
        {
            try
            {
                if (actionMode_ == EnumActionKbn.Add || actionMode_ == EnumActionKbn.Copy
                    || !CompareToControlsAndObject(selectedItem_))
                {
                    DialogResult result = MessageBox.Show("編集中のデータを保存しますか？", Text,
                        MessageBoxButtons.YesNo, MessageBoxIcon.Information, MessageBoxDefaultButton.Button2);

                    if (result == DialogResult.Yes)
                    {
                        // 登録データを作成する（特定施設等表）
                        TokuteiSisetuTouEntity entity = CreateRegisterData();

                        // 登録データを作成する(特定施設等有害物質使用状況表)
                        List<TsYugaiSiyoEntity> list = CreateRegisterDataYugaiSiyo();

                        // バリデーションチェックする
                        if (!Validation(entity))
                        {
                            // FormClosingイベントを中止
                            if(close != null)
                            close.Cancel = true;

                            return;
                        }

                        // データを登録する(特定施設等情報)
                        Register(entity);

                        // データを登録する(特定施設等有害物質使用状況情報)
                        Register(list);
                    }
                }
            }
            catch (Exception ex)
            {
                // なにもしない
            }

            // 画面を閉じるときの前処理
            ClosingPreprocessing();

            Close();
        }

        /// <summary>
        /// 編集前と編集後を比較します。
        /// (データソースとコントロール値を比較します。)
        /// </summary>
        /// <param name="source">編集前のオブジェクト</param>
        /// <returns>True:差異なし / False:差異あり</returns>
        private bool CompareToControlsAndObject(TokuteiSisetuTouEntity source)
        {
            // 施設番号
            if (txtTsNo.Text.Trim() != source.TsNo.Trim())
                return false;

            // 施設区分
            if (DBUtils.ConvertDaoComboBoxFormat(cboSisetuKbn.SelectedKey).Trim() != source.SisetuKbn.Trim())
                return false;

            // 施設名称
            if (txtSisetuNameN.Text != source.SisetuNameN)
                return false;
            
            // 特定施設種別
            if (DBUtils.ConvertDaoComboBoxFormat(cboTsSyubetu.Value).Trim() != source.TsSyubetu.Trim())
                return false;

            // 特定施設種別（細区分）
            if (DBUtils.ConvertDaoComboBoxFormat(cboTsSyubetuSai.Value).Trim() != source.TsSyubetuSai.Trim())
                return false;

            // 代表フラグ
            if (DBUtils.ConvertDaoCheckBoxFormat(chkDaihyoFlag.Checked) != source.DaihyoFlag)
                return false;

            // 整理番号1
            if (txtSeiriNo1.Text != CommonUtils.GetFormerSeiriNo(source.SeiriNo))
                return false;

            // 整理番号2
            if (txtSeiriNo2.Text != CommonUtils.GetLatterSeiriNo(source.SeiriNo))
                return false;

            // 設置基数
            if (txtSisetuSu.Text != source.Sisetusu)
                return false;

            // 届出年月日
            if (CommonUtils.FormatToDate(wrkSetiDate.Value) != source.SetiDate)
                return false;

            // 廃止年月日
            if (CommonUtils.FormatToDate(wrkHaisiDate.Value) != source.HaisiDate)
                return false;

            // 有害物質使用
            if (DBUtils.ConvertDaoCheckBoxFormat(chkYugaiSiyoFlag.Checked) != source.YugaiSiyoFlag)
                return false;

            // 有害地下浸透
            if (DBUtils.ConvertDaoCheckBoxFormat(chkYugaiTikaSintouFlag.Checked) != source.YugaiTikasintouFlag)
                return false;

            // 備考
            if (txtBiko.Text != source.Biko)
                return false;
            
            // 特定施設等有害使用状況一覧
            IEnumerable<TsYugaiSiyoEntity> bindingDataList = (IEnumerable<TsYugaiSiyoEntity>)bsTsYugaiSiyo.DataSource;

            foreach (var originEntity in originDataList_)
            {
                foreach (var srcEntity in bindingDataList)
                {
                    if (originEntity.KomokuCode != srcEntity.KomokuCode)
                    {
                        continue;
                    }

                    if (originEntity.GsiyoFlag != srcEntity.GsiyoFlag
                        || originEntity.KsiyoFlag != srcEntity.KsiyoFlag
                        || originEntity.Biko != srcEntity.Biko)
                    {
                        return false;
                    }
                }
            }

            return true;
        }

        /// <summary>
        /// バリデーションをチェックします。
        /// </summary>
        /// <returns>True:チェックOK / False:チェックNG</returns>
        private bool Validation(TokuteiSisetuTouEntity entity)
        {
            // コンボボックス入力値チェック
            if (cboSisetuKbn.IsInvalid)
            {
                MessageUtils.IncorrectInputComboBoxMessage(CommonUtils.Trim(lblSisetuKbn.Text), Text);
                cboSisetuKbn.Focus();
                return false;
            }

            if (cboTsSyubetu.IsInvalid)
            {
                MessageUtils.IncorrectInputComboBoxMessage(CommonUtils.Trim(lblTsSyubetu.Text), Text);
                cboTsSyubetu.Focus();
                return false;
            }

            if (cboTsSyubetuSai.IsInvalid)
            {
                MessageUtils.IncorrectInputComboBoxMessage(CommonUtils.Trim(lblTsSyubetu.Text) + "(細区分)", Text);
                cboTsSyubetuSai.Focus();
                return false;
            }

            // 必須入力チェック
            if (string.IsNullOrEmpty(cboSisetuKbn.Text))
            {
                MessageUtils.NoInputDataMessage(CommonUtils.Trim(lblSisetuKbn.Text), Text);
                cboSisetuKbn.Focus();
                return false;
            }

            // 日付整合性チェック
            if (!ValidationUtils.ValidateConcistencyDate(wrkSetiDate.Value, wrkHaisiDate.Value))
            {
                MessageUtils.NotConcistencyDate(CommonUtils.Trim(lblSetiDate.Text), CommonUtils.Trim(lblHaisiDate.Text), Text);
                wrkHaisiDate.Focus();
                return false;
            }

            // 条件つき必須入力チェック
            // 施設区分が「1：特定施設」の場合
            if (cboSisetuKbn.Value == "1")
            {
                if (string.IsNullOrEmpty(cboTsSyubetu.Text))
                {
                    MessageUtils.NoInputDataMessage(CommonUtils.Trim(lblTsSyubetu.Text), Text);
                    cboTsSyubetu.Focus();
                    return false;
                }

                if (string.IsNullOrEmpty(cboTsSyubetuSai.Text))
                {
                    MessageUtils.NoInputDataMessage(CommonUtils.Trim(lblTsSyubetu.Text) + "(細区分)", Text);
                    cboTsSyubetuSai.Focus();
                    return false;
                }
            }

            // 代表フラグがチェックありの場合
            if (chkDaihyoFlag.Checked)
            {
                if (string.IsNullOrEmpty(txtSeiriNo1.Text))
                {
                    MessageUtils.NoInputDataMessage(CommonUtils.Trim(lblSeiriNo.Text), Text);
                    txtSeiriNo1.Focus();
                    return false;
                }

                if (string.IsNullOrEmpty(txtSeiriNo2.Text))
                {
                    MessageUtils.NoInputDataMessage(CommonUtils.Trim(lblSeiriNo.Text), Text);
                    txtSeiriNo2.Focus();
                    return false;
                }
            }

            // 整理番号の書式チェック　必要であれば追記する

            return true;
        }

        /// <summary>
        /// 登録用特定施設等情報を作成します。
        /// </summary>
        /// <returns>特定施設等情報</returns>
        private TokuteiSisetuTouEntity CreateRegisterData()
        {
            // 登録データを作成する
            TokuteiSisetuTouEntity entity = new TokuteiSisetuTouEntity
            {
                Nendo = selectedItem_.Nendo,
                KanriNo = selectedItem_.KanriNo,
                TsNo = txtTsNo.Text,
                SisetuKbn = DBUtils.ConvertDaoComboBoxFormat(cboSisetuKbn.SelectedKey),
                SisetuNameN = txtSisetuNameN.Text,
                SetiDate = CommonUtils.FormatToDate(wrkSetiDate.Value),
                HaisiDate = CommonUtils.FormatToDate(wrkHaisiDate.Value),
                TsSyubetu = DBUtils.ConvertDaoComboBoxFormat(cboTsSyubetu.SelectedKey),
                TsSyubetuSai = DBUtils.ConvertDaoComboBoxFormat(cboTsSyubetuSai.SelectedKey),
                DaihyoFlag = DBUtils.ConvertDaoCheckBoxFormat(chkDaihyoFlag.Checked),
                SeiriNo = CommonUtils.GetSeiriNo(txtSeiriNo1.Text, txtSeiriNo2.Text),
                Sisetusu = txtSisetuSu.Text,
                YugaiSiyoFlag = DBUtils.ConvertDaoCheckBoxFormat(chkYugaiSiyoFlag.Checked),
                YugaiTikasintouFlag = DBUtils.ConvertDaoCheckBoxFormat(chkYugaiTikaSintouFlag.Checked),
                Biko = txtBiko.Text,
                TorokuDate = DateTime.Now.ToString(),
                UpdDate = DateTime.Now.ToString(),
                Rev = 1,
            };

            return entity;
        }
        
        /// <summary>
        /// 特定施設等情報を登録します。
        /// </summary>
        /// <param name="entity">特定施設等情報</param>
        private void Register(TokuteiSisetuTouEntity entity)
        {
            // 該当データが存在しない場合
            if (TokuteiSisetuTouDao.Select(entity) == null)
            {
                // 特定施設等情報を登録する
                TokuteiSisetuTouDao.Insert(entity);

                // 登録された施設番号を保持する
                addedTsNo_ = entity.TsNo;
            }
            // 該当データが存在する場合
            else
            {
                // 届出履歴情報を更新する
                TokuteiSisetuTouDao.Update(entity);
            }
        }

        /// <summary>
        /// 登録用特定施設等有害物質使用状況を作成します。
        /// </summary>
        /// <returns>有害物質使用状況</returns>
        private List<TsYugaiSiyoEntity> CreateRegisterDataYugaiSiyo()
        {
            List<TsYugaiSiyoEntity> registerDataList = new List<TsYugaiSiyoEntity>();

            IEnumerable<TsYugaiSiyoEntity> bindingDataList = (IEnumerable<TsYugaiSiyoEntity>)bsTsYugaiSiyo.DataSource;
            
            foreach (var originEntity in originDataList_)
            {
                foreach (var srcEntity in bindingDataList)
                {
                    if (originEntity.KomokuCode != srcEntity.KomokuCode)
                    {
                        continue;
                    }

                    if (originEntity.GsiyoFlag != srcEntity.GsiyoFlag 
                        || originEntity.KsiyoFlag != srcEntity.KsiyoFlag 
                        || originEntity.Biko != srcEntity.Biko)
                    {
                        TsYugaiSiyoEntity descEntity = new TsYugaiSiyoEntity();
                        BeanUtils.CopyObjectProperties(srcEntity, descEntity);

                        descEntity.TorokuDate = DateTime.Now.ToString();
                        descEntity.UpdDate = DateTime.Now.ToString();
                        descEntity.Rev = 1;

                        registerDataList.Add(descEntity);

                        break;
                    }
                }
            }

            return registerDataList;
        }

        /// <summary>
        /// 特定施設等有害物質使用状況を登録します。
        /// </summary>
        /// <param name="entity">有害物質使用状況</param>
        private void Register(List<TsYugaiSiyoEntity> list)
        {
            foreach (var entity in list)
            {
                // 該当データが存在しない場合
                if (TsYugaiSiyoDao.Select(entity) == null)
                {
                    // 有害物質使用状況を登録する
                    TsYugaiSiyoDao.Insert(entity);
                }
                // 該当データが存在する場合
                else
                {
                    // 有害物質使用状況を更新する
                    TsYugaiSiyoDao.Update(entity);
                }
            }
        }
        
        /// <summary>
        /// 画面を閉じるときの前処理
        /// </summary>
        private void ClosingPreprocessing()
        {
            this.Tag = true;
        }

        /// <summary>
        /// 特定施設画面の描画処理
        /// </summary>
        private void Load_Screen()
        {
            ////更新モードの場合、施設番号・施設区分テキストボックスを編集不可に設定
            //if (isInsert_ == false)
            //{
            //    txtTsNo.Enabled = false;
            //    cboSisetuKbn.Enabled = false;
            //}
            
            ////整理番号テキストボックスへ値を格納
            //txtSeiriNo1.Text = string.IsNullOrEmpty(selectedItem_.SeiriNo) ? "" : selectedItem_.SeiriNo.Substring(0, 3);
            //txtSeiriNo2.Text = string.IsNullOrEmpty(selectedItem_.SeiriNo) ? "" : selectedItem_.SeiriNo.Substring(4, 4);
            ////整理番号一覧画面からのデータ取得用変数を初期化
            //txtSeiriNo1_ = txtSeiriNo1.Text;
            //txtSeiriNo2_ = txtSeiriNo2.Text;

            ////一覧で選択されたレコードの情報をDataSourceに格納する
            //// 有害物質使用状況一覧取得・表示（DataGridView表示）
            //if (isInsert_ == false || isInsert_ == null)
            //{
            //    //更新・複写モードの場合、一覧画面で選択されたレコード情報を表示（画面上部）
            //    bsTokuteiSisetuTou.DataSource = TokuteiSisetuTouDao.Select(this.selectedItem_);
            //    //更新・複写モードの場合、一覧画面で選択されたレコード情報を表示（DataGridView）
            //    //bsViewYugaiSiyoJyokyo.DataSource = ViewYugaiSiyoJyokyoDao.SelectList(this.selectedItem_);
            //}
            //else
            //{
            //    TokuteiSisetuTouEntity tokuteiSisetuTouEntity = new TokuteiSisetuTouEntity
            //    {
            //        Nendo = selectedItem_.Nendo,
            //        KanriNo = selectedItem_.KanriNo,
            //    };

            //    //追加モードの場合、年度・管理番号以外が空白の情報を表示（DataGridView）
            //    //bsViewYugaiSiyoJyokyo.DataSource = ViewYugaiSiyoJyokyoDao.SelectList(tokuteiSisetuTouEntity);
            //}

            ////施設区分コンボボックスの値を取得・格納
            //cboSisetuKbn.InitCombo(KubunNameDao.GetMasterData("SISETU"));

            ////特定施設種別コンボボックスの値を取得・格納
            //cboTsSyubetu.InitCombo(TokuteiSisetuTouDao.SelectList(true));
            
            ////更新・複写のときのみ以下を実施
            //if (isInsert_ == false || isInsert_ == null)
            //{
            //    //施設区分コンボボックスの値を選択表示
            //    cboSisetuKbn.SelectedKey = selectedItem_.SisetuKbn;

            //    //特定施設種別コンボボックスの値を選択表示
            //    cboTsSyubetu.SelectedKey = selectedItem_.TsSyubetu;

            //    //特定施設種別(細区分)コンボボックスの値を取得・格納・表示
            //    cboTsSyubetuSai.InitCombo(TokuteiSisetuTouDao.SelectList(true, selectedItem_.TsSyubetu));
            //    cboTsSyubetuSai.SelectedKey = selectedItem_.TsSyubetu + selectedItem_.TsSyubetuSai;

            //    //和暦コントロール（設置年月日・廃止年月日）の表示
            //    wrkSetiDate.Value = selectedItem_.SetiDate != null ? selectedItem_.SetiDate : "";
            //    wrkHaisiDate.Value = selectedItem_.HaisiDate != null ? selectedItem_.HaisiDate : "";
            //}

            ////施設番号テキストボックスに値を格納
            //if(isInsert_ == true)
            //{
            //    //追加モードの場合は施設番号の最大値+1をセットする
            //    int maxValue = TokuteiSisetuTouDao.GetMaxValue(new TokuteiSisetuTouEntity{ Nendo = selectedItem_.Nendo, KanriNo = selectedItem_.KanriNo });
            //    txtTsNo.Text = (maxValue + 1).ToString();
            //}
            //else if(isInsert_ == null)
            //{
            //    //複写モードの場合は施設番号の最大値+1をセットする
            //    int maxValue = TokuteiSisetuTouDao.GetMaxValue((TokuteiSisetuTouEntity)bsTokuteiSisetuTou.Current);
            //    txtTsNo.Text = (maxValue + 1).ToString();
            //}
            //else
            //{
            //    //更新モードの場合は一覧画面で選択したレコードの値をセットする
            //    txtTsNo.Text = selectedItem_.TsNo;
            //}

            ////チェックボックスの値セット
            //if (isInsert_ == true)
            //{
            //    //追加モードの場合はチェックボックス値をすべてOFFにセットする
            //    chkDaihyoFlag.Checked = false;
            //    chkYugaiSiyoFlag.Checked = false;
            //    chkYugaiTikaSintouFlag.Checked = false;
            //}
            //else
            //{
            //    //更新・複写モードの場合は一覧画面で選択したレコードの値をセットする
            //    chkDaihyoFlag.Checked = DBUtils.ConvertDaoCheckBoxFormat(selectedItem_.DaihyoFlag);
            //    chkYugaiSiyoFlag.Checked = DBUtils.ConvertDaoCheckBoxFormat(selectedItem_.YugaiSiyoFlag);
            //    chkYugaiTikaSintouFlag.Checked = DBUtils.ConvertDaoCheckBoxFormat(selectedItem_.YugaiTikasintouFlag);
            //}

            ////代表者フラグのチェックがOFFの場合、整理番号の入力を不可に設定
            //if (chkDaihyoFlag.Checked == false)
            //{
            //    txtSeiriNo1.Text = "";
            //    txtSeiriNo2.Text = "";
            //    txtSeiriNo1.Enabled = false;
            //    txtSeiriNo2.Enabled = false;
            //    btnGetSeiriNo.Enabled = false;
            //}
        }

        #endregion
    }
}
