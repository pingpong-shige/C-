﻿namespace Suisitu.Forms.SD01
{
    partial class YugaiSiyoJyokyo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.btnReturn = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.dgvYugaiSiyoJyokyo = new System.Windows.Forms.DataGridView();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.label44 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.btnRegist = new System.Windows.Forms.Button();
            this.bsYugaiSiyoJokyo = new System.Windows.Forms.BindingSource(this.components);
            this.No = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.KomokuNameN = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.GSiyoFlagChk = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.KSiyoFlagChk = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.YugaiSiyoFlag = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dgvYugaiSiyoJyokyo)).BeginInit();
            this.tableLayoutPanel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bsYugaiSiyoJokyo)).BeginInit();
            this.SuspendLayout();
            // 
            // btnReturn
            // 
            this.btnReturn.Location = new System.Drawing.Point(728, 15);
            this.btnReturn.Name = "btnReturn";
            this.btnReturn.Size = new System.Drawing.Size(100, 30);
            this.btnReturn.TabIndex = 2;
            this.btnReturn.Text = "戻る";
            this.btnReturn.UseVisualStyleBackColor = true;
            this.btnReturn.Click += new System.EventHandler(this.btnReturn_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(622, 15);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(100, 30);
            this.btnCancel.TabIndex = 1;
            this.btnCancel.Text = "キャンセル";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // dgvYugaiSiyoJyokyo
            // 
            this.dgvYugaiSiyoJyokyo.AllowUserToAddRows = false;
            this.dgvYugaiSiyoJyokyo.AllowUserToDeleteRows = false;
            this.dgvYugaiSiyoJyokyo.AllowUserToResizeColumns = false;
            this.dgvYugaiSiyoJyokyo.AllowUserToResizeRows = false;
            this.dgvYugaiSiyoJyokyo.AutoGenerateColumns = false;
            this.dgvYugaiSiyoJyokyo.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvYugaiSiyoJyokyo.ColumnHeadersVisible = false;
            this.dgvYugaiSiyoJyokyo.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.No,
            this.KomokuNameN,
            this.GSiyoFlagChk,
            this.KSiyoFlagChk,
            this.YugaiSiyoFlag});
            this.dgvYugaiSiyoJyokyo.DataSource = this.bsYugaiSiyoJokyo;
            this.dgvYugaiSiyoJyokyo.Location = new System.Drawing.Point(15, 116);
            this.dgvYugaiSiyoJyokyo.MultiSelect = false;
            this.dgvYugaiSiyoJyokyo.Name = "dgvYugaiSiyoJyokyo";
            this.dgvYugaiSiyoJyokyo.RowHeadersVisible = false;
            this.dgvYugaiSiyoJyokyo.RowTemplate.Height = 21;
            this.dgvYugaiSiyoJyokyo.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvYugaiSiyoJyokyo.Size = new System.Drawing.Size(813, 591);
            this.dgvYugaiSiyoJyokyo.TabIndex = 0;
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.tableLayoutPanel3.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel3.ColumnCount = 6;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 400F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 150F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 16F));
            this.tableLayoutPanel3.Controls.Add(this.label44, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.label45, 1, 0);
            this.tableLayoutPanel3.Controls.Add(this.label49, 2, 0);
            this.tableLayoutPanel3.Controls.Add(this.label50, 4, 0);
            this.tableLayoutPanel3.Controls.Add(this.label1, 2, 1);
            this.tableLayoutPanel3.Controls.Add(this.label2, 3, 1);
            this.tableLayoutPanel3.Controls.Add(this.label3, 5, 0);
            this.tableLayoutPanel3.Location = new System.Drawing.Point(15, 60);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 2;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(813, 56);
            this.tableLayoutPanel3.TabIndex = 65;
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.BackColor = System.Drawing.SystemColors.Control;
            this.label44.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label44.Location = new System.Drawing.Point(1, 1);
            this.label44.Margin = new System.Windows.Forms.Padding(0);
            this.label44.Name = "label44";
            this.tableLayoutPanel3.SetRowSpan(this.label44, 2);
            this.label44.Size = new System.Drawing.Size(40, 54);
            this.label44.TabIndex = 0;
            this.label44.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.BackColor = System.Drawing.SystemColors.Control;
            this.label45.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label45.Location = new System.Drawing.Point(42, 1);
            this.label45.Margin = new System.Windows.Forms.Padding(0);
            this.label45.Name = "label45";
            this.tableLayoutPanel3.SetRowSpan(this.label45, 2);
            this.label45.Size = new System.Drawing.Size(400, 54);
            this.label45.TabIndex = 0;
            this.label45.Text = "項目";
            this.label45.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.BackColor = System.Drawing.SystemColors.Control;
            this.tableLayoutPanel3.SetColumnSpan(this.label49, 2);
            this.label49.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label49.Location = new System.Drawing.Point(443, 1);
            this.label49.Margin = new System.Windows.Forms.Padding(0);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(201, 26);
            this.label49.TabIndex = 0;
            this.label49.Text = "使用状況";
            this.label49.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.BackColor = System.Drawing.SystemColors.Control;
            this.label50.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label50.ForeColor = System.Drawing.Color.Red;
            this.label50.Location = new System.Drawing.Point(645, 1);
            this.label50.Margin = new System.Windows.Forms.Padding(0);
            this.label50.Name = "label50";
            this.tableLayoutPanel3.SetRowSpan(this.label50, 2);
            this.label50.Size = new System.Drawing.Size(150, 54);
            this.label50.TabIndex = 0;
            this.label50.Text = "特定施設以外を\r\n含む有害有無";
            this.label50.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.Control;
            this.label1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label1.Location = new System.Drawing.Point(443, 28);
            this.label1.Margin = new System.Windows.Forms.Padding(0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(100, 27);
            this.label1.TabIndex = 0;
            this.label1.Text = "現在使用";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.SystemColors.Control;
            this.label2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label2.Location = new System.Drawing.Point(544, 28);
            this.label2.Margin = new System.Windows.Forms.Padding(0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(100, 27);
            this.label2.TabIndex = 0;
            this.label2.Text = "過去使用";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.SystemColors.Control;
            this.label3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label3.Location = new System.Drawing.Point(796, 1);
            this.label3.Margin = new System.Windows.Forms.Padding(0);
            this.label3.Name = "label3";
            this.tableLayoutPanel3.SetRowSpan(this.label3, 2);
            this.label3.Size = new System.Drawing.Size(16, 54);
            this.label3.TabIndex = 0;
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnRegist
            // 
            this.btnRegist.Location = new System.Drawing.Point(516, 15);
            this.btnRegist.Name = "btnRegist";
            this.btnRegist.Size = new System.Drawing.Size(100, 30);
            this.btnRegist.TabIndex = 1;
            this.btnRegist.Text = "登録";
            this.btnRegist.UseVisualStyleBackColor = true;
            this.btnRegist.Click += new System.EventHandler(this.btnRegist_Click);
            // 
            // bsYugaiSiyoJokyo
            // 
            this.bsYugaiSiyoJokyo.DataSource = typeof(Suisitu.Entity.KojoYugaiSiyoEntity);
            // 
            // No
            // 
            this.No.DataPropertyName = "No";
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.No.DefaultCellStyle = dataGridViewCellStyle1;
            this.No.HeaderText = "";
            this.No.Name = "No";
            this.No.ReadOnly = true;
            this.No.Width = 40;
            // 
            // KomokuNameN
            // 
            this.KomokuNameN.DataPropertyName = "KomokuNameN";
            this.KomokuNameN.HeaderText = "項目";
            this.KomokuNameN.Name = "KomokuNameN";
            this.KomokuNameN.ReadOnly = true;
            this.KomokuNameN.Width = 401;
            // 
            // GSiyoFlagChk
            // 
            this.GSiyoFlagChk.DataPropertyName = "GSiyoFlagChk";
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            dataGridViewCellStyle2.NullValue = false;
            this.GSiyoFlagChk.DefaultCellStyle = dataGridViewCellStyle2;
            this.GSiyoFlagChk.HeaderText = "現在使用";
            this.GSiyoFlagChk.Name = "GSiyoFlagChk";
            this.GSiyoFlagChk.ReadOnly = true;
            this.GSiyoFlagChk.Width = 101;
            // 
            // KSiyoFlagChk
            // 
            this.KSiyoFlagChk.DataPropertyName = "KSiyoFlagChk";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            dataGridViewCellStyle3.NullValue = false;
            this.KSiyoFlagChk.DefaultCellStyle = dataGridViewCellStyle3;
            this.KSiyoFlagChk.HeaderText = "過去使用";
            this.KSiyoFlagChk.Name = "KSiyoFlagChk";
            this.KSiyoFlagChk.ReadOnly = true;
            this.KSiyoFlagChk.Width = 101;
            // 
            // YugaiSiyoFlag
            // 
            this.YugaiSiyoFlag.DataPropertyName = "YugaiSiyoFlag";
            this.YugaiSiyoFlag.HeaderText = "物質有無";
            this.YugaiSiyoFlag.Name = "YugaiSiyoFlag";
            this.YugaiSiyoFlag.Width = 151;
            // 
            // YugaiSiyoJyokyo
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.ClientSize = new System.Drawing.Size(843, 722);
            this.Controls.Add(this.tableLayoutPanel3);
            this.Controls.Add(this.dgvYugaiSiyoJyokyo);
            this.Controls.Add(this.btnRegist);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnReturn);
            this.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "YugaiSiyoJyokyo";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "有害物質使用状況";
            this.Load += new System.EventHandler(this.YugaiSiyoJyokyo_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvYugaiSiyoJyokyo)).EndInit();
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bsYugaiSiyoJokyo)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnReturn;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.DataGridView dgvYugaiSiyoJyokyo;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnRegist;
        private System.Windows.Forms.BindingSource bsYugaiSiyoJokyo;
        private System.Windows.Forms.DataGridViewTextBoxColumn No;
        private System.Windows.Forms.DataGridViewTextBoxColumn KomokuNameN;
        private System.Windows.Forms.DataGridViewCheckBoxColumn GSiyoFlagChk;
        private System.Windows.Forms.DataGridViewCheckBoxColumn KSiyoFlagChk;
        private System.Windows.Forms.DataGridViewCheckBoxColumn YugaiSiyoFlag;
    }
}