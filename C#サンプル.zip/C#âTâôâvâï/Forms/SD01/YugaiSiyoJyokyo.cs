﻿using Suisitu.Common;
using Suisitu.Dao;
using Suisitu.Entity;
using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace Suisitu.Forms.SD01
{
    #pragma warning disable 168
    
    /// <summary>
    /// 有害物質使用状況画面クラス
    /// </summary>
    public partial class YugaiSiyoJyokyo : Form
    {
        // 年度
        private int nendo_;
        // 管理番号
        private int kanriNo_;

        private IEnumerable<KojoYugaiSiyoEntity> originDataList_;

        #region コンストラクタ

        /// <summary>
        /// コンストラクタ
        /// </summary>
        /// <param name="nendo">年度</param>
        /// <param name="kanriNo">管理番号</param>
        public YugaiSiyoJyokyo(int nendo, int kanriNo)
        {
            InitializeComponent();

            nendo_ = nendo;
            kanriNo_ = kanriNo;
        }

        #endregion

        #region イベント

        /// <summary>
        /// 画面が表示されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void YugaiSiyoJyokyo_Load(object sender, EventArgs e)
        {
            // データを画面表示する
            InitializeData();

            // 画面ロックマトリックスを定義する
            SetLockMatrix();
        }

        /// <summary>
        /// 登録ボタンが選択されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnRegist_Click(object sender, EventArgs e)
        {
            // 登録データを作成する
            List<KojoYugaiSiyoEntity> list = CreateRegisterData();

            // 有害物質使用状況を登録する
            Register(list);

            Close();
        }

        /// <summary>
        /// キャンセルボタンが選択されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnCancel_Click(object sender, EventArgs e)
        {
            InitializeData();
        }

        /// <summary>
        /// 戻るボタンが選択されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnReturn_Click(object sender, EventArgs e)
        {
            try
            {
                if (!CompareToControlsAndObject())
                {
                    DialogResult result = MessageBox.Show("編集中のデータを保存しますか？", Text,
                        MessageBoxButtons.YesNo, MessageBoxIcon.Information, MessageBoxDefaultButton.Button2);

                    if (result == DialogResult.Yes)
                    {
                        // 登録データを作成する
                        List<KojoYugaiSiyoEntity> list = CreateRegisterData();

                        // 有害物質使用状況を登録する
                        Register(list);
                    }
                }
            }
            catch (Exception ex)
            {
                // なにもしない
            }

            Close();
        }

        #endregion

        #region プライベートメソッド

        /// <summary>
        /// 画面に表示するデータを初期化します。
        /// </summary>
        private void InitializeData()
        {
            // オリジナルの有害物質使用状況を保持する
            originDataList_ = KojoYugaiSiyoDao.Select(nendo_, kanriNo_);

            // 有害物質使用状況をデータソースに設定する
            bsYugaiSiyoJokyo.DataSource = KojoYugaiSiyoDao.Select(nendo_, kanriNo_);
        }

        /// <summary>
        /// ロックマトリックス定義
        /// </summary>
        private void SetLockMatrix()
        {
            // 年度が通年の場合
            if (nendo_ == 9999)
            {
                btnRegist.Enabled = true;
                btnCancel.Enabled = true;
                dgvYugaiSiyoJyokyo.Enabled = true;
            }
            // 年度が通年以外の場合
            else
            {
                btnRegist.Enabled = false;
                btnCancel.Enabled = false;
                dgvYugaiSiyoJyokyo.Enabled = false;
            }

            if (bsYugaiSiyoJokyo.Count > 0)
            {
                btnRegist.Enabled = true;
                btnCancel.Enabled = true;
            }
            else
            {
                btnRegist.Enabled = false;
                btnCancel.Enabled = false;
            }
        }

        /// <summary>
        /// 編集前と編集後を比較します。
        /// </summary>
        /// <returns>True:差異なし / False:差異あり</returns>
        private bool CompareToControlsAndObject()
        {
            IEnumerable<KojoYugaiSiyoEntity> bindingDataList = (IEnumerable<KojoYugaiSiyoEntity>)bsYugaiSiyoJokyo.DataSource;

            foreach (var originEntity in originDataList_)
            {
                foreach (var srcEntity in bindingDataList)
                {
                    if (originEntity.No != srcEntity.No)
                    {
                        continue;
                    }

                    if (originEntity.YugaiSiyoFlag != srcEntity.YugaiSiyoFlag)
                    {
                        return false;
                    }
                }
            }

            return true;
        }

        /// <summary>
        /// 登録用有害物質使用状況を作成します。
        /// </summary>
        /// <returns>有害物質使用状況</returns>
        private List<KojoYugaiSiyoEntity> CreateRegisterData()
        {
            List<KojoYugaiSiyoEntity> registerDataList = new List<KojoYugaiSiyoEntity>();

            IEnumerable<KojoYugaiSiyoEntity> bindingDataList= (IEnumerable<KojoYugaiSiyoEntity>)bsYugaiSiyoJokyo.DataSource;
            
            foreach (var originEntity in originDataList_)
            {
                foreach (var srcEntity in bindingDataList)
                {
                    if (originEntity.No != srcEntity.No)
                    {
                        continue;
                    }

                    if (originEntity.YugaiSiyoFlag != srcEntity.YugaiSiyoFlag)
                    {
                        KojoYugaiSiyoEntity descEntity = new KojoYugaiSiyoEntity();
                        BeanUtils.CopyObjectProperties(srcEntity, descEntity);

                        descEntity.TorokuDate = DateTime.Now.ToString();
                        descEntity.UpdDate = DateTime.Now.ToString();
                        descEntity.Rev = 1;

                        registerDataList.Add(descEntity);
                        
                        break;
                    }
                }
            }

            return registerDataList;
        }

        /// <summary>
        /// 有害物質使用状況を登録します。
        /// </summary>
        /// <param name="entity">有害物質使用状況</param>
        private void Register(List<KojoYugaiSiyoEntity> list)
        {
            foreach (var entity in list)
            {
                // 該当データが存在しない場合
                if (KojoYugaiSiyoDao.Select(entity) == null)
                {
                    // 有害物質使用状況を登録する
                    KojoYugaiSiyoDao.Insert(entity);
                }
                // 該当データが存在する場合
                else
                {
                    // 有害物質使用状況を更新する
                    KojoYugaiSiyoDao.Update(entity);
                }
            }
        }

        #endregion
    }
}
