﻿using Suisitu.Common;
using Suisitu.Dao;
using Suisitu.Enum;
using System;
using System.Windows.Forms;

namespace Suisitu.Forms.SD03
{
    using CommonEvents = Suisitu.Common.Events;

    /// <summary>
    /// 採水年月回入力画面クラス
    /// </summary>
    public partial class InputSaisuiYMKaisu : Form
    {
        // 採水計画情報
        private string copySaisuiKai_;
        
        // アクションモード
        private EnumActionKbn actionMode_;

        #region コンストラクタ

        /// <summary>
        /// コンストラクタ
        /// </summary>
        public InputSaisuiYMKaisu(EnumActionKbn mode, string copySaisuiKai = null)
        {
            InitializeComponent();

            copySaisuiKai_ = copySaisuiKai;
            actionMode_ = mode;

            // 採水年月 半角数字のみ入力可
            this.txtSaisuiKaiKai.KeyPress += new KeyPressEventHandler(CommonEvents.txtHalfNumber_KeyPress);
        }

        #endregion


        #region イベント

        /// <summary>
        /// 画面が表示されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void InputSaisuiYMKaisu_Load(object sender, EventArgs e)
        {
            if(actionMode_ == EnumActionKbn.Copy)
            {
                txtSaisuiKaiNengetu.Text = copySaisuiKai_.Substring(0,6);
            }
        }

        /// <summary>
        /// キャンセルボタンがクリックされたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnCancel_Click(object sender, EventArgs e)
        {
            Close();
        }

        /// <summary>
        /// OKボタンがクリックされたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnOK_Click(object sender, EventArgs e)
        {
            string kaiNengetu = CommonUtils.FormatToDate(txtSaisuiKaiNengetu.Value);

            if (!Validation())
                return;
            // 水質届出管理画面を表示する
            if (actionMode_ == EnumActionKbn.Add)
            {
                using (var dialog = new SaisuiKeikaku(actionMode_, kaiNengetu + txtSaisuiKaiKai.Text.ToString()))
                {
                    dialog.ShowDialog();
                }
            }else
                if(actionMode_ == EnumActionKbn.Copy)
            {
                using (var dialog = new SaisuiKeikaku(actionMode_, kaiNengetu + txtSaisuiKaiKai.Text.ToString(), copySaisuiKai_))
                {
                    dialog.ShowDialog();
                }
            }
            Close();
        }

        #endregion

        #region プライベートメソッド

        /// <summary>
        /// バリデーションをチェックします。
        /// </summary>
        /// <returns>True:チェックOK / False:チェックNG</returns>
        private bool Validation()
        {
            // 必須入力チェック
            if (string.IsNullOrEmpty(txtSaisuiKaiNengetu.Text))
            {
                MessageUtils.NoInputDataMessage(CommonUtils.Trim(lblSaisuiKai.Text) + "(年月)", Text);
                txtSaisuiKaiNengetu.Focus();
                return false;
            }

            if (string.IsNullOrEmpty(txtSaisuiKaiKai.Text))
            {
                MessageUtils.NoInputDataMessage(CommonUtils.Trim(lblSaisuiKai.Text) + "(回)", Text);
                txtSaisuiKaiKai.Focus();
                return false;
            }

            // 重複チェック
            if (SaisuiKeikakuDao.Select(txtSaisuiKaiNengetu.Text.ToString() + txtSaisuiKaiKai.Text.ToString()) != null)
            {
                MessageUtils.Duplication(CommonUtils.Trim(lblSaisuiKai.Text), Text);
                txtSaisuiKaiNengetu.Focus();
                return false;
            }

            return true;
        }

        #endregion
    }
}
