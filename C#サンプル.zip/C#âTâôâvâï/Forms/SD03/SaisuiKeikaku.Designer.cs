﻿namespace Suisitu.Forms.SD03
{
    partial class SaisuiKeikaku
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            this.pnlSaisuiKeikaku = new System.Windows.Forms.Panel();
            this.btnItiran = new System.Windows.Forms.Button();
            this.txtSaisuiKaiStatus = new System.Windows.Forms.TextBox();
            this.txtSaisuiKaiKai = new System.Windows.Forms.TextBox();
            this.txtSheetDate = new System.Windows.Forms.TextBox();
            this.txtNendo = new System.Windows.Forms.TextBox();
            this.lblSheetDate = new System.Windows.Forms.Label();
            this.lblsaisuiKai = new System.Windows.Forms.Label();
            this.lblNendo = new System.Windows.Forms.Label();
            this.lblSaisuiKeikakuJyoho = new System.Windows.Forms.Label();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnRegist = new System.Windows.Forms.Button();
            this.lblSaisuiDate = new System.Windows.Forms.Label();
            this.lblGyosyaNameN = new System.Windows.Forms.Label();
            this.lblSaisuisyaNameN = new System.Windows.Forms.Label();
            this.txtSaisuisyaNameN = new System.Windows.Forms.TextBox();
            this.lblJigyojoLine = new System.Windows.Forms.Label();
            this.lblJigyojo = new System.Windows.Forms.Label();
            this.lblSeiriNo = new System.Windows.Forms.Label();
            this.txtSeiriNo = new System.Windows.Forms.TextBox();
            this.lblJigyosyoNameN = new System.Windows.Forms.Label();
            this.txtJigyosyoNameN = new System.Windows.Forms.TextBox();
            this.lblSyozaiJyusyo = new System.Windows.Forms.Label();
            this.txtSyozaiJyusyo = new System.Windows.Forms.TextBox();
            this.btnSearch = new System.Windows.Forms.Button();
            this.lblCountNumberTodokedeRireki = new System.Windows.Forms.Label();
            this.dgvJigyojo = new System.Windows.Forms.DataGridView();
            this.lblCountRecordTodokedeRireki = new System.Windows.Forms.Label();
            this.lblSaisuiKeikakuLine = new System.Windows.Forms.Label();
            this.lblSaisuiKeikaku = new System.Windows.Forms.Label();
            this.dgvSaisuiKeikaku = new System.Windows.Forms.DataGridView();
            this.KANRINO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.JIGYOSYONAMEN = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TATIIRIKANRINO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.HAISUIKONO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnSelect = new System.Windows.Forms.Button();
            this.btnExclusion = new System.Windows.Forms.Button();
            this.btnExport = new System.Windows.Forms.Button();
            this.btnImport = new System.Windows.Forms.Button();
            this.txtSaisuiDate = new Suisitu.Components.Controls.WarekiDate();
            this.cboGyosyaNameN = new Suisitu.Components.Controls.ValueCombo();
            this.backColorChangeOnFocusProvider1 = new Suisitu.Component.BackColorChangeOnFocusProvider();
            this.txtSaisuiKaiNengetu = new System.Windows.Forms.TextBox();
            this.seiriNoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.jigyosyoNameNDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bsSaisuiKeikakuJigyojoItiran = new System.Windows.Forms.BindingSource(this.components);
            this.bsSaisuiKeikaku = new System.Windows.Forms.BindingSource(this.components);
            this.pnlSaisuiKeikaku.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvJigyojo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSaisuiKeikaku)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsSaisuiKeikakuJigyojoItiran)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsSaisuiKeikaku)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlSaisuiKeikaku
            // 
            this.pnlSaisuiKeikaku.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlSaisuiKeikaku.Controls.Add(this.btnItiran);
            this.pnlSaisuiKeikaku.Controls.Add(this.txtSaisuiKaiStatus);
            this.pnlSaisuiKeikaku.Controls.Add(this.txtSaisuiKaiKai);
            this.pnlSaisuiKeikaku.Controls.Add(this.txtSheetDate);
            this.pnlSaisuiKeikaku.Controls.Add(this.txtSaisuiKaiNengetu);
            this.pnlSaisuiKeikaku.Controls.Add(this.txtNendo);
            this.pnlSaisuiKeikaku.Controls.Add(this.lblSheetDate);
            this.pnlSaisuiKeikaku.Controls.Add(this.lblsaisuiKai);
            this.pnlSaisuiKeikaku.Controls.Add(this.lblNendo);
            this.pnlSaisuiKeikaku.Location = new System.Drawing.Point(15, 15);
            this.pnlSaisuiKeikaku.Name = "pnlSaisuiKeikaku";
            this.pnlSaisuiKeikaku.Size = new System.Drawing.Size(978, 89);
            this.pnlSaisuiKeikaku.TabIndex = 0;
            // 
            // btnItiran
            // 
            this.btnItiran.Location = new System.Drawing.Point(866, 45);
            this.btnItiran.Name = "btnItiran";
            this.btnItiran.Size = new System.Drawing.Size(100, 30);
            this.btnItiran.TabIndex = 6;
            this.btnItiran.Text = "一覧";
            this.btnItiran.UseVisualStyleBackColor = true;
            this.btnItiran.Click += new System.EventHandler(this.btnItiran_Click);
            // 
            // txtSaisuiKaiStatus
            // 
            this.txtSaisuiKaiStatus.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsSaisuiKeikaku, "StatusKubunNameN", true, System.Windows.Forms.DataSourceUpdateMode.Never));
            this.txtSaisuiKaiStatus.Location = new System.Drawing.Point(323, 45);
            this.txtSaisuiKaiStatus.Name = "txtSaisuiKaiStatus";
            this.txtSaisuiKaiStatus.Size = new System.Drawing.Size(75, 31);
            this.txtSaisuiKaiStatus.TabIndex = 4;
            // 
            // txtSaisuiKaiKai
            // 
            this.txtSaisuiKaiKai.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsSaisuiKeikaku, "SaisuiKaiKai", true, System.Windows.Forms.DataSourceUpdateMode.Never));
            this.txtSaisuiKaiKai.Location = new System.Drawing.Point(217, 45);
            this.txtSaisuiKaiKai.Name = "txtSaisuiKaiKai";
            this.txtSaisuiKaiKai.Size = new System.Drawing.Size(57, 31);
            this.txtSaisuiKaiKai.TabIndex = 3;
            // 
            // txtSheetDate
            // 
            this.txtSheetDate.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsSaisuiKeikaku, "SheetDateV", true, System.Windows.Forms.DataSourceUpdateMode.Never));
            this.txtSheetDate.Location = new System.Drawing.Point(636, 45);
            this.txtSheetDate.Name = "txtSheetDate";
            this.txtSheetDate.Size = new System.Drawing.Size(224, 31);
            this.txtSheetDate.TabIndex = 5;
            // 
            // txtNendo
            // 
            this.txtNendo.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsSaisuiKeikaku, "NendoW", true, System.Windows.Forms.DataSourceUpdateMode.Never));
            this.txtNendo.Location = new System.Drawing.Point(111, 12);
            this.txtNendo.Name = "txtNendo";
            this.txtNendo.Size = new System.Drawing.Size(100, 31);
            this.txtNendo.TabIndex = 1;
            // 
            // lblSheetDate
            // 
            this.lblSheetDate.AutoSize = true;
            this.lblSheetDate.Location = new System.Drawing.Point(476, 48);
            this.lblSheetDate.Name = "lblSheetDate";
            this.lblSheetDate.Size = new System.Drawing.Size(154, 24);
            this.lblSheetDate.TabIndex = 0;
            this.lblSheetDate.Text = "試験成績表作成日時";
            // 
            // lblsaisuiKai
            // 
            this.lblsaisuiKai.AutoSize = true;
            this.lblsaisuiKai.Location = new System.Drawing.Point(15, 48);
            this.lblsaisuiKai.Name = "lblsaisuiKai";
            this.lblsaisuiKai.Size = new System.Drawing.Size(90, 24);
            this.lblsaisuiKai.TabIndex = 0;
            this.lblsaisuiKai.Text = "採水年月回";
            // 
            // lblNendo
            // 
            this.lblNendo.AutoSize = true;
            this.lblNendo.Location = new System.Drawing.Point(15, 15);
            this.lblNendo.Name = "lblNendo";
            this.lblNendo.Size = new System.Drawing.Size(42, 24);
            this.lblNendo.TabIndex = 0;
            this.lblNendo.Text = "年度";
            // 
            // lblSaisuiKeikakuJyoho
            // 
            this.lblSaisuiKeikakuJyoho.AutoSize = true;
            this.lblSaisuiKeikakuJyoho.Font = new System.Drawing.Font("メイリオ", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblSaisuiKeikakuJyoho.Location = new System.Drawing.Point(434, 119);
            this.lblSaisuiKeikakuJyoho.Name = "lblSaisuiKeikakuJyoho";
            this.lblSaisuiKeikakuJyoho.Size = new System.Drawing.Size(140, 31);
            this.lblSaisuiKeikakuJyoho.TabIndex = 143;
            this.lblSaisuiKeikakuJyoho.Text = "採水計画情報";
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(882, 121);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(100, 30);
            this.btnCancel.TabIndex = 8;
            this.btnCancel.Text = "キャンセル";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnRegist
            // 
            this.btnRegist.Location = new System.Drawing.Point(776, 121);
            this.btnRegist.Name = "btnRegist";
            this.btnRegist.Size = new System.Drawing.Size(100, 30);
            this.btnRegist.TabIndex = 7;
            this.btnRegist.Text = "登録";
            this.btnRegist.UseVisualStyleBackColor = true;
            this.btnRegist.Click += new System.EventHandler(this.btnRegist_Click);
            // 
            // lblSaisuiDate
            // 
            this.lblSaisuiDate.AutoSize = true;
            this.lblSaisuiDate.Location = new System.Drawing.Point(31, 167);
            this.lblSaisuiDate.Name = "lblSaisuiDate";
            this.lblSaisuiDate.Size = new System.Drawing.Size(90, 24);
            this.lblSaisuiDate.TabIndex = 0;
            this.lblSaisuiDate.Text = "採水年月日";
            // 
            // lblGyosyaNameN
            // 
            this.lblGyosyaNameN.AutoSize = true;
            this.lblGyosyaNameN.Location = new System.Drawing.Point(233, 167);
            this.lblGyosyaNameN.Name = "lblGyosyaNameN";
            this.lblGyosyaNameN.Size = new System.Drawing.Size(90, 24);
            this.lblGyosyaNameN.TabIndex = 0;
            this.lblGyosyaNameN.Text = "分析業者名";
            // 
            // lblSaisuisyaNameN
            // 
            this.lblSaisuisyaNameN.AutoSize = true;
            this.lblSaisuisyaNameN.Location = new System.Drawing.Point(720, 171);
            this.lblSaisuisyaNameN.Name = "lblSaisuisyaNameN";
            this.lblSaisuisyaNameN.Size = new System.Drawing.Size(90, 24);
            this.lblSaisuisyaNameN.TabIndex = 0;
            this.lblSaisuisyaNameN.Text = "採水者氏名";
            // 
            // txtSaisuisyaNameN
            // 
            this.txtSaisuisyaNameN.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsSaisuiKeikaku, "SaisuisyaNameN", true, System.Windows.Forms.DataSourceUpdateMode.Never));
            this.txtSaisuisyaNameN.ImeMode = System.Windows.Forms.ImeMode.Hiragana;
            this.txtSaisuisyaNameN.Location = new System.Drawing.Point(816, 164);
            this.txtSaisuisyaNameN.Name = "txtSaisuisyaNameN";
            this.txtSaisuisyaNameN.Size = new System.Drawing.Size(166, 31);
            this.txtSaisuisyaNameN.TabIndex = 11;
            this.txtSaisuisyaNameN.TextChanged += new System.EventHandler(this.txtSaisuisyaNameN_TextChanged);
            // 
            // lblJigyojoLine
            // 
            this.lblJigyojoLine.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblJigyojoLine.Font = new System.Drawing.Font("ＭＳ ゴシック", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblJigyojoLine.Location = new System.Drawing.Point(133, 211);
            this.lblJigyojoLine.Name = "lblJigyojoLine";
            this.lblJigyojoLine.Size = new System.Drawing.Size(860, 1);
            this.lblJigyojoLine.TabIndex = 146;
            // 
            // lblJigyojo
            // 
            this.lblJigyojo.AutoSize = true;
            this.lblJigyojo.Font = new System.Drawing.Font("メイリオ", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblJigyojo.Location = new System.Drawing.Point(31, 202);
            this.lblJigyojo.Name = "lblJigyojo";
            this.lblJigyojo.Size = new System.Drawing.Size(100, 20);
            this.lblJigyojo.TabIndex = 145;
            this.lblJigyojo.Text = "工場事業場一覧";
            // 
            // lblSeiriNo
            // 
            this.lblSeiriNo.AutoSize = true;
            this.lblSeiriNo.Location = new System.Drawing.Point(31, 229);
            this.lblSeiriNo.Name = "lblSeiriNo";
            this.lblSeiriNo.Size = new System.Drawing.Size(74, 24);
            this.lblSeiriNo.TabIndex = 0;
            this.lblSeiriNo.Text = "整理番号";
            // 
            // txtSeiriNo
            // 
            this.txtSeiriNo.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.txtSeiriNo.Location = new System.Drawing.Point(127, 226);
            this.txtSeiriNo.Name = "txtSeiriNo";
            this.txtSeiriNo.Size = new System.Drawing.Size(100, 31);
            this.txtSeiriNo.TabIndex = 12;
            // 
            // lblJigyosyoNameN
            // 
            this.lblJigyosyoNameN.AutoSize = true;
            this.lblJigyosyoNameN.Location = new System.Drawing.Point(233, 229);
            this.lblJigyosyoNameN.Name = "lblJigyosyoNameN";
            this.lblJigyosyoNameN.Size = new System.Drawing.Size(122, 24);
            this.lblJigyosyoNameN.TabIndex = 0;
            this.lblJigyosyoNameN.Text = "工場事業場名称";
            // 
            // txtJigyosyoNameN
            // 
            this.txtJigyosyoNameN.ImeMode = System.Windows.Forms.ImeMode.Hiragana;
            this.txtJigyosyoNameN.Location = new System.Drawing.Point(377, 226);
            this.txtJigyosyoNameN.Name = "txtJigyosyoNameN";
            this.txtJigyosyoNameN.Size = new System.Drawing.Size(499, 31);
            this.txtJigyosyoNameN.TabIndex = 13;
            // 
            // lblSyozaiJyusyo
            // 
            this.lblSyozaiJyusyo.AutoSize = true;
            this.lblSyozaiJyusyo.Location = new System.Drawing.Point(233, 262);
            this.lblSyozaiJyusyo.Name = "lblSyozaiJyusyo";
            this.lblSyozaiJyusyo.Size = new System.Drawing.Size(138, 24);
            this.lblSyozaiJyusyo.TabIndex = 0;
            this.lblSyozaiJyusyo.Text = "工場事業場所在地";
            // 
            // txtSyozaiJyusyo
            // 
            this.txtSyozaiJyusyo.ImeMode = System.Windows.Forms.ImeMode.Hiragana;
            this.txtSyozaiJyusyo.Location = new System.Drawing.Point(377, 259);
            this.txtSyozaiJyusyo.Name = "txtSyozaiJyusyo";
            this.txtSyozaiJyusyo.Size = new System.Drawing.Size(499, 31);
            this.txtSyozaiJyusyo.TabIndex = 14;
            // 
            // btnSearch
            // 
            this.btnSearch.Location = new System.Drawing.Point(882, 259);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(100, 30);
            this.btnSearch.TabIndex = 15;
            this.btnSearch.Text = "検索";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // lblCountNumberTodokedeRireki
            // 
            this.lblCountNumberTodokedeRireki.AutoSize = true;
            this.lblCountNumberTodokedeRireki.Location = new System.Drawing.Point(35, 305);
            this.lblCountNumberTodokedeRireki.Name = "lblCountNumberTodokedeRireki";
            this.lblCountNumberTodokedeRireki.Size = new System.Drawing.Size(60, 24);
            this.lblCountNumberTodokedeRireki.TabIndex = 149;
            this.lblCountNumberTodokedeRireki.Text = "件数 =";
            // 
            // dgvJigyojo
            // 
            this.dgvJigyojo.AllowUserToAddRows = false;
            this.dgvJigyojo.AllowUserToDeleteRows = false;
            this.dgvJigyojo.AllowUserToResizeColumns = false;
            this.dgvJigyojo.AllowUserToResizeRows = false;
            this.dgvJigyojo.AutoGenerateColumns = false;
            this.dgvJigyojo.ColumnHeadersHeight = 56;
            this.dgvJigyojo.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dgvJigyojo.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.seiriNoDataGridViewTextBoxColumn,
            this.jigyosyoNameNDataGridViewTextBoxColumn});
            this.dgvJigyojo.DataSource = this.bsSaisuiKeikakuJigyojoItiran;
            this.dgvJigyojo.Location = new System.Drawing.Point(35, 329);
            this.dgvJigyojo.MultiSelect = false;
            this.dgvJigyojo.Name = "dgvJigyojo";
            this.dgvJigyojo.ReadOnly = true;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopCenter;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvJigyojo.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dgvJigyojo.RowHeadersVisible = false;
            this.dgvJigyojo.RowTemplate.Height = 21;
            this.dgvJigyojo.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvJigyojo.Size = new System.Drawing.Size(439, 348);
            this.dgvJigyojo.TabIndex = 16;
            this.dgvJigyojo.TabStop = false;
            this.dgvJigyojo.CellMouseDoubleClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgvJigyojo_CellMouseDoubleClick);
            // 
            // lblCountRecordTodokedeRireki
            // 
            this.lblCountRecordTodokedeRireki.AutoSize = true;
            this.lblCountRecordTodokedeRireki.Location = new System.Drawing.Point(95, 305);
            this.lblCountRecordTodokedeRireki.Name = "lblCountRecordTodokedeRireki";
            this.lblCountRecordTodokedeRireki.Size = new System.Drawing.Size(20, 24);
            this.lblCountRecordTodokedeRireki.TabIndex = 148;
            this.lblCountRecordTodokedeRireki.Text = "0";
            // 
            // lblSaisuiKeikakuLine
            // 
            this.lblSaisuiKeikakuLine.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblSaisuiKeikakuLine.Font = new System.Drawing.Font("ＭＳ ゴシック", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblSaisuiKeikakuLine.Location = new System.Drawing.Point(597, 317);
            this.lblSaisuiKeikakuLine.Name = "lblSaisuiKeikakuLine";
            this.lblSaisuiKeikakuLine.Size = new System.Drawing.Size(400, 1);
            this.lblSaisuiKeikakuLine.TabIndex = 151;
            // 
            // lblSaisuiKeikaku
            // 
            this.lblSaisuiKeikaku.AutoSize = true;
            this.lblSaisuiKeikaku.Font = new System.Drawing.Font("メイリオ", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblSaisuiKeikaku.Location = new System.Drawing.Point(534, 308);
            this.lblSaisuiKeikaku.Name = "lblSaisuiKeikaku";
            this.lblSaisuiKeikaku.Size = new System.Drawing.Size(61, 20);
            this.lblSaisuiKeikaku.TabIndex = 150;
            this.lblSaisuiKeikaku.Text = "採水計画";
            // 
            // dgvSaisuiKeikaku
            // 
            this.dgvSaisuiKeikaku.AllowUserToAddRows = false;
            this.dgvSaisuiKeikaku.AllowUserToDeleteRows = false;
            this.dgvSaisuiKeikaku.AllowUserToResizeColumns = false;
            this.dgvSaisuiKeikaku.AllowUserToResizeRows = false;
            this.dgvSaisuiKeikaku.ColumnHeadersHeight = 56;
            this.dgvSaisuiKeikaku.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dgvSaisuiKeikaku.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.KANRINO,
            this.JIGYOSYONAMEN,
            this.TATIIRIKANRINO,
            this.HAISUIKONO});
            this.dgvSaisuiKeikaku.Location = new System.Drawing.Point(534, 329);
            this.dgvSaisuiKeikaku.MultiSelect = false;
            this.dgvSaisuiKeikaku.Name = "dgvSaisuiKeikaku";
            this.dgvSaisuiKeikaku.ReadOnly = true;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopCenter;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvSaisuiKeikaku.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.dgvSaisuiKeikaku.RowHeadersVisible = false;
            this.dgvSaisuiKeikaku.RowTemplate.Height = 21;
            this.dgvSaisuiKeikaku.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvSaisuiKeikaku.Size = new System.Drawing.Size(459, 348);
            this.dgvSaisuiKeikaku.TabIndex = 19;
            this.dgvSaisuiKeikaku.TabStop = false;
            // 
            // KANRINO
            // 
            this.KANRINO.HeaderText = "管理番号";
            this.KANRINO.Name = "KANRINO";
            this.KANRINO.ReadOnly = true;
            this.KANRINO.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.KANRINO.Visible = false;
            // 
            // JIGYOSYONAMEN
            // 
            this.JIGYOSYONAMEN.HeaderText = "工場事業場名称";
            this.JIGYOSYONAMEN.Name = "JIGYOSYONAMEN";
            this.JIGYOSYONAMEN.ReadOnly = true;
            this.JIGYOSYONAMEN.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.JIGYOSYONAMEN.Width = 200;
            // 
            // TATIIRIKANRINO
            // 
            this.TATIIRIKANRINO.HeaderText = "立入　　管理番号";
            this.TATIIRIKANRINO.Name = "TATIIRIKANRINO";
            this.TATIIRIKANRINO.ReadOnly = true;
            this.TATIIRIKANRINO.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.TATIIRIKANRINO.Width = 85;
            // 
            // HAISUIKONO
            // 
            this.HAISUIKONO.HeaderText = "排水口　番号";
            this.HAISUIKONO.Name = "HAISUIKONO";
            this.HAISUIKONO.ReadOnly = true;
            this.HAISUIKONO.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.HAISUIKONO.Width = 85;
            // 
            // btnSelect
            // 
            this.btnSelect.Font = new System.Drawing.Font("メイリオ", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnSelect.Location = new System.Drawing.Point(489, 383);
            this.btnSelect.Name = "btnSelect";
            this.btnSelect.Size = new System.Drawing.Size(30, 100);
            this.btnSelect.TabIndex = 17;
            this.btnSelect.Text = "▸";
            this.btnSelect.UseVisualStyleBackColor = true;
            this.btnSelect.Click += new System.EventHandler(this.btnSelect_Click);
            // 
            // btnExclusion
            // 
            this.btnExclusion.Font = new System.Drawing.Font("メイリオ", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnExclusion.Location = new System.Drawing.Point(489, 511);
            this.btnExclusion.Name = "btnExclusion";
            this.btnExclusion.Size = new System.Drawing.Size(30, 100);
            this.btnExclusion.TabIndex = 18;
            this.btnExclusion.Text = "◂";
            this.btnExclusion.UseVisualStyleBackColor = true;
            this.btnExclusion.Click += new System.EventHandler(this.btnExclusion_Click);
            // 
            // btnExport
            // 
            this.btnExport.Location = new System.Drawing.Point(727, 688);
            this.btnExport.Name = "btnExport";
            this.btnExport.Size = new System.Drawing.Size(130, 30);
            this.btnExport.TabIndex = 20;
            this.btnExport.Text = "試験成績表出力";
            this.btnExport.UseVisualStyleBackColor = true;
            // 
            // btnImport
            // 
            this.btnImport.Location = new System.Drawing.Point(863, 688);
            this.btnImport.Name = "btnImport";
            this.btnImport.Size = new System.Drawing.Size(130, 30);
            this.btnImport.TabIndex = 21;
            this.btnImport.Text = "試験成績表取込";
            this.btnImport.UseVisualStyleBackColor = true;
            // 
            // txtSaisuiDate
            // 
            this.txtSaisuiDate.Location = new System.Drawing.Point(127, 164);
            this.txtSaisuiDate.Name = "txtSaisuiDate";
            this.txtSaisuiDate.Size = new System.Drawing.Size(100, 31);
            this.txtSaisuiDate.TabIndex = 9;
            this.txtSaisuiDate.ValueChanged += new Suisitu.Components.Controls.WarekiDate.ValueChangedHandler(this.txtSaisuiDate_ValueChanged);
            // 
            // cboGyosyaNameN
            // 
            this.cboGyosyaNameN.ImeMode = System.Windows.Forms.ImeMode.Hiragana;
            this.cboGyosyaNameN.Location = new System.Drawing.Point(377, 165);
            this.cboGyosyaNameN.Name = "cboGyosyaNameN";
            this.cboGyosyaNameN.Size = new System.Drawing.Size(317, 31);
            this.cboGyosyaNameN.TabIndex = 10;
            this.cboGyosyaNameN.Value = "-1";
            this.cboGyosyaNameN.SelectedIndexChanged += new Suisitu.Components.Controls.ValueCombo.SelectedIndexChangedHandler(this.cboGyosyaNameN_SelectedIndexChanged);
            // 
            // backColorChangeOnFocusProvider1
            // 
            this.backColorChangeOnFocusProvider1.Target = this;
            // 
            // txtSaisuiKaiNengetu
            // 
            this.txtSaisuiKaiNengetu.Location = new System.Drawing.Point(111, 45);
            this.txtSaisuiKaiNengetu.Name = "txtSaisuiKaiNengetu";
            this.txtSaisuiKaiNengetu.Size = new System.Drawing.Size(100, 31);
            this.txtSaisuiKaiNengetu.TabIndex = 2;
            // 
            // seiriNoDataGridViewTextBoxColumn
            // 
            this.seiriNoDataGridViewTextBoxColumn.DataPropertyName = "SeiriNo";
            this.seiriNoDataGridViewTextBoxColumn.HeaderText = "整理番号";
            this.seiriNoDataGridViewTextBoxColumn.Name = "seiriNoDataGridViewTextBoxColumn";
            this.seiriNoDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // jigyosyoNameNDataGridViewTextBoxColumn
            // 
            this.jigyosyoNameNDataGridViewTextBoxColumn.DataPropertyName = "JigyosyoNameN";
            this.jigyosyoNameNDataGridViewTextBoxColumn.HeaderText = "工場事業場名称";
            this.jigyosyoNameNDataGridViewTextBoxColumn.Name = "jigyosyoNameNDataGridViewTextBoxColumn";
            this.jigyosyoNameNDataGridViewTextBoxColumn.ReadOnly = true;
            this.jigyosyoNameNDataGridViewTextBoxColumn.Width = 319;
            // 
            // bsSaisuiKeikakuJigyojoItiran
            // 
            this.bsSaisuiKeikakuJigyojoItiran.DataSource = typeof(Suisitu.Entity.JigyojoItiranEntity);
            // 
            // bsSaisuiKeikaku
            // 
            this.bsSaisuiKeikaku.DataSource = typeof(Suisitu.Entity.SaisuiKeikakuEntity);
            // 
            // SaisuiKeikaku
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.ClientSize = new System.Drawing.Size(1008, 730);
            this.Controls.Add(this.txtSaisuiDate);
            this.Controls.Add(this.btnExclusion);
            this.Controls.Add(this.btnSelect);
            this.Controls.Add(this.lblSaisuiKeikakuLine);
            this.Controls.Add(this.lblSaisuiKeikaku);
            this.Controls.Add(this.lblCountNumberTodokedeRireki);
            this.Controls.Add(this.dgvSaisuiKeikaku);
            this.Controls.Add(this.dgvJigyojo);
            this.Controls.Add(this.lblCountRecordTodokedeRireki);
            this.Controls.Add(this.lblJigyojoLine);
            this.Controls.Add(this.lblJigyojo);
            this.Controls.Add(this.cboGyosyaNameN);
            this.Controls.Add(this.btnRegist);
            this.Controls.Add(this.btnImport);
            this.Controls.Add(this.btnExport);
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.lblSaisuiKeikakuJyoho);
            this.Controls.Add(this.pnlSaisuiKeikaku);
            this.Controls.Add(this.txtSaisuisyaNameN);
            this.Controls.Add(this.txtSyozaiJyusyo);
            this.Controls.Add(this.txtJigyosyoNameN);
            this.Controls.Add(this.txtSeiriNo);
            this.Controls.Add(this.lblSaisuisyaNameN);
            this.Controls.Add(this.lblGyosyaNameN);
            this.Controls.Add(this.lblSyozaiJyusyo);
            this.Controls.Add(this.lblJigyosyoNameN);
            this.Controls.Add(this.lblSeiriNo);
            this.Controls.Add(this.lblSaisuiDate);
            this.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "SaisuiKeikaku";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "採水計画";
            this.Load += new System.EventHandler(this.SelectHaisuikoNo_Load);
            this.pnlSaisuiKeikaku.ResumeLayout(false);
            this.pnlSaisuiKeikaku.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvJigyojo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSaisuiKeikaku)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsSaisuiKeikakuJigyojoItiran)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsSaisuiKeikaku)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel pnlSaisuiKeikaku;
        private System.Windows.Forms.Button btnItiran;
        private System.Windows.Forms.TextBox txtSaisuiKaiStatus;
        private System.Windows.Forms.TextBox txtSaisuiKaiKai;
        private System.Windows.Forms.TextBox txtSheetDate;
        private System.Windows.Forms.TextBox txtNendo;
        private System.Windows.Forms.Label lblSheetDate;
        private System.Windows.Forms.Label lblsaisuiKai;
        private System.Windows.Forms.Label lblNendo;
        private System.Windows.Forms.Label lblSaisuiKeikakuJyoho;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnRegist;
        private System.Windows.Forms.Label lblSaisuiDate;
        private System.Windows.Forms.Label lblGyosyaNameN;
        private Components.Controls.ValueCombo cboGyosyaNameN;
        private System.Windows.Forms.Label lblSaisuisyaNameN;
        private System.Windows.Forms.TextBox txtSaisuisyaNameN;
        private System.Windows.Forms.Label lblJigyojoLine;
        private System.Windows.Forms.Label lblJigyojo;
        private System.Windows.Forms.Label lblSeiriNo;
        private System.Windows.Forms.TextBox txtSeiriNo;
        private System.Windows.Forms.Label lblJigyosyoNameN;
        private System.Windows.Forms.TextBox txtJigyosyoNameN;
        private System.Windows.Forms.Label lblSyozaiJyusyo;
        private System.Windows.Forms.TextBox txtSyozaiJyusyo;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.Label lblCountNumberTodokedeRireki;
        public System.Windows.Forms.DataGridView dgvJigyojo;
        private System.Windows.Forms.Label lblCountRecordTodokedeRireki;
        private System.Windows.Forms.Label lblSaisuiKeikakuLine;
        private System.Windows.Forms.Label lblSaisuiKeikaku;
        public System.Windows.Forms.DataGridView dgvSaisuiKeikaku;
        private System.Windows.Forms.Button btnSelect;
        private System.Windows.Forms.Button btnExclusion;
        private System.Windows.Forms.Button btnExport;
        private System.Windows.Forms.Button btnImport;
        private Component.BackColorChangeOnFocusProvider backColorChangeOnFocusProvider1;
        private System.Windows.Forms.BindingSource bsSaisuiKeikaku;
        private System.Windows.Forms.BindingSource bsSaisuiKeikakuJigyojoItiran;
        private System.Windows.Forms.DataGridViewTextBoxColumn seiriNoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn jigyosyoNameNDataGridViewTextBoxColumn;
        private Components.Controls.WarekiDate txtSaisuiDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn KANRINO;
        private System.Windows.Forms.DataGridViewTextBoxColumn JIGYOSYONAMEN;
        private System.Windows.Forms.DataGridViewTextBoxColumn TATIIRIKANRINO;
        private System.Windows.Forms.DataGridViewTextBoxColumn HAISUIKONO;
        private System.Windows.Forms.TextBox txtSaisuiKaiNengetu;
    }
}