﻿using Suisitu.Common;
using Suisitu.Dao;
using Suisitu.Entity;
using Suisitu.Enum;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using Suisitu.Components.Common;

namespace Suisitu.Forms.SD03
{
    using CommonEvents = Suisitu.Common.Events;

    /// <summary>
    /// 採水計画情報画面クラス
    /// </summary>
    public partial class SaisuiKeikaku : Form
    {
        // 採水年月回情報
        private string saisuiKai_;

        // コピー元採水年月回情報
        private string copySaisuiKai_;

        // 採水計画情報
        private SaisuiKeikakuEntity saisuiKeikaku_;

        // アクションモード
        private EnumActionKbn actionMode_;

        // 事業場検索キー
        private JigyojoItiranEntity searchKey_;

        // 採水項目リスト
        IEnumerable<KomokuCodeEntity> saisuiKomokuList_;

        // 登録済みフラグ
        private bool registeredFlag_;

        #region コンストラクタ

        /// <summary>
        /// コンストラクタ
        /// </summary>
        public SaisuiKeikaku(EnumActionKbn mode, string saisuiKai, string copySaisuiKai = null)
        {
            InitializeComponent();

            this.txtSaisuiDate.KeyPress += new KeyPressEventHandler(CommonEvents.txtHalfNumber_KeyPress);
            this.txtSeiriNo.KeyPress += new KeyPressEventHandler(CommonEvents.txtHalfNumber_KeyPress);

            saisuiKai_ = saisuiKai;
            copySaisuiKai_ = copySaisuiKai;
            actionMode_ = mode;
        }


        #endregion


        #region イベント

        /// <summary>
        /// 画面が表示されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void SelectHaisuikoNo_Load(object sender, EventArgs e)
        {
            // 採水計画一覧項目列追加
            AddColumns();
            // 表示初期化
            InitializeData();

            // 採水年月の表示
            txtSaisuiKaiNengetu.Text = WarekiDateUtil.GetShortJapaneseText(saisuiKai_.Substring(0, 4) + "/" + saisuiKai_.Substring(4, 2));
            txtSaisuiKaiNengetu.Tag = saisuiKai_.Substring(0, 6);
        }

        /// <summary>
        /// 一覧ボタンが押下されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnItiran_Click(object sender, EventArgs e)
        {
            if (!registeredFlag_)
            {
                DialogResult result = MessageBox.Show("編集中のデータを保存しますか？", Text,
                    MessageBoxButtons.YesNo, MessageBoxIcon.Information, MessageBoxDefaultButton.Button2);

                if (result == DialogResult.Yes)
                {
                    // 採水計画情報を登録する
                    if (Register())
                    {
                        Close();
                    }
                }else if(result == DialogResult.No)
                {
                    Close();
                }
            }
            else
            {
                Close();
            }
        }

        /// <summary>
        /// キャンセルボタンが押下されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnCancel_Click(object sender, EventArgs e)
        {
            InitializeData();
        }

        /// <summary>
        /// 登録ボタンが押下されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnRegist_Click(object sender, EventArgs e)
        {
            if (Register())
            {
                Close();
            }
        }
        /// <summary>
        /// 検索ボタンが押下されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnSearch_Click(object sender, EventArgs e)
        {
            searchKey_ = new JigyojoItiranEntity()
            {
                Nendo = 9999,
                SeiriNo = DBUtils.AddWildCard(txtSeiriNo.Text),
                JigyosyoNameN = DBUtils.AddWildCard(txtJigyosyoNameN.Text),
                SyozaiJyusyo = DBUtils.AddWildCard(txtSyozaiJyusyo.Text),
            };

            IEnumerable<JigyojoItiranEntity> list = JigyojoItiranDao.SelectList(searchKey_);
            bsSaisuiKeikakuJigyojoItiran.DataSource = list;
            lblCountRecordTodokedeRireki.Text = list.Count().ToString();

            var isExist = list.Count() > 0;

            if (!isExist)
                MessageUtils.NoFoundDataMessage(Text);

        }

        /// <summary>
        /// ▸ボタンが押下されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnSelect_Click(object sender, EventArgs e)
        {
            if(dgvJigyojo.SelectedRows.Count == 0)
            {
                MessageBox.Show("工場事業場が選択されていません。", Text, MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            ShowSelectHaisuikoNo();
            if (registeredFlag_)
            {
                registeredFlag_ = false;
                SetLockMatrix();
            }
        }

        /// <summary>
        /// ◂ボタンが押下されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnExclusion_Click(object sender, EventArgs e)
        {
            if (dgvSaisuiKeikaku.SelectedRows.Count == 0)
            {
                MessageBox.Show("削除する工場事業場・排水口番号が選択されていません。", Text, MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            dgvSaisuiKeikaku.Rows.Remove(dgvSaisuiKeikaku.CurrentRow);
            if (registeredFlag_)
            {
                registeredFlag_ = false;
                SetLockMatrix();
            }
        }

        /// <summary>
        /// 事業場一覧がダブルクリックされたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void dgvJigyojo_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (bsSaisuiKeikakuJigyojoItiran.Current != null)
                ShowSelectHaisuikoNo();
        }

        /// 採水年月日が変更されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void txtSaisuiDate_ValueChanged(object sender, EventArgs e)
        {
            Changed();
        }

        /// 採水業者が変更されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void cboGyosyaNameN_SelectedIndexChanged(object sender, Components.Controls.ValueComboEventArgs e)
        {
            Changed();
        }

        /// 採水者名が変更されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void txtSaisuisyaNameN_TextChanged(object sender, EventArgs e)
        {
            Changed();
        }

        #endregion

        #region プライベートメソッド

        /// <summary>
        /// ロックマトリックス定義
        /// </summary>
        private void SetLockMatrix()
        {
            // 共通
            txtNendo.Enabled = false;
            txtSaisuiKaiNengetu.Enabled = false;
            txtSaisuiKaiKai.Enabled = false;
            txtSaisuiKaiStatus.Enabled = false;
            txtSheetDate.Enabled = false;
            btnItiran.Enabled = true;
            dgvSaisuiKeikaku.Enabled = true;

            // 年度が通年以外の場合
            if (saisuiKeikaku_.Nendo != 9999)
            {
                btnRegist.Enabled = false;
                btnCancel.Enabled = false;
                txtSaisuiDate.Enabled = false;
                cboGyosyaNameN.Enabled = false;
                txtSaisuisyaNameN.Enabled = false;
                txtSeiriNo.Enabled = false;
                txtJigyosyoNameN.Enabled = false;
                txtSyozaiJyusyo.Enabled = false;
                btnSearch.Enabled = false;
                dgvJigyojo.Enabled = false;
                btnSelect.Enabled = false;
                btnExclusion.Enabled = false;
                btnImport.Enabled = false;
                btnExport.Enabled = false;

            }
            else
                // 年度が通年の場合
                if (saisuiKeikaku_.Nendo == 9999)
            {
                btnCancel.Enabled = true;
                txtSaisuiDate.Enabled = true;
                cboGyosyaNameN.Enabled = true;
                txtSaisuisyaNameN.Enabled = true;
                txtSeiriNo.Enabled = true;
                txtJigyosyoNameN.Enabled = true;
                txtSyozaiJyusyo.Enabled = true;
                btnSearch.Enabled = true;
                dgvJigyojo.Enabled = true;

                // statusが「0:計画」以外の場合
                if (saisuiKeikaku_.Status != "0")
                {
                    btnSelect.Enabled = false;
                    btnExclusion.Enabled = false;
                }
                // statusが「0:計画」の場合
                else if (saisuiKeikaku_.Status == "0")
                {
                    btnSelect.Enabled = true;
                    btnExclusion.Enabled = true;
                }
                
                // statusが「1:依頼中」以外の場合
                if (saisuiKeikaku_.Status != "1")
                {
                    btnImport.Enabled = false;
                }
                // statusが「1:依頼中」の場合
                else if (saisuiKeikaku_.Status == "1")
                {
                    btnImport.Enabled = true;
                }

                // 未登録の場合
                if (!registeredFlag_)
                {
                    btnRegist.Enabled = true;
                    btnExport.Enabled = false;
                }
                else
                {
                    btnRegist.Enabled = false;
                    btnExport.Enabled = true;
                }
            }

        }

        /// <summary>
        /// 画面に表示するデータを初期化します。
        /// </summary>
        private void InitializeData()
        {
            // 産業分類中分類コンボボックスの初期化
            cboGyosyaNameN.InitCombo(SGyosyaCodeDao.GetMasterData());

            dgvSaisuiKeikaku.Rows.Clear();

            switch (actionMode_)
            {
                // 選択の場合
                case EnumActionKbn.Select:
                    saisuiKeikaku_ = SaisuiKeikakuDao.Select(saisuiKai_);
                    bsSaisuiKeikaku.DataSource = saisuiKeikaku_;
                    txtSaisuiDate.Value = saisuiKeikaku_.SaisuiDate;
                    cboGyosyaNameN.SelectedKey = saisuiKeikaku_.GyosyaCode;

                    SetSaisuiItiran(saisuiKai_);

                    registeredFlag_ = true;

                    break;
                // 複写の場合
                case EnumActionKbn.Copy:

                    // コピー元情報を設定
                    saisuiKeikaku_ = SaisuiKeikakuDao.Select(copySaisuiKai_);

                    SetSaisuiItiran(copySaisuiKai_);

                    // 登録用情報で上書き
                    saisuiKeikaku_.Nendo = 9999;
                    saisuiKeikaku_.SaisuiKai = saisuiKai_;
                    saisuiKeikaku_.Status = "0";
                    saisuiKeikaku_.StatusKubunNameN = "計画";
                    saisuiKeikaku_.SheetDate = null;

                    bsSaisuiKeikaku.DataSource = saisuiKeikaku_;
                    txtSaisuiDate.Value = saisuiKeikaku_.SaisuiDate;
                    cboGyosyaNameN.SelectedKey = saisuiKeikaku_.GyosyaCode;

                    registeredFlag_ = false;

                    break;

                // 追加の場合
                case EnumActionKbn.Add:

                    saisuiKeikaku_ = new SaisuiKeikakuEntity
                    {
                        Nendo = 9999,
                        SaisuiKai = saisuiKai_,
                        Status = "0",
                        StatusKubunNameN = "計画",
                        SheetDate = null,
                    };

                    bsSaisuiKeikaku.DataSource = saisuiKeikaku_;

                    registeredFlag_ = false;

                    break;
            }
            // 画面ロックマトリックスを定義する
            SetLockMatrix();
        }

        /// <summary>
        /// 登録するデータのチェックをします。
        /// </summary>
        ///<returns>True:チェックOK / False:チェックNG</returns>
        private bool RegisterCheck()
        {
            if (dgvSaisuiKeikaku.SelectedRows.Count == 0)
            {
                MessageBox.Show("採水計画が指定されていません。", Text, MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            if (NoCheckList().Count() > 0)
            {
                MessageBox.Show("「" + string.Join(",",NoCheckList()) + "」" + "の測定項目が指定されていません。", Text, MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            return true;
        }

        /// <summary>
        /// 項目コード表の値に応じてdatagridviewに列を追加します。
        /// </summary>
        private void AddColumns()
        {
            DataTable dt = new DataTable();
            saisuiKomokuList_ = KomokuCodeDao.GetKomokuNameNAndKomokuCodeOfNotSonota();
            foreach (KomokuCodeEntity komku in saisuiKomokuList_)
            {
                dgvSaisuiKeikaku.Columns.Add(new DataGridViewCheckBoxColumn()
                {
                    Name = "KOMOKUCODE" + komku.KomokuCode,
                    HeaderText = komku.KomokuNameN,
                    Width = komku.KomokuNameN.Length < 4 ? komku.KomokuNameN.Length * 30 : komku.KomokuNameN.Length * 15,
                });
            }
        }

        /// <summary>
        /// 排水口番号選択画面を表示し、採水計画に行を追加します。
        /// </summary>
        private void ShowSelectHaisuikoNo()
        {
            string selectHaisuikoNo;
            List<string> haisuikoList = new List<string>();
            bool okFlag;

            JigyojoItiranEntity jigyojo = (JigyojoItiranEntity)bsSaisuiKeikakuJigyojoItiran.Current;
            for (int row = 0; row < dgvSaisuiKeikaku.Rows.Count; row++)
            {
                if(dgvSaisuiKeikaku["KANRINO",row].Value != null && Convert.ToInt32(dgvSaisuiKeikaku["KANRINO", row].Value) == jigyojo.KanriNo)
                {
                    haisuikoList.Add(Convert.ToString(dgvSaisuiKeikaku["HAISUIKONO", row].Value));
                }

            }
            // 付帯設備等情報画面を表示する
            using (var dialog = new SelectHaisuikoNo(jigyojo, haisuikoList))
            {
                dialog.ShowDialog();
                selectHaisuikoNo = dialog.selectHaisuikoNo_;
                okFlag = dialog.okFlag_;
            }
            if (!okFlag)
            {
                return;
            }
            object[] obj2 = { jigyojo.KanriNo, jigyojo.JigyosyoNameN, null, selectHaisuikoNo };
            int addIdx = dgvSaisuiKeikaku.Rows.Add(obj2);

            HaisuikoKomokuItiranEntity searchHaisuikoKomoku = new HaisuikoKomokuItiranEntity
            {
                Nendo = saisuiKeikaku_.Nendo,
                KanriNo = Convert.ToInt32(dgvSaisuiKeikaku["KANRINO", addIdx].Value),
                HaisuikoNo = Convert.ToString(dgvSaisuiKeikaku["HAISUIKONO", addIdx].Value),
            };

            IEnumerable<HaisuikoKomokuItiranEntity> haisuikoKomokuList = HaisuikoKomokuDao.SelectList(searchHaisuikoKomoku);

            foreach(HaisuikoKomokuItiranEntity haisuikoKomoku in haisuikoKomokuList)
            {
                dgvSaisuiKeikaku["KOMOKUCODE" + haisuikoKomoku.KomokuCode, addIdx].Value = true;
            }
        }

        /// <summary>
        /// 指定された採水年月回の採水計画一覧をDataGridViewに表示します。
        /// </summary>
        /// <param name="saisuiKai">採水年月回</param>
        private void SetSaisuiItiran(string saisuiKai)
        {
            IEnumerable<SaisuiKeikakuEntity> list = SaisuiKeikakuDao.SelectSaisuiKaiList(saisuiKai);
            foreach (SaisuiKeikakuEntity saisui in list)
            {
                object[] obj = { saisui.KanriNo, saisui.JigyosyoNameN, saisui.TatiiriKanriNo, saisui.HaisuikoNo };

                int idx = dgvSaisuiKeikaku.Rows.Add(obj);

                IEnumerable<SaisuiKeikakuEntity> komokuList = SaisuiKeikakuDao.SelectSaisuiKaiKomokuList(saisui);
                foreach (SaisuiKeikakuEntity komoku in komokuList)
                {
                    dgvSaisuiKeikaku["KOMOKUCODE" + komoku.KomokuCode, idx].Value = true;
                }
            }
        }

        /// <summary>
        /// 採水計画表にデータを登録します。
        /// </summary>
        ///<returns>True:登録OK / False:登録NG</returns>
        private bool Register()
        {
            if (!RegisterCheck())
            {
                return false;
            }
            SaisuiKeikakuDao.Delete(txtSaisuiKaiNengetu.Tag + txtSaisuiKaiKai.Text);
            SaisuiKeikakuEntity data = new SaisuiKeikakuEntity
            {
                Nendo = 9999,
                SaisuiKai = txtSaisuiKaiNengetu.Tag + txtSaisuiKaiKai.Text,
                TatiiriKanriNo = null,
                SaisuiDate = CommonUtils.FormatToDate(txtSaisuiDate.Value),
                Status = "0",
                GyosyaCode = cboGyosyaNameN.Value,
                SaisuisyaNameN = txtSaisuisyaNameN.Text,
                SheetDate = null,
                TorokuDate = DateTime.Now.ToString(),
                HaisiFlag = null,
                UpdDate = DateTime.Now.ToString(),
                Rev = Convert.ToInt32(((SaisuiKeikakuEntity)bsSaisuiKeikaku.Current).Rev) + 1,
            };

            for (int row = 0; row < dgvSaisuiKeikaku.Rows.Count; row++)
            {
                data.KanriNo = Convert.ToInt32(dgvSaisuiKeikaku["KANRINO", row].Value);
                data.HaisuikoNo = dgvSaisuiKeikaku["HAISUIKONO", row].Value.ToString();
                foreach (KomokuCodeEntity komoku in saisuiKomokuList_)
                {
                    data.KomokuCode = komoku.KomokuCode;
                    if(dgvSaisuiKeikaku["KOMOKUCODE" + komoku.KomokuCode, row].Value != null && dgvSaisuiKeikaku["KOMOKUCODE" + komoku.KomokuCode, row].Value.Equals(true))
                    {
                        SaisuiKeikakuDao.Insert(data);
                    }
                }
            }
            return true;
        }

        /// <summary>
        /// 採水計画のうち各測定項目にチェックが一つもない事業場一覧を返します。
        /// </summary>
        /// <returns>事業場一覧</returns>
        private List<string> NoCheckList()
        {
            List<string> errList = new List<string>();
            for(int i = 0; i < dgvSaisuiKeikaku.Rows.Count; i++)
            {
                bool noCheck = true;
                foreach (KomokuCodeEntity komoku in saisuiKomokuList_)
                {
                    if(Convert.ToBoolean(dgvSaisuiKeikaku["KOMOKUCODE" + komoku.KomokuCode, i].Value))
                    {
                        noCheck = false;
                        break;
                    }
                }
                if (noCheck)
                {
                    errList.Add(Convert.ToString(dgvSaisuiKeikaku["JIGYOSYONAMEN", i].Value));
                }
            }
            return errList;
        }

        /// <summary>
        /// 登録内容が変更されたとき、statusを計画に変更し登録済フラグをfalseに設定します。
        /// </summary>
        private void Changed()
        {
            if (registeredFlag_)
            {
                saisuiKeikaku_.Status = "0";
                saisuiKeikaku_.StatusKubunNameN = "計画";
                txtSaisuiKaiStatus.Text = "計画";
                txtSheetDate.Text = null;
                saisuiKeikaku_.SheetDate = null;
                registeredFlag_ = false;
                SetLockMatrix();
            }
        }

        #endregion

    }
}
