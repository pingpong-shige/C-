﻿namespace Suisitu.Forms.SD03
{
    partial class SaisuiKeikakuItiran
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.pnlSaisuiKeikaku = new System.Windows.Forms.Panel();
            this.btnEnd = new System.Windows.Forms.Button();
            this.btnSearch = new System.Windows.Forms.Button();
            this.lblWavyLine = new System.Windows.Forms.Label();
            this.cboNendo = new System.Windows.Forms.ComboBox();
            this.lblSaisuiDate = new System.Windows.Forms.Label();
            this.lblNendo = new System.Windows.Forms.Label();
            this.pnlSaisuiKeikakuItiran = new System.Windows.Forms.Panel();
            this.lblCountRecord = new System.Windows.Forms.Label();
            this.lblCountNumber = new System.Windows.Forms.Label();
            this.btnBottom = new System.Windows.Forms.Button();
            this.btnTop = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnStop = new System.Windows.Forms.Button();
            this.btnSelect = new System.Windows.Forms.Button();
            this.btnCopy = new System.Windows.Forms.Button();
            this.btnAdd = new System.Windows.Forms.Button();
            this.dgvSaisuiKeikakuItiran = new System.Windows.Forms.DataGridView();
            this.bsSaisuiKeikakuItiran = new System.Windows.Forms.BindingSource(this.components);
            this.txtSaisuiDateTo = new Suisitu.Components.Controls.WarekiDate();
            this.txtSaisuiDateFrom = new Suisitu.Components.Controls.WarekiDate();
            this.backColorChangeOnFocusProvider1 = new Suisitu.Component.BackColorChangeOnFocusProvider();
            this.SaisuiKaiV = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SaisuiDateV = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.KentaiSu = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SheetDateV = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.StatusKubunNameN = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Nendo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Status = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pnlSaisuiKeikaku.SuspendLayout();
            this.pnlSaisuiKeikakuItiran.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSaisuiKeikakuItiran)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsSaisuiKeikakuItiran)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlSaisuiKeikaku
            // 
            this.pnlSaisuiKeikaku.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlSaisuiKeikaku.Controls.Add(this.btnEnd);
            this.pnlSaisuiKeikaku.Controls.Add(this.btnSearch);
            this.pnlSaisuiKeikaku.Controls.Add(this.txtSaisuiDateTo);
            this.pnlSaisuiKeikaku.Controls.Add(this.lblWavyLine);
            this.pnlSaisuiKeikaku.Controls.Add(this.txtSaisuiDateFrom);
            this.pnlSaisuiKeikaku.Controls.Add(this.cboNendo);
            this.pnlSaisuiKeikaku.Controls.Add(this.lblSaisuiDate);
            this.pnlSaisuiKeikaku.Controls.Add(this.lblNendo);
            this.pnlSaisuiKeikaku.Location = new System.Drawing.Point(15, 15);
            this.pnlSaisuiKeikaku.Name = "pnlSaisuiKeikaku";
            this.pnlSaisuiKeikaku.Size = new System.Drawing.Size(978, 89);
            this.pnlSaisuiKeikaku.TabIndex = 1;
            // 
            // btnEnd
            // 
            this.btnEnd.Location = new System.Drawing.Point(861, 45);
            this.btnEnd.Name = "btnEnd";
            this.btnEnd.Size = new System.Drawing.Size(100, 30);
            this.btnEnd.TabIndex = 5;
            this.btnEnd.Text = "終了";
            this.btnEnd.UseVisualStyleBackColor = true;
            this.btnEnd.Click += new System.EventHandler(this.btnEnd_Click);
            // 
            // btnSearch
            // 
            this.btnSearch.Location = new System.Drawing.Point(755, 45);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(100, 30);
            this.btnSearch.TabIndex = 4;
            this.btnSearch.Text = "検索";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // lblWavyLine
            // 
            this.lblWavyLine.AutoSize = true;
            this.lblWavyLine.Location = new System.Drawing.Point(233, 48);
            this.lblWavyLine.Name = "lblWavyLine";
            this.lblWavyLine.Size = new System.Drawing.Size(23, 24);
            this.lblWavyLine.TabIndex = 0;
            this.lblWavyLine.Text = "~";
            // 
            // cboNendo
            // 
            this.cboNendo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboNendo.FormattingEnabled = true;
            this.cboNendo.Location = new System.Drawing.Point(109, 12);
            this.cboNendo.Name = "cboNendo";
            this.cboNendo.Size = new System.Drawing.Size(121, 32);
            this.cboNendo.TabIndex = 1;
            this.cboNendo.SelectedIndexChanged += new System.EventHandler(this.cboNendo_SelectedIndexChanged);
            // 
            // lblSaisuiDate
            // 
            this.lblSaisuiDate.AutoSize = true;
            this.lblSaisuiDate.Location = new System.Drawing.Point(15, 48);
            this.lblSaisuiDate.Name = "lblSaisuiDate";
            this.lblSaisuiDate.Size = new System.Drawing.Size(90, 24);
            this.lblSaisuiDate.TabIndex = 0;
            this.lblSaisuiDate.Text = "採水年月日";
            // 
            // lblNendo
            // 
            this.lblNendo.AutoSize = true;
            this.lblNendo.Location = new System.Drawing.Point(15, 15);
            this.lblNendo.Name = "lblNendo";
            this.lblNendo.Size = new System.Drawing.Size(42, 24);
            this.lblNendo.TabIndex = 0;
            this.lblNendo.Text = "年度";
            // 
            // pnlSaisuiKeikakuItiran
            // 
            this.pnlSaisuiKeikakuItiran.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlSaisuiKeikakuItiran.Controls.Add(this.lblCountRecord);
            this.pnlSaisuiKeikakuItiran.Controls.Add(this.lblCountNumber);
            this.pnlSaisuiKeikakuItiran.Controls.Add(this.btnBottom);
            this.pnlSaisuiKeikakuItiran.Controls.Add(this.btnTop);
            this.pnlSaisuiKeikakuItiran.Controls.Add(this.btnDelete);
            this.pnlSaisuiKeikakuItiran.Controls.Add(this.btnStop);
            this.pnlSaisuiKeikakuItiran.Controls.Add(this.btnSelect);
            this.pnlSaisuiKeikakuItiran.Controls.Add(this.btnCopy);
            this.pnlSaisuiKeikakuItiran.Controls.Add(this.btnAdd);
            this.pnlSaisuiKeikakuItiran.Controls.Add(this.dgvSaisuiKeikakuItiran);
            this.pnlSaisuiKeikakuItiran.Location = new System.Drawing.Point(15, 111);
            this.pnlSaisuiKeikakuItiran.Name = "pnlSaisuiKeikakuItiran";
            this.pnlSaisuiKeikakuItiran.Size = new System.Drawing.Size(978, 604);
            this.pnlSaisuiKeikakuItiran.TabIndex = 2;
            // 
            // lblCountRecord
            // 
            this.lblCountRecord.AutoSize = true;
            this.lblCountRecord.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblCountRecord.Location = new System.Drawing.Point(75, 25);
            this.lblCountRecord.Name = "lblCountRecord";
            this.lblCountRecord.Size = new System.Drawing.Size(20, 24);
            this.lblCountRecord.TabIndex = 17;
            this.lblCountRecord.Text = "0";
            // 
            // lblCountNumber
            // 
            this.lblCountNumber.AutoSize = true;
            this.lblCountNumber.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblCountNumber.Location = new System.Drawing.Point(15, 25);
            this.lblCountNumber.Name = "lblCountNumber";
            this.lblCountNumber.Size = new System.Drawing.Size(65, 24);
            this.lblCountNumber.TabIndex = 16;
            this.lblCountNumber.Text = "件数 = ";
            // 
            // btnBottom
            // 
            this.btnBottom.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnBottom.Location = new System.Drawing.Point(861, 9);
            this.btnBottom.Name = "btnBottom";
            this.btnBottom.Size = new System.Drawing.Size(100, 30);
            this.btnBottom.TabIndex = 7;
            this.btnBottom.Text = "最後";
            this.btnBottom.UseVisualStyleBackColor = true;
            this.btnBottom.Click += new System.EventHandler(this.btnBottom_Click);
            // 
            // btnTop
            // 
            this.btnTop.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnTop.Location = new System.Drawing.Point(755, 9);
            this.btnTop.Name = "btnTop";
            this.btnTop.Size = new System.Drawing.Size(100, 30);
            this.btnTop.TabIndex = 6;
            this.btnTop.Text = "先頭";
            this.btnTop.UseVisualStyleBackColor = true;
            this.btnTop.Click += new System.EventHandler(this.btnTop_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnDelete.Location = new System.Drawing.Point(437, 558);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(100, 30);
            this.btnDelete.TabIndex = 9;
            this.btnDelete.Text = "削除";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnStop
            // 
            this.btnStop.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnStop.Location = new System.Drawing.Point(543, 558);
            this.btnStop.Name = "btnStop";
            this.btnStop.Size = new System.Drawing.Size(100, 30);
            this.btnStop.TabIndex = 10;
            this.btnStop.Text = "中止";
            this.btnStop.UseVisualStyleBackColor = true;
            this.btnStop.Click += new System.EventHandler(this.btnStop_Click);
            // 
            // btnSelect
            // 
            this.btnSelect.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnSelect.Location = new System.Drawing.Point(861, 558);
            this.btnSelect.Name = "btnSelect";
            this.btnSelect.Size = new System.Drawing.Size(100, 30);
            this.btnSelect.TabIndex = 13;
            this.btnSelect.Text = "選択";
            this.btnSelect.UseVisualStyleBackColor = true;
            this.btnSelect.Click += new System.EventHandler(this.btnSelect_Click);
            // 
            // btnCopy
            // 
            this.btnCopy.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnCopy.Location = new System.Drawing.Point(755, 558);
            this.btnCopy.Name = "btnCopy";
            this.btnCopy.Size = new System.Drawing.Size(100, 30);
            this.btnCopy.TabIndex = 12;
            this.btnCopy.Text = "複写";
            this.btnCopy.UseVisualStyleBackColor = true;
            this.btnCopy.Click += new System.EventHandler(this.btnCopy_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnAdd.Location = new System.Drawing.Point(649, 558);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(100, 30);
            this.btnAdd.TabIndex = 11;
            this.btnAdd.Text = "追加";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // dgvSaisuiKeikakuItiran
            // 
            this.dgvSaisuiKeikakuItiran.AllowUserToAddRows = false;
            this.dgvSaisuiKeikakuItiran.AllowUserToDeleteRows = false;
            this.dgvSaisuiKeikakuItiran.AllowUserToResizeColumns = false;
            this.dgvSaisuiKeikakuItiran.AllowUserToResizeRows = false;
            this.dgvSaisuiKeikakuItiran.AutoGenerateColumns = false;
            this.dgvSaisuiKeikakuItiran.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvSaisuiKeikakuItiran.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.SaisuiKaiV,
            this.SaisuiDateV,
            this.KentaiSu,
            this.SheetDateV,
            this.StatusKubunNameN,
            this.Nendo,
            this.Status});
            this.dgvSaisuiKeikakuItiran.DataSource = this.bsSaisuiKeikakuItiran;
            this.dgvSaisuiKeikakuItiran.Location = new System.Drawing.Point(15, 49);
            this.dgvSaisuiKeikakuItiran.MultiSelect = false;
            this.dgvSaisuiKeikakuItiran.Name = "dgvSaisuiKeikakuItiran";
            this.dgvSaisuiKeikakuItiran.ReadOnly = true;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvSaisuiKeikakuItiran.RowHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvSaisuiKeikakuItiran.RowHeadersVisible = false;
            this.dgvSaisuiKeikakuItiran.RowHeadersWidth = 25;
            this.dgvSaisuiKeikakuItiran.RowTemplate.Height = 21;
            this.dgvSaisuiKeikakuItiran.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvSaisuiKeikakuItiran.Size = new System.Drawing.Size(946, 496);
            this.dgvSaisuiKeikakuItiran.TabIndex = 8;
            this.dgvSaisuiKeikakuItiran.TabStop = false;
            this.dgvSaisuiKeikakuItiran.CellMouseDoubleClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgvSaisuiKeikakuItiran_CellMouseDoubleClick);
            this.dgvSaisuiKeikakuItiran.SelectionChanged += new System.EventHandler(this.dgvSaisuiKeikakuItiran_SelectionChanged);
            // 
            // bsSaisuiKeikakuItiran
            // 
            this.bsSaisuiKeikakuItiran.DataSource = typeof(Suisitu.Entity.SaisuiKeikakuItiranEntity);
            // 
            // txtSaisuiDateTo
            // 
            this.txtSaisuiDateTo.Location = new System.Drawing.Point(260, 45);
            this.txtSaisuiDateTo.Name = "txtSaisuiDateTo";
            this.txtSaisuiDateTo.Size = new System.Drawing.Size(115, 31);
            this.txtSaisuiDateTo.TabIndex = 3;
            // 
            // txtSaisuiDateFrom
            // 
            this.txtSaisuiDateFrom.Location = new System.Drawing.Point(109, 45);
            this.txtSaisuiDateFrom.Name = "txtSaisuiDateFrom";
            this.txtSaisuiDateFrom.Size = new System.Drawing.Size(121, 31);
            this.txtSaisuiDateFrom.TabIndex = 2;
            // 
            // backColorChangeOnFocusProvider1
            // 
            this.backColorChangeOnFocusProvider1.Target = this;
            // 
            // SaisuiKaiV
            // 
            this.SaisuiKaiV.DataPropertyName = "SaisuiKaiV";
            this.SaisuiKaiV.HeaderText = "採水年月回";
            this.SaisuiKaiV.Name = "SaisuiKaiV";
            this.SaisuiKaiV.ReadOnly = true;
            this.SaisuiKaiV.Width = 200;
            // 
            // SaisuiDateV
            // 
            this.SaisuiDateV.DataPropertyName = "SaisuiDateV";
            this.SaisuiDateV.HeaderText = "採水年月日";
            this.SaisuiDateV.Name = "SaisuiDateV";
            this.SaisuiDateV.ReadOnly = true;
            this.SaisuiDateV.Width = 150;
            // 
            // KentaiSu
            // 
            this.KentaiSu.DataPropertyName = "KentaiSu";
            this.KentaiSu.HeaderText = "検体数";
            this.KentaiSu.Name = "KentaiSu";
            this.KentaiSu.ReadOnly = true;
            // 
            // SheetDateV
            // 
            this.SheetDateV.DataPropertyName = "SheetDateV";
            this.SheetDateV.HeaderText = "試験成績表作成日時";
            this.SheetDateV.Name = "SheetDateV";
            this.SheetDateV.ReadOnly = true;
            this.SheetDateV.Width = 352;
            // 
            // StatusKubunNameN
            // 
            this.StatusKubunNameN.DataPropertyName = "StatusKubunNameN";
            this.StatusKubunNameN.HeaderText = "状況";
            this.StatusKubunNameN.Name = "StatusKubunNameN";
            this.StatusKubunNameN.ReadOnly = true;
            this.StatusKubunNameN.Width = 124;
            // 
            // Nendo
            // 
            this.Nendo.DataPropertyName = "Nendo";
            this.Nendo.HeaderText = "Nendo";
            this.Nendo.Name = "Nendo";
            this.Nendo.ReadOnly = true;
            this.Nendo.Visible = false;
            // 
            // Status
            // 
            this.Status.DataPropertyName = "Status";
            this.Status.HeaderText = "Status";
            this.Status.Name = "Status";
            this.Status.ReadOnly = true;
            this.Status.Visible = false;
            // 
            // SaisuiKeikakuItiran
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.ClientSize = new System.Drawing.Size(1008, 730);
            this.Controls.Add(this.pnlSaisuiKeikakuItiran);
            this.Controls.Add(this.pnlSaisuiKeikaku);
            this.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "SaisuiKeikakuItiran";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "採水計画一覧";
            this.Load += new System.EventHandler(this.SaisuiKeikakuItiran_Load);
            this.pnlSaisuiKeikaku.ResumeLayout(false);
            this.pnlSaisuiKeikaku.PerformLayout();
            this.pnlSaisuiKeikakuItiran.ResumeLayout(false);
            this.pnlSaisuiKeikakuItiran.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSaisuiKeikakuItiran)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsSaisuiKeikakuItiran)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Component.BackColorChangeOnFocusProvider backColorChangeOnFocusProvider1;
        private System.Windows.Forms.Panel pnlSaisuiKeikaku;
        private System.Windows.Forms.Label lblSaisuiDate;
        private System.Windows.Forms.Label lblNendo;
        private System.Windows.Forms.ComboBox cboNendo;
        private Components.Controls.WarekiDate txtSaisuiDateTo;
        private System.Windows.Forms.Label lblWavyLine;
        private Components.Controls.WarekiDate txtSaisuiDateFrom;
        private System.Windows.Forms.Button btnEnd;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.Panel pnlSaisuiKeikakuItiran;
        private System.Windows.Forms.Label lblCountRecord;
        private System.Windows.Forms.Label lblCountNumber;
        private System.Windows.Forms.Button btnBottom;
        private System.Windows.Forms.Button btnTop;
        private System.Windows.Forms.Button btnStop;
        private System.Windows.Forms.Button btnSelect;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.DataGridView dgvSaisuiKeikakuItiran;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnCopy;
        private System.Windows.Forms.BindingSource bsSaisuiKeikakuItiran;
        private System.Windows.Forms.DataGridViewTextBoxColumn SaisuiKaiV;
        private System.Windows.Forms.DataGridViewTextBoxColumn SaisuiDateV;
        private System.Windows.Forms.DataGridViewTextBoxColumn KentaiSu;
        private System.Windows.Forms.DataGridViewTextBoxColumn SheetDateV;
        private System.Windows.Forms.DataGridViewTextBoxColumn StatusKubunNameN;
        private System.Windows.Forms.DataGridViewTextBoxColumn Nendo;
        private System.Windows.Forms.DataGridViewTextBoxColumn Status;
    }
}