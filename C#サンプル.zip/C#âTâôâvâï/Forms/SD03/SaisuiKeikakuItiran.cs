﻿using Suisitu.Common;
using Suisitu.Components.Common;
using Suisitu.Components.Controls;
using Suisitu.Dao;
using Suisitu.Entity;
using Suisitu.Enum;
using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Linq;

namespace Suisitu.Forms.SD03
{
    using CommonEvents = Suisitu.Common.Events;

    /// <summary>
    /// 採水計画一覧画面クラス
    /// </summary>
    public partial class SaisuiKeikakuItiran : Form
    {

        // 検索条件
        private SaisuiKeikakuItiranEntity key;

        #region コンストラクタ

        /// <summary>
        /// コンストラクタ
        /// </summary>
        public SaisuiKeikakuItiran()
        {
            InitializeComponent();

            this.txtSaisuiDateFrom.KeyPress += new KeyPressEventHandler(CommonEvents.txtHalfAll_KeyPress);
            this.txtSaisuiDateTo.KeyPress += new KeyPressEventHandler(CommonEvents.txtHalfAll_KeyPress);
        }

        #endregion

        #region イベント

        /// <summary>
        /// 画面が表示されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void SaisuiKeikakuItiran_Load(object sender, EventArgs e)
        {
            List<ValueComboItem> cboList = new List<ValueComboItem>();

            IEnumerable<dynamic> nendoList = KojoKihonDao.GetNendoList();
            foreach (var nendo in nendoList)
            {
                cboList.Add(new ValueComboItem(nendo.NENDO.ToString(), WarekiDateUtil.GetNendoText(Convert.ToInt32(nendo.NENDO))));
            }

            if (cboList.Count == 0)
                cboList.Add(new ValueComboItem("9999", "通年"));

            cboNendo.DataSource = cboList;
            cboNendo.DisplayMember = "Value";
            cboNendo.ValueMember = "Key";

        }

        /// <summary>
        /// 検索ボタンが選択されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnSearch_Click(object sender, EventArgs e)
        {
            key = new SaisuiKeikakuItiranEntity()
            {
                Nendo = int.Parse(cboNendo.SelectedValue.ToString()),
                SaisuiDateFrom = CommonUtils.FormatToDate(txtSaisuiDateFrom.Value),
                SaisuiDateTo = CommonUtils.FormatToDate(txtSaisuiDateTo.Value),
            };
            Search();

        }

        /// <summary>
        /// 終了ボタンが選択されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnEnd_Click(object sender, EventArgs e)
        {
            Close();
        }

        /// <summary>
        /// 先頭ボタンが選択されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnTop_Click(object sender, EventArgs e)
        {
            bsSaisuiKeikakuItiran.MoveFirst();
        }

        /// <summary>
        /// 最後ボタンが選択されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnBottom_Click(object sender, EventArgs e)
        {
            bsSaisuiKeikakuItiran.MoveLast();
        }

        /// <summary>
        /// 削除ボタンが選択されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (bsSaisuiKeikakuItiran.Current == null)
                return;

            DialogResult result = MessageBox.Show("選択している採水計画の全データを削除します。よろしいですか。", Text,
                MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button2);

            if (result == DialogResult.Yes)
            {
                SaisuiKeikakuItiranEntity entity = (SaisuiKeikakuItiranEntity)bsSaisuiKeikakuItiran.Current;

                // 年度、採水年月回をキーに採水計画表から該当データを削除する
                SaisuiKeikakuDao.Delete(entity.Nendo, entity.SaisuiKai);

            }

            Search();
        }

        /// <summary>
        /// 中止ボタンが選択されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnStop_Click(object sender, EventArgs e)
        {
            if (bsSaisuiKeikakuItiran.Current == null)
                return;

            DialogResult result = MessageBox.Show("選択している採水計画を中止します。よろしいですか。", Text,
                MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button2);

            if (result == DialogResult.Yes)
            {
                SaisuiKeikakuItiranEntity entity = (SaisuiKeikakuItiranEntity)bsSaisuiKeikakuItiran.Current;

                entity.Rev = entity.Rev + 1;
                entity.UpdDate = DateTime.Now.ToString();

                // 年度、採水年月回をキーに採水計画表から該当データのstatusを「9：中止」に更新する
                SaisuiKeikakuDao.Stop(entity);

            }

            Search();
        }

        /// <summary>
        /// 追加ボタンが選択されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnAdd_Click(object sender, EventArgs e)
        {
            InputSaisuiYMKaisu InputSaisuiYMKaisu = new InputSaisuiYMKaisu(EnumActionKbn.Add);
            InputSaisuiYMKaisu.ShowDialog();
        }

        /// <summary>
        /// 複写ボタンが選択されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnCopy_Click(object sender, EventArgs e)
        {
            SaisuiKeikakuItiranEntity entity = (SaisuiKeikakuItiranEntity)bsSaisuiKeikakuItiran.Current;
            // 水質届出管理画面を表示する
            using (var dialog = new InputSaisuiYMKaisu(EnumActionKbn.Copy, entity.SaisuiKai))
            {
                dialog.ShowDialog();
            }
        }

        /// <summary>
        /// 選択ボタンが選択されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnSelect_Click(object sender, EventArgs e)
        {
            SaisuiKeikakuItiranEntity entity = (SaisuiKeikakuItiranEntity)bsSaisuiKeikakuItiran.Current;
            SaisuiKeikaku SaisuiKeikaku = new SaisuiKeikaku(EnumActionKbn.Select, entity.SaisuiKai);
            SaisuiKeikaku.ShowDialog();
        }

        /// <summary>
        /// データグリッドビューのセルがダブルクリックされたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void dgvSaisuiKeikakuItiran_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (bsSaisuiKeikakuItiran.Current != null)
                ShowTodokedeKanri();
        }

        /// <summary>
        /// 年度コンボボックスの値が変更されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void cboNendo_SelectedIndexChanged(object sender, EventArgs e)
        {
            dgvSaisuiKeikakuItiran.Rows.Clear();
            lblCountRecord.Text = "0";
            // 画面ロックマトリックスを定義する
            SetLockMatrix();
        }

        /// <summary>
        /// 選択行が変更されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void dgvSaisuiKeikakuItiran_SelectionChanged(object sender, EventArgs e)
        {
            SetLockMatrix();
        }
        #endregion

        #region プライベートメソッド

        /// <summary>
        /// ロックマトリックス定義
        /// </summary>
        //private void SetLockMatrix(bool enabled)
        private void SetLockMatrix()
        {
            // 年度が「通年」かつ一覧の件数が1件以上存在し、ステータスが「0:計画」の場合
            if (cboNendo.SelectedValue.ToString() == "9999" && bsSaisuiKeikakuItiran.Count > 0 && dgvSaisuiKeikakuItiran.CurrentRow.Cells[6].Value.ToString() == "0")
            {
                btnDelete.Enabled = true;
                btnStop.Enabled = true;
                btnAdd.Enabled = true;
                btnCopy.Enabled = true;
                btnSelect.Enabled = true;
            }
            // 年度が「通年」かつ一覧の件数が1件以上存在し、ステータスが「0:計画」以外の場合
            else if(cboNendo.SelectedValue.ToString() == "9999" && bsSaisuiKeikakuItiran.Count > 0 && dgvSaisuiKeikakuItiran.CurrentRow.Cells[6].Value.ToString() != "0")
            {
                btnDelete.Enabled = false;
                btnStop.Enabled = false;
                btnAdd.Enabled = true;
                btnCopy.Enabled = true;
                btnSelect.Enabled = true;
            }
            // 年度が「通年」以外かつ一覧の件数が1件以上存在する場合
            else if (cboNendo.SelectedValue.ToString() != "9999" && bsSaisuiKeikakuItiran.Count > 0)
            {
                btnDelete.Enabled = false;
                btnStop.Enabled = false;
                btnAdd.Enabled = false;
                btnCopy.Enabled = false;
                btnSelect.Enabled = true;

            }
            // 年度が「通年」かつ一覧の件数が0件の場合
            else if (cboNendo.SelectedValue.ToString() == "9999" && bsSaisuiKeikakuItiran.Count == 0)
            {
                btnDelete.Enabled = false;
                btnStop.Enabled = false;
                btnAdd.Enabled = true;
                btnCopy.Enabled = false;
                btnSelect.Enabled = false;
            }
            // 年度が「通年」以外かつ一覧の件数が0件の場合
            else if (cboNendo.SelectedValue.ToString() != "9999" && bsSaisuiKeikakuItiran.Count == 0)
            {
                btnDelete.Enabled = false;
                btnStop.Enabled = false;
                btnAdd.Enabled = false;
                btnCopy.Enabled = false;
                btnSelect.Enabled = false;
            }
        }

        /// <summary>
        /// 採水計画情報画面を表示
        /// </summary>
        private void ShowTodokedeKanri()
        {
            SaisuiKeikakuItiranEntity entity = (SaisuiKeikakuItiranEntity)bsSaisuiKeikakuItiran.Current;
            // 水質届出管理画面を表示する
            using (var dialog = new SaisuiKeikaku(EnumActionKbn.Select, entity.SaisuiKai))
            {
                dialog.ShowDialog();
            }

            Search();
        }

        /// <summary>
        /// 検索処理。
        /// </summary>
        private void Search()
        {
            IEnumerable<SaisuiKeikakuItiranEntity> list = SaisuiKeikakuDao.SelectList(key);
            bsSaisuiKeikakuItiran.DataSource = list;
            lblCountRecord.Text = list.Count().ToString();

            var isExist = list.Count() > 0;

            if (!isExist)
                MessageUtils.NoFoundDataMessage(Text);

            // 画面ロックマトリックスを定義する
            SetLockMatrix();
        }

        #endregion
    }
}
