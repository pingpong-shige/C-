﻿namespace Suisitu.Forms.SD03
{
    partial class SelectHaisuikoNo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblJigyosyoNameN = new System.Windows.Forms.Label();
            this.lblHaisuikoNo = new System.Windows.Forms.Label();
            this.txtJigyosyoNameN = new System.Windows.Forms.TextBox();
            this.btnOK = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.backColorChangeOnFocusProvider1 = new Suisitu.Component.BackColorChangeOnFocusProvider();
            this.cboHaisuikoNo = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // lblJigyosyoNameN
            // 
            this.lblJigyosyoNameN.AutoSize = true;
            this.lblJigyosyoNameN.Location = new System.Drawing.Point(15, 15);
            this.lblJigyosyoNameN.Name = "lblJigyosyoNameN";
            this.lblJigyosyoNameN.Size = new System.Drawing.Size(122, 24);
            this.lblJigyosyoNameN.TabIndex = 0;
            this.lblJigyosyoNameN.Text = "工場事業場名称";
            // 
            // lblHaisuikoNo
            // 
            this.lblHaisuikoNo.AutoSize = true;
            this.lblHaisuikoNo.Location = new System.Drawing.Point(15, 48);
            this.lblHaisuikoNo.Name = "lblHaisuikoNo";
            this.lblHaisuikoNo.Size = new System.Drawing.Size(90, 24);
            this.lblHaisuikoNo.TabIndex = 0;
            this.lblHaisuikoNo.Text = "排水口番号";
            // 
            // txtJigyosyoNameN
            // 
            this.txtJigyosyoNameN.Location = new System.Drawing.Point(143, 12);
            this.txtJigyosyoNameN.Name = "txtJigyosyoNameN";
            this.txtJigyosyoNameN.Size = new System.Drawing.Size(200, 31);
            this.txtJigyosyoNameN.TabIndex = 1;
            // 
            // btnOK
            // 
            this.btnOK.Location = new System.Drawing.Point(137, 91);
            this.btnOK.Name = "btnOK";
            this.btnOK.Size = new System.Drawing.Size(100, 30);
            this.btnOK.TabIndex = 3;
            this.btnOK.Text = "OK";
            this.btnOK.UseVisualStyleBackColor = true;
            this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(243, 91);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(100, 30);
            this.btnCancel.TabIndex = 4;
            this.btnCancel.Text = "キャンセル";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // backColorChangeOnFocusProvider1
            // 
            this.backColorChangeOnFocusProvider1.Target = this;
            // 
            // cboHaisuikoNo
            // 
            this.cboHaisuikoNo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboHaisuikoNo.FormattingEnabled = true;
            this.cboHaisuikoNo.Location = new System.Drawing.Point(143, 45);
            this.cboHaisuikoNo.Name = "cboHaisuikoNo";
            this.cboHaisuikoNo.Size = new System.Drawing.Size(60, 32);
            this.cboHaisuikoNo.TabIndex = 2;
            // 
            // SelectHaisuikoNo
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.ClientSize = new System.Drawing.Size(358, 136);
            this.Controls.Add(this.cboHaisuikoNo);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnOK);
            this.Controls.Add(this.txtJigyosyoNameN);
            this.Controls.Add(this.lblHaisuikoNo);
            this.Controls.Add(this.lblJigyosyoNameN);
            this.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "SelectHaisuikoNo";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "排水口番号選択";
            this.Load += new System.EventHandler(this.SelectHaisuikoNo_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblJigyosyoNameN;
        private System.Windows.Forms.Label lblHaisuikoNo;
        private System.Windows.Forms.TextBox txtJigyosyoNameN;
        private System.Windows.Forms.Button btnOK;
        private System.Windows.Forms.Button btnCancel;
        private Component.BackColorChangeOnFocusProvider backColorChangeOnFocusProvider1;
        private System.Windows.Forms.ComboBox cboHaisuikoNo;
    }
}