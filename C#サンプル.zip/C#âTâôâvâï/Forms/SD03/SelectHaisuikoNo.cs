﻿using Suisitu.Common;
using Suisitu.Dao;
using Suisitu.Entity;
using Suisitu.Enum;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Suisitu.Forms.SD03
{
    using CommonEvents = Suisitu.Common.Events;

    /// <summary>
    /// 排水番号選択画面クラス
    /// </summary>
    public partial class SelectHaisuikoNo : Form
    {
        // 事業場検索キー
        private JigyojoItiranEntity selectJigyojo_;

        // 既存排水口番号
        private List<string> extHaisuikoNo_;
        
        // 選択排水口番号
        public string selectHaisuikoNo_ { get; set; }

        // OKボタンフラグ
        public bool okFlag_ { get; set; } = false;

        #region コンストラクタ

        /// <summary>
        /// コンストラクタ
        public SelectHaisuikoNo(JigyojoItiranEntity entity, List<string> haisuikoNo)
        {
            InitializeComponent();

            selectJigyojo_ = entity;

            extHaisuikoNo_ = haisuikoNo;
        }

        #endregion

        #region イベント

        /// <summary>
        /// 画面が表示されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void SelectHaisuikoNo_Load(object sender, EventArgs e)
        {
            // 排水口コンボボックス生成
            CreateCbo();
            // 工場事業上名称設定
            txtJigyosyoNameN.Text = selectJigyojo_.JigyosyoNameN;
            // 画面ロックマトリックスを定義する
            SetLockMatrix();
        }

        /// <summary>
        /// キャンセルボタンが押下されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnCancel_Click(object sender, EventArgs e)
        {
            Close();
        }

        /// <summary>
        /// OKボタンが押下されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnOK_Click(object sender, EventArgs e)
        {
            if (Validation())
            {
                selectHaisuikoNo_ = cboHaisuikoNo.Text;
                okFlag_ = true;
                Close();
            }
        }
        #endregion

        #region プライベートメソッド

        /// <summary>
        /// ロックマトリックス定義
        /// </summary>
        private void SetLockMatrix()
        {
            txtJigyosyoNameN.Enabled = false;
        }

        /// <summary>
        /// 排水口コンボボックスの作成
        /// </summary>
        /// <param name="enabled">使用可フラグ</param>
        private void CreateCbo()
        {
            IEnumerable<HaisuikoEntity> entity = HaisuikoDao.SelectList(selectJigyojo_.Nendo,selectJigyojo_.KanriNo);
            foreach(HaisuikoEntity e in entity)
            {
                cboHaisuikoNo.Items.Add(e.HaisuikoNo);
            }
        }

        /// <summary>
        /// 排水口番号バリデーション
        /// </summary>
        ///<returns>True:チェックOK / False:チェックNG</returns>
        private bool Validation()
        {
            // 必須チェック
            if (string.IsNullOrEmpty(cboHaisuikoNo.Text))
            {
                MessageUtils.NoInputDataMessage(CommonUtils.Trim(lblHaisuikoNo.Text) , Text);
                cboHaisuikoNo.Focus();
                return false;
            }

            // 既登録チェック
            if (extHaisuikoNo_.Contains(cboHaisuikoNo.Text))
            {
                MessageUtils.Duplication(CommonUtils.Trim(lblHaisuikoNo.Text), Text);
                cboHaisuikoNo.Focus();
                return false;
            }

            return true;
        }
        #endregion


    }

}
