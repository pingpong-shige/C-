﻿namespace Suisitu.Forms.SD90
{
    partial class Gentani
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnReturn = new System.Windows.Forms.Button();
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnSelect = new System.Windows.Forms.Button();
            this.dgvGentani = new System.Windows.Forms.DataGridView();
            this.bsGentani = new System.Windows.Forms.BindingSource(this.components);
            this.panel2 = new System.Windows.Forms.Panel();
            this.lblTpPpm = new System.Windows.Forms.Label();
            this.lblTnPpm = new System.Windows.Forms.Label();
            this.lblCodPpm = new System.Windows.Forms.Label();
            this.lblBodPpm = new System.Windows.Forms.Label();
            this.lblTp = new System.Windows.Forms.Label();
            this.lblTn = new System.Windows.Forms.Label();
            this.txtTp = new System.Windows.Forms.TextBox();
            this.txtTn = new System.Windows.Forms.TextBox();
            this.cboSangyoBunrui = new Suisitu.Components.Controls.ValueCombo();
            this.lblSangyoBunrui = new System.Windows.Forms.Label();
            this.chkDelete = new System.Windows.Forms.CheckBox();
            this.lblCod = new System.Windows.Forms.Label();
            this.lblBod = new System.Windows.Forms.Label();
            this.txtCod = new System.Windows.Forms.TextBox();
            this.txtBod = new System.Windows.Forms.TextBox();
            this.btnSetting = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.backColorChangeOnFocusProvider1 = new Suisitu.Component.BackColorChangeOnFocusProvider();
            this.sangyobcDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bodDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.codDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tnDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tpDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvGentani)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsGentani)).BeginInit();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.btnReturn);
            this.panel1.Controls.Add(this.btnAdd);
            this.panel1.Controls.Add(this.btnSelect);
            this.panel1.Controls.Add(this.dgvGentani);
            this.panel1.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel1.Location = new System.Drawing.Point(15, 15);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(706, 438);
            this.panel1.TabIndex = 0;
            // 
            // btnReturn
            // 
            this.btnReturn.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReturn.Location = new System.Drawing.Point(587, 394);
            this.btnReturn.Name = "btnReturn";
            this.btnReturn.Size = new System.Drawing.Size(100, 30);
            this.btnReturn.TabIndex = 3;
            this.btnReturn.Text = "戻る";
            this.btnReturn.UseVisualStyleBackColor = true;
            this.btnReturn.Click += new System.EventHandler(this.btnReturn_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdd.Location = new System.Drawing.Point(481, 394);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(100, 30);
            this.btnAdd.TabIndex = 2;
            this.btnAdd.Text = "追加";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // btnSelect
            // 
            this.btnSelect.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSelect.Location = new System.Drawing.Point(375, 394);
            this.btnSelect.Name = "btnSelect";
            this.btnSelect.Size = new System.Drawing.Size(100, 30);
            this.btnSelect.TabIndex = 1;
            this.btnSelect.Text = "選択";
            this.btnSelect.UseVisualStyleBackColor = true;
            this.btnSelect.Click += new System.EventHandler(this.btnSelect_Click);
            // 
            // dgvGentani
            // 
            this.dgvGentani.AllowUserToAddRows = false;
            this.dgvGentani.AllowUserToDeleteRows = false;
            this.dgvGentani.AllowUserToResizeColumns = false;
            this.dgvGentani.AllowUserToResizeRows = false;
            this.dgvGentani.AutoGenerateColumns = false;
            this.dgvGentani.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvGentani.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.sangyobcDataGridViewTextBoxColumn,
            this.bodDataGridViewTextBoxColumn,
            this.codDataGridViewTextBoxColumn,
            this.tnDataGridViewTextBoxColumn,
            this.tpDataGridViewTextBoxColumn});
            this.dgvGentani.DataSource = this.bsGentani;
            this.dgvGentani.Location = new System.Drawing.Point(15, 15);
            this.dgvGentani.MultiSelect = false;
            this.dgvGentani.Name = "dgvGentani";
            this.dgvGentani.ReadOnly = true;
            this.dgvGentani.RowHeadersVisible = false;
            this.dgvGentani.RowHeadersWidth = 40;
            this.dgvGentani.RowTemplate.DefaultCellStyle.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvGentani.RowTemplate.Height = 21;
            this.dgvGentani.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvGentani.Size = new System.Drawing.Size(671, 373);
            this.dgvGentani.TabIndex = 0;
            this.dgvGentani.CellMouseDoubleClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgvGentani_CellMouseDoubleClick);
            // 
            // bsGentani
            // 
            this.bsGentani.DataSource = typeof(Suisitu.Entity.GentaniEntity);
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.lblTpPpm);
            this.panel2.Controls.Add(this.lblTnPpm);
            this.panel2.Controls.Add(this.lblCodPpm);
            this.panel2.Controls.Add(this.lblBodPpm);
            this.panel2.Controls.Add(this.lblTp);
            this.panel2.Controls.Add(this.lblTn);
            this.panel2.Controls.Add(this.txtTp);
            this.panel2.Controls.Add(this.txtTn);
            this.panel2.Controls.Add(this.cboSangyoBunrui);
            this.panel2.Controls.Add(this.lblSangyoBunrui);
            this.panel2.Controls.Add(this.chkDelete);
            this.panel2.Controls.Add(this.lblCod);
            this.panel2.Controls.Add(this.lblBod);
            this.panel2.Controls.Add(this.txtCod);
            this.panel2.Controls.Add(this.txtBod);
            this.panel2.Controls.Add(this.btnSetting);
            this.panel2.Controls.Add(this.btnCancel);
            this.panel2.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.panel2.Location = new System.Drawing.Point(15, 459);
            this.panel2.Margin = new System.Windows.Forms.Padding(3, 5, 3, 3);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(706, 251);
            this.panel2.TabIndex = 1;
            // 
            // lblTpPpm
            // 
            this.lblTpPpm.AutoSize = true;
            this.lblTpPpm.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblTpPpm.Location = new System.Drawing.Point(293, 143);
            this.lblTpPpm.Name = "lblTpPpm";
            this.lblTpPpm.Size = new System.Drawing.Size(59, 24);
            this.lblTpPpm.TabIndex = 21;
            this.lblTpPpm.Text = "(ppm)";
            // 
            // lblTnPpm
            // 
            this.lblTnPpm.AutoSize = true;
            this.lblTnPpm.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblTnPpm.Location = new System.Drawing.Point(293, 111);
            this.lblTnPpm.Name = "lblTnPpm";
            this.lblTnPpm.Size = new System.Drawing.Size(59, 24);
            this.lblTnPpm.TabIndex = 20;
            this.lblTnPpm.Text = "(ppm)";
            // 
            // lblCodPpm
            // 
            this.lblCodPpm.AutoSize = true;
            this.lblCodPpm.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblCodPpm.Location = new System.Drawing.Point(293, 79);
            this.lblCodPpm.Name = "lblCodPpm";
            this.lblCodPpm.Size = new System.Drawing.Size(59, 24);
            this.lblCodPpm.TabIndex = 19;
            this.lblCodPpm.Text = "(ppm)";
            // 
            // lblBodPpm
            // 
            this.lblBodPpm.AutoSize = true;
            this.lblBodPpm.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblBodPpm.Location = new System.Drawing.Point(293, 47);
            this.lblBodPpm.Name = "lblBodPpm";
            this.lblBodPpm.Size = new System.Drawing.Size(59, 24);
            this.lblBodPpm.TabIndex = 18;
            this.lblBodPpm.Text = "(ppm)";
            // 
            // lblTp
            // 
            this.lblTp.AutoSize = true;
            this.lblTp.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblTp.Location = new System.Drawing.Point(15, 143);
            this.lblTp.Name = "lblTp";
            this.lblTp.Size = new System.Drawing.Size(58, 24);
            this.lblTp.TabIndex = 17;
            this.lblTp.Text = "Ｔ－Ｐ";
            // 
            // lblTn
            // 
            this.lblTn.AutoSize = true;
            this.lblTn.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblTn.Location = new System.Drawing.Point(15, 111);
            this.lblTn.Name = "lblTn";
            this.lblTn.Size = new System.Drawing.Size(58, 24);
            this.lblTn.TabIndex = 16;
            this.lblTn.Text = "Ｔ－Ｎ";
            // 
            // txtTp
            // 
            this.txtTp.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtTp.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.txtTp.Location = new System.Drawing.Point(172, 140);
            this.txtTp.MaxLength = 7;
            this.txtTp.Name = "txtTp";
            this.txtTp.Size = new System.Drawing.Size(118, 31);
            this.txtTp.TabIndex = 8;
            this.txtTp.Text = "0.00";
            this.txtTp.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtTp.Leave += new System.EventHandler(this.txtTp_Leave);
            // 
            // txtTn
            // 
            this.txtTn.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtTn.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.txtTn.Location = new System.Drawing.Point(172, 108);
            this.txtTn.MaxLength = 7;
            this.txtTn.Name = "txtTn";
            this.txtTn.Size = new System.Drawing.Size(118, 31);
            this.txtTn.TabIndex = 7;
            this.txtTn.Text = "0.00";
            this.txtTn.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtTn.Leave += new System.EventHandler(this.txtTn_Leave);
            // 
            // cboSangyoBunrui
            // 
            this.cboSangyoBunrui.Location = new System.Drawing.Point(172, 12);
            this.cboSangyoBunrui.Name = "cboSangyoBunrui";
            this.cboSangyoBunrui.Size = new System.Drawing.Size(515, 31);
            this.cboSangyoBunrui.TabIndex = 4;
            this.cboSangyoBunrui.Value = "-1";
            // 
            // lblSangyoBunrui
            // 
            this.lblSangyoBunrui.AutoSize = true;
            this.lblSangyoBunrui.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblSangyoBunrui.Location = new System.Drawing.Point(15, 15);
            this.lblSangyoBunrui.Name = "lblSangyoBunrui";
            this.lblSangyoBunrui.Size = new System.Drawing.Size(154, 24);
            this.lblSangyoBunrui.TabIndex = 12;
            this.lblSangyoBunrui.Text = "産業分類（中分類）";
            // 
            // chkDelete
            // 
            this.chkDelete.AutoSize = true;
            this.chkDelete.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.chkDelete.Location = new System.Drawing.Point(587, 172);
            this.chkDelete.Name = "chkDelete";
            this.chkDelete.Size = new System.Drawing.Size(61, 28);
            this.chkDelete.TabIndex = 9;
            this.chkDelete.Text = "削除";
            this.chkDelete.UseVisualStyleBackColor = true;
            // 
            // lblCod
            // 
            this.lblCod.AutoSize = true;
            this.lblCod.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblCod.Location = new System.Drawing.Point(15, 79);
            this.lblCod.Name = "lblCod";
            this.lblCod.Size = new System.Drawing.Size(58, 24);
            this.lblCod.TabIndex = 11;
            this.lblCod.Text = "ＣＯＤ";
            // 
            // lblBod
            // 
            this.lblBod.AutoSize = true;
            this.lblBod.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblBod.Location = new System.Drawing.Point(15, 47);
            this.lblBod.Name = "lblBod";
            this.lblBod.Size = new System.Drawing.Size(58, 24);
            this.lblBod.TabIndex = 10;
            this.lblBod.Text = "ＢＯＤ";
            // 
            // txtCod
            // 
            this.txtCod.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtCod.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.txtCod.Location = new System.Drawing.Point(172, 76);
            this.txtCod.MaxLength = 7;
            this.txtCod.Name = "txtCod";
            this.txtCod.Size = new System.Drawing.Size(118, 31);
            this.txtCod.TabIndex = 6;
            this.txtCod.Text = "0.00";
            this.txtCod.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtCod.Leave += new System.EventHandler(this.txtCod_Leave);
            // 
            // txtBod
            // 
            this.txtBod.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtBod.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.txtBod.Location = new System.Drawing.Point(172, 44);
            this.txtBod.MaxLength = 7;
            this.txtBod.Name = "txtBod";
            this.txtBod.Size = new System.Drawing.Size(118, 31);
            this.txtBod.TabIndex = 5;
            this.txtBod.Text = "0.00";
            this.txtBod.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtBod.Leave += new System.EventHandler(this.txtBod_Leave);
            // 
            // btnSetting
            // 
            this.btnSetting.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnSetting.Location = new System.Drawing.Point(480, 206);
            this.btnSetting.Name = "btnSetting";
            this.btnSetting.Size = new System.Drawing.Size(100, 30);
            this.btnSetting.TabIndex = 10;
            this.btnSetting.Text = "設定";
            this.btnSetting.UseVisualStyleBackColor = true;
            this.btnSetting.Click += new System.EventHandler(this.btnSetting_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnCancel.Location = new System.Drawing.Point(586, 206);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(100, 30);
            this.btnCancel.TabIndex = 11;
            this.btnCancel.Text = "キャンセル";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // backColorChangeOnFocusProvider1
            // 
            this.backColorChangeOnFocusProvider1.Target = this;
            // 
            // sangyobcDataGridViewTextBoxColumn
            // 
            this.sangyobcDataGridViewTextBoxColumn.DataPropertyName = "Sangyobc";
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.sangyobcDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle1;
            this.sangyobcDataGridViewTextBoxColumn.HeaderText = "産業分類";
            this.sangyobcDataGridViewTextBoxColumn.Name = "sangyobcDataGridViewTextBoxColumn";
            this.sangyobcDataGridViewTextBoxColumn.ReadOnly = true;
            this.sangyobcDataGridViewTextBoxColumn.Width = 130;
            // 
            // bodDataGridViewTextBoxColumn
            // 
            this.bodDataGridViewTextBoxColumn.DataPropertyName = "Bod";
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.bodDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle2;
            this.bodDataGridViewTextBoxColumn.HeaderText = "ＢＯＤ   （ppm）";
            this.bodDataGridViewTextBoxColumn.Name = "bodDataGridViewTextBoxColumn";
            this.bodDataGridViewTextBoxColumn.ReadOnly = true;
            this.bodDataGridViewTextBoxColumn.Width = 130;
            // 
            // codDataGridViewTextBoxColumn
            // 
            this.codDataGridViewTextBoxColumn.DataPropertyName = "Cod";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.codDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle3;
            this.codDataGridViewTextBoxColumn.HeaderText = "ＣＯＤ   （ppm）";
            this.codDataGridViewTextBoxColumn.Name = "codDataGridViewTextBoxColumn";
            this.codDataGridViewTextBoxColumn.ReadOnly = true;
            this.codDataGridViewTextBoxColumn.Width = 130;
            // 
            // tnDataGridViewTextBoxColumn
            // 
            this.tnDataGridViewTextBoxColumn.DataPropertyName = "Tn";
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.tnDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle4;
            this.tnDataGridViewTextBoxColumn.HeaderText = "Ｔ－Ｎ   （ppm）";
            this.tnDataGridViewTextBoxColumn.Name = "tnDataGridViewTextBoxColumn";
            this.tnDataGridViewTextBoxColumn.ReadOnly = true;
            this.tnDataGridViewTextBoxColumn.Width = 130;
            // 
            // tpDataGridViewTextBoxColumn
            // 
            this.tpDataGridViewTextBoxColumn.DataPropertyName = "Tp";
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.tpDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle5;
            this.tpDataGridViewTextBoxColumn.HeaderText = "Ｔ－Ｐ   （ppm）";
            this.tpDataGridViewTextBoxColumn.Name = "tpDataGridViewTextBoxColumn";
            this.tpDataGridViewTextBoxColumn.ReadOnly = true;
            this.tpDataGridViewTextBoxColumn.Width = 130;
            // 
            // Gentani
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.ClientSize = new System.Drawing.Size(733, 722);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "Gentani";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "原単位表　保守画面";
            this.Load += new System.EventHandler(this.SuisituGentani_Load);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvGentani)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsGentani)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DataGridView dgvGentani;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btnSelect;
        private System.Windows.Forms.Button btnReturn;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.TextBox txtCod;
        private System.Windows.Forms.TextBox txtBod;
        private System.Windows.Forms.Button btnSetting;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Label lblBod;
        private System.Windows.Forms.CheckBox chkDelete;
        private System.Windows.Forms.Label lblCod;
        private System.Windows.Forms.BindingSource bsGentani;
        private Component.BackColorChangeOnFocusProvider backColorChangeOnFocusProvider1;
        private Components.Controls.ValueCombo cboSangyoBunrui;
        private System.Windows.Forms.Label lblSangyoBunrui;
        private System.Windows.Forms.TextBox txtTn;
        private System.Windows.Forms.Label lblTp;
        private System.Windows.Forms.Label lblTn;
        private System.Windows.Forms.TextBox txtTp;
        private System.Windows.Forms.Label lblTpPpm;
        private System.Windows.Forms.Label lblTnPpm;
        private System.Windows.Forms.Label lblCodPpm;
        private System.Windows.Forms.Label lblBodPpm;
        private System.Windows.Forms.DataGridViewTextBoxColumn sangyobcDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn bodDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn codDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn tnDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn tpDataGridViewTextBoxColumn;
    }
}