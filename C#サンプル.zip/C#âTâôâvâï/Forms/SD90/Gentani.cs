﻿using Suisitu.Common;
using Suisitu.Dao;
using Suisitu.Entity;
using System;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using System.Collections.Generic;

namespace Suisitu.Forms.SD90
{
    using CommonEvents = Suisitu.Common.Events;

    /// <summary>
    /// 原単位保守画面クラス
    /// </summary>
    public partial class Gentani : Form
    {
        private bool isInsert_ = false;
        private IEnumerable<MasterEntity> sangyoBcMasterData_;

        #region コンストラクタ

        /// <summary>
        /// コンストラクタ
        /// </summary>
        public Gentani()
        {
            InitializeComponent();

            this.cboSangyoBunrui.KeyPress += new KeyPressEventHandler(CommonEvents.txtHalfNumber_KeyPress);
            this.txtBod.KeyPress += new KeyPressEventHandler(CommonEvents.txtHalfDecimal_KeyPress);
            this.txtCod.KeyPress += new KeyPressEventHandler(CommonEvents.txtHalfDecimal_KeyPress);
            this.txtTn.KeyPress += new KeyPressEventHandler(CommonEvents.txtHalfDecimal_KeyPress);
            this.txtTp.KeyPress += new KeyPressEventHandler(CommonEvents.txtHalfDecimal_KeyPress);
        }

        #endregion

        #region イベント

        /// <summary>
        /// 画面が表示されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void SuisituGentani_Load(object sender, EventArgs e)
        {
            bsGentani.DataSource = GentaniDao.SelectAll();
            sangyoBcMasterData_ = GentaniDao.GetMasterData();
            cboSangyoBunrui.InitCombo(sangyoBcMasterData_);

            Clear();
        }

        /// <summary>
        /// 選択ボタンが押下されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnSelect_Click(object sender, EventArgs e)
        {
            SelectedItem();
        }

        /// <summary>
        /// データグリッドビューのセルがダブルクリックされたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void dgvGentani_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (bsGentani.Current != null)
                SelectedItem();
        }

        /// <summary>
        /// 設定ボタンが押下されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnSetting_Click(object sender, EventArgs e)
        {
            GentaniEntity entity = null;

            if (chkDelete.Checked)
            {
                GentaniDao.Delete((GentaniEntity)bsGentani.Current);
            }
            else
            {
                entity = new GentaniEntity
                {
                    Sangyobc = cboSangyoBunrui.Value,
                    Bod = txtBod.Text,
                    Cod = txtCod.Text,
                    Tn = txtTn.Text,
                    Tp = txtTp.Text,
                    UpdDate = DateTime.Now.ToString(),
                    Rev = 1,
                };

                if (!Validation(entity))
                    return;

                // 追加モードの場合はInsert、それ以外はUpdateする
                if (this.isInsert_)
                {
                    GentaniDao.Insert(entity);
                }
                else
                {
                    GentaniDao.Update(entity);
                }
            }

            // 一覧をリフレッシュする
            bsGentani.DataSource = GentaniDao.SelectAll();

            // 追加モードの場合は、追加行を選択行に設定する
            if (this.isInsert_)
            {
                int rowIndex = 0;

                foreach (DataGridViewRow row in dgvGentani.Rows)
                {
                    if (row.Cells[0].Value.ToString().Trim() == entity.Sangyobc)
                    {
                        break;
                    }
                    rowIndex++;
                }
                dgvGentani.CurrentCell = dgvGentani[0, rowIndex];
            }

            // コントロールを初期化する
            Clear();
        }

        /// <summary>
        /// 追加ボタンが押下されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnAdd_Click(object sender, EventArgs e)
        {
            // 追加モードに設定する
            this.isInsert_ = true;

            panel1.Enabled = false;
            panel2.Enabled = true;
            cboSangyoBunrui.Enabled = true;
            chkDelete.Enabled = false;

            // 産業分類（中分類）にフォーカスをセット
            cboSangyoBunrui.Focus();
        }

        /// <summary>
        /// キャンセルボタンが押下されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnCancel_Click(object sender, EventArgs e)
        {
            Clear();
        }

        /// <summary>
        /// 戻るボタンが押下されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnReturn_Click(object sender, EventArgs e)
        {
            Close();
        }

        /// <summary>
        /// BODロストフォーカス時のイベント
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void txtBod_Leave(object sender, EventArgs e)
        {
            txtBod.Text = GetDecimalFormatValue(txtBod.Text);
        }

        /// <summary>
        /// CODロストフォーカス時のイベント
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void txtCod_Leave(object sender, EventArgs e)
        {
            txtCod.Text = GetDecimalFormatValue(txtCod.Text);
        }

        /// <summary>
        /// T-Nロストフォーカス時のイベント
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void txtTn_Leave(object sender, EventArgs e)
        {
            txtTn.Text = GetDecimalFormatValue(txtTn.Text);
        }

        /// <summary>
        /// T-Pロストフォーカス時のイベント
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void txtTp_Leave(object sender, EventArgs e)
        {
            txtTp.Text = GetDecimalFormatValue(txtTp.Text);
        }

        #endregion

        #region プライベートメソッド

        /// <summary>
        /// バリデーションをチェックします。
        /// </summary>
        /// <returns>True:チェックOK / False:チェックNG</returns>
        private bool Validation(GentaniEntity entity)
        {
            bool sangyobcExists = false;
            string minValue = "0.00";
            string maxValue = "9999.99";

            // 必須入力チェック
            // この部分が半角数字チェックも兼ねています。
            // コピペで張り付けられた場合、cboSangyoBunrui.Text = Nullとなるので弾かれます。
            if (string.IsNullOrEmpty(cboSangyoBunrui.Text))
            {
                MessageUtils.NoInputDataMessage(CommonUtils.Trim(lblSangyoBunrui.Text), Text);
                cboSangyoBunrui.Focus();
                return false;
            }

            // コードチェック
            // 入力した産業分類（中分類）が産業分類（中分類）表に存在するかどうかチェック
            foreach (MasterEntity data in sangyoBcMasterData_)
            {
                if (entity.Sangyobc.Trim().Equals(data.Value)) {
                    sangyobcExists = true;
                    break;
                } 
            }
            if (!sangyobcExists)
            {
                MessageUtils.IncorrectInputComboBoxMessage(CommonUtils.Trim(lblSangyoBunrui.Text), Text);
                cboSangyoBunrui.Focus();
                return false;
            }

            // 書式チェック
            string regExp = @"^[0-9]{1,4}(\.[0-9]{1,2})?$";
            if (!Regex.IsMatch(txtBod.Text, regExp))
            {
                MessageUtils.TypeAndRangeErrorMessage(CommonUtils.Trim(lblBod.Text), minValue, maxValue, Text);
                txtBod.Focus();
                return false;
            }
            if (!Regex.IsMatch(txtCod.Text, regExp))
            {
                MessageUtils.TypeAndRangeErrorMessage(CommonUtils.Trim(lblCod.Text), minValue, maxValue, Text);
                txtCod.Focus();
                return false;
            }
            if (!Regex.IsMatch(txtTn.Text, regExp))
            {
                MessageUtils.TypeAndRangeErrorMessage(CommonUtils.Trim(lblTn.Text), minValue, maxValue, Text);
                txtTn.Focus();
                return false;
            }
            if (!Regex.IsMatch(txtTp.Text, regExp))
            {
                MessageUtils.TypeAndRangeErrorMessage(CommonUtils.Trim(lblTp.Text), minValue, maxValue, Text);
                txtTp.Focus();
                return false;
            }

            // 存在チェック
            if (this.isInsert_)
            {
                if (GentaniDao.Select(entity) != null)
                {
                    MessageUtils.Duplication(CommonUtils.Trim(lblSangyoBunrui.Text), Text);
                    cboSangyoBunrui.Focus();
                    return false;
                }
            }

            return true;
        }

        /// <summary>
        /// 画面のクリア処理
        /// </summary>
        private void Clear()
        {
            // コントロールを初期値に戻す
            cboSangyoBunrui.Value = "";
            txtBod.Text = "";
            txtCod.Text = "";
            txtTn.Text = "";
            txtTp.Text = "";
            chkDelete.Checked = false;

            // 選択ボタンの使用可/不可を設定する
            if (dgvGentani.Rows.Count == 0)
            {
                btnSelect.Enabled = false;
            }
            else
            {
                btnSelect.Enabled = true;
            }

            // 一覧部分を操作可、編集部分を操作不可に設定する
            panel1.Enabled = true;
            panel2.Enabled = false;
            
            this.isInsert_ = false;
        }

        /// <summary>
        /// 一覧からアイテムが選択されたときの処理
        /// </summary>
        private void SelectedItem()
        {
            panel1.Enabled = false;
            panel2.Enabled = true;
            chkDelete.Enabled = true;
            cboSangyoBunrui.Enabled = false;

            //選択行を取得する
            GentaniEntity currentEntity = (GentaniEntity)bsGentani.Current;

            // 産業分類（中分類）
            cboSangyoBunrui.Value = currentEntity.Sangyobc;
            // BOD
            txtBod.Text = currentEntity.Bod;
            // COD
            txtCod.Text = currentEntity.Cod;
            // T-N
            txtTn.Text = currentEntity.Tn;
            // T-P
            txtTp.Text = currentEntity.Tp;

            // BODにフォーカスをセット
            txtBod.Focus();
        }

        /// <summary>
        /// 入力値に小数点以下2桁まで付与した値を返す
        /// </summary>
        /// <param name="value">入力値</param>
        /// <returns>入力値に小数点以下2桁まで付与した値（小数に変換できない場合は元の値）</returns>
        private string GetDecimalFormatValue(string value)
        {
            double result;
            if (Double.TryParse(value, out result))
            {
                value = string.Format("{0:0.00}", Double.Parse(value));
            }

            return value;
        }

        #endregion
    }
}
