﻿namespace Suisitu.Forms.SD90
{
    partial class GyosyuKbn
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel1 = new System.Windows.Forms.Panel();
            this.dgvGyosyuKbn = new System.Windows.Forms.DataGridView();
            this.btnReturn = new System.Windows.Forms.Button();
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnSelect = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.chkDelete = new System.Windows.Forms.CheckBox();
            this.lblGyosyuName = new System.Windows.Forms.Label();
            this.lblGyosyuKbn = new System.Windows.Forms.Label();
            this.txtGyosyuName = new System.Windows.Forms.TextBox();
            this.txtGyosyuKbn = new System.Windows.Forms.TextBox();
            this.btnSetting = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.backColorChangeOnFocusProvider1 = new Suisitu.Component.BackColorChangeOnFocusProvider();
            this.gyosyuKbnDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gyosyuKbnNameNDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bsGyosyuKbn = new System.Windows.Forms.BindingSource(this.components);
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvGyosyuKbn)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bsGyosyuKbn)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.dgvGyosyuKbn);
            this.panel1.Controls.Add(this.btnReturn);
            this.panel1.Controls.Add(this.btnAdd);
            this.panel1.Controls.Add(this.btnSelect);
            this.panel1.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel1.Location = new System.Drawing.Point(15, 15);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(576, 435);
            this.panel1.TabIndex = 1;
            // 
            // dgvGyosyuKbn
            // 
            this.dgvGyosyuKbn.AllowUserToAddRows = false;
            this.dgvGyosyuKbn.AllowUserToResizeColumns = false;
            this.dgvGyosyuKbn.AllowUserToResizeRows = false;
            this.dgvGyosyuKbn.AutoGenerateColumns = false;
            this.dgvGyosyuKbn.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvGyosyuKbn.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.gyosyuKbnDataGridViewTextBoxColumn,
            this.gyosyuKbnNameNDataGridViewTextBoxColumn});
            this.dgvGyosyuKbn.DataSource = this.bsGyosyuKbn;
            this.dgvGyosyuKbn.Location = new System.Drawing.Point(15, 15);
            this.dgvGyosyuKbn.Name = "dgvGyosyuKbn";
            this.dgvGyosyuKbn.ReadOnly = true;
            this.dgvGyosyuKbn.RowHeadersVisible = false;
            this.dgvGyosyuKbn.RowHeadersWidth = 40;
            this.dgvGyosyuKbn.RowTemplate.Height = 21;
            this.dgvGyosyuKbn.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvGyosyuKbn.Size = new System.Drawing.Size(546, 370);
            this.dgvGyosyuKbn.TabIndex = 0;
            this.dgvGyosyuKbn.CellMouseDoubleClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgvGyosyuKbn_CellMouseDoubleClick);
            // 
            // btnReturn
            // 
            this.btnReturn.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReturn.Location = new System.Drawing.Point(461, 391);
            this.btnReturn.Name = "btnReturn";
            this.btnReturn.Size = new System.Drawing.Size(100, 30);
            this.btnReturn.TabIndex = 3;
            this.btnReturn.Text = "戻る";
            this.btnReturn.UseVisualStyleBackColor = true;
            this.btnReturn.Click += new System.EventHandler(this.btnReturn_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdd.Location = new System.Drawing.Point(355, 391);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(100, 30);
            this.btnAdd.TabIndex = 2;
            this.btnAdd.Text = "追加";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // btnSelect
            // 
            this.btnSelect.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSelect.Location = new System.Drawing.Point(249, 391);
            this.btnSelect.Name = "btnSelect";
            this.btnSelect.Size = new System.Drawing.Size(100, 30);
            this.btnSelect.TabIndex = 1;
            this.btnSelect.Text = "選択";
            this.btnSelect.UseVisualStyleBackColor = true;
            this.btnSelect.Click += new System.EventHandler(this.btnSelect_Click);
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.chkDelete);
            this.panel2.Controls.Add(this.lblGyosyuName);
            this.panel2.Controls.Add(this.lblGyosyuKbn);
            this.panel2.Controls.Add(this.txtGyosyuName);
            this.panel2.Controls.Add(this.txtGyosyuKbn);
            this.panel2.Controls.Add(this.btnSetting);
            this.panel2.Controls.Add(this.btnCancel);
            this.panel2.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.panel2.Location = new System.Drawing.Point(15, 456);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(576, 172);
            this.panel2.TabIndex = 2;
            // 
            // chkDelete
            // 
            this.chkDelete.AutoSize = true;
            this.chkDelete.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.chkDelete.Location = new System.Drawing.Point(461, 90);
            this.chkDelete.Name = "chkDelete";
            this.chkDelete.Size = new System.Drawing.Size(61, 28);
            this.chkDelete.TabIndex = 6;
            this.chkDelete.Text = "削除";
            this.chkDelete.UseVisualStyleBackColor = true;
            // 
            // lblGyosyuName
            // 
            this.lblGyosyuName.AutoSize = true;
            this.lblGyosyuName.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblGyosyuName.Location = new System.Drawing.Point(15, 47);
            this.lblGyosyuName.Name = "lblGyosyuName";
            this.lblGyosyuName.Size = new System.Drawing.Size(106, 24);
            this.lblGyosyuName.TabIndex = 11;
            this.lblGyosyuName.Text = "業種区分名称";
            // 
            // lblGyosyuKbn
            // 
            this.lblGyosyuKbn.AutoSize = true;
            this.lblGyosyuKbn.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblGyosyuKbn.Location = new System.Drawing.Point(15, 15);
            this.lblGyosyuKbn.Name = "lblGyosyuKbn";
            this.lblGyosyuKbn.Size = new System.Drawing.Size(74, 24);
            this.lblGyosyuKbn.TabIndex = 10;
            this.lblGyosyuKbn.Text = "業種区分";
            // 
            // txtGyosyuName
            // 
            this.txtGyosyuName.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtGyosyuName.ImeMode = System.Windows.Forms.ImeMode.Hiragana;
            this.txtGyosyuName.Location = new System.Drawing.Point(143, 44);
            this.txtGyosyuName.MaxLength = 50;
            this.txtGyosyuName.Name = "txtGyosyuName";
            this.txtGyosyuName.Size = new System.Drawing.Size(418, 31);
            this.txtGyosyuName.TabIndex = 5;
            // 
            // txtGyosyuKbn
            // 
            this.txtGyosyuKbn.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtGyosyuKbn.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.txtGyosyuKbn.Location = new System.Drawing.Point(143, 12);
            this.txtGyosyuKbn.MaxLength = 6;
            this.txtGyosyuKbn.Name = "txtGyosyuKbn";
            this.txtGyosyuKbn.Size = new System.Drawing.Size(73, 31);
            this.txtGyosyuKbn.TabIndex = 4;
            // 
            // btnSetting
            // 
            this.btnSetting.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnSetting.Location = new System.Drawing.Point(355, 124);
            this.btnSetting.Name = "btnSetting";
            this.btnSetting.Size = new System.Drawing.Size(100, 30);
            this.btnSetting.TabIndex = 7;
            this.btnSetting.Text = "設定";
            this.btnSetting.UseVisualStyleBackColor = true;
            this.btnSetting.Click += new System.EventHandler(this.btnSetting_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnCancel.Location = new System.Drawing.Point(461, 124);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(100, 30);
            this.btnCancel.TabIndex = 8;
            this.btnCancel.Text = "キャンセル";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // backColorChangeOnFocusProvider1
            // 
            this.backColorChangeOnFocusProvider1.Target = this;
            // 
            // gyosyuKbnDataGridViewTextBoxColumn
            // 
            this.gyosyuKbnDataGridViewTextBoxColumn.DataPropertyName = "GyosyuKbn";
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.gyosyuKbnDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle1;
            this.gyosyuKbnDataGridViewTextBoxColumn.HeaderText = "業種区分";
            this.gyosyuKbnDataGridViewTextBoxColumn.Name = "gyosyuKbnDataGridViewTextBoxColumn";
            this.gyosyuKbnDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // gyosyuKbnNameNDataGridViewTextBoxColumn
            // 
            this.gyosyuKbnNameNDataGridViewTextBoxColumn.DataPropertyName = "GyosyuKbnNameN";
            this.gyosyuKbnNameNDataGridViewTextBoxColumn.HeaderText = "業種区分名称";
            this.gyosyuKbnNameNDataGridViewTextBoxColumn.Name = "gyosyuKbnNameNDataGridViewTextBoxColumn";
            this.gyosyuKbnNameNDataGridViewTextBoxColumn.ReadOnly = true;
            this.gyosyuKbnNameNDataGridViewTextBoxColumn.Width = 425;
            // 
            // bsGyosyuKbn
            // 
            this.bsGyosyuKbn.DataSource = typeof(Suisitu.Entity.GyosyuKbnEntity);
            // 
            // GyosyuKbn
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.ClientSize = new System.Drawing.Size(605, 641);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "GyosyuKbn";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "業種区分　保守画面";
            this.Load += new System.EventHandler(this.GyosyuKbn_Load);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvGyosyuKbn)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bsGyosyuKbn)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnReturn;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnSelect;
        private System.Windows.Forms.BindingSource bsGyosyuKbn;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.CheckBox chkDelete;
        private System.Windows.Forms.Label lblGyosyuName;
        private System.Windows.Forms.Label lblGyosyuKbn;
        private System.Windows.Forms.TextBox txtGyosyuName;
        private System.Windows.Forms.TextBox txtGyosyuKbn;
        private System.Windows.Forms.Button btnSetting;
        private System.Windows.Forms.Button btnCancel;
        private Component.BackColorChangeOnFocusProvider backColorChangeOnFocusProvider1;
        private System.Windows.Forms.DataGridView dgvGyosyuKbn;
        private System.Windows.Forms.DataGridViewTextBoxColumn gyosyuKbnDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn gyosyuKbnNameNDataGridViewTextBoxColumn;
    }
}