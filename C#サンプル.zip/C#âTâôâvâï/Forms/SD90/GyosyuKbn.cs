﻿using Suisitu.Common;
using Suisitu.Dao;
using Suisitu.Entity;
using System;
using System.Windows.Forms;

namespace Suisitu.Forms.SD90
{
    using CommonEvents = Suisitu.Common.Events;

    /// <summary>
    /// 業種区分保守画面クラス
    /// </summary>
    public partial class GyosyuKbn : Form
    {
        private bool isInsert_ = false;

        #region コンストラクタ

        /// <summary>
        /// コンストラクタ
        /// </summary>
        public GyosyuKbn()
        {
            InitializeComponent();

            this.txtGyosyuKbn.KeyPress += new KeyPressEventHandler(CommonEvents.txtHalfNumber_KeyPress);
            this.txtGyosyuName.KeyPress += new KeyPressEventHandler(CommonEvents.txtFullAll_KeyPress);
        }

        #endregion

        #region イベント

        /// <summary>
        /// 画面が表示されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void GyosyuKbn_Load(object sender, EventArgs e)
        {
            bsGyosyuKbn.DataSource = GyosyuKbnDao.SelectAll();

            Clear();
        }

        /// <summary>
        /// 選択ボタンが押下されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnSelect_Click(object sender, EventArgs e)
        {
            SelectedItem();
        }

        /// <summary>
        /// データグリッドビューのセルがダブルクリックされたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void dgvGyosyuKbn_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (bsGyosyuKbn.Current != null)
                SelectedItem();
        }

        /// <summary>
        /// 設定ボタンが押下されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnSetting_Click(object sender, EventArgs e)
        {
            GyosyuKbnEntity entity = null;

            if (chkDelete.Checked)
            {
                GyosyuKbnDao.Delete((GyosyuKbnEntity)bsGyosyuKbn.Current);
            }
            else
            {
                entity = new GyosyuKbnEntity
                {
                    GyosyuKbn = txtGyosyuKbn.Text,
                    GyosyuKbnNameN = txtGyosyuName.Text,
                    UpdDate = DateTime.Now.ToString(),
                    Rev = 1,
                };

                if (!Validation(entity))
                    return;

                // 追加モードの場合はInsert、それ以外はUpdateする
                if (this.isInsert_)
                {
                    GyosyuKbnDao.Insert(entity);
                }
                else
                {
                    GyosyuKbnDao.Update(entity);
                }
            }

            // 一覧をリフレッシュする
            bsGyosyuKbn.DataSource = GyosyuKbnDao.SelectAll();

            // 追加モードの場合は、追加行を選択行に設定する
            if (this.isInsert_)
            {
                int rowIndex = 0;

                foreach (DataGridViewRow row in dgvGyosyuKbn.Rows)
                {
                    if (row.Cells[0].Value.ToString() == entity.GyosyuKbn)
                    {
                        break;
                    }
                    rowIndex++;
                }
                dgvGyosyuKbn.CurrentCell = dgvGyosyuKbn[0, rowIndex];
            }

            // コントロールを初期化する
            Clear();
        }

        /// <summary>
        /// 追加ボタンが押下されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnAdd_Click(object sender, EventArgs e)
        {
            // 追加モードに設定する
            this.isInsert_ = true;

            panel1.Enabled = false;
            panel2.Enabled = true;
            chkDelete.Enabled = false;
            txtGyosyuKbn.Enabled = true;

            // 業種区分にフォーカスをセット
            txtGyosyuKbn.Focus();
        }

        /// <summary>
        /// キャンセルボタンが押下されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnCancel_Click(object sender, EventArgs e)
        {
            Clear();
        }

        /// <summary>
        /// 戻るボタンが押下されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnReturn_Click(object sender, EventArgs e)
        {
            Close();
        }

        #endregion

        #region プライベートメソッド

        /// <summary>
        /// バリデーションをチェックします。
        /// </summary>
        /// <returns>True:チェックOK / False:チェックNG</returns>
        private bool Validation(GyosyuKbnEntity entity)
        {
            // 業種区分必須入力チェック
            if (string.IsNullOrEmpty(entity.GyosyuKbn))
            {
                MessageUtils.NoInputDataMessage(CommonUtils.Trim(lblGyosyuKbn.Text), Text);
                txtGyosyuKbn.Focus();
                return false;
            }

            // 半角数字チェック行う
            if (!ValidationUtils.ValidateTypeNumeric(txtGyosyuKbn.Text))
            {
                MessageUtils.ZenkakuHankakuMessage(CommonUtils.Trim(lblGyosyuKbn.Text), 0, Text);
                txtGyosyuKbn.Focus();
                return false;
            }
           
            // 業種区分桁数チェック
            if (entity.GyosyuKbn.Length < txtGyosyuKbn.MaxLength)
            {
                MessageUtils.MismatchInputDigitsMessage(CommonUtils.Trim(lblGyosyuKbn.Text), txtGyosyuKbn.MaxLength, Text);
                txtGyosyuKbn.Focus();
                return false;
            }

            // 全角文字チェック
            if (!ValidationUtils.ValidateZenkaku(txtGyosyuName.Text) & !string.IsNullOrEmpty(txtGyosyuName.Text))
            {
                MessageUtils.ZenkakuHankakuMessage(CommonUtils.Trim(lblGyosyuName.Text), 1, Text);
                txtGyosyuName.Focus();
                return false;
            }

            // 存在チェック
            if (this.isInsert_)
            {
                if (GyosyuKbnDao.Select(entity) != null)
                {
                    MessageUtils.Duplication(CommonUtils.Trim(lblGyosyuKbn.Text), Text);
                    txtGyosyuKbn.Focus();
                    return false;
                }
            }

            return true;
        }

        /// <summary>
        /// 画面のクリア処理
        /// </summary>
        private void Clear()
        {
            // コントロールを初期値に戻す
            txtGyosyuKbn.Text = "";
            txtGyosyuName.Text = "";
            chkDelete.Checked = false;
            
            // 選択ボタンの使用可/不可を設定する
            if (dgvGyosyuKbn.Rows.Count == 0)
            {
                btnSelect.Enabled = false;
            }
            else
            {
                btnSelect.Enabled = true;
            }

            // 一覧部分を操作可、編集部分を操作不可に設定する
            panel1.Enabled = true;
            panel2.Enabled = false;
            
            this.isInsert_ = false;
        }

        /// <summary>
        /// 一覧からアイテムが選択されたときの処理
        /// </summary>
        private void SelectedItem()
        {
            panel1.Enabled = false;
            panel2.Enabled = true;
            chkDelete.Enabled = true;
            txtGyosyuKbn.Enabled = false;

            // 選択行を取得する
            GyosyuKbnEntity currentEntity = (GyosyuKbnEntity)bsGyosyuKbn.Current;

            // 業種区分
            txtGyosyuKbn.Text = currentEntity.GyosyuKbn;
            // 業種区分名称
            txtGyosyuName.Text = currentEntity.GyosyuKbnNameN;

            // 業種区分名称にフォーカスをセット
            txtGyosyuName.Focus();
        }

        #endregion
    }
}
