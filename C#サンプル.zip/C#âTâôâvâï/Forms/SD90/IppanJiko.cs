﻿using Suisitu.Common;
using Suisitu.Dao;
using Suisitu.Entity;
using System;
using System.Windows.Forms;

namespace Suisitu.Forms.SD90
{
#pragma warning disable 168

    using CommonEvents = Suisitu.Common.Events;

    /// <summary>
    /// 一般事項マスタ保守
    /// </summary>
    public partial class IppanJiko : Form
    {
        // 一般事項(画面起動時)
        private IppanJikoEntity currentEntity_;

        #region コンストラクタ

        /// <summary>
        /// コンストラクタ
        /// </summary>
        public IppanJiko()
        {
            InitializeComponent();
            
            // 自治体コード 半角数字のみ入力可
            this.txtJititaiCode.KeyPress += new KeyPressEventHandler(CommonEvents.txtHalfNumber_KeyPress);
            // 担当課名 全角のみ入力可
            this.txtTantoKaNameN.KeyPress += new KeyPressEventHandler(CommonEvents.txtFullAll_KeyPress);
            // 電話番号 半角英数字のみ入力可
            this.txtTelNo.KeyPress += new KeyPressEventHandler(CommonEvents.txtHalfAll_KeyPress);
            // FAX番号 半角英数字のみ入力可
            this.txtFaxNo.KeyPress += new KeyPressEventHandler(CommonEvents.txtHalfAll_KeyPress);
            // メールアドレス 半角英数字のみ入力可
            this.txtEMail.KeyPress += new KeyPressEventHandler(CommonEvents.txtHalfAll_KeyPress);
        }
        #endregion

        #region イベント

        /// <summary>
        /// 画面が表示されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void IppanJiko_Load(object sender, EventArgs e)
        {
            // 一般事項を取得する
            bsIppanJiko.DataSource = IppanJikoDao.SelectAll();

            // 編集前の一般事項を保持する
            currentEntity_ = (IppanJikoEntity)bsIppanJiko.Current;

            // 一般事項マスタが0件の場合、空文字を設定
            if (currentEntity_ == null)
            {
                currentEntity_ = new IppanJikoEntity();
                currentEntity_.JititaiCode = "";
                currentEntity_.TantoKaNameN = "";
                currentEntity_.TelNo = "";
                currentEntity_.FaxNo = "";
                currentEntity_.EMail = "";
            }
        }

        /// <summary>
        /// 戻るボタンが選択されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnReturn_Click(object sender, EventArgs e)
        {
            Return();
        }

        /// <summary>
        /// 設定ボタンが選択されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnSetting_Click(object sender, EventArgs e)
        {
            // 登録データを作成する
            IppanJikoEntity entity = CreateRegisterData();

            // バリデーションチェックする
            if (!Validation(entity))
                return;

            // 一般事項を登録する
            Register(entity);

            MessageBox.Show("更新が完了しました。", Text);
        }


        private void IppanJiko_FormClosing(object sender, FormClosingEventArgs e)
        {
            // 各種ボタンイベントから画面を閉じる場合
            if (this.Tag == null)
                Return();
        }

        #endregion

        #region プライベートメソッド

        /// <summary>
        /// 編集前と編集後を比較します。
        /// </summary>
        /// <returns>True:差異なし / False:差異あり</returns>
        private bool CompareToControlsAndObject()
        {
            // 自治体コード
            if (txtJititaiCode.Text != currentEntity_.JititaiCode)
                return false;

            // 担当課名
            if (txtTantoKaNameN.Text != currentEntity_.TantoKaNameN)
                return false;

            // 電話番号
            if (txtTelNo.Text != currentEntity_.TelNo)
                return false;

            // FAX番号
            if (txtFaxNo.Text != currentEntity_.FaxNo)
                return false;

            // メールアドレス
            if (txtEMail.Text != currentEntity_.EMail)
                return false;

            return true;
        }

        /// <summary>
        /// バリデーションをチェックします。
        /// </summary>
        /// <returns>True:チェックOK / False:チェックNG</returns>
        private bool Validation(IppanJikoEntity entity)
        {
            // 必須入力チェック
            if (string.IsNullOrEmpty(entity.JititaiCode.Trim()))
            {
                MessageUtils.NoInputDataMessage(CommonUtils.Trim(lblJititaiCode.Text), Text);
                txtJititaiCode.Focus();
                return false;
            }

            // 半角数字チェック行う
            if (!ValidationUtils.ValidateTypeNumeric(txtJititaiCode.Text))
            {
                MessageUtils.ZenkakuHankakuMessage(CommonUtils.Trim(lblJititaiCode.Text), 0, Text);
                txtJititaiCode.Focus();
                return false;
            }

            // 全角文字チェック 担当課名
            if (!ValidationUtils.ValidateZenkaku(txtTantoKaNameN.Text) & !string.IsNullOrEmpty(txtTantoKaNameN.Text))
            {
                MessageUtils.ZenkakuHankakuMessage(CommonUtils.Trim(lblTantoKaNameN.Text), 1, Text);
                txtTantoKaNameN.Focus();
                return false;
            }

            // 半角英数字チェック　電話番号
            if (!ValidationUtils.ValidatetxtHalfAll(txtTelNo.Text) & !string.IsNullOrEmpty(txtTelNo.Text))
            {
                MessageUtils.ZenkakuHankakuMessage(CommonUtils.Trim(lblTelNo.Text), 0, Text);
                txtTelNo.Focus();
                return false;
            }

            // 半角英数字チェック　FAX番号
            if (!ValidationUtils.ValidatetxtHalfAll(txtFaxNo.Text) & !string.IsNullOrEmpty(txtFaxNo.Text))
            {
                MessageUtils.ZenkakuHankakuMessage(CommonUtils.Trim(lblFaxNo.Text), 0, Text);
                txtFaxNo.Focus();
                return false;
            }

            // 半角英数字チェック　メールアドレス
            if (!ValidationUtils.ValidatetxtHalfAll(txtEMail.Text) & !string.IsNullOrEmpty(txtEMail.Text))
            {
                MessageUtils.ZenkakuHankakuMessage(CommonUtils.Trim(lblEMail.Text), 0, Text);
                txtEMail.Focus();
                return false;
            }

            return true;
        }


        /// <summary>
        /// データを作成します。
        /// </summary>
        /// <returns>一般事項</returns>
        private IppanJikoEntity CreateRegisterData()
        {
            // 登録データを作成する
            IppanJikoEntity entity = new IppanJikoEntity
            {
                JititaiCode = txtJititaiCode.Text,
                TantoKaNameN = txtTantoKaNameN.Text,
                TelNo = txtTelNo.Text,
                FaxNo = txtFaxNo.Text,
                EMail = txtEMail.Text,
                UpdDate = DateTime.Now.ToString(),
                Rev = 1,
            };

            return entity;
        }

        /// <summary>
        /// 一般事項を登録します。
        /// </summary>
        /// <param name="entity">一般事項</param>
        private void Register(IppanJikoEntity entity)
        {
            // データが存在しない場合
            if ((IppanJikoDao.Select(entity) == null) && (string.IsNullOrEmpty(currentEntity_.JititaiCode)))
            {
                // 一般事項を登録する
                IppanJikoDao.Insert(entity);
            }
            // データが存在する場合
            else
            {
                if (currentEntity_.JititaiCode == txtJititaiCode.Text)
                {
                    // 自治体コードが編集前と同じ場合、一般事項を更新する
                    IppanJikoDao.Update(entity);
                }
                else
                {
                    // 自治体コードが編集前と異なる場合、一般事項を削除/登録する
                    IppanJikoDao.Delete(currentEntity_);
                    IppanJikoDao.Insert(entity);
                }
            }

            // 編集前の一般事項を保持する
            currentEntity_ = entity;
        }

        /// <summary>
        /// 呼び出し元の画面に戻ります。
        /// </summary>
        private void Return()
        {
            try
            {
                if (!CompareToControlsAndObject())
                {
                    DialogResult result = MessageBox.Show("編集中のデータを保存しますか？", Text,
                        MessageBoxButtons.YesNo, MessageBoxIcon.Information, MessageBoxDefaultButton.Button2);

                    if (result == DialogResult.Yes)
                    {
                        // 登録データを作成する
                        IppanJikoEntity entity = CreateRegisterData();

                        // バリデーションチェックする
                        if (!Validation(entity))
                            return;

                        // 一般事項を登録する
                        Register(entity);

                        MessageBox.Show("更新が完了しました。", Text);
                    }
                }
            }
            catch (Exception ex)
            {
                // なにもしない
            }

            // 画面を閉じるときの前処理
            ClosingPreprocessing();

            Close();
        }

        /// <summary>
        /// 画面を閉じるときの前処理
        /// </summary>
        private void ClosingPreprocessing()
        {
            this.Tag = true;
        }

        #endregion
    }
}
