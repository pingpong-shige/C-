﻿namespace Suisitu.Forms.SD90
{
    partial class IppanJiko
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lblJititaiCode = new System.Windows.Forms.Label();
            this.lblTantoKaNameN = new System.Windows.Forms.Label();
            this.lblTelNo = new System.Windows.Forms.Label();
            this.txtJititaiCode = new System.Windows.Forms.TextBox();
            this.txtTantoKaNameN = new System.Windows.Forms.TextBox();
            this.btnReturn = new System.Windows.Forms.Button();
            this.btnSetting = new System.Windows.Forms.Button();
            this.lblFaxNo = new System.Windows.Forms.Label();
            this.lblEMail = new System.Windows.Forms.Label();
            this.txtTelNo = new System.Windows.Forms.TextBox();
            this.txtFaxNo = new System.Windows.Forms.TextBox();
            this.txtEMail = new System.Windows.Forms.TextBox();
            this.backColorChangeOnFocusProvider1 = new Suisitu.Component.BackColorChangeOnFocusProvider();
            this.bsIppanJiko = new System.Windows.Forms.BindingSource(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.bsIppanJiko)).BeginInit();
            this.SuspendLayout();
            // 
            // lblJititaiCode
            // 
            this.lblJititaiCode.AutoSize = true;
            this.lblJititaiCode.Location = new System.Drawing.Point(15, 15);
            this.lblJititaiCode.Name = "lblJititaiCode";
            this.lblJititaiCode.Size = new System.Drawing.Size(106, 24);
            this.lblJititaiCode.TabIndex = 0;
            this.lblJititaiCode.Text = "自治体コード";
            // 
            // lblTantoKaNameN
            // 
            this.lblTantoKaNameN.AutoSize = true;
            this.lblTantoKaNameN.Location = new System.Drawing.Point(15, 47);
            this.lblTantoKaNameN.Name = "lblTantoKaNameN";
            this.lblTantoKaNameN.Size = new System.Drawing.Size(74, 24);
            this.lblTantoKaNameN.TabIndex = 0;
            this.lblTantoKaNameN.Text = "担当課名";
            // 
            // lblTelNo
            // 
            this.lblTelNo.AutoSize = true;
            this.lblTelNo.Location = new System.Drawing.Point(15, 79);
            this.lblTelNo.Name = "lblTelNo";
            this.lblTelNo.Size = new System.Drawing.Size(74, 24);
            this.lblTelNo.TabIndex = 0;
            this.lblTelNo.Text = "電話番号";
            // 
            // txtJititaiCode
            // 
            this.txtJititaiCode.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsIppanJiko, "JititaiCode", true, System.Windows.Forms.DataSourceUpdateMode.Never));
            this.txtJititaiCode.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.txtJititaiCode.Location = new System.Drawing.Point(162, 12);
            this.txtJititaiCode.MaxLength = 6;
            this.txtJititaiCode.Name = "txtJititaiCode";
            this.txtJititaiCode.Size = new System.Drawing.Size(80, 31);
            this.txtJititaiCode.TabIndex = 1;
            // 
            // txtTantoKaNameN
            // 
            this.txtTantoKaNameN.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsIppanJiko, "TantoKaNameN", true, System.Windows.Forms.DataSourceUpdateMode.Never));
            this.txtTantoKaNameN.ImeMode = System.Windows.Forms.ImeMode.Hiragana;
            this.txtTantoKaNameN.Location = new System.Drawing.Point(162, 44);
            this.txtTantoKaNameN.MaxLength = 20;
            this.txtTantoKaNameN.Name = "txtTantoKaNameN";
            this.txtTantoKaNameN.Size = new System.Drawing.Size(340, 31);
            this.txtTantoKaNameN.TabIndex = 2;
            // 
            // btnReturn
            // 
            this.btnReturn.Location = new System.Drawing.Point(582, 187);
            this.btnReturn.Name = "btnReturn";
            this.btnReturn.Size = new System.Drawing.Size(100, 30);
            this.btnReturn.TabIndex = 7;
            this.btnReturn.Text = "戻る";
            this.btnReturn.UseVisualStyleBackColor = true;
            this.btnReturn.Click += new System.EventHandler(this.btnReturn_Click);
            // 
            // btnSetting
            // 
            this.btnSetting.Location = new System.Drawing.Point(476, 187);
            this.btnSetting.Name = "btnSetting";
            this.btnSetting.Size = new System.Drawing.Size(100, 30);
            this.btnSetting.TabIndex = 6;
            this.btnSetting.Text = "設定";
            this.btnSetting.UseVisualStyleBackColor = true;
            this.btnSetting.Click += new System.EventHandler(this.btnSetting_Click);
            // 
            // lblFaxNo
            // 
            this.lblFaxNo.AutoSize = true;
            this.lblFaxNo.Location = new System.Drawing.Point(15, 111);
            this.lblFaxNo.Name = "lblFaxNo";
            this.lblFaxNo.Size = new System.Drawing.Size(72, 24);
            this.lblFaxNo.TabIndex = 9;
            this.lblFaxNo.Text = "FAX番号";
            // 
            // lblEMail
            // 
            this.lblEMail.AutoSize = true;
            this.lblEMail.Location = new System.Drawing.Point(15, 143);
            this.lblEMail.Name = "lblEMail";
            this.lblEMail.Size = new System.Drawing.Size(122, 24);
            this.lblEMail.TabIndex = 11;
            this.lblEMail.Text = "メールアドレス";
            // 
            // txtTelNo
            // 
            this.txtTelNo.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsIppanJiko, "TelNo", true, System.Windows.Forms.DataSourceUpdateMode.Never));
            this.txtTelNo.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.txtTelNo.Location = new System.Drawing.Point(162, 76);
            this.txtTelNo.MaxLength = 13;
            this.txtTelNo.Name = "txtTelNo";
            this.txtTelNo.Size = new System.Drawing.Size(150, 31);
            this.txtTelNo.TabIndex = 3;
            // 
            // txtFaxNo
            // 
            this.txtFaxNo.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsIppanJiko, "FaxNo", true, System.Windows.Forms.DataSourceUpdateMode.Never));
            this.txtFaxNo.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.txtFaxNo.Location = new System.Drawing.Point(162, 108);
            this.txtFaxNo.MaxLength = 13;
            this.txtFaxNo.Name = "txtFaxNo";
            this.txtFaxNo.Size = new System.Drawing.Size(150, 31);
            this.txtFaxNo.TabIndex = 4;
            // 
            // txtEMail
            // 
            this.txtEMail.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsIppanJiko, "EMail", true, System.Windows.Forms.DataSourceUpdateMode.Never));
            this.txtEMail.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.txtEMail.Location = new System.Drawing.Point(162, 140);
            this.txtEMail.MaxLength = 50;
            this.txtEMail.Name = "txtEMail";
            this.txtEMail.Size = new System.Drawing.Size(520, 31);
            this.txtEMail.TabIndex = 5;
            // 
            // backColorChangeOnFocusProvider1
            // 
            this.backColorChangeOnFocusProvider1.Target = this;
            // 
            // bsIppanJiko
            // 
            this.bsIppanJiko.DataSource = typeof(Suisitu.Entity.IppanJikoEntity);
            // 
            // IppanJiko
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.ClientSize = new System.Drawing.Size(699, 232);
            this.Controls.Add(this.txtEMail);
            this.Controls.Add(this.txtFaxNo);
            this.Controls.Add(this.txtTelNo);
            this.Controls.Add(this.lblEMail);
            this.Controls.Add(this.lblFaxNo);
            this.Controls.Add(this.btnSetting);
            this.Controls.Add(this.btnReturn);
            this.Controls.Add(this.txtTantoKaNameN);
            this.Controls.Add(this.txtJititaiCode);
            this.Controls.Add(this.lblTelNo);
            this.Controls.Add(this.lblTantoKaNameN);
            this.Controls.Add(this.lblJititaiCode);
            this.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "IppanJiko";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "一般事項マスタ 保守画面";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.IppanJiko_FormClosing);
            this.Load += new System.EventHandler(this.IppanJiko_Load);
            ((System.ComponentModel.ISupportInitialize)(this.bsIppanJiko)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblJititaiCode;
        private System.Windows.Forms.Label lblTantoKaNameN;
        private System.Windows.Forms.Label lblTelNo;
        private System.Windows.Forms.TextBox txtJititaiCode;
        private System.Windows.Forms.TextBox txtTantoKaNameN;
        private System.Windows.Forms.Button btnReturn;
        private System.Windows.Forms.Button btnSetting;
        private Component.BackColorChangeOnFocusProvider backColorChangeOnFocusProvider1;
        private System.Windows.Forms.Label lblEMail;
        private System.Windows.Forms.Label lblFaxNo;
        private System.Windows.Forms.TextBox txtEMail;
        private System.Windows.Forms.TextBox txtFaxNo;
        private System.Windows.Forms.TextBox txtTelNo;
        private System.Windows.Forms.BindingSource bsIppanJiko;
    }
}