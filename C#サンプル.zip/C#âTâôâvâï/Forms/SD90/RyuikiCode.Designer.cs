﻿namespace Suisitu.Forms.SD90
{
    partial class RyuikiCode
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnReturn = new System.Windows.Forms.Button();
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnSelect = new System.Windows.Forms.Button();
            this.dgvRyuikiCode = new System.Windows.Forms.DataGridView();
            this.bsRyuikiCode = new System.Windows.Forms.BindingSource(this.components);
            this.panel2 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.txtAbKiseiTekiyoFlag = new System.Windows.Forms.TextBox();
            this.lblAbKiseiTekiyoFlag = new System.Windows.Forms.Label();
            this.txtRyuikiNameN = new System.Windows.Forms.TextBox();
            this.chkDelete = new System.Windows.Forms.CheckBox();
            this.lblRyuikiName = new System.Windows.Forms.Label();
            this.lblKijuntenCode = new System.Windows.Forms.Label();
            this.lblRyuikiCode = new System.Windows.Forms.Label();
            this.txtKijuntenCode = new System.Windows.Forms.TextBox();
            this.txtRyuikiCode = new System.Windows.Forms.TextBox();
            this.btnSetting = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.backColorChangeOnFocusProvider1 = new Suisitu.Component.BackColorChangeOnFocusProvider();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvRyuikiCode)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsRyuikiCode)).BeginInit();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.btnReturn);
            this.panel1.Controls.Add(this.btnAdd);
            this.panel1.Controls.Add(this.btnSelect);
            this.panel1.Controls.Add(this.dgvRyuikiCode);
            this.panel1.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel1.Location = new System.Drawing.Point(15, 15);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(706, 438);
            this.panel1.TabIndex = 0;
            // 
            // btnReturn
            // 
            this.btnReturn.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReturn.Location = new System.Drawing.Point(586, 394);
            this.btnReturn.Name = "btnReturn";
            this.btnReturn.Size = new System.Drawing.Size(101, 30);
            this.btnReturn.TabIndex = 3;
            this.btnReturn.Text = "戻る";
            this.btnReturn.UseVisualStyleBackColor = true;
            this.btnReturn.Click += new System.EventHandler(this.btnReturn_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdd.Location = new System.Drawing.Point(479, 394);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(101, 30);
            this.btnAdd.TabIndex = 2;
            this.btnAdd.Text = "追加";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // btnSelect
            // 
            this.btnSelect.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSelect.Location = new System.Drawing.Point(372, 394);
            this.btnSelect.Name = "btnSelect";
            this.btnSelect.Size = new System.Drawing.Size(101, 30);
            this.btnSelect.TabIndex = 1;
            this.btnSelect.Text = "選択";
            this.btnSelect.UseVisualStyleBackColor = true;
            this.btnSelect.Click += new System.EventHandler(this.btnSelect_Click);
            // 
            // dgvRyuikiCode
            // 
            this.dgvRyuikiCode.AllowUserToAddRows = false;
            this.dgvRyuikiCode.AllowUserToDeleteRows = false;
            this.dgvRyuikiCode.AllowUserToResizeColumns = false;
            this.dgvRyuikiCode.AllowUserToResizeRows = false;
            this.dgvRyuikiCode.AutoGenerateColumns = false;
            this.dgvRyuikiCode.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvRyuikiCode.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4});
            this.dgvRyuikiCode.DataSource = this.bsRyuikiCode;
            this.dgvRyuikiCode.Location = new System.Drawing.Point(15, 15);
            this.dgvRyuikiCode.MultiSelect = false;
            this.dgvRyuikiCode.Name = "dgvRyuikiCode";
            this.dgvRyuikiCode.ReadOnly = true;
            this.dgvRyuikiCode.RowHeadersVisible = false;
            this.dgvRyuikiCode.RowHeadersWidth = 40;
            this.dgvRyuikiCode.RowTemplate.Height = 21;
            this.dgvRyuikiCode.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvRyuikiCode.Size = new System.Drawing.Size(671, 373);
            this.dgvRyuikiCode.TabIndex = 0;
            this.dgvRyuikiCode.CellMouseDoubleClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgvRyuikiCode_CellMouseDoubleClick);
            // 
            // bsRyuikiCode
            // 
            this.bsRyuikiCode.DataSource = typeof(Suisitu.Entity.RyuikiCodeEntity);
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.txtAbKiseiTekiyoFlag);
            this.panel2.Controls.Add(this.lblAbKiseiTekiyoFlag);
            this.panel2.Controls.Add(this.txtRyuikiNameN);
            this.panel2.Controls.Add(this.chkDelete);
            this.panel2.Controls.Add(this.lblRyuikiName);
            this.panel2.Controls.Add(this.lblKijuntenCode);
            this.panel2.Controls.Add(this.lblRyuikiCode);
            this.panel2.Controls.Add(this.txtKijuntenCode);
            this.panel2.Controls.Add(this.txtRyuikiCode);
            this.panel2.Controls.Add(this.btnSetting);
            this.panel2.Controls.Add(this.btnCancel);
            this.panel2.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.panel2.Location = new System.Drawing.Point(15, 459);
            this.panel2.Margin = new System.Windows.Forms.Padding(3, 5, 3, 3);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(706, 210);
            this.panel2.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.label1.Location = new System.Drawing.Point(196, 111);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(148, 24);
            this.label1.TabIndex = 17;
            this.label1.Text = "(0:非適用  1:適用)";
            // 
            // txtAbKiseiTekiyoFlag
            // 
            this.txtAbKiseiTekiyoFlag.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtAbKiseiTekiyoFlag.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.txtAbKiseiTekiyoFlag.Location = new System.Drawing.Point(163, 108);
            this.txtAbKiseiTekiyoFlag.MaxLength = 1;
            this.txtAbKiseiTekiyoFlag.Name = "txtAbKiseiTekiyoFlag";
            this.txtAbKiseiTekiyoFlag.Size = new System.Drawing.Size(27, 31);
            this.txtAbKiseiTekiyoFlag.TabIndex = 7;
            // 
            // lblAbKiseiTekiyoFlag
            // 
            this.lblAbKiseiTekiyoFlag.AutoSize = true;
            this.lblAbKiseiTekiyoFlag.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblAbKiseiTekiyoFlag.Location = new System.Drawing.Point(15, 111);
            this.lblAbKiseiTekiyoFlag.Name = "lblAbKiseiTekiyoFlag";
            this.lblAbKiseiTekiyoFlag.Size = new System.Drawing.Size(141, 24);
            this.lblAbKiseiTekiyoFlag.TabIndex = 15;
            this.lblAbKiseiTekiyoFlag.Text = "ab規制適用フラグ";
            // 
            // txtRyuikiNameN
            // 
            this.txtRyuikiNameN.ImeMode = System.Windows.Forms.ImeMode.Hiragana;
            this.txtRyuikiNameN.Location = new System.Drawing.Point(163, 76);
            this.txtRyuikiNameN.MaxLength = 20;
            this.txtRyuikiNameN.Name = "txtRyuikiNameN";
            this.txtRyuikiNameN.Size = new System.Drawing.Size(295, 31);
            this.txtRyuikiNameN.TabIndex = 6;
            // 
            // chkDelete
            // 
            this.chkDelete.AutoSize = true;
            this.chkDelete.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.chkDelete.Location = new System.Drawing.Point(587, 131);
            this.chkDelete.Name = "chkDelete";
            this.chkDelete.Size = new System.Drawing.Size(61, 28);
            this.chkDelete.TabIndex = 8;
            this.chkDelete.Text = "削除";
            this.chkDelete.UseVisualStyleBackColor = true;
            // 
            // lblRyuikiName
            // 
            this.lblRyuikiName.AutoSize = true;
            this.lblRyuikiName.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblRyuikiName.Location = new System.Drawing.Point(15, 79);
            this.lblRyuikiName.Name = "lblRyuikiName";
            this.lblRyuikiName.Size = new System.Drawing.Size(74, 24);
            this.lblRyuikiName.TabIndex = 12;
            this.lblRyuikiName.Text = "流域名称";
            // 
            // lblKijuntenCode
            // 
            this.lblKijuntenCode.AutoSize = true;
            this.lblKijuntenCode.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblKijuntenCode.Location = new System.Drawing.Point(15, 47);
            this.lblKijuntenCode.Name = "lblKijuntenCode";
            this.lblKijuntenCode.Size = new System.Drawing.Size(106, 24);
            this.lblKijuntenCode.TabIndex = 11;
            this.lblKijuntenCode.Text = "基準点コード";
            // 
            // lblRyuikiCode
            // 
            this.lblRyuikiCode.AutoSize = true;
            this.lblRyuikiCode.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblRyuikiCode.Location = new System.Drawing.Point(15, 15);
            this.lblRyuikiCode.Name = "lblRyuikiCode";
            this.lblRyuikiCode.Size = new System.Drawing.Size(90, 24);
            this.lblRyuikiCode.TabIndex = 10;
            this.lblRyuikiCode.Text = "流域コード";
            // 
            // txtKijuntenCode
            // 
            this.txtKijuntenCode.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtKijuntenCode.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.txtKijuntenCode.Location = new System.Drawing.Point(163, 44);
            this.txtKijuntenCode.MaxLength = 3;
            this.txtKijuntenCode.Name = "txtKijuntenCode";
            this.txtKijuntenCode.Size = new System.Drawing.Size(54, 31);
            this.txtKijuntenCode.TabIndex = 5;
            // 
            // txtRyuikiCode
            // 
            this.txtRyuikiCode.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtRyuikiCode.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.txtRyuikiCode.Location = new System.Drawing.Point(163, 12);
            this.txtRyuikiCode.MaxLength = 8;
            this.txtRyuikiCode.Name = "txtRyuikiCode";
            this.txtRyuikiCode.Size = new System.Drawing.Size(118, 31);
            this.txtRyuikiCode.TabIndex = 4;
            // 
            // btnSetting
            // 
            this.btnSetting.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnSetting.Location = new System.Drawing.Point(479, 165);
            this.btnSetting.Name = "btnSetting";
            this.btnSetting.Size = new System.Drawing.Size(101, 30);
            this.btnSetting.TabIndex = 9;
            this.btnSetting.Text = "設定";
            this.btnSetting.UseVisualStyleBackColor = true;
            this.btnSetting.Click += new System.EventHandler(this.btnSetting_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnCancel.Location = new System.Drawing.Point(586, 165);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(101, 30);
            this.btnCancel.TabIndex = 10;
            this.btnCancel.Text = "キャンセル";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // backColorChangeOnFocusProvider1
            // 
            this.backColorChangeOnFocusProvider1.Target = this;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "RyuikiCode";
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn1.DefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridViewTextBoxColumn1.HeaderText = "流域コード";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.Width = 150;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "KijuntenCode";
            this.dataGridViewTextBoxColumn2.HeaderText = "基準点\r\nコード";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "RyuikiNameN";
            this.dataGridViewTextBoxColumn3.HeaderText = "流域名称";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            this.dataGridViewTextBoxColumn3.Width = 300;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "AbKiseiTekiyoFlag";
            this.dataGridViewTextBoxColumn4.HeaderText = "ab規制適用フラグ";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            // 
            // RyuikiCode
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.ClientSize = new System.Drawing.Size(733, 681);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "RyuikiCode";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "流域コード　保守画面";
            this.Load += new System.EventHandler(this.RyuikiCode_Load);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvRyuikiCode)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsRyuikiCode)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DataGridView dgvRyuikiCode;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btnSelect;
        private System.Windows.Forms.Button btnReturn;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.TextBox txtKijuntenCode;
        private System.Windows.Forms.TextBox txtRyuikiCode;
        private System.Windows.Forms.Button btnSetting;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Label lblRyuikiCode;
        private System.Windows.Forms.CheckBox chkDelete;
        private System.Windows.Forms.Label lblRyuikiName;
        private System.Windows.Forms.Label lblKijuntenCode;
        private System.Windows.Forms.Label lblAbKiseiTekiyoFlag;
        private System.Windows.Forms.TextBox txtRyuikiNameN;
        private System.Windows.Forms.TextBox txtAbKiseiTekiyoFlag;
        private System.Windows.Forms.BindingSource bsRyuikiCode;
        private System.Windows.Forms.Label label1;
        private Component.BackColorChangeOnFocusProvider backColorChangeOnFocusProvider1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
    }
}