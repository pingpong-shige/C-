﻿using Suisitu.Common;
using Suisitu.Dao;
using Suisitu.Entity;
using System;
using System.Windows.Forms;

namespace Suisitu.Forms.SD90
{
    using CommonEvents = Suisitu.Common.Events;

    /// <summary>
    /// 届出区分コード保守画面クラス
    /// </summary>
    public partial class RyuikiCode : Form
    {
        private bool isInsert_ = false;

        #region コンストラクタ

        /// <summary>
        /// コンストラクタ
        /// </summary>
        public RyuikiCode()
        {
            InitializeComponent();

            this.txtRyuikiCode.KeyPress += new KeyPressEventHandler(CommonEvents.txtHalfNumber_KeyPress);
            this.txtKijuntenCode.KeyPress += new KeyPressEventHandler(CommonEvents.txtHalfAll_KeyPress);
            this.txtRyuikiNameN.KeyPress += new KeyPressEventHandler(CommonEvents.txtFullAll_KeyPress);
            this.txtAbKiseiTekiyoFlag.KeyPress += new KeyPressEventHandler(CommonEvents.txtHalfNumber_KeyPress);
        }

        #endregion

        #region イベント

        /// <summary>
        /// 画面が表示されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void RyuikiCode_Load(object sender, EventArgs e)
        {
            bsRyuikiCode.DataSource = RyuikiCodeDao.SelectAll();

            Clear();
        }

        /// <summary>
        /// 選択ボタンが押下されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnSelect_Click(object sender, EventArgs e)
        {
            SelectedItem();
        }

        /// <summary>
        /// データグリッドビューのセルがダブルクリックされたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void dgvRyuikiCode_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (bsRyuikiCode.Current != null)
                SelectedItem();
        }

        /// <summary>
        /// 設定ボタンが押下されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnSetting_Click(object sender, EventArgs e)
        {
            RyuikiCodeEntity entity = null;

            if (chkDelete.Checked)
            {
                RyuikiCodeDao.Delete((RyuikiCodeEntity)bsRyuikiCode.Current);
            }
            else
            {
                entity = new RyuikiCodeEntity
                {
                    RyuikiCode = txtRyuikiCode.Text,
                    KijuntenCode = txtKijuntenCode.Text,
                    RyuikiNameN = txtRyuikiNameN.Text,
                    AbKiseiTekiyoFlag = txtAbKiseiTekiyoFlag.Text,
                    UpdDate = DateTime.Now.ToString(),
                    Rev = 1,
                };

                if (!Validation(entity))
                    return;

                // 追加モードの場合はInsert、それ以外はUpdateする
                if (this.isInsert_)
                {
                    RyuikiCodeDao.Insert(entity);
                }
                else
                {
                    RyuikiCodeDao.Update(entity);
                }
            }

            // 一覧をリフレッシュする
            bsRyuikiCode.DataSource = RyuikiCodeDao.SelectAll();

            // 追加モードの場合は、追加行を選択行に設定する
            if (this.isInsert_)
            {
                int rowIndex = 0;

                foreach (DataGridViewRow row in dgvRyuikiCode.Rows)
                {
                    if (row.Cells[0].Value.ToString().Trim() == entity.RyuikiCode.Trim())
                    {
                        break;
                    }
                    rowIndex++;
                }
                dgvRyuikiCode.CurrentCell = dgvRyuikiCode[0, rowIndex];
            }

            // コントロールを初期化する
            Clear();
        }

        /// <summary>
        /// 追加ボタンが押下されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnAdd_Click(object sender, EventArgs e)
        {
            // 追加モードに設定する
            this.isInsert_ = true;

            panel1.Enabled = false;
            panel2.Enabled = true;
            chkDelete.Enabled = false;
            txtRyuikiCode.Enabled = true;

            // 流域コードにフォーカスをセット
            txtRyuikiCode.Focus();
        }

        /// <summary>
        /// キャンセルボタンが押下されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnCancel_Click(object sender, EventArgs e)
        {
            Clear();
        }

        /// <summary>
        /// 戻るボタンが押下されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnReturn_Click(object sender, EventArgs e)
        {
            Close();
        }

        #endregion

        #region プライベートメソッド

        /// <summary>
        /// バリデーションをチェックします。
        /// </summary>
        /// <returns>True:チェックOK / False:チェックNG</returns>
        private bool Validation(RyuikiCodeEntity entity)
        {
            // 必須入力チェック
            if (string.IsNullOrEmpty(entity.RyuikiCode.Trim()))
            {
                MessageUtils.NoInputDataMessage(CommonUtils.Trim(lblRyuikiCode.Text), Text);
                txtRyuikiCode.Focus();
                return false;
            }

            // 半角数字チェック行う
            if (!ValidationUtils.ValidateTypeNumeric(txtRyuikiCode.Text))
            {
                MessageUtils.ZenkakuHankakuMessage(CommonUtils.Trim(lblRyuikiCode.Text), 0, Text);
                txtRyuikiCode.Focus();
                return false;
            }

            // 桁数チェック
            if (entity.RyuikiCode.Length < txtRyuikiCode.MaxLength)
            {
                MessageUtils.MismatchInputDigitsMessage(CommonUtils.Trim(lblRyuikiCode.Text), txtRyuikiCode.MaxLength, Text);
                txtRyuikiCode.Focus();
                return false;
            }

            // 半角英字チェックを行う　基準点コード
            if (!ValidationUtils.ValidatetxtHalfAll(txtKijuntenCode.Text) & !string.IsNullOrEmpty(txtKijuntenCode.Text))
            {
                MessageUtils.ZenkakuHankakuMessage(CommonUtils.Trim(lblKijuntenCode.Text), 0, Text);
                txtKijuntenCode.Focus();
                return false;
            }

            // 桁数チェック　基準点コード
            if (entity.KijuntenCode.Length < txtKijuntenCode.MaxLength)
            {
                MessageUtils.MismatchInputDigitsMessage(CommonUtils.Trim(lblKijuntenCode.Text), txtKijuntenCode.MaxLength, Text);
                txtKijuntenCode.Focus();
                return false;
            }

            // 全角文字チェック　流域名称
            if (!ValidationUtils.ValidateZenkaku(txtRyuikiNameN.Text) & !string.IsNullOrEmpty(txtRyuikiNameN.Text))
            {
                MessageUtils.ZenkakuHankakuMessage(CommonUtils.Trim(lblRyuikiName.Text), 1, Text);
                txtRyuikiNameN.Focus();
                return false;
            }

            // ab規制適用フラグチェック
            if (entity.AbKiseiTekiyoFlag != "0" && entity.AbKiseiTekiyoFlag != "1")
            {
                MessageUtils.TypeErrorMessage(CommonUtils.Trim(lblAbKiseiTekiyoFlag.Text), Text);
                txtAbKiseiTekiyoFlag.Focus();
                return false;
            }

            // 存在チェック
            if (this.isInsert_)
            {
                if (RyuikiCodeDao.Select(entity) != null)
                {
                    MessageUtils.Duplication(CommonUtils.Trim(lblRyuikiCode.Text), Text);
                    txtRyuikiCode.Focus();
                    return false;
                }
            }

            return true;
        }

        /// <summary>
        /// 画面のクリア処理
        /// </summary>
        private void Clear()
        {
            // コントロールを初期値に戻す
            txtRyuikiCode.Text = "";
            txtKijuntenCode.Text = "";
            txtRyuikiNameN.Text = "";
            txtAbKiseiTekiyoFlag.Text = "";
            chkDelete.Checked = false;

            // 選択ボタンの使用可/不可を設定する
            if (dgvRyuikiCode.Rows.Count == 0)
            {
                btnSelect.Enabled = false;
            }
            else
            {
                btnSelect.Enabled = true;
            }

            // 一覧部分を操作可、編集部分を操作不可に設定する
            panel1.Enabled = true;
            panel2.Enabled = false;

            this.isInsert_ = false;
        }

        /// <summary>
        /// 一覧からアイテムが選択されたときの処理
        /// </summary>
        private void SelectedItem()
        {
            panel1.Enabled = false;
            panel2.Enabled = true;
            chkDelete.Enabled = true;
            txtRyuikiCode.Enabled = false;

            //選択行を取得する
            RyuikiCodeEntity currentEntity = (RyuikiCodeEntity)bsRyuikiCode.Current;

            // 流域コード
            txtRyuikiCode.Text = currentEntity.RyuikiCode;
            // 基準点コード
            txtKijuntenCode.Text = currentEntity.KijuntenCode;
            // 流域名称
            txtRyuikiNameN.Text = currentEntity.RyuikiNameN;
            // ab規制適用フラグ
            txtAbKiseiTekiyoFlag.Text = currentEntity.AbKiseiTekiyoFlag;

            // 基準点コードにフォーカスをセット
            txtKijuntenCode.Focus();
        }

        #endregion

    }
}
