﻿namespace Suisitu.Forms.SD90
{
    partial class SGyosyaCode
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnReturn = new System.Windows.Forms.Button();
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnSelect = new System.Windows.Forms.Button();
            this.dgvSGyosyaCode = new System.Windows.Forms.DataGridView();
            this.bsSGyosyaCode = new System.Windows.Forms.BindingSource(this.components);
            this.panel2 = new System.Windows.Forms.Panel();
            this.txtTantoName = new System.Windows.Forms.TextBox();
            this.lblTantoName = new System.Windows.Forms.Label();
            this.chkDelete = new System.Windows.Forms.CheckBox();
            this.lblGyosyaName = new System.Windows.Forms.Label();
            this.lblGyosyacode = new System.Windows.Forms.Label();
            this.txtGyosyaName = new System.Windows.Forms.TextBox();
            this.txtGyosyaCode = new System.Windows.Forms.TextBox();
            this.btnSetting = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.backColorChangeOnFocusProvider1 = new Suisitu.Component.BackColorChangeOnFocusProvider();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.GyosyaNameN = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tantoNameNDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSGyosyaCode)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsSGyosyaCode)).BeginInit();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.btnReturn);
            this.panel1.Controls.Add(this.btnAdd);
            this.panel1.Controls.Add(this.btnSelect);
            this.panel1.Controls.Add(this.dgvSGyosyaCode);
            this.panel1.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel1.Location = new System.Drawing.Point(15, 15);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(574, 312);
            this.panel1.TabIndex = 1;
            // 
            // btnReturn
            // 
            this.btnReturn.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReturn.Location = new System.Drawing.Point(456, 268);
            this.btnReturn.Name = "btnReturn";
            this.btnReturn.Size = new System.Drawing.Size(100, 30);
            this.btnReturn.TabIndex = 3;
            this.btnReturn.Text = "戻る";
            this.btnReturn.UseVisualStyleBackColor = true;
            this.btnReturn.Click += new System.EventHandler(this.btnReturn_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdd.Location = new System.Drawing.Point(350, 268);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(100, 30);
            this.btnAdd.TabIndex = 2;
            this.btnAdd.Text = "追加";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // btnSelect
            // 
            this.btnSelect.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSelect.Location = new System.Drawing.Point(244, 268);
            this.btnSelect.Name = "btnSelect";
            this.btnSelect.Size = new System.Drawing.Size(100, 30);
            this.btnSelect.TabIndex = 1;
            this.btnSelect.Text = "選択";
            this.btnSelect.UseVisualStyleBackColor = true;
            this.btnSelect.Click += new System.EventHandler(this.btnSelect_Click);
            // 
            // dgvSGyosyaCode
            // 
            this.dgvSGyosyaCode.AllowUserToAddRows = false;
            this.dgvSGyosyaCode.AllowUserToResizeColumns = false;
            this.dgvSGyosyaCode.AllowUserToResizeRows = false;
            this.dgvSGyosyaCode.AutoGenerateColumns = false;
            this.dgvSGyosyaCode.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvSGyosyaCode.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.GyosyaNameN,
            this.tantoNameNDataGridViewTextBoxColumn});
            this.dgvSGyosyaCode.DataSource = this.bsSGyosyaCode;
            this.dgvSGyosyaCode.Location = new System.Drawing.Point(15, 15);
            this.dgvSGyosyaCode.Name = "dgvSGyosyaCode";
            this.dgvSGyosyaCode.ReadOnly = true;
            this.dgvSGyosyaCode.RowHeadersVisible = false;
            this.dgvSGyosyaCode.RowHeadersWidth = 40;
            this.dgvSGyosyaCode.RowTemplate.Height = 21;
            this.dgvSGyosyaCode.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvSGyosyaCode.Size = new System.Drawing.Size(541, 247);
            this.dgvSGyosyaCode.TabIndex = 0;
            this.dgvSGyosyaCode.CellMouseDoubleClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgvSGyosyaCode_CellMouseDoubleClick);
            // 
            // bsSGyosyaCode
            // 
            this.bsSGyosyaCode.DataSource = typeof(Suisitu.Entity.SGyosyaCodeEntity);
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.txtTantoName);
            this.panel2.Controls.Add(this.lblTantoName);
            this.panel2.Controls.Add(this.chkDelete);
            this.panel2.Controls.Add(this.lblGyosyaName);
            this.panel2.Controls.Add(this.lblGyosyacode);
            this.panel2.Controls.Add(this.txtGyosyaName);
            this.panel2.Controls.Add(this.txtGyosyaCode);
            this.panel2.Controls.Add(this.btnSetting);
            this.panel2.Controls.Add(this.btnCancel);
            this.panel2.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.panel2.Location = new System.Drawing.Point(15, 333);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(574, 192);
            this.panel2.TabIndex = 2;
            // 
            // txtTantoName
            // 
            this.txtTantoName.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtTantoName.ImeMode = System.Windows.Forms.ImeMode.Hiragana;
            this.txtTantoName.Location = new System.Drawing.Point(143, 76);
            this.txtTantoName.MaxLength = 10;
            this.txtTantoName.Name = "txtTantoName";
            this.txtTantoName.Size = new System.Drawing.Size(180, 31);
            this.txtTantoName.TabIndex = 6;
            // 
            // lblTantoName
            // 
            this.lblTantoName.AutoSize = true;
            this.lblTantoName.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblTantoName.Location = new System.Drawing.Point(15, 79);
            this.lblTantoName.Name = "lblTantoName";
            this.lblTantoName.Size = new System.Drawing.Size(90, 24);
            this.lblTantoName.TabIndex = 12;
            this.lblTantoName.Text = "担当者氏名";
            // 
            // chkDelete
            // 
            this.chkDelete.AutoSize = true;
            this.chkDelete.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.chkDelete.Location = new System.Drawing.Point(456, 113);
            this.chkDelete.Name = "chkDelete";
            this.chkDelete.Size = new System.Drawing.Size(61, 28);
            this.chkDelete.TabIndex = 7;
            this.chkDelete.Text = "削除";
            this.chkDelete.UseVisualStyleBackColor = true;
            // 
            // lblGyosyaName
            // 
            this.lblGyosyaName.AutoSize = true;
            this.lblGyosyaName.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblGyosyaName.Location = new System.Drawing.Point(15, 47);
            this.lblGyosyaName.Name = "lblGyosyaName";
            this.lblGyosyaName.Size = new System.Drawing.Size(74, 24);
            this.lblGyosyaName.TabIndex = 11;
            this.lblGyosyaName.Text = "業者名称";
            // 
            // lblGyosyacode
            // 
            this.lblGyosyacode.AutoSize = true;
            this.lblGyosyacode.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblGyosyacode.Location = new System.Drawing.Point(15, 15);
            this.lblGyosyacode.Name = "lblGyosyacode";
            this.lblGyosyacode.Size = new System.Drawing.Size(90, 24);
            this.lblGyosyacode.TabIndex = 10;
            this.lblGyosyacode.Text = "業者コード";
            // 
            // txtGyosyaName
            // 
            this.txtGyosyaName.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtGyosyaName.ImeMode = System.Windows.Forms.ImeMode.Hiragana;
            this.txtGyosyaName.Location = new System.Drawing.Point(143, 44);
            this.txtGyosyaName.MaxLength = 20;
            this.txtGyosyaName.Name = "txtGyosyaName";
            this.txtGyosyaName.Size = new System.Drawing.Size(323, 31);
            this.txtGyosyaName.TabIndex = 5;
            // 
            // txtGyosyaCode
            // 
            this.txtGyosyaCode.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtGyosyaCode.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.txtGyosyaCode.Location = new System.Drawing.Point(143, 12);
            this.txtGyosyaCode.MaxLength = 1;
            this.txtGyosyaCode.Name = "txtGyosyaCode";
            this.txtGyosyaCode.Size = new System.Drawing.Size(30, 31);
            this.txtGyosyaCode.TabIndex = 4;
            // 
            // btnSetting
            // 
            this.btnSetting.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnSetting.Location = new System.Drawing.Point(350, 147);
            this.btnSetting.Name = "btnSetting";
            this.btnSetting.Size = new System.Drawing.Size(100, 30);
            this.btnSetting.TabIndex = 8;
            this.btnSetting.Text = "設定";
            this.btnSetting.UseVisualStyleBackColor = true;
            this.btnSetting.Click += new System.EventHandler(this.btnSetting_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnCancel.Location = new System.Drawing.Point(456, 147);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(100, 30);
            this.btnCancel.TabIndex = 9;
            this.btnCancel.Text = "キャンセル";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // backColorChangeOnFocusProvider1
            // 
            this.backColorChangeOnFocusProvider1.Target = this;
            // 
            // Column1
            // 
            this.Column1.DataPropertyName = "Gyosyacode";
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.Column1.DefaultCellStyle = dataGridViewCellStyle1;
            this.Column1.HeaderText = "業者 コード";
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            this.Column1.Width = 85;
            // 
            // GyosyaNameN
            // 
            this.GyosyaNameN.DataPropertyName = "GyosyaNameN";
            this.GyosyaNameN.HeaderText = "業者名称";
            this.GyosyaNameN.Name = "GyosyaNameN";
            this.GyosyaNameN.ReadOnly = true;
            this.GyosyaNameN.Width = 272;
            // 
            // tantoNameNDataGridViewTextBoxColumn
            // 
            this.tantoNameNDataGridViewTextBoxColumn.DataPropertyName = "TantoNameN";
            this.tantoNameNDataGridViewTextBoxColumn.HeaderText = "担当者氏名";
            this.tantoNameNDataGridViewTextBoxColumn.Name = "tantoNameNDataGridViewTextBoxColumn";
            this.tantoNameNDataGridViewTextBoxColumn.ReadOnly = true;
            this.tantoNameNDataGridViewTextBoxColumn.Width = 180;
            // 
            // SGyosyaCode
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.ClientSize = new System.Drawing.Size(601, 537);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "SGyosyaCode";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "採水業者コード　保守画面";
            this.Load += new System.EventHandler(this.SGyosyacode_Load);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvSGyosyaCode)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsSGyosyaCode)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnReturn;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnSelect;
        private System.Windows.Forms.DataGridView dgvSGyosyaCode;
        private System.Windows.Forms.BindingSource bsSGyosyaCode;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.CheckBox chkDelete;
        private System.Windows.Forms.Label lblGyosyaName;
        private System.Windows.Forms.Label lblGyosyacode;
        private System.Windows.Forms.TextBox txtGyosyaName;
        private System.Windows.Forms.TextBox txtGyosyaCode;
        private System.Windows.Forms.Button btnSetting;
        private System.Windows.Forms.Button btnCancel;
        private Component.BackColorChangeOnFocusProvider backColorChangeOnFocusProvider1;
        private System.Windows.Forms.TextBox txtTantoName;
        private System.Windows.Forms.Label lblTantoName;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn GyosyaNameN;
        private System.Windows.Forms.DataGridViewTextBoxColumn tantoNameNDataGridViewTextBoxColumn;
    }
}