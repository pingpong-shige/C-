﻿using Suisitu.Common;
using Suisitu.Dao;
using Suisitu.Entity;
using System;
using System.Windows.Forms;

namespace Suisitu.Forms.SD90
{
    using CommonEvents = Suisitu.Common.Events;

    /// <summary>
    /// 採水業者コード保守画面クラス
    /// </summary>
    public partial class SGyosyaCode : Form
    {
        private bool isInsert_ = false;

        #region コンストラクタ

        /// <summary>
        /// コンストラクタ
        /// </summary>
        public SGyosyaCode()
        {
            InitializeComponent();

            // 業者コード　半角数字のみ入力可
            this.txtGyosyaCode.KeyPress += new KeyPressEventHandler(CommonEvents.txtHalfNumber_KeyPress);
            // 業者名称　　全角文字のみ入力可
            this.txtGyosyaName.KeyPress += new KeyPressEventHandler(CommonEvents.txtFullAll_KeyPress);
            // 担当者氏名　全角文字のみ入力可
            this.txtTantoName.KeyPress += new KeyPressEventHandler(CommonEvents.txtFullAll_KeyPress);
        }

        #endregion

        #region イベント

        /// <summary>
        /// 画面が表示されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void SGyosyacode_Load(object sender, EventArgs e)
        {
            bsSGyosyaCode.DataSource = SGyosyaCodeDao.SelectAll();

            Clear();
        }

        /// <summary>
        /// 選択ボタンが押下されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnSelect_Click(object sender, EventArgs e)
        {
            SelectedItem();
        }

        /// <summary>
        /// データグリッドビューのセルがダブルクリックされたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void dgvSGyosyaCode_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (bsSGyosyaCode.Current != null)
                SelectedItem();
        }

        /// <summary>
        /// 設定ボタンが押下されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnSetting_Click(object sender, EventArgs e)
        {
            SGyosyaCodeEntity entity = null;

            if (chkDelete.Checked)
            {
                SGyosyaCodeDao.Delete((SGyosyaCodeEntity)bsSGyosyaCode.Current);
            }
            else
            {
                entity = new SGyosyaCodeEntity
                {
                    Gyosyacode = txtGyosyaCode.Text,
                    GyosyaNameN = txtGyosyaName.Text,
                    TantoNameN = txtTantoName.Text,
                    UpdDate = DateTime.Now.ToString(),
                    Rev = 1,
                };

                if (!Validation(entity))
                    return;

                // 追加モードの場合はInsert、それ以外はUpdateする
                if (this.isInsert_)
                {
                    SGyosyaCodeDao.Insert(entity);
                }
                else
                {
                    SGyosyaCodeDao.Update(entity);
                }
            }

            // 一覧をリフレッシュする
            bsSGyosyaCode.DataSource = SGyosyaCodeDao.SelectAll();

            // 追加モードの場合は、追加行を選択行に設定する
            if (this.isInsert_)
            {
                int rowIndex = 0;

                foreach (DataGridViewRow row in dgvSGyosyaCode.Rows)
                {
                    if (row.Cells[0].Value.ToString() == entity.Gyosyacode)
                    {
                        break;
                    }
                    rowIndex++;
                }
                dgvSGyosyaCode.CurrentCell = dgvSGyosyaCode[0, rowIndex];
            }

            // コントロールを初期化する
            Clear();
        }

        /// <summary>
        /// 追加ボタンが押下されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnAdd_Click(object sender, EventArgs e)
        {
            // 追加モードに設定する
            this.isInsert_ = true;

            panel1.Enabled = false;
            panel2.Enabled = true;
            chkDelete.Enabled = false;
            txtGyosyaCode.Enabled = true;

            // 識別コードにフォーカスをセット
            txtGyosyaCode.Focus();
        }

        /// <summary>
        /// キャンセルボタンが押下されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnCancel_Click(object sender, EventArgs e)
        {
            Clear();
        }

        /// <summary>
        /// 戻るボタンが押下されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnReturn_Click(object sender, EventArgs e)
        {
            Close();
        }

        #endregion

        #region プライベートメソッド

        /// <summary>
        /// バリデーションをチェックします。
        /// </summary>
        /// <returns>True:チェックOK / False:チェックNG</returns>
        private bool Validation(SGyosyaCodeEntity entity)
        {
            // 必須入力チェック
            // 業者コード
            if (string.IsNullOrEmpty(entity.Gyosyacode))
            {
                MessageUtils.NoInputDataMessage(CommonUtils.Trim(lblGyosyacode.Text), Text);
                txtGyosyaCode.Focus();
                return false;
            }

            // 半角数字チェック行う
            if (!ValidationUtils.ValidateTypeNumeric(txtGyosyaCode.Text))
            {
                MessageUtils.ZenkakuHankakuMessage(CommonUtils.Trim(lblGyosyacode.Text), 0, Text);
                txtGyosyaCode.Focus();
                return false;
            }

            // 全角文字チェック  業者名称
            if (!ValidationUtils.ValidateZenkaku(txtGyosyaName.Text) & !string.IsNullOrEmpty(txtGyosyaName.Text))
            {
                MessageUtils.ZenkakuHankakuMessage(CommonUtils.Trim(lblGyosyaName.Text), 1, Text);
                txtGyosyaName.Focus();
                return false;
            }

            // 全角文字チェック  担当者氏名
            if (!ValidationUtils.ValidateZenkaku(txtTantoName.Text) & !string.IsNullOrEmpty(txtTantoName.Text))
            {
                MessageUtils.ZenkakuHankakuMessage(CommonUtils.Trim(lblTantoName.Text), 1, Text);
                txtTantoName.Focus();
                return false;
            }

            // 存在チェック
            if (this.isInsert_)
            {
                if (SGyosyaCodeDao.Select(entity) != null)
                {
                    MessageUtils.Duplication(CommonUtils.Trim(lblGyosyacode.Text), Text);
                    txtGyosyaCode.Focus();
                    return false;
                }
            }

            return true;
        }

        /// <summary>
        /// 画面のクリア処理
        /// </summary>
        private void Clear()
        {
            // コントロールを初期値に戻す
            txtGyosyaCode.Text = "";
            txtGyosyaName.Text = "";
            txtTantoName.Text = "";
            chkDelete.Checked = false;
            
            // 選択ボタンの使用可/不可を設定する
            if (dgvSGyosyaCode.Rows.Count == 0)
            {
                btnSelect.Enabled = false;
            }
            else
            {
                btnSelect.Enabled = true;
            }

            // 一覧部分を操作可、編集部分を操作不可に設定する
            panel1.Enabled = true;
            panel2.Enabled = false;
            
            this.isInsert_ = false;
        }

        /// <summary>
        /// 一覧からアイテムが選択されたときの処理
        /// </summary>
        private void SelectedItem()
        {

            // 選択行を取得する
            SGyosyaCodeEntity currentEntity = (SGyosyaCodeEntity)bsSGyosyaCode.Current;

            // 選択行を取得できない場合は処理を抜ける（データがない場合のアボート対策）
            if (currentEntity == null)
            {
                return;
            }

            panel1.Enabled = false;
            panel2.Enabled = true;
            chkDelete.Enabled = true;
            txtGyosyaCode.Enabled = false;


            // 業者コード
            txtGyosyaCode.Text = currentEntity.Gyosyacode;
            // 業者名称
            txtGyosyaName.Text = currentEntity.GyosyaNameN;
            // 担当者氏名
            txtTantoName.Text = currentEntity.TantoNameN;

            // 業者名称にフォーカスをセット
            txtGyosyaName.Focus();
        }

        #endregion
    }
}
