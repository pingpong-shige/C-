﻿namespace Suisitu.Forms.SD90
{
    partial class SangyoB
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblSangyoBcListLine = new System.Windows.Forms.Label();
            this.lblSangyoBcList = new System.Windows.Forms.Label();
            this.btnAddBc = new System.Windows.Forms.Button();
            this.btnSelectBc = new System.Windows.Forms.Button();
            this.dgvSangyoBc = new System.Windows.Forms.DataGridView();
            this.bsSangyoBc = new System.Windows.Forms.BindingSource(this.components);
            this.btnReturn = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.txtSangyobc = new System.Windows.Forms.TextBox();
            this.lblSangyoBc = new System.Windows.Forms.Label();
            this.chkDeleteBc = new System.Windows.Forms.CheckBox();
            this.lblSangyobcName = new System.Windows.Forms.Label();
            this.txtSangyobcName = new System.Windows.Forms.TextBox();
            this.btnSettingBc = new System.Windows.Forms.Button();
            this.btnCancelBc = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.lblSangyoBsListLine = new System.Windows.Forms.Label();
            this.lblSangyoBsList = new System.Windows.Forms.Label();
            this.btnAddBs = new System.Windows.Forms.Button();
            this.btnSelectBs = new System.Windows.Forms.Button();
            this.dgvSangyoBs = new System.Windows.Forms.DataGridView();
            this.bsSangyoBs = new System.Windows.Forms.BindingSource(this.components);
            this.panel4 = new System.Windows.Forms.Panel();
            this.txtSangyobs = new System.Windows.Forms.TextBox();
            this.lblSangyobs = new System.Windows.Forms.Label();
            this.txtParent = new System.Windows.Forms.TextBox();
            this.lblParent = new System.Windows.Forms.Label();
            this.chkDeleteBs = new System.Windows.Forms.CheckBox();
            this.lblSangyobsName = new System.Windows.Forms.Label();
            this.txtSangyobsName = new System.Windows.Forms.TextBox();
            this.btnSettingBs = new System.Windows.Forms.Button();
            this.btnCancelBs = new System.Windows.Forms.Button();
            this.backColorChangeOnFocusProvider1 = new Suisitu.Component.BackColorChangeOnFocusProvider();
            this.sangyobcDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SangyobcNameN = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sangyobsDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sangyobsNameNDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSangyoBc)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsSangyoBc)).BeginInit();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSangyoBs)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsSangyoBs)).BeginInit();
            this.panel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.lblSangyoBcListLine);
            this.panel1.Controls.Add(this.lblSangyoBcList);
            this.panel1.Controls.Add(this.btnAddBc);
            this.panel1.Controls.Add(this.btnSelectBc);
            this.panel1.Controls.Add(this.dgvSangyoBc);
            this.panel1.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel1.Location = new System.Drawing.Point(15, 51);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(482, 461);
            this.panel1.TabIndex = 1;
            // 
            // lblSangyoBcListLine
            // 
            this.lblSangyoBcListLine.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblSangyoBcListLine.Font = new System.Drawing.Font("ＭＳ ゴシック", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblSangyoBcListLine.Location = new System.Drawing.Point(142, 25);
            this.lblSangyoBcListLine.Name = "lblSangyoBcListLine";
            this.lblSangyoBcListLine.Size = new System.Drawing.Size(325, 1);
            this.lblSangyoBcListLine.TabIndex = 80;
            // 
            // lblSangyoBcList
            // 
            this.lblSangyoBcList.AutoSize = true;
            this.lblSangyoBcList.Font = new System.Drawing.Font("メイリオ", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblSangyoBcList.Location = new System.Drawing.Point(15, 15);
            this.lblSangyoBcList.Name = "lblSangyoBcList";
            this.lblSangyoBcList.Size = new System.Drawing.Size(126, 20);
            this.lblSangyoBcList.TabIndex = 79;
            this.lblSangyoBcList.Text = "産業分類（中分類）";
            // 
            // btnAddBc
            // 
            this.btnAddBc.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddBc.Location = new System.Drawing.Point(367, 417);
            this.btnAddBc.Name = "btnAddBc";
            this.btnAddBc.Size = new System.Drawing.Size(100, 30);
            this.btnAddBc.TabIndex = 4;
            this.btnAddBc.Text = "追加";
            this.btnAddBc.UseVisualStyleBackColor = true;
            this.btnAddBc.Click += new System.EventHandler(this.btnAddBc_Click);
            // 
            // btnSelectBc
            // 
            this.btnSelectBc.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSelectBc.Location = new System.Drawing.Point(261, 417);
            this.btnSelectBc.Name = "btnSelectBc";
            this.btnSelectBc.Size = new System.Drawing.Size(100, 30);
            this.btnSelectBc.TabIndex = 3;
            this.btnSelectBc.Text = "選択";
            this.btnSelectBc.UseVisualStyleBackColor = true;
            this.btnSelectBc.Click += new System.EventHandler(this.btnSelectBc_Click);
            // 
            // dgvSangyoBc
            // 
            this.dgvSangyoBc.AllowUserToAddRows = false;
            this.dgvSangyoBc.AllowUserToDeleteRows = false;
            this.dgvSangyoBc.AllowUserToResizeColumns = false;
            this.dgvSangyoBc.AllowUserToResizeRows = false;
            this.dgvSangyoBc.AutoGenerateColumns = false;
            this.dgvSangyoBc.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvSangyoBc.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.sangyobcDataGridViewTextBoxColumn,
            this.SangyobcNameN});
            this.dgvSangyoBc.DataSource = this.bsSangyoBc;
            this.dgvSangyoBc.Location = new System.Drawing.Point(15, 41);
            this.dgvSangyoBc.MultiSelect = false;
            this.dgvSangyoBc.Name = "dgvSangyoBc";
            this.dgvSangyoBc.ReadOnly = true;
            this.dgvSangyoBc.RowHeadersVisible = false;
            this.dgvSangyoBc.RowHeadersWidth = 40;
            this.dgvSangyoBc.RowTemplate.DefaultCellStyle.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvSangyoBc.RowTemplate.Height = 21;
            this.dgvSangyoBc.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvSangyoBc.Size = new System.Drawing.Size(452, 370);
            this.dgvSangyoBc.TabIndex = 2;
            this.dgvSangyoBc.CellMouseDoubleClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgvSangyoBc_CellMouseDoubleClick);
            this.dgvSangyoBc.CurrentCellChanged += new System.EventHandler(this.dgvSangyoBc_CurrentCellChanged);
            // 
            // bsSangyoBc
            // 
            this.bsSangyoBc.DataSource = typeof(Suisitu.Entity.SangyoBcEntity);
            // 
            // btnReturn
            // 
            this.btnReturn.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReturn.Location = new System.Drawing.Point(885, 15);
            this.btnReturn.Name = "btnReturn";
            this.btnReturn.Size = new System.Drawing.Size(100, 30);
            this.btnReturn.TabIndex = 0;
            this.btnReturn.Text = "戻る";
            this.btnReturn.UseVisualStyleBackColor = true;
            this.btnReturn.Click += new System.EventHandler(this.btnReturn_Click);
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.txtSangyobc);
            this.panel2.Controls.Add(this.lblSangyoBc);
            this.panel2.Controls.Add(this.chkDeleteBc);
            this.panel2.Controls.Add(this.lblSangyobcName);
            this.panel2.Controls.Add(this.txtSangyobcName);
            this.panel2.Controls.Add(this.btnSettingBc);
            this.panel2.Controls.Add(this.btnCancelBc);
            this.panel2.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.panel2.Location = new System.Drawing.Point(15, 518);
            this.panel2.Margin = new System.Windows.Forms.Padding(3, 5, 3, 3);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(482, 192);
            this.panel2.TabIndex = 1;
            // 
            // txtSangyobc
            // 
            this.txtSangyobc.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtSangyobc.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.txtSangyobc.Location = new System.Drawing.Point(202, 12);
            this.txtSangyobc.MaxLength = 2;
            this.txtSangyobc.Name = "txtSangyobc";
            this.txtSangyobc.Size = new System.Drawing.Size(31, 31);
            this.txtSangyobc.TabIndex = 5;
            // 
            // lblSangyoBc
            // 
            this.lblSangyoBc.AutoSize = true;
            this.lblSangyoBc.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblSangyoBc.Location = new System.Drawing.Point(15, 15);
            this.lblSangyoBc.Name = "lblSangyoBc";
            this.lblSangyoBc.Size = new System.Drawing.Size(154, 24);
            this.lblSangyoBc.TabIndex = 12;
            this.lblSangyoBc.Text = "産業分類（中分類）";
            // 
            // chkDeleteBc
            // 
            this.chkDeleteBc.AutoSize = true;
            this.chkDeleteBc.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.chkDeleteBc.Location = new System.Drawing.Point(366, 113);
            this.chkDeleteBc.Name = "chkDeleteBc";
            this.chkDeleteBc.Size = new System.Drawing.Size(61, 28);
            this.chkDeleteBc.TabIndex = 7;
            this.chkDeleteBc.Text = "削除";
            this.chkDeleteBc.UseVisualStyleBackColor = true;
            // 
            // lblSangyobcName
            // 
            this.lblSangyobcName.AutoSize = true;
            this.lblSangyobcName.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblSangyobcName.Location = new System.Drawing.Point(15, 47);
            this.lblSangyobcName.Name = "lblSangyobcName";
            this.lblSangyobcName.Size = new System.Drawing.Size(186, 24);
            this.lblSangyobcName.TabIndex = 10;
            this.lblSangyobcName.Text = "産業分類（中分類）名称";
            // 
            // txtSangyobcName
            // 
            this.txtSangyobcName.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtSangyobcName.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.txtSangyobcName.Location = new System.Drawing.Point(202, 44);
            this.txtSangyobcName.MaxLength = 40;
            this.txtSangyobcName.Name = "txtSangyobcName";
            this.txtSangyobcName.Size = new System.Drawing.Size(265, 31);
            this.txtSangyobcName.TabIndex = 6;
            // 
            // btnSettingBc
            // 
            this.btnSettingBc.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnSettingBc.Location = new System.Drawing.Point(261, 147);
            this.btnSettingBc.Name = "btnSettingBc";
            this.btnSettingBc.Size = new System.Drawing.Size(100, 30);
            this.btnSettingBc.TabIndex = 8;
            this.btnSettingBc.Text = "設定";
            this.btnSettingBc.UseVisualStyleBackColor = true;
            this.btnSettingBc.Click += new System.EventHandler(this.btnSettingBc_Click);
            // 
            // btnCancelBc
            // 
            this.btnCancelBc.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnCancelBc.Location = new System.Drawing.Point(367, 147);
            this.btnCancelBc.Name = "btnCancelBc";
            this.btnCancelBc.Size = new System.Drawing.Size(100, 30);
            this.btnCancelBc.TabIndex = 9;
            this.btnCancelBc.Text = "キャンセル";
            this.btnCancelBc.UseVisualStyleBackColor = true;
            this.btnCancelBc.Click += new System.EventHandler(this.btnCancelBc_Click);
            // 
            // panel3
            // 
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.lblSangyoBsListLine);
            this.panel3.Controls.Add(this.lblSangyoBsList);
            this.panel3.Controls.Add(this.btnAddBs);
            this.panel3.Controls.Add(this.btnSelectBs);
            this.panel3.Controls.Add(this.dgvSangyoBs);
            this.panel3.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel3.Location = new System.Drawing.Point(503, 51);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(482, 461);
            this.panel3.TabIndex = 4;
            // 
            // lblSangyoBsListLine
            // 
            this.lblSangyoBsListLine.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblSangyoBsListLine.Font = new System.Drawing.Font("ＭＳ ゴシック", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblSangyoBsListLine.Location = new System.Drawing.Point(142, 25);
            this.lblSangyoBsListLine.Name = "lblSangyoBsListLine";
            this.lblSangyoBsListLine.Size = new System.Drawing.Size(325, 1);
            this.lblSangyoBsListLine.TabIndex = 81;
            // 
            // lblSangyoBsList
            // 
            this.lblSangyoBsList.AutoSize = true;
            this.lblSangyoBsList.Font = new System.Drawing.Font("メイリオ", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblSangyoBsList.Location = new System.Drawing.Point(15, 15);
            this.lblSangyoBsList.Name = "lblSangyoBsList";
            this.lblSangyoBsList.Size = new System.Drawing.Size(126, 20);
            this.lblSangyoBsList.TabIndex = 80;
            this.lblSangyoBsList.Text = "産業分類（細区分）";
            // 
            // btnAddBs
            // 
            this.btnAddBs.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddBs.Location = new System.Drawing.Point(367, 417);
            this.btnAddBs.Name = "btnAddBs";
            this.btnAddBs.Size = new System.Drawing.Size(100, 30);
            this.btnAddBs.TabIndex = 12;
            this.btnAddBs.Text = "追加";
            this.btnAddBs.UseVisualStyleBackColor = true;
            this.btnAddBs.Click += new System.EventHandler(this.btnAddBs_Click);
            // 
            // btnSelectBs
            // 
            this.btnSelectBs.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSelectBs.Location = new System.Drawing.Point(261, 417);
            this.btnSelectBs.Name = "btnSelectBs";
            this.btnSelectBs.Size = new System.Drawing.Size(100, 30);
            this.btnSelectBs.TabIndex = 11;
            this.btnSelectBs.Text = "選択";
            this.btnSelectBs.UseVisualStyleBackColor = true;
            this.btnSelectBs.Click += new System.EventHandler(this.btnSelectBs_Click);
            // 
            // dgvSangyoBs
            // 
            this.dgvSangyoBs.AllowUserToAddRows = false;
            this.dgvSangyoBs.AllowUserToDeleteRows = false;
            this.dgvSangyoBs.AllowUserToResizeColumns = false;
            this.dgvSangyoBs.AllowUserToResizeRows = false;
            this.dgvSangyoBs.AutoGenerateColumns = false;
            this.dgvSangyoBs.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvSangyoBs.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.sangyobsDataGridViewTextBoxColumn,
            this.sangyobsNameNDataGridViewTextBoxColumn});
            this.dgvSangyoBs.DataSource = this.bsSangyoBs;
            this.dgvSangyoBs.Location = new System.Drawing.Point(15, 41);
            this.dgvSangyoBs.MultiSelect = false;
            this.dgvSangyoBs.Name = "dgvSangyoBs";
            this.dgvSangyoBs.ReadOnly = true;
            this.dgvSangyoBs.RowHeadersVisible = false;
            this.dgvSangyoBs.RowHeadersWidth = 40;
            this.dgvSangyoBs.RowTemplate.DefaultCellStyle.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvSangyoBs.RowTemplate.Height = 21;
            this.dgvSangyoBs.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvSangyoBs.Size = new System.Drawing.Size(452, 370);
            this.dgvSangyoBs.TabIndex = 10;
            this.dgvSangyoBs.CellMouseDoubleClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgvSangyoBs_CellMouseDoubleClick);
            // 
            // bsSangyoBs
            // 
            this.bsSangyoBs.DataSource = typeof(Suisitu.Entity.SangyoBsEntity);
            // 
            // panel4
            // 
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel4.Controls.Add(this.txtSangyobs);
            this.panel4.Controls.Add(this.lblSangyobs);
            this.panel4.Controls.Add(this.txtParent);
            this.panel4.Controls.Add(this.lblParent);
            this.panel4.Controls.Add(this.chkDeleteBs);
            this.panel4.Controls.Add(this.lblSangyobsName);
            this.panel4.Controls.Add(this.txtSangyobsName);
            this.panel4.Controls.Add(this.btnSettingBs);
            this.panel4.Controls.Add(this.btnCancelBs);
            this.panel4.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.panel4.Location = new System.Drawing.Point(503, 518);
            this.panel4.Margin = new System.Windows.Forms.Padding(3, 5, 3, 3);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(482, 192);
            this.panel4.TabIndex = 5;
            // 
            // txtSangyobs
            // 
            this.txtSangyobs.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtSangyobs.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.txtSangyobs.Location = new System.Drawing.Point(202, 44);
            this.txtSangyobs.MaxLength = 2;
            this.txtSangyobs.Name = "txtSangyobs";
            this.txtSangyobs.Size = new System.Drawing.Size(31, 31);
            this.txtSangyobs.TabIndex = 14;
            // 
            // lblSangyobs
            // 
            this.lblSangyobs.AutoSize = true;
            this.lblSangyobs.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblSangyobs.Location = new System.Drawing.Point(15, 47);
            this.lblSangyobs.Name = "lblSangyobs";
            this.lblSangyobs.Size = new System.Drawing.Size(154, 24);
            this.lblSangyobs.TabIndex = 13;
            this.lblSangyobs.Text = "産業分類（細区分）";
            // 
            // txtParent
            // 
            this.txtParent.Enabled = false;
            this.txtParent.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtParent.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.txtParent.Location = new System.Drawing.Point(202, 12);
            this.txtParent.MaxLength = 2;
            this.txtParent.Name = "txtParent";
            this.txtParent.Size = new System.Drawing.Size(31, 31);
            this.txtParent.TabIndex = 13;
            // 
            // lblParent
            // 
            this.lblParent.AutoSize = true;
            this.lblParent.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblParent.Location = new System.Drawing.Point(15, 15);
            this.lblParent.Name = "lblParent";
            this.lblParent.Size = new System.Drawing.Size(154, 24);
            this.lblParent.TabIndex = 12;
            this.lblParent.Text = "産業分類（中分類）";
            // 
            // chkDeleteBs
            // 
            this.chkDeleteBs.AutoSize = true;
            this.chkDeleteBs.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.chkDeleteBs.Location = new System.Drawing.Point(366, 113);
            this.chkDeleteBs.Name = "chkDeleteBs";
            this.chkDeleteBs.Size = new System.Drawing.Size(61, 28);
            this.chkDeleteBs.TabIndex = 16;
            this.chkDeleteBs.Text = "削除";
            this.chkDeleteBs.UseVisualStyleBackColor = true;
            // 
            // lblSangyobsName
            // 
            this.lblSangyobsName.AutoSize = true;
            this.lblSangyobsName.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblSangyobsName.Location = new System.Drawing.Point(15, 79);
            this.lblSangyobsName.Name = "lblSangyobsName";
            this.lblSangyobsName.Size = new System.Drawing.Size(186, 24);
            this.lblSangyobsName.TabIndex = 10;
            this.lblSangyobsName.Text = "産業分類（細区分）名称";
            // 
            // txtSangyobsName
            // 
            this.txtSangyobsName.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtSangyobsName.Location = new System.Drawing.Point(202, 76);
            this.txtSangyobsName.MaxLength = 40;
            this.txtSangyobsName.Name = "txtSangyobsName";
            this.txtSangyobsName.Size = new System.Drawing.Size(265, 31);
            this.txtSangyobsName.TabIndex = 15;
            // 
            // btnSettingBs
            // 
            this.btnSettingBs.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnSettingBs.Location = new System.Drawing.Point(261, 147);
            this.btnSettingBs.Name = "btnSettingBs";
            this.btnSettingBs.Size = new System.Drawing.Size(100, 30);
            this.btnSettingBs.TabIndex = 17;
            this.btnSettingBs.Text = "設定";
            this.btnSettingBs.UseVisualStyleBackColor = true;
            this.btnSettingBs.Click += new System.EventHandler(this.btnSettingBs_Click);
            // 
            // btnCancelBs
            // 
            this.btnCancelBs.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnCancelBs.Location = new System.Drawing.Point(367, 147);
            this.btnCancelBs.Name = "btnCancelBs";
            this.btnCancelBs.Size = new System.Drawing.Size(100, 30);
            this.btnCancelBs.TabIndex = 18;
            this.btnCancelBs.Text = "キャンセル";
            this.btnCancelBs.UseVisualStyleBackColor = true;
            this.btnCancelBs.Click += new System.EventHandler(this.btnCancelBs_Click);
            // 
            // backColorChangeOnFocusProvider1
            // 
            this.backColorChangeOnFocusProvider1.Target = this;
            // 
            // sangyobcDataGridViewTextBoxColumn
            // 
            this.sangyobcDataGridViewTextBoxColumn.DataPropertyName = "Sangyobc";
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.sangyobcDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle1;
            this.sangyobcDataGridViewTextBoxColumn.HeaderText = "中分類";
            this.sangyobcDataGridViewTextBoxColumn.Name = "sangyobcDataGridViewTextBoxColumn";
            this.sangyobcDataGridViewTextBoxColumn.ReadOnly = true;
            this.sangyobcDataGridViewTextBoxColumn.Width = 85;
            // 
            // SangyobcNameN
            // 
            this.SangyobcNameN.DataPropertyName = "SangyobcNameN";
            this.SangyobcNameN.HeaderText = "中分類名称";
            this.SangyobcNameN.Name = "SangyobcNameN";
            this.SangyobcNameN.ReadOnly = true;
            this.SangyobcNameN.Width = 346;
            // 
            // sangyobsDataGridViewTextBoxColumn
            // 
            this.sangyobsDataGridViewTextBoxColumn.DataPropertyName = "Sangyobs";
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.sangyobsDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle2;
            this.sangyobsDataGridViewTextBoxColumn.HeaderText = "細分類";
            this.sangyobsDataGridViewTextBoxColumn.Name = "sangyobsDataGridViewTextBoxColumn";
            this.sangyobsDataGridViewTextBoxColumn.ReadOnly = true;
            this.sangyobsDataGridViewTextBoxColumn.Width = 85;
            // 
            // sangyobsNameNDataGridViewTextBoxColumn
            // 
            this.sangyobsNameNDataGridViewTextBoxColumn.DataPropertyName = "SangyobsNameN";
            this.sangyobsNameNDataGridViewTextBoxColumn.HeaderText = "細区分名称";
            this.sangyobsNameNDataGridViewTextBoxColumn.Name = "sangyobsNameNDataGridViewTextBoxColumn";
            this.sangyobsNameNDataGridViewTextBoxColumn.ReadOnly = true;
            this.sangyobsNameNDataGridViewTextBoxColumn.Width = 346;
            // 
            // SangyoB
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.ClientSize = new System.Drawing.Size(997, 722);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.btnReturn);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "SangyoB";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "産業分類　保守画面";
            this.Load += new System.EventHandler(this.SangyoB_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSangyoBc)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsSangyoBc)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSangyoBs)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsSangyoBs)).EndInit();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DataGridView dgvSangyoBc;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btnSelectBc;
        private System.Windows.Forms.Button btnReturn;
        private System.Windows.Forms.Button btnAddBc;
        private System.Windows.Forms.TextBox txtSangyobcName;
        private System.Windows.Forms.Button btnSettingBc;
        private System.Windows.Forms.Button btnCancelBc;
        private System.Windows.Forms.Label lblSangyobcName;
        private System.Windows.Forms.CheckBox chkDeleteBc;
        private System.Windows.Forms.BindingSource bsSangyoBc;
        private Component.BackColorChangeOnFocusProvider backColorChangeOnFocusProvider1;
        private System.Windows.Forms.Label lblSangyoBc;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button btnAddBs;
        private System.Windows.Forms.Button btnSelectBs;
        private System.Windows.Forms.DataGridView dgvSangyoBs;
        private System.Windows.Forms.BindingSource bsSangyoBs;
        private System.Windows.Forms.TextBox txtSangyobc;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.TextBox txtParent;
        private System.Windows.Forms.Label lblParent;
        private System.Windows.Forms.CheckBox chkDeleteBs;
        private System.Windows.Forms.Label lblSangyobsName;
        private System.Windows.Forms.TextBox txtSangyobsName;
        private System.Windows.Forms.Button btnSettingBs;
        private System.Windows.Forms.Button btnCancelBs;
        private System.Windows.Forms.TextBox txtSangyobs;
        private System.Windows.Forms.Label lblSangyobs;
        private System.Windows.Forms.Label lblSangyoBcList;
        private System.Windows.Forms.Label lblSangyoBcListLine;
        private System.Windows.Forms.Label lblSangyoBsListLine;
        private System.Windows.Forms.Label lblSangyoBsList;
        private System.Windows.Forms.DataGridViewTextBoxColumn sangyobcDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn SangyobcNameN;
        private System.Windows.Forms.DataGridViewTextBoxColumn sangyobsDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sangyobsNameNDataGridViewTextBoxColumn;
    }
}