﻿using Suisitu.Common;
using Suisitu.Dao;
using Suisitu.Entity;
using System;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using System.Collections.Generic;

namespace Suisitu.Forms.SD90
{
    using CommonEvents = Suisitu.Common.Events;

    /// <summary>
    /// 産業分類保守画面クラス
    /// </summary>
    public partial class SangyoB : Form
    {
        // 産業分類（中分類）が追加モードかどうか
        private bool isInsertBc_ = false;
        // 産業分類（細区分）が追加モードかどうか
        private bool isInsertBs_ = false;

        #region コンストラクタ

        /// <summary>
        /// コンストラクタ
        /// </summary>
        public SangyoB()
        {
            InitializeComponent();

            // 左側の産業分類（中分類） 半角数字のみ入力可
            this.txtSangyobc.KeyPress += new KeyPressEventHandler(CommonEvents.txtHalfNumber_KeyPress);
            // 左側の産業分類（中分類）名称 全角のみ入力可
            this.txtSangyobcName.KeyPress += new KeyPressEventHandler(CommonEvents.txtFullAll_KeyPress);
            // 右側の産業分類（中分類） 半角数字のみ入力可
            this.txtParent.KeyPress += new KeyPressEventHandler(CommonEvents.txtHalfNumber_KeyPress);
            // 右側の産業分類（細区分） 半角数字のみ入力可
            this.txtSangyobs.KeyPress += new KeyPressEventHandler(CommonEvents.txtHalfNumber_KeyPress);
            // 右側の産業分類（細区分）名称 半角数字のみ入力可
            this.txtSangyobsName.KeyPress += new KeyPressEventHandler(CommonEvents.txtFullAll_KeyPress);
        }

        #endregion

        #region イベント

        /// <summary>
        /// 画面が表示されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void SangyoB_Load(object sender, EventArgs e)
        {
            // 産業分類（中分類）のデータを取得
            bsSangyoBc.DataSource = SangyoBcDao.SelectAll();

            ClearBc();
            ClearBs();
        }

        /// <summary>
        /// 戻るボタンが押下されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnReturn_Click(object sender, EventArgs e)
        {
            Close();
        }

        /// <summary>
        /// 左側の選択ボタンが押下されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnSelectBc_Click(object sender, EventArgs e)
        {
            SelectedBcItem();
        }

        /// <summary>
        /// 左側のデータグリッドビューのセルがダブルクリックされたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void dgvSangyoBc_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (bsSangyoBc.Current != null)
                SelectedBcItem();
        }

        /// <summary>
        /// 左側の設定ボタンが押下されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnSettingBc_Click(object sender, EventArgs e)
        {
            SangyoBcEntity entity = null;

            if (chkDeleteBc.Checked)
            {
                SangyoBcDao.Delete((SangyoBcEntity)bsSangyoBc.Current);
            }
            else
            {
                entity = new SangyoBcEntity
                {
                    Sangyobc = txtSangyobc.Text,
                    SangyobcNameN = txtSangyobcName.Text,
                    UpdDate = DateTime.Now.ToString(),
                    Rev = 1,
                };

                if (!ValidationBc(entity))
                    return;

                // 追加モードの場合はInsert、それ以外はUpdateする
                if (this.isInsertBc_)
                {
                    SangyoBcDao.Insert(entity);
                }
                else
                {
                    SangyoBcDao.Update(entity);
                }
            }

            // 一覧をリフレッシュする
            bsSangyoBc.DataSource = SangyoBcDao.SelectAll();

            // 追加モードの場合は、追加行を選択行に設定する
            if (this.isInsertBc_)
            {
                int rowIndex = 0;

                foreach (DataGridViewRow row in dgvSangyoBc.Rows)
                {
                    if (row.Cells[0].Value.ToString().Trim() == entity.Sangyobc)
                    {
                        break;
                    }
                    rowIndex++;
                }
                dgvSangyoBc.CurrentCell = dgvSangyoBc[0, rowIndex];
            }

            // コントロールを初期化する
            ClearBc();
        }

        /// <summary>
        /// 左側の追加ボタンが押下されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnAddBc_Click(object sender, EventArgs e)
        {
            // 産業分類（中分類）を追加モードに設定する
            this.isInsertBc_ = true;

            // 左側下部のパネルのみ使用可とする
            panel1.Enabled = false;
            panel2.Enabled = true;
            panel3.Enabled = false;
            panel4.Enabled = false;

            // 戻るボタンをタッチ不可にする
            btnReturn.Enabled = false;

            txtSangyobc.Enabled = true;
            chkDeleteBc.Enabled = false;

            // 産業分類（中分類）にフォーカスをセット
            txtSangyobc.Focus();
        }

        /// <summary>
        /// 左側のキャンセルボタンが押下されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnCancelBc_Click(object sender, EventArgs e)
        {
            ClearBc();
        }

        /// <summary>
        /// 左側のカレントセル変更時の処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void dgvSangyoBc_CurrentCellChanged(object sender, EventArgs e)
        {
            // 選択行を取得する
            SangyoBcEntity currentEntity = (SangyoBcEntity)bsSangyoBc.Current;

            // データがない場合は処理を抜ける（データがない場合のアボート対策）
            if (currentEntity == null)
            {
                currentEntity = new SangyoBcEntity();
            }

            // 選択行の産業分類（中分類）に該当する産業分類（細区分）を取得する
            bsSangyoBs.DataSource = SangyoBsDao.SelectByParent(currentEntity);
            // 産業分類（細区分）を取得できた場合
            if (bsSangyoBs.Count > 0)
            {
                // 産業分類（細区分）のカレントセルを先頭行とする
                dgvSangyoBs.CurrentCell = dgvSangyoBs[0, 0];
            }

            // 右側の選択ボタンの使用可/不可を設定する
            if (dgvSangyoBs.Rows.Count == 0)
            {
                btnSelectBs.Enabled = false;
            }
            else
            {
                btnSelectBs.Enabled = true;
            }
        }

        /// <summary>
        /// 右側の選択ボタンが押下されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnSelectBs_Click(object sender, EventArgs e)
        {
            SelectedBsItem();
        }

        /// <summary>
        /// 右側のデータグリッドビューのセルがダブルクリックされたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void dgvSangyoBs_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (bsSangyoBs.Current != null)
                SelectedBsItem();
        }

        /// <summary>
        /// 右側の設定ボタンが押下されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnSettingBs_Click(object sender, EventArgs e)
        {
            SangyoBsEntity entity = null;

            if (chkDeleteBs.Checked)
            {
                SangyoBsDao.Delete((SangyoBsEntity)bsSangyoBs.Current);
            }
            else
            {
                entity = new SangyoBsEntity
                {
                    Sangyobs = txtParent.Text + txtSangyobs.Text,
                    SangyobsNameN = txtSangyobsName.Text,
                    Parent = txtParent.Text,
                    UpdDate = DateTime.Now.ToString(),
                    Rev = 1,
                };

                if (!ValidationBs(entity))
                    return;

                // 追加モードの場合はInsert、それ以外はUpdateする
                if (this.isInsertBs_)
                {
                    SangyoBsDao.Insert(entity);
                }
                else
                {
                    SangyoBsDao.Update(entity);
                }
            }

            // 一覧をリフレッシュする
            bsSangyoBs.DataSource = SangyoBsDao.SelectByParent((SangyoBcEntity)bsSangyoBc.Current);

            // 追加モードの場合は、追加行を選択行に設定する
            if (this.isInsertBs_)
            {
                int rowIndex = 0;

                foreach (DataGridViewRow row in dgvSangyoBs.Rows)
                {
                    if (row.Cells[0].Value.ToString().Trim() == entity.Sangyobs)
                    {
                        break;
                    }
                    rowIndex++;
                }
                dgvSangyoBs.CurrentCell = dgvSangyoBs[0, rowIndex];
            }

            // コントロールを初期化する
            ClearBs();
        }

        /// <summary>
        /// 右側の追加ボタンが押下されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnAddBs_Click(object sender, EventArgs e)
        {
            // 左側の選択行を取得
            SangyoBcEntity currentBcEntity = (SangyoBcEntity)bsSangyoBc.Current;

            // 選択行を取得できない場合は処理を抜ける（データがない場合のアボート対策）
            if (currentBcEntity == null)
            {
                return;
            }

            // 産業分類（細区分）を追加モードに設定する
            this.isInsertBs_ = true;

            // 右側下部のパネルのみ使用可とする
            panel1.Enabled = false;
            panel2.Enabled = false;
            panel3.Enabled = false;
            panel4.Enabled = true;

            // 戻るボタンをタッチ不可にする
            btnReturn.Enabled = false;

            txtSangyobs.Enabled = true;
            chkDeleteBs.Enabled = false;

            // 産業分類（中分類）に左側で選択されているものと同じ値を設定する
            txtParent.Text = currentBcEntity.Sangyobc;

            // 産業分類（細区分）にフォーカスをセット
            txtSangyobs.Focus();
        }

        /// <summary>
        /// 右側のキャンセルボタンが押下されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnCancelBs_Click(object sender, EventArgs e)
        {
            ClearBs();
        }

        #endregion

        #region プライベートメソッド

        /// <summary>
        /// 産業分類（中分類）のバリデーションをチェックします。
        /// </summary>
        /// <returns>True:チェックOK / False:チェックNG</returns>
        private bool ValidationBc(SangyoBcEntity entity)
        {
            // 必須入力チェック
            if (string.IsNullOrEmpty(entity.Sangyobc.Trim()))
            {
                MessageUtils.NoInputDataMessage(CommonUtils.Trim(lblSangyoBc.Text), Text);
                txtSangyobc.Focus();
                return false;
            }

            // 半角数字チェック行う
            if (!ValidationUtils.ValidateTypeNumeric(txtSangyobc.Text))
            {
                MessageUtils.ZenkakuHankakuMessage(CommonUtils.Trim(lblSangyoBc.Text), 0, Text);
                txtSangyobc.Focus();
                return false;
            }

            // 全角文字チェック
            if (!ValidationUtils.ValidateZenkaku(txtSangyobcName.Text) & !string.IsNullOrEmpty(txtSangyobcName.Text))
            {
                MessageUtils.ZenkakuHankakuMessage(CommonUtils.Trim(lblSangyobcName.Text), 1, Text);
                txtSangyobcName.Focus();
                return false;
            }

            // 存在チェック
            if (this.isInsertBc_)
            {
                if (SangyoBcDao.Select(entity) != null)
                {
                    MessageUtils.Duplication(CommonUtils.Trim(lblSangyoBc.Text), Text);
                    txtSangyobc.Focus();
                    return false;
                }
            }

            return true;
        }

        /// <summary>
        /// 産業分類（細区分）のバリデーションをチェックします。
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        private bool ValidationBs(SangyoBsEntity entity)
        {
            // 必須チェック  産業分類(中分類)
            if (string.IsNullOrEmpty(txtSangyobs.Text.Trim()))
            {
                MessageUtils.NoInputDataMessage(CommonUtils.Trim(lblSangyobs.Text), Text);
                txtSangyobs.Focus();
                return false;
            }

            // 半角数字チェック行う
            if (!ValidationUtils.ValidateTypeNumeric(txtSangyobs.Text))
            {
                MessageUtils.ZenkakuHankakuMessage(CommonUtils.Trim(lblSangyobs.Text), 0, Text);
                txtSangyobs.Focus();
                return false;
            }

            // 必須チェック  産業分類(細区分名称)
            if (string.IsNullOrEmpty(entity.SangyobsNameN.Trim()))
            {
                MessageUtils.NoInputDataMessage(CommonUtils.Trim(lblSangyobsName.Text), Text);
                txtSangyobsName.Focus();
                return false;
            }

            // 全角文字チェック
            if (!ValidationUtils.ValidateZenkaku(txtSangyobsName.Text))
            {
                MessageUtils.ZenkakuHankakuMessage(CommonUtils.Trim(lblSangyobsName.Text), 1, Text);
                txtSangyobsName.Focus();
                return false;
            }

            // 存在チェック
            if (this.isInsertBs_)
            {
                if (SangyoBsDao.SelectBySangyoBs(entity) != null)
                {
                    MessageUtils.Duplication(CommonUtils.Trim(lblSangyobs.Text), Text);
                    txtSangyobs.Focus();
                    return false;
                }
            }

            return true;
        }

        /// <summary>
        /// 産業分類（中分類）のクリア処理
        /// </summary>
        private void ClearBc()
        {
            // コントロールを初期値に戻す
            txtSangyobc.Text = "";
            txtSangyobcName.Text = "";
            chkDeleteBc.Checked = false;
            
            // 左側の選択ボタンの使用可/不可を設定する
            if (dgvSangyoBc.Rows.Count == 0)
            {
                btnSelectBc.Enabled = false;
            }
            else
            {
                btnSelectBc.Enabled = true;
            }

            // 右側の選択ボタンの使用可/不可を設定する
            if (dgvSangyoBs.Rows.Count == 0)
            {
                btnSelectBs.Enabled = false;
            }
            else
            {
                btnSelectBs.Enabled = true;
            }

            // 一覧部分を操作可、編集部分を操作不可に設定する
            panel1.Enabled = true;
            panel2.Enabled = false;
            panel3.Enabled = true;
            panel4.Enabled = false;

            // 戻るボタンをタッチ可能にする
            btnReturn.Enabled = true;

            this.isInsertBc_ = false;
        }

        /// <summary>
        /// 産業分類（中分類）の一覧からアイテムが選択されたときの処理
        /// </summary>
        private void SelectedBcItem()
        {
            // 選択行を取得する
            SangyoBcEntity currentEntity = (SangyoBcEntity)bsSangyoBc.Current;

            // 選択行を取得できない場合は処理を抜ける（データがない場合のアボート対策）
            if (currentEntity == null)
            {
                return;
            }

            // 左側下部のパネルのみ使用可とする
            panel1.Enabled = false;
            panel2.Enabled = true;
            panel3.Enabled = false;
            panel4.Enabled = false;

            // 戻るボタンをタッチ不可にする
            btnReturn.Enabled = false;

            // 左側の削除チェックボックス：使用可
            chkDeleteBc.Enabled = true;
            // 左側の産業分類（中分類）：使用不可
            txtSangyobc.Enabled = false;

            // 産業分類（中分類）
            txtSangyobc.Text = currentEntity.Sangyobc;
            // 産業分類（中分類）名称
            txtSangyobcName.Text = currentEntity.SangyobcNameN;

            // 産業分類（中分類）にフォーカスをセット
            txtSangyobcName.Focus();
        }

        /// <summary>
        /// 産業分類（細区分）のクリア処理
        /// </summary>
        private void ClearBs()
        {
            // コントロールを初期値に戻す
            txtParent.Text = "";
            txtSangyobs.Text = "";
            txtSangyobsName.Text = "";
            chkDeleteBs.Checked = false;

            // 左側の選択ボタンの使用可/不可を設定する
            if (dgvSangyoBc.Rows.Count == 0)
            {
                btnSelectBc.Enabled = false;
            }
            else
            {
                btnSelectBc.Enabled = true;
            }

            // 右側の選択ボタンの使用可/不可を設定する
            if (dgvSangyoBs.Rows.Count == 0)
            {
                btnSelectBs.Enabled = false;
            }
            else
            {
                btnSelectBs.Enabled = true;
            }
            
            // 一覧部分を操作可、編集部分を操作不可に設定する
            panel1.Enabled = true;
            panel2.Enabled = false;
            panel3.Enabled = true;
            panel4.Enabled = false;

            // 戻るボタンをタッチ可能にする
            btnReturn.Enabled = true;

            this.isInsertBs_ = false;
        }

        /// <summary>
        /// 産業分類（細区分）の一覧からアイテムが選択されたときの処理
        /// </summary>
        private void SelectedBsItem()
        {
            // 選択行を取得する
            SangyoBsEntity currentEntity = (SangyoBsEntity)bsSangyoBs.Current;

            // 選択行を取得できない場合は処理を抜ける（データがない場合のアボート対策）
            if (currentEntity == null)
            {
                return;
            }

            // 右側下部のパネルのみ使用可とする
            panel1.Enabled = false;
            panel2.Enabled = false;
            panel3.Enabled = false;
            panel4.Enabled = true;

            // 戻るボタンをタッチ不可にする
            btnReturn.Enabled = false;

            // 右側の削除チェックボックス：使用可
            chkDeleteBs.Enabled = true;
            // 右側の産業分類（細区分）名称：使用不可
            txtSangyobs.Enabled = false;

            // 産業分類（中分類）
            txtParent.Text = currentEntity.Parent;
            // 産業分類（細区分）
            // 産業分類（細分類）表の産業分類（細分類）の下2桁を取得
            txtSangyobs.Text = currentEntity.Sangyobs.Substring(currentEntity.Sangyobs.Length - 2, 2);
            // 産業分類（細区分）名称
            txtSangyobsName.Text = currentEntity.SangyobsNameN;

            // 産業分類（細区分）名称にフォーカスをセット
            txtSangyobsName.Focus();
        }

        #endregion
    }
}
