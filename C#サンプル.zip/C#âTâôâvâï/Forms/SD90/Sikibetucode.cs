﻿using Suisitu.Common;
using Suisitu.Dao;
using Suisitu.Entity;
using System;
using System.Windows.Forms;

namespace Suisitu.Forms.SD90
{
    using CommonEvents = Suisitu.Common.Events;

    /// <summary>
    /// 識別コード保守画面クラス
    /// </summary>
    public partial class Sikibetucode : Form
    {
        private bool isInsert_ = false;

        #region コンストラクタ

        /// <summary>
        /// コンストラクタ
        /// </summary>
        public Sikibetucode()
        {
            InitializeComponent();

            this.txtSikibetuCode.KeyPress += new KeyPressEventHandler(CommonEvents.txtHalfNumber_KeyPress);
            this.txtSikibetuName.KeyPress += new KeyPressEventHandler(CommonEvents.txtFullAll_KeyPress);
        }

        #endregion

        #region イベント

        /// <summary>
        /// 画面が表示されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void Sikibetucode_Load(object sender, EventArgs e)
        {
            bsSikibetucode.DataSource = SikibetuCodeDao.SelectAll();

            Clear();
        }

        /// <summary>
        /// 選択ボタンが押下されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnSelect_Click(object sender, EventArgs e)
        {
            SelectedItem();
        }

        /// <summary>
        /// データグリッドビューのセルがダブルクリックされたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void dgvSikibetucode_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (bsSikibetucode.Current != null)
                SelectedItem();
        }

        /// <summary>
        /// 設定ボタンが押下されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnSetting_Click(object sender, EventArgs e)
        {
            SikibetuCodeEntity entity = null;

            if (chkDelete.Checked)
            {
                SikibetuCodeDao.Delete((SikibetuCodeEntity)bsSikibetucode.Current);
            }
            else
            {
                entity = new SikibetuCodeEntity
                {
                    SikibetuCode = txtSikibetuCode.Text,
                    SikibetuNameN = txtSikibetuName.Text,
                    UpdDate = DateTime.Now.ToString(),
                    Rev = 1,
                };

                if (!Validation(entity))
                    return;

                // 追加モードの場合はInsert、それ以外はUpdateする
                if (this.isInsert_)
                {
                    SikibetuCodeDao.Insert(entity);
                }
                else
                {
                    SikibetuCodeDao.Update(entity);
                }
            }

            // 一覧をリフレッシュする
            bsSikibetucode.DataSource = SikibetuCodeDao.SelectAll();

            // 追加モードの場合は、追加行を選択行に設定する
            if (this.isInsert_)
            {
                int rowIndex = 0;

                foreach (DataGridViewRow row in dgvSikibetucode.Rows)
                {
                    if (row.Cells[0].Value.ToString() == entity.SikibetuCode)
                    {
                        break;
                    }
                    rowIndex++;
                }
                dgvSikibetucode.CurrentCell = dgvSikibetucode[0, rowIndex];
            }

            // コントロールを初期化する
            Clear();
        }

        /// <summary>
        /// 追加ボタンが押下されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnAdd_Click(object sender, EventArgs e)
        {
            // 追加モードに設定する
            this.isInsert_ = true;

            panel1.Enabled = false;
            panel2.Enabled = true;
            chkDelete.Enabled = false;
            txtSikibetuCode.Enabled = true;

            // 識別コードにフォーカスをセット
            txtSikibetuCode.Focus();
        }

        /// <summary>
        /// キャンセルボタンが押下されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnCancel_Click(object sender, EventArgs e)
        {
            Clear();
        }

        /// <summary>
        /// 戻るボタンが押下されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnReturn_Click(object sender, EventArgs e)
        {
            Close();
        }

        #endregion

        #region プライベートメソッド

        /// <summary>
        /// バリデーションをチェックします。
        /// </summary>
        /// <returns>True:チェックOK / False:チェックNG</returns>
        private bool Validation(SikibetuCodeEntity entity)
        {
            // 識別コード必須入力チェック
            if (string.IsNullOrEmpty(entity.SikibetuCode))
            {
                MessageUtils.NoInputDataMessage(CommonUtils.Trim(lblSikibetucode.Text), Text);
                txtSikibetuCode.Focus();
                return false;
            }

            // 半角数字チェック行う
            if (!ValidationUtils.ValidateTypeNumeric(txtSikibetuCode.Text))
            {
                MessageUtils.ZenkakuHankakuMessage(CommonUtils.Trim(lblSikibetucode.Text), 0, Text);
                txtSikibetuCode.Focus();
                return false;
            }

            // 識別コード桁数チェック
            if (entity.SikibetuCode.Length < txtSikibetuCode.MaxLength)
            {
                MessageUtils.MismatchInputDigitsMessage(CommonUtils.Trim(lblSikibetucode.Text), txtSikibetuCode.MaxLength, Text);
                txtSikibetuCode.Focus();
                return false;
            }

            // 全角文字チェック　識別名称
            if (!ValidationUtils.ValidateZenkaku(txtSikibetuName.Text) & !string.IsNullOrEmpty(txtSikibetuName.Text))
            {
                MessageUtils.ZenkakuHankakuMessage(CommonUtils.Trim(lblSikibetuName.Text), 1, Text);
                txtSikibetuName.Focus();
                return false;
            }

            // 存在チェック
            if (this.isInsert_)
            {
                if (SikibetuCodeDao.Select(entity) != null)
                {
                    MessageUtils.Duplication(CommonUtils.Trim(lblSikibetucode.Text), Text);
                    txtSikibetuCode.Focus();
                    return false;
                }
            }

            return true;
        }

        /// <summary>
        /// 画面のクリア処理
        /// </summary>
        private void Clear()
        {
            // コントロールを初期値に戻す
            txtSikibetuCode.Text = "";
            txtSikibetuName.Text = "";
            chkDelete.Checked = false;

            // 選択ボタンの使用可/不可を設定する
            if (dgvSikibetucode.Rows.Count == 0)
            {
                btnSelect.Enabled = false;
            }
            else
            {
                btnSelect.Enabled = true;
            }

            // 一覧部分を操作可、編集部分を操作不可に設定する
            panel1.Enabled = true;
            panel2.Enabled = false;
            
            this.isInsert_ = false;
        }

        /// <summary>
        /// 一覧からアイテムが選択されたときの処理
        /// </summary>
        private void SelectedItem()
        {
            panel1.Enabled = false;
            panel2.Enabled = true;
            chkDelete.Enabled = true;
            txtSikibetuCode.Enabled = false;

            // 選択行を取得する
            SikibetuCodeEntity currentEntity = (SikibetuCodeEntity)bsSikibetucode.Current;

            // 識別コード
            txtSikibetuCode.Text = currentEntity.SikibetuCode;
            // 識別名称
            txtSikibetuName.Text = currentEntity.SikibetuNameN;

            // 識別名称にフォーカスをセット
            txtSikibetuName.Focus();
        }

        #endregion
    }
}
