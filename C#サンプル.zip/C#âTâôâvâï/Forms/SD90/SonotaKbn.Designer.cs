﻿namespace Suisitu.Forms.SD90
{
    partial class SonotaKbn
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnReturn = new System.Windows.Forms.Button();
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnSelect = new System.Windows.Forms.Button();
            this.dgvSonotaKbn = new System.Windows.Forms.DataGridView();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lblWrtSeqNo = new System.Windows.Forms.Label();
            this.txtWrtSeqNo = new System.Windows.Forms.TextBox();
            this.chkDelete = new System.Windows.Forms.CheckBox();
            this.lblKubunNameN = new System.Windows.Forms.Label();
            this.lblKubun = new System.Windows.Forms.Label();
            this.txtKubunNameN = new System.Windows.Forms.TextBox();
            this.txtKubun = new System.Windows.Forms.TextBox();
            this.btnSetting = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.backColorChangeOnFocusProvider1 = new Suisitu.Component.BackColorChangeOnFocusProvider();
            this.kubunDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.kubunNameNDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.wrtSeqNoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bsSonotaKbn = new System.Windows.Forms.BindingSource(this.components);
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSonotaKbn)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bsSonotaKbn)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.btnReturn);
            this.panel1.Controls.Add(this.btnAdd);
            this.panel1.Controls.Add(this.btnSelect);
            this.panel1.Controls.Add(this.dgvSonotaKbn);
            this.panel1.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel1.Location = new System.Drawing.Point(15, 15);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(483, 435);
            this.panel1.TabIndex = 1;
            // 
            // btnReturn
            // 
            this.btnReturn.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReturn.Location = new System.Drawing.Point(366, 391);
            this.btnReturn.Name = "btnReturn";
            this.btnReturn.Size = new System.Drawing.Size(100, 30);
            this.btnReturn.TabIndex = 3;
            this.btnReturn.Text = "戻る";
            this.btnReturn.UseVisualStyleBackColor = true;
            this.btnReturn.Click += new System.EventHandler(this.btnReturn_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdd.Location = new System.Drawing.Point(260, 391);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(100, 30);
            this.btnAdd.TabIndex = 2;
            this.btnAdd.Text = "追加";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // btnSelect
            // 
            this.btnSelect.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSelect.Location = new System.Drawing.Point(154, 391);
            this.btnSelect.Name = "btnSelect";
            this.btnSelect.Size = new System.Drawing.Size(100, 30);
            this.btnSelect.TabIndex = 1;
            this.btnSelect.Text = "選択";
            this.btnSelect.UseVisualStyleBackColor = true;
            this.btnSelect.Click += new System.EventHandler(this.btnSelect_Click);
            // 
            // dgvSonotaKbn
            // 
            this.dgvSonotaKbn.AllowUserToAddRows = false;
            this.dgvSonotaKbn.AllowUserToResizeColumns = false;
            this.dgvSonotaKbn.AllowUserToResizeRows = false;
            this.dgvSonotaKbn.AutoGenerateColumns = false;
            this.dgvSonotaKbn.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvSonotaKbn.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.kubunDataGridViewTextBoxColumn,
            this.kubunNameNDataGridViewTextBoxColumn,
            this.wrtSeqNoDataGridViewTextBoxColumn});
            this.dgvSonotaKbn.DataSource = this.bsSonotaKbn;
            this.dgvSonotaKbn.Location = new System.Drawing.Point(15, 15);
            this.dgvSonotaKbn.Name = "dgvSonotaKbn";
            this.dgvSonotaKbn.ReadOnly = true;
            this.dgvSonotaKbn.RowHeadersVisible = false;
            this.dgvSonotaKbn.RowHeadersWidth = 40;
            this.dgvSonotaKbn.RowTemplate.Height = 21;
            this.dgvSonotaKbn.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvSonotaKbn.Size = new System.Drawing.Size(450, 370);
            this.dgvSonotaKbn.TabIndex = 0;
            this.dgvSonotaKbn.CellMouseDoubleClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgvSonotaKbn_CellMouseDoubleClick);
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.lblWrtSeqNo);
            this.panel2.Controls.Add(this.txtWrtSeqNo);
            this.panel2.Controls.Add(this.chkDelete);
            this.panel2.Controls.Add(this.lblKubunNameN);
            this.panel2.Controls.Add(this.lblKubun);
            this.panel2.Controls.Add(this.txtKubunNameN);
            this.panel2.Controls.Add(this.txtKubun);
            this.panel2.Controls.Add(this.btnSetting);
            this.panel2.Controls.Add(this.btnCancel);
            this.panel2.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.panel2.Location = new System.Drawing.Point(15, 456);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(483, 204);
            this.panel2.TabIndex = 2;
            // 
            // lblWrtSeqNo
            // 
            this.lblWrtSeqNo.AutoSize = true;
            this.lblWrtSeqNo.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblWrtSeqNo.Location = new System.Drawing.Point(15, 79);
            this.lblWrtSeqNo.Name = "lblWrtSeqNo";
            this.lblWrtSeqNo.Size = new System.Drawing.Size(74, 24);
            this.lblWrtSeqNo.TabIndex = 15;
            this.lblWrtSeqNo.Text = "出力順番";
            // 
            // txtWrtSeqNo
            // 
            this.txtWrtSeqNo.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtWrtSeqNo.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.txtWrtSeqNo.Location = new System.Drawing.Point(127, 76);
            this.txtWrtSeqNo.MaxLength = 3;
            this.txtWrtSeqNo.Name = "txtWrtSeqNo";
            this.txtWrtSeqNo.Size = new System.Drawing.Size(50, 31);
            this.txtWrtSeqNo.TabIndex = 7;
            this.txtWrtSeqNo.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // chkDelete
            // 
            this.chkDelete.AutoSize = true;
            this.chkDelete.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.chkDelete.Location = new System.Drawing.Point(367, 122);
            this.chkDelete.Name = "chkDelete";
            this.chkDelete.Size = new System.Drawing.Size(61, 28);
            this.chkDelete.TabIndex = 8;
            this.chkDelete.Text = "削除";
            this.chkDelete.UseVisualStyleBackColor = true;
            // 
            // lblKubunNameN
            // 
            this.lblKubunNameN.AutoSize = true;
            this.lblKubunNameN.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblKubunNameN.Location = new System.Drawing.Point(15, 47);
            this.lblKubunNameN.Name = "lblKubunNameN";
            this.lblKubunNameN.Size = new System.Drawing.Size(58, 24);
            this.lblKubunNameN.TabIndex = 11;
            this.lblKubunNameN.Text = "区分名";
            // 
            // lblKubun
            // 
            this.lblKubun.AutoSize = true;
            this.lblKubun.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblKubun.Location = new System.Drawing.Point(15, 15);
            this.lblKubun.Name = "lblKubun";
            this.lblKubun.Size = new System.Drawing.Size(42, 24);
            this.lblKubun.TabIndex = 10;
            this.lblKubun.Text = "区分";
            // 
            // txtKubunNameN
            // 
            this.txtKubunNameN.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtKubunNameN.ImeMode = System.Windows.Forms.ImeMode.Hiragana;
            this.txtKubunNameN.Location = new System.Drawing.Point(127, 44);
            this.txtKubunNameN.MaxLength = 50;
            this.txtKubunNameN.Name = "txtKubunNameN";
            this.txtKubunNameN.Size = new System.Drawing.Size(341, 31);
            this.txtKubunNameN.TabIndex = 5;
            // 
            // txtKubun
            // 
            this.txtKubun.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtKubun.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.txtKubun.Location = new System.Drawing.Point(127, 12);
            this.txtKubun.MaxLength = 8;
            this.txtKubun.Name = "txtKubun";
            this.txtKubun.Size = new System.Drawing.Size(50, 31);
            this.txtKubun.TabIndex = 4;
            this.txtKubun.Text = "123";
            // 
            // btnSetting
            // 
            this.btnSetting.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnSetting.Location = new System.Drawing.Point(260, 156);
            this.btnSetting.Name = "btnSetting";
            this.btnSetting.Size = new System.Drawing.Size(100, 30);
            this.btnSetting.TabIndex = 9;
            this.btnSetting.Text = "設定";
            this.btnSetting.UseVisualStyleBackColor = true;
            this.btnSetting.Click += new System.EventHandler(this.btnSetting_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnCancel.Location = new System.Drawing.Point(366, 156);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(100, 30);
            this.btnCancel.TabIndex = 10;
            this.btnCancel.Text = "キャンセル";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // backColorChangeOnFocusProvider1
            // 
            this.backColorChangeOnFocusProvider1.Target = this;
            // 
            // kubunDataGridViewTextBoxColumn
            // 
            this.kubunDataGridViewTextBoxColumn.DataPropertyName = "Kubun";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.kubunDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle3;
            this.kubunDataGridViewTextBoxColumn.HeaderText = "区分";
            this.kubunDataGridViewTextBoxColumn.Name = "kubunDataGridViewTextBoxColumn";
            this.kubunDataGridViewTextBoxColumn.ReadOnly = true;
            this.kubunDataGridViewTextBoxColumn.Width = 80;
            // 
            // kubunNameNDataGridViewTextBoxColumn
            // 
            this.kubunNameNDataGridViewTextBoxColumn.DataPropertyName = "KubunNameN";
            this.kubunNameNDataGridViewTextBoxColumn.HeaderText = "区分名";
            this.kubunNameNDataGridViewTextBoxColumn.Name = "kubunNameNDataGridViewTextBoxColumn";
            this.kubunNameNDataGridViewTextBoxColumn.ReadOnly = true;
            this.kubunNameNDataGridViewTextBoxColumn.Width = 249;
            // 
            // wrtSeqNoDataGridViewTextBoxColumn
            // 
            this.wrtSeqNoDataGridViewTextBoxColumn.DataPropertyName = "WrtSeqNo";
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.wrtSeqNoDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle4;
            this.wrtSeqNoDataGridViewTextBoxColumn.HeaderText = "出力順番";
            this.wrtSeqNoDataGridViewTextBoxColumn.Name = "wrtSeqNoDataGridViewTextBoxColumn";
            this.wrtSeqNoDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // bsSonotaKbn
            // 
            this.bsSonotaKbn.DataSource = typeof(Suisitu.Entity.SonotaKbnEntity);
            // 
            // SonotaKbn
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.ClientSize = new System.Drawing.Size(510, 672);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "SonotaKbn";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "XXXXコード　保守画面";
            this.Load += new System.EventHandler(this.SonotaCode_Load);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvSonotaKbn)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bsSonotaKbn)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnReturn;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnSelect;
        private System.Windows.Forms.DataGridView dgvSonotaKbn;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.CheckBox chkDelete;
        private System.Windows.Forms.Label lblKubunNameN;
        private System.Windows.Forms.Label lblKubun;
        private System.Windows.Forms.TextBox txtKubunNameN;
        private System.Windows.Forms.TextBox txtKubun;
        private System.Windows.Forms.Button btnSetting;
        private System.Windows.Forms.Button btnCancel;
        private Component.BackColorChangeOnFocusProvider backColorChangeOnFocusProvider1;
        private System.Windows.Forms.BindingSource bsSonotaKbn;
        private System.Windows.Forms.Label lblWrtSeqNo;
        private System.Windows.Forms.TextBox txtWrtSeqNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn kubunDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn kubunNameNDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn wrtSeqNoDataGridViewTextBoxColumn;
    }
}