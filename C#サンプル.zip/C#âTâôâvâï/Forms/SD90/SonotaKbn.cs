﻿using Suisitu.Common;
using Suisitu.Dao;
using Suisitu.Entity;
using System;
using System.Windows.Forms;

namespace Suisitu.Forms.SD90
{
    using CommonEvents = Suisitu.Common.Events;

    /// <summary>
    /// その他区分保守画面クラス
    /// </summary>
    public partial class SonotaKbn : Form
    {
        private bool isInsert_ = false;

        // 画面モード
        private int mode_ = 0;

        #region コンストラクタ

        /// <summary>
        /// コンストラクタ
        /// </summary>
        public SonotaKbn(int mode)
        {
            InitializeComponent();

            mode_ = mode;

            // タイトルの表示
            this.Text = GetSonotaCode(mode_) + "  保守画面";

            // 区分の入力桁数設定
            int kubunLen = GetKubunLen(mode_);
            txtKubun.Width = (kubunLen) * 10 + 20;
            txtKubun.MaxLength = kubunLen;

            // 区分 半角数字のみ入力可
            this.txtKubun.KeyPress += new KeyPressEventHandler(CommonEvents.txtHalfNumber_KeyPress);
            // 区分名 全角のみ入力可
            this.txtKubunNameN.KeyPress += new KeyPressEventHandler(CommonEvents.txtFullAll_KeyPress);
            // 出力順番 半角数字のみ入力可
            this.txtWrtSeqNo.KeyPress += new KeyPressEventHandler(CommonEvents.txtHalfNumber_KeyPress);
        }

        #endregion

        #region イベント

        /// <summary>
        /// 画面が表示されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void SonotaCode_Load(object sender, EventArgs e)
        {
            SonotaKbnEntity entity = null;
            entity = new SonotaKbnEntity
            {
                Id = GetSonotaID(mode_)
            };

            bsSonotaKbn.DataSource = SonotaKbnDao.SelectAll(entity);

            Clear();
        }

        /// <summary>
        /// 選択ボタンが押下されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnSelect_Click(object sender, EventArgs e)
        {
            SelectedItem();
        }

        /// <summary>
        /// データグリッドビューのセルがダブルクリックされたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void dgvSonotaKbn_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (bsSonotaKbn.Current != null)
                SelectedItem();
        }

        /// <summary>
        /// 設定ボタンが押下されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnSetting_Click(object sender, EventArgs e)
        {
            SonotaKbnEntity entity = null;
            string wrtSeqNo = null;

            if (chkDelete.Checked)
            {
                SonotaKbnDao.Delete((SonotaKbnEntity)bsSonotaKbn.Current);

                entity = new SonotaKbnEntity
                {
                    Id = GetSonotaID(mode_)
                };
            }
            else
            {
                // 出力順番をセット（空の場合はNull）
                if (!string.IsNullOrEmpty(CommonUtils.Trim(txtWrtSeqNo.Text)))
                {
                    wrtSeqNo = txtWrtSeqNo.Text;
                }

                entity = new SonotaKbnEntity
                {
                    Id = GetSonotaID(mode_),
                    Kubun = txtKubun.Text,
                    KubunNameN = txtKubunNameN.Text,
                    Parent = "0",
                    WrtSeqNo = wrtSeqNo,
                    UpdDate = DateTime.Now.ToString(),
                    Rev = 1,
                };

                if (!Validation(entity))
                    return;

                // 追加モードの場合はInsert、それ以外はUpdateする
                if (this.isInsert_)
                {
                    SonotaKbnDao.Insert(entity);
                }
                else
                {
                    SonotaKbnDao.Update(entity);
                }
            }

            // 一覧をリフレッシュする
            bsSonotaKbn.DataSource = SonotaKbnDao.SelectAll(entity);

            // 追加モードの場合は、追加行を選択行に設定する
            if (this.isInsert_)
            {
                int rowIndex = 0;

                foreach (DataGridViewRow row in dgvSonotaKbn.Rows)
                {
                    if (row.Cells[0].Value.ToString() == entity.Kubun)
                    {
                        break;
                    }
                    rowIndex++;
                }
                dgvSonotaKbn.CurrentCell = dgvSonotaKbn[0, rowIndex];
            }

            // コントロールを初期化する
            Clear();
        }

        /// <summary>
        /// 追加ボタンが押下されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnAdd_Click(object sender, EventArgs e)
        {
            // 追加モードに設定する
            this.isInsert_ = true;

            panel1.Enabled = false;
            panel2.Enabled = true;
            chkDelete.Enabled = false;
            txtKubun.Enabled = true;

            // 区分にフォーカスをセット
            txtKubun.Focus();
        }

        /// <summary>
        /// キャンセルボタンが押下されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnCancel_Click(object sender, EventArgs e)
        {
            Clear();
        }

        /// <summary>
        /// 戻るボタンが押下されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnReturn_Click(object sender, EventArgs e)
        {
            Close();
        }

        #endregion

        #region プライベートメソッド

        /// <summary>
        /// バリデーションをチェックします。
        /// </summary>
        /// <returns>True:チェックOK / False:チェックNG</returns>
        private bool Validation(SonotaKbnEntity entity)
        {
            // 区分必須入力チェック
            if (string.IsNullOrEmpty(entity.Kubun))
            {
                MessageUtils.NoInputDataMessage(CommonUtils.Trim(lblKubun.Text), Text);
                txtKubun.Focus();
                return false;
            }

            // 半角数字チェック行う
            if (!ValidationUtils.ValidateTypeNumeric(txtKubun.Text))
            {
                MessageUtils.ZenkakuHankakuMessage(CommonUtils.Trim(lblKubun.Text), 0, Text);
                txtKubun.Focus();
                return false;
            }

            // 区分桁数チェック
            if (entity.Kubun.Length < txtKubun.MaxLength)
            {
                MessageUtils.MismatchInputDigitsMessage(CommonUtils.Trim(lblKubun.Text), txtKubun.MaxLength, Text);
                txtKubun.Focus();
                return false;
            }

            // 全角文字チェック　区分名
            if (!ValidationUtils.ValidateZenkaku(txtKubunNameN.Text) & !string.IsNullOrEmpty(txtKubunNameN.Text))
            {
                MessageUtils.ZenkakuHankakuMessage(CommonUtils.Trim(lblKubunNameN.Text), 1, Text);
                txtKubunNameN.Focus();
                return false;
            }

            // 半角数字チェック行う 出力順番
            if (!ValidationUtils.ValidateTypeNumeric(txtWrtSeqNo.Text) & !string.IsNullOrEmpty(txtWrtSeqNo.Text))
            {
                MessageUtils.ZenkakuHankakuMessage(CommonUtils.Trim(lblWrtSeqNo.Text), 0, Text);
                txtWrtSeqNo.Focus();
                return false;
            }

            // 存在チェック
            if (this.isInsert_)
            {
                if (SonotaKbnDao.Select(entity) != null)
                {
                    MessageUtils.Duplication(CommonUtils.Trim(lblKubun.Text), Text);
                    txtKubun.Focus();
                    return false;
                }
            }

            return true;
        }

        /// <summary>
        /// 画面のクリア処理
        /// </summary>
        private void Clear()
        {
            // コントロールを初期値に戻す
            txtKubun.Text = "";
            txtKubunNameN.Text = "";
            txtWrtSeqNo.Text = "";
            chkDelete.Checked = false;
            
            // 選択ボタンの使用可/不可を設定する
            if (dgvSonotaKbn.Rows.Count == 0)
            {
                btnSelect.Enabled = false;
            }
            else
            {
                btnSelect.Enabled = true;
            }

            // 一覧部分を操作可、編集部分を操作不可に設定する
            panel1.Enabled = true;
            panel2.Enabled = false;
            
            this.isInsert_ = false;
        }

        /// <summary>
        /// 一覧からアイテムが選択されたときの処理
        /// </summary>
        private void SelectedItem()
        {
            panel1.Enabled = false;
            panel2.Enabled = true;
            chkDelete.Enabled = true;
            txtKubun.Enabled = false;

            // 選択行を取得する
            SonotaKbnEntity currentEntity = (SonotaKbnEntity)bsSonotaKbn.Current;

            // 区分
            txtKubun.Text = currentEntity.Kubun;
            // 区分名
            txtKubunNameN.Text = currentEntity.KubunNameN;
            // 出力順番
            txtWrtSeqNo.Text = currentEntity.WrtSeqNo;

            // 区分名にフォーカスをセット
            txtKubunNameN.Focus();
        }

        // タイトルの取得
        private string GetSonotaCode(int mode)
        {
            string[] values = { "分析機関コード", "色相コード", "臭気コード", "天候コード" };
            return values[mode];
        }

        // IDの取得
        private string GetSonotaID(int mode)
        {
            string[] values = { "BKIKAN", "SIKISO", "SYUKI", "TENKO" };
            return values[mode];
        }

        // 区分の入力桁数の取得
        private int GetKubunLen(int mode)
        {
            int[] values = { 2, 3, 3, 2 };
            return values[mode];
        }
        #endregion
    }
}
