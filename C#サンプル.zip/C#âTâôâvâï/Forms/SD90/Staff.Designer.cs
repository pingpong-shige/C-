﻿using System;

namespace Suisitu.Forms.SD90
{
    partial class Staff
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel1 = new System.Windows.Forms.Panel();
            this.dgvStaff = new System.Windows.Forms.DataGridView();
            this.bsStaff = new System.Windows.Forms.BindingSource(this.components);
            this.btnReturn = new System.Windows.Forms.Button();
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnSelect = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.chkKanrisya = new System.Windows.Forms.CheckBox();
            this.lblKanrisya = new System.Windows.Forms.Label();
            this.txtRevPass = new System.Windows.Forms.TextBox();
            this.lblRevPass = new System.Windows.Forms.Label();
            this.txtPassWord = new System.Windows.Forms.TextBox();
            this.lblPassWord = new System.Windows.Forms.Label();
            this.chkDelete = new System.Windows.Forms.CheckBox();
            this.lblStaffName = new System.Windows.Forms.Label();
            this.lblStaffID = new System.Windows.Forms.Label();
            this.txtStaffName = new System.Windows.Forms.TextBox();
            this.txtStaffID = new System.Windows.Forms.TextBox();
            this.btnSetting = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.backColorChangeOnFocusProvider1 = new Suisitu.Component.BackColorChangeOnFocusProvider();
            this.staffIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.staffNameNDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.kanrisyaFlagDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvStaff)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsStaff)).BeginInit();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.dgvStaff);
            this.panel1.Controls.Add(this.btnReturn);
            this.panel1.Controls.Add(this.btnAdd);
            this.panel1.Controls.Add(this.btnSelect);
            this.panel1.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel1.Location = new System.Drawing.Point(15, 15);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(607, 414);
            this.panel1.TabIndex = 1;
            // 
            // dgvStaff
            // 
            this.dgvStaff.AllowUserToAddRows = false;
            this.dgvStaff.AllowUserToResizeColumns = false;
            this.dgvStaff.AllowUserToResizeRows = false;
            this.dgvStaff.AutoGenerateColumns = false;
            this.dgvStaff.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvStaff.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.staffIDDataGridViewTextBoxColumn,
            this.staffNameNDataGridViewTextBoxColumn,
            this.kanrisyaFlagDataGridViewTextBoxColumn});
            this.dgvStaff.DataSource = this.bsStaff;
            this.dgvStaff.Location = new System.Drawing.Point(15, 15);
            this.dgvStaff.Name = "dgvStaff";
            this.dgvStaff.ReadOnly = true;
            this.dgvStaff.RowHeadersVisible = false;
            this.dgvStaff.RowHeadersWidth = 40;
            this.dgvStaff.RowTemplate.Height = 21;
            this.dgvStaff.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvStaff.Size = new System.Drawing.Size(573, 349);
            this.dgvStaff.TabIndex = 0;
            this.dgvStaff.CellMouseDoubleClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgvStaff_CellMouseDoubleClick);
            this.dgvStaff.RowsAdded += new System.Windows.Forms.DataGridViewRowsAddedEventHandler(this.dgvStaff_RowsAdded);
            this.dgvStaff.RowsRemoved += new System.Windows.Forms.DataGridViewRowsRemovedEventHandler(this.dgvStaff_RowsRemoved);
            // 
            // bsStaff
            // 
            this.bsStaff.DataSource = typeof(Suisitu.Entity.StaffEntity);
            // 
            // btnReturn
            // 
            this.btnReturn.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReturn.Location = new System.Drawing.Point(488, 370);
            this.btnReturn.Name = "btnReturn";
            this.btnReturn.Size = new System.Drawing.Size(100, 30);
            this.btnReturn.TabIndex = 3;
            this.btnReturn.Text = "戻る";
            this.btnReturn.UseVisualStyleBackColor = true;
            this.btnReturn.Click += new System.EventHandler(this.btnReturn_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdd.Location = new System.Drawing.Point(382, 370);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(100, 30);
            this.btnAdd.TabIndex = 2;
            this.btnAdd.Text = "追加";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // btnSelect
            // 
            this.btnSelect.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSelect.Location = new System.Drawing.Point(276, 370);
            this.btnSelect.Name = "btnSelect";
            this.btnSelect.Size = new System.Drawing.Size(100, 30);
            this.btnSelect.TabIndex = 1;
            this.btnSelect.Text = "選択";
            this.btnSelect.UseVisualStyleBackColor = true;
            this.btnSelect.Click += new System.EventHandler(this.btnSelect_Click);
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.chkKanrisya);
            this.panel2.Controls.Add(this.lblKanrisya);
            this.panel2.Controls.Add(this.txtRevPass);
            this.panel2.Controls.Add(this.lblRevPass);
            this.panel2.Controls.Add(this.txtPassWord);
            this.panel2.Controls.Add(this.lblPassWord);
            this.panel2.Controls.Add(this.chkDelete);
            this.panel2.Controls.Add(this.lblStaffName);
            this.panel2.Controls.Add(this.lblStaffID);
            this.panel2.Controls.Add(this.txtStaffName);
            this.panel2.Controls.Add(this.txtStaffID);
            this.panel2.Controls.Add(this.btnSetting);
            this.panel2.Controls.Add(this.btnCancel);
            this.panel2.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.panel2.Location = new System.Drawing.Point(15, 435);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(607, 242);
            this.panel2.TabIndex = 2;
            // 
            // chkKanrisya
            // 
            this.chkKanrisya.AutoSize = true;
            this.chkKanrisya.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.chkKanrisya.Location = new System.Drawing.Point(192, 149);
            this.chkKanrisya.Name = "chkKanrisya";
            this.chkKanrisya.Size = new System.Drawing.Size(15, 14);
            this.chkKanrisya.TabIndex = 8;
            this.chkKanrisya.UseVisualStyleBackColor = true;
            // 
            // lblKanrisya
            // 
            this.lblKanrisya.AutoSize = true;
            this.lblKanrisya.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblKanrisya.Location = new System.Drawing.Point(15, 143);
            this.lblKanrisya.Name = "lblKanrisya";
            this.lblKanrisya.Size = new System.Drawing.Size(58, 24);
            this.lblKanrisya.TabIndex = 17;
            this.lblKanrisya.Text = "管理者";
            // 
            // txtRevPass
            // 
            this.txtRevPass.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtRevPass.ImeMode = System.Windows.Forms.ImeMode.Hiragana;
            this.txtRevPass.Location = new System.Drawing.Point(182, 108);
            this.txtRevPass.MaxLength = 50;
            this.txtRevPass.Name = "txtRevPass";
            this.txtRevPass.Size = new System.Drawing.Size(263, 31);
            this.txtRevPass.TabIndex = 7;
            this.txtRevPass.UseSystemPasswordChar = true;
            // 
            // lblRevPass
            // 
            this.lblRevPass.AutoSize = true;
            this.lblRevPass.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblRevPass.Location = new System.Drawing.Point(15, 111);
            this.lblRevPass.Name = "lblRevPass";
            this.lblRevPass.Size = new System.Drawing.Size(170, 24);
            this.lblRevPass.TabIndex = 14;
            this.lblRevPass.Text = "パスワード（確認用）";
            // 
            // txtPassWord
            // 
            this.txtPassWord.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtPassWord.ImeMode = System.Windows.Forms.ImeMode.Hiragana;
            this.txtPassWord.Location = new System.Drawing.Point(182, 76);
            this.txtPassWord.MaxLength = 50;
            this.txtPassWord.Name = "txtPassWord";
            this.txtPassWord.Size = new System.Drawing.Size(263, 31);
            this.txtPassWord.TabIndex = 6;
            this.txtPassWord.UseSystemPasswordChar = true;
            // 
            // lblPassWord
            // 
            this.lblPassWord.AutoSize = true;
            this.lblPassWord.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblPassWord.Location = new System.Drawing.Point(15, 79);
            this.lblPassWord.Name = "lblPassWord";
            this.lblPassWord.Size = new System.Drawing.Size(90, 24);
            this.lblPassWord.TabIndex = 12;
            this.lblPassWord.Text = "パスワード";
            // 
            // chkDelete
            // 
            this.chkDelete.AutoSize = true;
            this.chkDelete.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.chkDelete.Location = new System.Drawing.Point(488, 164);
            this.chkDelete.Name = "chkDelete";
            this.chkDelete.Size = new System.Drawing.Size(61, 28);
            this.chkDelete.TabIndex = 9;
            this.chkDelete.Text = "削除";
            this.chkDelete.UseVisualStyleBackColor = true;
            // 
            // lblStaffName
            // 
            this.lblStaffName.AutoSize = true;
            this.lblStaffName.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblStaffName.Location = new System.Drawing.Point(15, 47);
            this.lblStaffName.Name = "lblStaffName";
            this.lblStaffName.Size = new System.Drawing.Size(58, 24);
            this.lblStaffName.TabIndex = 11;
            this.lblStaffName.Text = "職員名";
            // 
            // lblStaffID
            // 
            this.lblStaffID.AutoSize = true;
            this.lblStaffID.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblStaffID.Location = new System.Drawing.Point(15, 15);
            this.lblStaffID.Name = "lblStaffID";
            this.lblStaffID.Size = new System.Drawing.Size(60, 24);
            this.lblStaffID.TabIndex = 10;
            this.lblStaffID.Text = "職員ID";
            // 
            // txtStaffName
            // 
            this.txtStaffName.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtStaffName.ImeMode = System.Windows.Forms.ImeMode.Hiragana;
            this.txtStaffName.Location = new System.Drawing.Point(182, 44);
            this.txtStaffName.MaxLength = 25;
            this.txtStaffName.Name = "txtStaffName";
            this.txtStaffName.Size = new System.Drawing.Size(406, 31);
            this.txtStaffName.TabIndex = 5;
            // 
            // txtStaffID
            // 
            this.txtStaffID.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtStaffID.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.txtStaffID.Location = new System.Drawing.Point(182, 12);
            this.txtStaffID.MaxLength = 20;
            this.txtStaffID.Name = "txtStaffID";
            this.txtStaffID.Size = new System.Drawing.Size(207, 31);
            this.txtStaffID.TabIndex = 4;
            // 
            // btnSetting
            // 
            this.btnSetting.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnSetting.Location = new System.Drawing.Point(382, 198);
            this.btnSetting.Name = "btnSetting";
            this.btnSetting.Size = new System.Drawing.Size(100, 30);
            this.btnSetting.TabIndex = 10;
            this.btnSetting.Text = "設定";
            this.btnSetting.UseVisualStyleBackColor = true;
            this.btnSetting.Click += new System.EventHandler(this.btnSetting_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnCancel.Location = new System.Drawing.Point(488, 198);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(100, 30);
            this.btnCancel.TabIndex = 11;
            this.btnCancel.Text = "キャンセル";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // backColorChangeOnFocusProvider1
            // 
            this.backColorChangeOnFocusProvider1.Target = this;
            // 
            // staffIDDataGridViewTextBoxColumn
            // 
            this.staffIDDataGridViewTextBoxColumn.DataPropertyName = "StaffID";
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.staffIDDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle1;
            this.staffIDDataGridViewTextBoxColumn.HeaderText = "職員ID";
            this.staffIDDataGridViewTextBoxColumn.Name = "staffIDDataGridViewTextBoxColumn";
            this.staffIDDataGridViewTextBoxColumn.ReadOnly = true;
            this.staffIDDataGridViewTextBoxColumn.Width = 159;
            // 
            // staffNameNDataGridViewTextBoxColumn
            // 
            this.staffNameNDataGridViewTextBoxColumn.DataPropertyName = "StaffNameN";
            this.staffNameNDataGridViewTextBoxColumn.HeaderText = "職員名";
            this.staffNameNDataGridViewTextBoxColumn.Name = "staffNameNDataGridViewTextBoxColumn";
            this.staffNameNDataGridViewTextBoxColumn.ReadOnly = true;
            this.staffNameNDataGridViewTextBoxColumn.Width = 294;
            // 
            // kanrisyaFlagDataGridViewTextBoxColumn
            // 
            this.kanrisyaFlagDataGridViewTextBoxColumn.DataPropertyName = "KanrisyaFlagV";
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.kanrisyaFlagDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle2;
            this.kanrisyaFlagDataGridViewTextBoxColumn.HeaderText = "管理者";
            this.kanrisyaFlagDataGridViewTextBoxColumn.Name = "kanrisyaFlagDataGridViewTextBoxColumn";
            this.kanrisyaFlagDataGridViewTextBoxColumn.ReadOnly = true;
            this.kanrisyaFlagDataGridViewTextBoxColumn.Width = 99;
            // 
            // Staff
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.ClientSize = new System.Drawing.Size(638, 691);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "Staff";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "職員マスタ　保守画面";
            this.Load += new System.EventHandler(this.Staff_Load);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvStaff)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsStaff)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnReturn;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnSelect;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.CheckBox chkDelete;
        private System.Windows.Forms.Label lblStaffName;
        private System.Windows.Forms.Label lblStaffID;
        private System.Windows.Forms.TextBox txtStaffName;
        private System.Windows.Forms.TextBox txtStaffID;
        private System.Windows.Forms.Button btnSetting;
        private System.Windows.Forms.Button btnCancel;
        private Component.BackColorChangeOnFocusProvider backColorChangeOnFocusProvider1;
        private System.Windows.Forms.DataGridView dgvStaff;
        private System.Windows.Forms.BindingSource bsStaff;
        private System.Windows.Forms.Label lblRevPass;
        private System.Windows.Forms.Label lblPassWord;
        private System.Windows.Forms.CheckBox chkKanrisya;
        private System.Windows.Forms.Label lblKanrisya;
        private System.Windows.Forms.TextBox txtRevPass;
        private System.Windows.Forms.TextBox txtPassWord;
        private System.Windows.Forms.DataGridViewTextBoxColumn staffIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn staffNameNDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn kanrisyaFlagDataGridViewTextBoxColumn;
    }
}