﻿using Suisitu.Common;
using Suisitu.Dao;
using Suisitu.Entity;
using System;
using System.Windows.Forms;

namespace Suisitu.Forms.SD90
{
    using CommonEvents = Suisitu.Common.Events;

    /// <summary>
    /// 職員マスタ保守画面クラス
    /// </summary>
    public partial class Staff : Form
    {
        private bool isInsert_ = false;
        private const string ADMIN = "administrator";

        #region コンストラクタ

        /// <summary>
        /// コンストラクタ
        /// </summary>
        public Staff()
        {
            InitializeComponent();

            this.txtStaffID.KeyPress += new KeyPressEventHandler(CommonEvents.txtHalfAll_KeyPress);
            this.txtPassWord.KeyPress += new KeyPressEventHandler(CommonEvents.txtHalfAll_KeyPress);
            this.txtRevPass.KeyPress += new KeyPressEventHandler(CommonEvents.txtHalfAll_KeyPress);
        }

        #endregion

        #region イベント

        /// <summary>
        /// 画面が表示されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void Staff_Load(object sender, EventArgs e)
        {

            bsStaff.DataSource = StaffDao.SelectAll();

            InitializeDataStaff();

            Clear();
            
        }

        /// <summary>
        /// 選択ボタンが押下されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnSelect_Click(object sender, EventArgs e)
        {
            SelectedItem();
        }

        /// <summary>
        /// データグリッドビューのセルがダブルクリックされたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void dgvStaff_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (bsStaff.Current != null)
                SelectedItem();
        }

        /// <summary>
        /// 設定ボタンが押下されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnSetting_Click(object sender, EventArgs e)
        {
            StaffEntity entity = null;

            if (chkDelete.Checked)
            {
                StaffDao.Delete((StaffEntity)bsStaff.Current);
            }
            else
            {
                entity = new StaffEntity
                {
                   StaffID = txtStaffID.Text,
                   StaffNameN = txtStaffName.Text,
                   PassWord = txtPassWord.Text,
                   KanrisyaFlag = DBUtils.ConvertDaoCheckBoxFormat(chkKanrisya.Checked),
                   UpdDate = DateTime.Now.ToString(),
                   Rev = 1,
                };
               
                if (!Validation(entity))
                    return;

                // 追加モードの場合はInsert、それ以外はUpdateする
                if (this.isInsert_)
                {
                    StaffDao.Insert(entity);
                }
                else
                {
                    StaffDao.Update(entity);
                }
            }

            // 一覧をリフレッシュする
            bsStaff.DataSource = StaffDao.SelectAll();

            // 追加モードの場合は、追加行を選択行に設定する
            if (this.isInsert_)
            {
                int rowIndex = 0;

                foreach (DataGridViewRow row in dgvStaff.Rows)
                {
                    if (row.Cells[0].Value.ToString() == entity.StaffID)
                    {
                        break;
                    }
                    rowIndex++;
                }
                dgvStaff.CurrentCell = dgvStaff[0, rowIndex];
            }

            // コントロールを初期化する
            Clear();
        }

        /// <summary>
        /// 追加ボタンが押下されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnAdd_Click(object sender, EventArgs e)
        {
            // 追加モードに設定する
            this.isInsert_ = true;

            panel1.Enabled = false;
            panel2.Enabled = true;
            chkDelete.Enabled = false;
            txtStaffID.Enabled = true;

            // 業種区分にフォーカスをセット
            txtStaffID.Focus();
        }

        /// <summary>
        /// キャンセルボタンが押下されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnCancel_Click(object sender, EventArgs e)
        {
            Clear();
        }

        /// <summary>
        /// 戻るボタンが押下されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnReturn_Click(object sender, EventArgs e)
        {
            Close();
        }

        /// <summary>
        /// 行を削除したときの処理
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dgvStaff_RowsRemoved(object sender, DataGridViewRowsRemovedEventArgs e)
        {
            InitializeDataStaff();
        }

        /// <summary>
        /// 行を追加したときの処理
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dgvStaff_RowsAdded(object sender, DataGridViewRowsAddedEventArgs e)
        {
            InitializeDataStaff();
        }
        #endregion

        #region プライベートメソッド

        /// <summary>
        /// バリデーションをチェックします。
        /// </summary>
        /// <returns>True:チェックOK / False:チェックNG</returns>
        private bool Validation(StaffEntity entity)
        {
            // 職員ID必須入力チェック
            if (string.IsNullOrEmpty(entity.StaffID))
            {
                MessageUtils.NoInputDataMessage(CommonUtils.Trim(lblStaffID.Text), Text);
                txtStaffID.Focus();
                return false;
            }

            // 半角英字チェックを行う　職員ID
            if (!ValidationUtils.ValidatetxtHalfAll(txtStaffID.Text))
            {
                MessageUtils.ZenkakuHankakuMessage(CommonUtils.Trim(lblStaffID.Text), 0, Text);
                txtStaffID.Focus();
                return false;
            }

            // 職員名必須入力チェック
            if (string.IsNullOrEmpty(entity.StaffNameN))
            {
                MessageUtils.NoInputDataMessage(CommonUtils.Trim(lblStaffName.Text), Text);
                txtStaffName.Focus();
                return false;
            }

            // 半角英字チェックを行う　職員名
            if (!ValidationUtils.ValidatetxtHalfAll(txtStaffName.Text))
            {
                MessageUtils.ZenkakuHankakuMessage(CommonUtils.Trim(lblStaffName.Text), 0, Text);
                txtStaffName.Focus();
                return false;
            }

            // パスワード必須入力チェック
            if (string.IsNullOrEmpty(entity.PassWord))
            {
                MessageUtils.NoInputDataMessage(CommonUtils.Trim(lblPassWord.Text), Text);
                txtPassWord.Focus();
                return false;
            }

            // 半角英字チェックを行う　パスワード
            if (!ValidationUtils.ValidatetxtHalfAll(txtPassWord.Text))
            {
                MessageUtils.ZenkakuHankakuMessage(CommonUtils.Trim(lblPassWord.Text), 0, Text);
                txtPassWord.Focus();
                return false;
            }

            // パスワード(確認用)必須入力チェック
            if (string.IsNullOrEmpty(txtRevPass.Text))
            {
                MessageUtils.NoInputDataMessage(CommonUtils.Trim(lblRevPass.Text), Text);
                txtRevPass.Focus();
                return false;
            }

            // 半角英字チェックを行う　パスワード(確認用)
            if (!ValidationUtils.ValidatetxtHalfAll(txtRevPass.Text))
            {
                MessageUtils.ZenkakuHankakuMessage(CommonUtils.Trim(lblRevPass.Text), 0, Text);
                txtRevPass.Focus();
                return false;
            }

            // 存在チェック
            if (this.isInsert_)
            {
                if (StaffDao.Select(entity) != null)
                {
                    MessageUtils.Duplication(CommonUtils.Trim(lblStaffID.Text), Text);
                    txtStaffID.Focus();
                    return false;
                }
            }

            // パスワード一致チェック
            if (txtPassWord.Text != txtRevPass.Text)
            {
                MessageUtils.NotMatchValue(CommonUtils.Trim(lblPassWord.Text), CommonUtils.Trim(lblRevPass.Text), Text);
                txtRevPass.Focus();
                return false;
            };

            return true;
        }

        /// <summary>
        /// 画面のクリア処理
        /// </summary>
        private void Clear()
        {
            // コントロールを初期値に戻す
            txtStaffID.Text = "";
            txtStaffName.Text = "";
            txtPassWord.Text = "";
            txtRevPass.Text = "";
            chkKanrisya.Checked = false;
            chkDelete.Checked = false;
            
            // 選択ボタンの使用可/不可を設定する
            if (dgvStaff.Rows.Count == 0)
            {
                btnSelect.Enabled = false;
            }
            else
            {
                btnSelect.Enabled = true;
            }

            // 一覧部分を操作可、編集部分を操作不可に設定する
            panel1.Enabled = true;
            panel2.Enabled = false;

            this.isInsert_ = false;
        }

        /// <summary>
        /// 一覧からアイテムが選択されたときの処理
        /// </summary>
        private void SelectedItem()
        {

            panel1.Enabled = false;
            panel2.Enabled = true;
            chkDelete.Enabled = true;
            txtStaffID.Enabled = false;

            // 選択行を取得する
            StaffEntity currentEntity = (StaffEntity)bsStaff.Current;

            // 職員ID
            txtStaffID.Text = currentEntity.StaffID;
            // 職員名
            txtStaffName.Text = currentEntity.StaffNameN;
            // パスワード
            txtPassWord.Text = currentEntity.PassWord;
            // パスワード（確認用）
            txtRevPass.Text = currentEntity.PassWord;
            // 管理者フラグ
            if (currentEntity.KanrisyaFlag == "1")
            {
                chkKanrisya.Checked = true;
            }
            else
            {
                chkKanrisya.Checked = false;
            }

            // 職員名にフォーカスをセット
            txtStaffName.Focus();
        }

        /// <summary>
        /// 選択ボタン切り換え処理
        /// </summary>
        private void InitializeDataStaff()
        {
            // マスタ0件または管理者のみの場合、選択ボタンタッチ不可
            if (bsStaff.Count > 0)
            {
                btnSelect.Enabled = true;
            }
            else
            {
                btnSelect.Enabled = false;
            }
        }
        #endregion


    }
}
