﻿namespace Suisitu.Forms.SD90
{
    partial class Todokedekbn
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnReturn = new System.Windows.Forms.Button();
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnSelect = new System.Windows.Forms.Button();
            this.dgvTodokedekbn = new System.Windows.Forms.DataGridView();
            this.bsTodokedekbn = new System.Windows.Forms.BindingSource(this.components);
            this.panel2 = new System.Windows.Forms.Panel();
            this.cboParent = new Suisitu.Components.Controls.ValueCombo();
            this.chkDelete = new System.Windows.Forms.CheckBox();
            this.lblParent = new System.Windows.Forms.Label();
            this.lblTodokedekbnName = new System.Windows.Forms.Label();
            this.lblTodokedekbn = new System.Windows.Forms.Label();
            this.txtTodokedekbnName = new System.Windows.Forms.TextBox();
            this.txtTodokedekbn = new System.Windows.Forms.TextBox();
            this.btnSetting = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.backColorChangeOnFocusProvider1 = new Suisitu.Component.BackColorChangeOnFocusProvider();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTodokedekbn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsTodokedekbn)).BeginInit();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.btnReturn);
            this.panel1.Controls.Add(this.btnAdd);
            this.panel1.Controls.Add(this.btnSelect);
            this.panel1.Controls.Add(this.dgvTodokedekbn);
            this.panel1.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel1.Location = new System.Drawing.Point(15, 15);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(483, 438);
            this.panel1.TabIndex = 0;
            // 
            // btnReturn
            // 
            this.btnReturn.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReturn.Location = new System.Drawing.Point(366, 394);
            this.btnReturn.Name = "btnReturn";
            this.btnReturn.Size = new System.Drawing.Size(100, 30);
            this.btnReturn.TabIndex = 3;
            this.btnReturn.Text = "戻る";
            this.btnReturn.UseVisualStyleBackColor = true;
            this.btnReturn.Click += new System.EventHandler(this.btnReturn_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdd.Location = new System.Drawing.Point(260, 394);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(100, 30);
            this.btnAdd.TabIndex = 2;
            this.btnAdd.Text = "追加";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // btnSelect
            // 
            this.btnSelect.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSelect.Location = new System.Drawing.Point(154, 394);
            this.btnSelect.Name = "btnSelect";
            this.btnSelect.Size = new System.Drawing.Size(100, 30);
            this.btnSelect.TabIndex = 1;
            this.btnSelect.Text = "選択";
            this.btnSelect.UseVisualStyleBackColor = true;
            this.btnSelect.Click += new System.EventHandler(this.btnSelect_Click);
            // 
            // dgvTodokedekbn
            // 
            this.dgvTodokedekbn.AllowUserToAddRows = false;
            this.dgvTodokedekbn.AllowUserToDeleteRows = false;
            this.dgvTodokedekbn.AllowUserToResizeColumns = false;
            this.dgvTodokedekbn.AllowUserToResizeRows = false;
            this.dgvTodokedekbn.AutoGenerateColumns = false;
            this.dgvTodokedekbn.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvTodokedekbn.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3});
            this.dgvTodokedekbn.DataSource = this.bsTodokedekbn;
            this.dgvTodokedekbn.Location = new System.Drawing.Point(15, 15);
            this.dgvTodokedekbn.MultiSelect = false;
            this.dgvTodokedekbn.Name = "dgvTodokedekbn";
            this.dgvTodokedekbn.ReadOnly = true;
            this.dgvTodokedekbn.RowHeadersVisible = false;
            this.dgvTodokedekbn.RowHeadersWidth = 40;
            this.dgvTodokedekbn.RowTemplate.Height = 21;
            this.dgvTodokedekbn.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvTodokedekbn.Size = new System.Drawing.Size(450, 373);
            this.dgvTodokedekbn.TabIndex = 0;
            this.dgvTodokedekbn.CellMouseDoubleClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgvTodokedekbn_CellMouseDoubleClick);
            // 
            // bsTodokedekbn
            // 
            this.bsTodokedekbn.DataSource = typeof(Suisitu.Entity.TodokedeKbnEntity);
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.cboParent);
            this.panel2.Controls.Add(this.chkDelete);
            this.panel2.Controls.Add(this.lblParent);
            this.panel2.Controls.Add(this.lblTodokedekbnName);
            this.panel2.Controls.Add(this.lblTodokedekbn);
            this.panel2.Controls.Add(this.txtTodokedekbnName);
            this.panel2.Controls.Add(this.txtTodokedekbn);
            this.panel2.Controls.Add(this.btnSetting);
            this.panel2.Controls.Add(this.btnCancel);
            this.panel2.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.panel2.Location = new System.Drawing.Point(15, 459);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(483, 201);
            this.panel2.TabIndex = 1;
            // 
            // cboParent
            // 
            this.cboParent.Location = new System.Drawing.Point(143, 76);
            this.cboParent.MaxLength = 1;
            this.cboParent.Name = "cboParent";
            this.cboParent.Size = new System.Drawing.Size(293, 31);
            this.cboParent.TabIndex = 6;
            this.cboParent.Value = "-1";
            // 
            // chkDelete
            // 
            this.chkDelete.AutoSize = true;
            this.chkDelete.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.chkDelete.Location = new System.Drawing.Point(367, 122);
            this.chkDelete.Name = "chkDelete";
            this.chkDelete.Size = new System.Drawing.Size(61, 28);
            this.chkDelete.TabIndex = 7;
            this.chkDelete.Text = "削除";
            this.chkDelete.UseVisualStyleBackColor = true;
            // 
            // lblParent
            // 
            this.lblParent.AutoSize = true;
            this.lblParent.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblParent.Location = new System.Drawing.Point(15, 79);
            this.lblParent.Name = "lblParent";
            this.lblParent.Size = new System.Drawing.Size(106, 24);
            this.lblParent.TabIndex = 12;
            this.lblParent.Text = "法区分コード";
            // 
            // lblTodokedekbnName
            // 
            this.lblTodokedekbnName.AutoSize = true;
            this.lblTodokedekbnName.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblTodokedekbnName.Location = new System.Drawing.Point(15, 47);
            this.lblTodokedekbnName.Name = "lblTodokedekbnName";
            this.lblTodokedekbnName.Size = new System.Drawing.Size(106, 24);
            this.lblTodokedekbnName.TabIndex = 11;
            this.lblTodokedekbnName.Text = "届出区分名称";
            // 
            // lblTodokedekbn
            // 
            this.lblTodokedekbn.AutoSize = true;
            this.lblTodokedekbn.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblTodokedekbn.Location = new System.Drawing.Point(15, 15);
            this.lblTodokedekbn.Name = "lblTodokedekbn";
            this.lblTodokedekbn.Size = new System.Drawing.Size(74, 24);
            this.lblTodokedekbn.TabIndex = 10;
            this.lblTodokedekbn.Text = "届出区分";
            // 
            // txtTodokedekbnName
            // 
            this.txtTodokedekbnName.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtTodokedekbnName.ImeMode = System.Windows.Forms.ImeMode.Hiragana;
            this.txtTodokedekbnName.Location = new System.Drawing.Point(143, 44);
            this.txtTodokedekbnName.MaxLength = 20;
            this.txtTodokedekbnName.Name = "txtTodokedekbnName";
            this.txtTodokedekbnName.Size = new System.Drawing.Size(294, 31);
            this.txtTodokedekbnName.TabIndex = 5;
            // 
            // txtTodokedekbn
            // 
            this.txtTodokedekbn.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtTodokedekbn.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.txtTodokedekbn.Location = new System.Drawing.Point(143, 12);
            this.txtTodokedekbn.MaxLength = 4;
            this.txtTodokedekbn.Name = "txtTodokedekbn";
            this.txtTodokedekbn.Size = new System.Drawing.Size(53, 31);
            this.txtTodokedekbn.TabIndex = 4;
            // 
            // btnSetting
            // 
            this.btnSetting.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnSetting.Location = new System.Drawing.Point(260, 156);
            this.btnSetting.Name = "btnSetting";
            this.btnSetting.Size = new System.Drawing.Size(100, 30);
            this.btnSetting.TabIndex = 8;
            this.btnSetting.Text = "設定";
            this.btnSetting.UseVisualStyleBackColor = true;
            this.btnSetting.Click += new System.EventHandler(this.btnSetting_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnCancel.Location = new System.Drawing.Point(366, 156);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(100, 30);
            this.btnCancel.TabIndex = 9;
            this.btnCancel.Text = "キャンセル";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // backColorChangeOnFocusProvider1
            // 
            this.backColorChangeOnFocusProvider1.Target = this;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "TodokedeKbn";
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn1.DefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridViewTextBoxColumn1.HeaderText = "届出区分";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "TodokedeKbnNameN";
            this.dataGridViewTextBoxColumn2.HeaderText = "届出区分名称";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            this.dataGridViewTextBoxColumn2.Width = 230;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "Parent";
            this.dataGridViewTextBoxColumn3.HeaderText = "法区分 コード";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            // 
            // Todokedekbn
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.ClientSize = new System.Drawing.Size(510, 672);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "Todokedekbn";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "届出区分コード　保守画面";
            this.Load += new System.EventHandler(this.Todokedekbn_Load);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvTodokedekbn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsTodokedekbn)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DataGridView dgvTodokedekbn;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btnSelect;
        private System.Windows.Forms.Button btnReturn;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.TextBox txtTodokedekbnName;
        private System.Windows.Forms.TextBox txtTodokedekbn;
        private System.Windows.Forms.Button btnSetting;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Label lblTodokedekbn;
        private System.Windows.Forms.CheckBox chkDelete;
        private System.Windows.Forms.Label lblParent;
        private System.Windows.Forms.Label lblTodokedekbnName;
        private System.Windows.Forms.BindingSource bsTodokedekbn;
        private Components.Controls.ValueCombo cboParent;
        private Component.BackColorChangeOnFocusProvider backColorChangeOnFocusProvider1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
    }
}