﻿using Suisitu.Common;
using Suisitu.Dao;
using Suisitu.Entity;
using System;
using System.Windows.Forms;

namespace Suisitu.Forms.SD90
{
    using CommonEvents = Suisitu.Common.Events;

    /// <summary>
    /// 届出区分コード保守画面クラス
    /// </summary>
    public partial class Todokedekbn : Form
    {
        private bool isInsert_ = false;

        #region コンストラクタ

        /// <summary>
        /// コンストラクタ
        /// </summary>
        public Todokedekbn()
        {
            InitializeComponent();

            this.txtTodokedekbn.KeyPress += new KeyPressEventHandler(CommonEvents.txtHalfNumber_KeyPress);
            this.txtTodokedekbnName.KeyPress += new KeyPressEventHandler(CommonEvents.txtFullAll_KeyPress);
            this.cboParent.KeyPress += new KeyPressEventHandler(CommonEvents.txtHalfNumber_KeyPress);
        }

        #endregion

        #region イベント

        /// <summary>
        /// 画面が表示されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void Todokedekbn_Load(object sender, EventArgs e)
        {
            bsTodokedekbn.DataSource = TodokedeKbnDao.SelectAll();
            cboParent.InitCombo(KubunNameDao.GetMasterData("HOKBN"));

            Clear();
        }

        /// <summary>
        /// 選択ボタンが押下されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnSelect_Click(object sender, EventArgs e)
        {
            SelectedItem();
        }

        /// <summary>
        /// データグリッドビューのセルがダブルクリックされたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void dgvTodokedekbn_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (bsTodokedekbn.Current != null)
                SelectedItem();
        }

        /// <summary>
        /// 設定ボタンが押下されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnSetting_Click(object sender, EventArgs e)
        {
            TodokedeKbnEntity entity = null;

            if (chkDelete.Checked)
            {
                TodokedeKbnDao.Delete((TodokedeKbnEntity)bsTodokedekbn.Current);
            }
            else
            {
                entity = new TodokedeKbnEntity
                {
                    TodokedeKbn = txtTodokedekbn.Text,
                    TodokedeKbnNameN = txtTodokedekbnName.Text,
                    Parent = cboParent.Value,
                    UpdDate = DateTime.Now.ToString(),
                    Rev = 1,
                };

                if (!Validation(entity))
                    return;

                // 追加モードの場合はInsert、それ以外はUpdateする
                if (this.isInsert_)
                {
                    TodokedeKbnDao.Insert(entity);
                }
                else
                {
                    TodokedeKbnDao.Update(entity);
                }
            }

            // 一覧をリフレッシュする
            bsTodokedekbn.DataSource = TodokedeKbnDao.SelectAll();

            // 追加モードの場合は、追加行を選択行に設定する
            if (this.isInsert_)
            {
                int rowIndex = 0;

                foreach (DataGridViewRow row in dgvTodokedekbn.Rows)
                {
                    if (row.Cells[0].Value.ToString() == entity.TodokedeKbn)
                    {
                        break;
                    }
                    rowIndex++;
                }
                dgvTodokedekbn.CurrentCell = dgvTodokedekbn[0, rowIndex];
            }

            // コントロールを初期化する
            Clear();
        }

        /// <summary>
        /// 追加ボタンが押下されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnAdd_Click(object sender, EventArgs e)
        {
            // 追加モードに設定する
            this.isInsert_ = true;

            panel1.Enabled = false;
            panel2.Enabled = true;
            chkDelete.Enabled = false;
            txtTodokedekbn.Enabled = true;

            // 届出区分にフォーカスをセット
            txtTodokedekbn.Focus();
        }

        /// <summary>
        /// キャンセルボタンが押下されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnCancel_Click(object sender, EventArgs e)
        {
            Clear();
        }

        /// <summary>
        /// 戻るボタンが押下されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnReturn_Click(object sender, EventArgs e)
        {
            Close();
        }

        #endregion

        #region プライベートメソッド

        /// <summary>
        /// バリデーションをチェックします。
        /// </summary>
        /// <returns>True:チェックOK / False:チェックNG</returns>
        private bool Validation(TodokedeKbnEntity entity)
        {
            // 必須入力チェック　届出区分
            if (string.IsNullOrEmpty(entity.TodokedeKbn))
            {
                MessageUtils.NoInputDataMessage(CommonUtils.Trim(lblTodokedekbn.Text), Text);
                txtTodokedekbn.Focus();
                return false;
            }

            // 半角数字チェック行う
            if (!ValidationUtils.ValidateTypeNumeric(txtTodokedekbn.Text))
            {
                MessageUtils.ZenkakuHankakuMessage(CommonUtils.Trim(lblTodokedekbn.Text), 0, Text);
                txtTodokedekbn.Focus();
                return false;
            }

            // 全角文字チェック　届出区分名称
            if (!ValidationUtils.ValidateZenkaku(txtTodokedekbnName.Text) & !string.IsNullOrEmpty(txtTodokedekbnName.Text))
            {
                MessageUtils.ZenkakuHankakuMessage(CommonUtils.Trim(lblTodokedekbnName.Text), 1, Text);
                txtTodokedekbnName.Focus();
                return false;
            }

            // 存在チェック
            if (this.isInsert_)
            {
                if (TodokedeKbnDao.Select(entity) != null)
                {
                    MessageUtils.Duplication(CommonUtils.Trim(lblTodokedekbn.Text), Text);
                    txtTodokedekbn.Focus();
                    return false;
                }
            }

            // 届出区分の先頭１桁目が法区分コードと一致するかチェック
            // この部分が半角数字チェックも兼ねています。
            // コピペで張り付けられた場合、entity.Paret = -1となるので弾かれます。
            if (entity.TodokedeKbn.Substring(0, 1) != entity.Parent)
            {
                MessageUtils.NotMatchValue("届出区分の先頭１桁目", "法区分コードの値", Text);
                txtTodokedekbn.Focus();
                return false;
            }

            return true;
        }

        /// <summary>
        /// 画面のクリア処理
        /// </summary>
        private void Clear()
        {
            // コントロールを初期値に戻す
            txtTodokedekbn.Text = "";
            txtTodokedekbnName.Text = "";
            cboParent.Clear();
            chkDelete.Checked = false;

            // 選択ボタンの使用可/不可を設定する
            if (dgvTodokedekbn.Rows.Count == 0)
            {
                btnSelect.Enabled = false;
            }
            else
            {
                btnSelect.Enabled = true;
            }

            // 一覧部分を操作可、編集部分を操作不可に設定する
            panel1.Enabled = true;
            panel2.Enabled = false;
            
            this.isInsert_ = false;
        }

        /// <summary>
        /// 一覧からアイテムが選択されたときの処理
        /// </summary>
        private void SelectedItem()
        {
            panel1.Enabled = false;
            panel2.Enabled = true;
            chkDelete.Enabled = true;
            txtTodokedekbn.Enabled = false;

            // 選択行を取得する
            TodokedeKbnEntity currentEntity = (TodokedeKbnEntity)bsTodokedekbn.Current;

            // 届出区分
            txtTodokedekbn.Text = currentEntity.TodokedeKbn;
            // 届出区分名称
            txtTodokedekbnName.Text = currentEntity.TodokedeKbnNameN;
            // 法区分コード名称
            int value = 0;
            int.TryParse(currentEntity.Parent, out value);
            cboParent.SelectedIndex = value - 1;

            // 届出区分名称にフォーカスをセット
            txtTodokedekbnName.Focus();
        }

        #endregion
    }
}
