﻿namespace Suisitu.Forms.SD90
{
    partial class TsSyubetu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblTsSyubetuListLine = new System.Windows.Forms.Label();
            this.lblTsSyubetuList = new System.Windows.Forms.Label();
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnSelect = new System.Windows.Forms.Button();
            this.dgvTsSyubetu = new System.Windows.Forms.DataGridView();
            this.btnReturn = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lblTsSyubetuNo = new System.Windows.Forms.Label();
            this.txtTsSyubetuNo = new System.Windows.Forms.TextBox();
            this.txtTsSyubetu = new System.Windows.Forms.TextBox();
            this.lblTsSyubetu = new System.Windows.Forms.Label();
            this.chkDelete = new System.Windows.Forms.CheckBox();
            this.lblTsSyubetuNameN = new System.Windows.Forms.Label();
            this.txtTsSyubetuNameN = new System.Windows.Forms.TextBox();
            this.btnSetting = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.lblTsSyubetuSaiListLine = new System.Windows.Forms.Label();
            this.lblTsSyubetuSaiList = new System.Windows.Forms.Label();
            this.btnAddSai = new System.Windows.Forms.Button();
            this.btnSelectSai = new System.Windows.Forms.Button();
            this.dgvTsSyubetuSai = new System.Windows.Forms.DataGridView();
            this.panel4 = new System.Windows.Forms.Panel();
            this.txtTsSyubetuSaiNo = new System.Windows.Forms.TextBox();
            this.lblTsSyubetuSaiNo = new System.Windows.Forms.Label();
            this.txtTsSyubetuSai = new System.Windows.Forms.TextBox();
            this.lblTsSyubetuSai = new System.Windows.Forms.Label();
            this.txtParent = new System.Windows.Forms.TextBox();
            this.lblParent = new System.Windows.Forms.Label();
            this.chkDeleteSai = new System.Windows.Forms.CheckBox();
            this.lblTsSyubetuSaiNameN = new System.Windows.Forms.Label();
            this.txtTsSyubetuSaiNameN = new System.Windows.Forms.TextBox();
            this.btnSettingSai = new System.Windows.Forms.Button();
            this.btnCancelSai = new System.Windows.Forms.Button();
            this.backColorChangeOnFocusProvider1 = new Suisitu.Component.BackColorChangeOnFocusProvider();
            this.tsSyubetuSaiDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tsSyubetuSaiNameNDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tsSyubetuSaiNoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bsTsSyubetuSai = new System.Windows.Forms.BindingSource(this.components);
            this.tsSyubetuDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tsSyubetuNameNDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tsSyubetuNoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bsTsSyubetu = new System.Windows.Forms.BindingSource(this.components);
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTsSyubetu)).BeginInit();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTsSyubetuSai)).BeginInit();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bsTsSyubetuSai)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsTsSyubetu)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.lblTsSyubetuListLine);
            this.panel1.Controls.Add(this.lblTsSyubetuList);
            this.panel1.Controls.Add(this.btnAdd);
            this.panel1.Controls.Add(this.btnSelect);
            this.panel1.Controls.Add(this.dgvTsSyubetu);
            this.panel1.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel1.Location = new System.Drawing.Point(15, 51);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(482, 420);
            this.panel1.TabIndex = 1;
            // 
            // lblTsSyubetuListLine
            // 
            this.lblTsSyubetuListLine.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblTsSyubetuListLine.Font = new System.Drawing.Font("ＭＳ ゴシック", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblTsSyubetuListLine.Location = new System.Drawing.Point(112, 25);
            this.lblTsSyubetuListLine.Name = "lblTsSyubetuListLine";
            this.lblTsSyubetuListLine.Size = new System.Drawing.Size(355, 1);
            this.lblTsSyubetuListLine.TabIndex = 80;
            // 
            // lblTsSyubetuList
            // 
            this.lblTsSyubetuList.AutoSize = true;
            this.lblTsSyubetuList.Font = new System.Drawing.Font("メイリオ", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblTsSyubetuList.Location = new System.Drawing.Point(15, 15);
            this.lblTsSyubetuList.Name = "lblTsSyubetuList";
            this.lblTsSyubetuList.Size = new System.Drawing.Size(87, 20);
            this.lblTsSyubetuList.TabIndex = 79;
            this.lblTsSyubetuList.Text = "特定施設種別";
            // 
            // btnAdd
            // 
            this.btnAdd.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdd.Location = new System.Drawing.Point(367, 375);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(100, 30);
            this.btnAdd.TabIndex = 4;
            this.btnAdd.Text = "追加";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // btnSelect
            // 
            this.btnSelect.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSelect.Location = new System.Drawing.Point(261, 375);
            this.btnSelect.Name = "btnSelect";
            this.btnSelect.Size = new System.Drawing.Size(100, 30);
            this.btnSelect.TabIndex = 3;
            this.btnSelect.Text = "選択";
            this.btnSelect.UseVisualStyleBackColor = true;
            this.btnSelect.Click += new System.EventHandler(this.btnSelect_Click);
            // 
            // dgvTsSyubetu
            // 
            this.dgvTsSyubetu.AllowUserToAddRows = false;
            this.dgvTsSyubetu.AllowUserToDeleteRows = false;
            this.dgvTsSyubetu.AllowUserToResizeColumns = false;
            this.dgvTsSyubetu.AllowUserToResizeRows = false;
            this.dgvTsSyubetu.AutoGenerateColumns = false;
            this.dgvTsSyubetu.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvTsSyubetu.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.tsSyubetuDataGridViewTextBoxColumn,
            this.tsSyubetuNameNDataGridViewTextBoxColumn,
            this.tsSyubetuNoDataGridViewTextBoxColumn});
            this.dgvTsSyubetu.DataSource = this.bsTsSyubetu;
            this.dgvTsSyubetu.Location = new System.Drawing.Point(15, 41);
            this.dgvTsSyubetu.MultiSelect = false;
            this.dgvTsSyubetu.Name = "dgvTsSyubetu";
            this.dgvTsSyubetu.ReadOnly = true;
            this.dgvTsSyubetu.RowHeadersVisible = false;
            this.dgvTsSyubetu.RowHeadersWidth = 40;
            this.dgvTsSyubetu.RowTemplate.Height = 21;
            this.dgvTsSyubetu.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvTsSyubetu.Size = new System.Drawing.Size(452, 328);
            this.dgvTsSyubetu.TabIndex = 2;
            this.dgvTsSyubetu.CellMouseDoubleClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgvTsSyubetu_CellMouseDoubleClick);
            this.dgvTsSyubetu.CurrentCellChanged += new System.EventHandler(this.dgvTsSyubetu_CurrentCellChanged);
            // 
            // btnReturn
            // 
            this.btnReturn.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReturn.Location = new System.Drawing.Point(885, 15);
            this.btnReturn.Name = "btnReturn";
            this.btnReturn.Size = new System.Drawing.Size(100, 30);
            this.btnReturn.TabIndex = 0;
            this.btnReturn.Text = "戻る";
            this.btnReturn.UseVisualStyleBackColor = true;
            this.btnReturn.Click += new System.EventHandler(this.btnReturn_Click);
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.lblTsSyubetuNo);
            this.panel2.Controls.Add(this.txtTsSyubetuNo);
            this.panel2.Controls.Add(this.txtTsSyubetu);
            this.panel2.Controls.Add(this.lblTsSyubetu);
            this.panel2.Controls.Add(this.chkDelete);
            this.panel2.Controls.Add(this.lblTsSyubetuNameN);
            this.panel2.Controls.Add(this.txtTsSyubetuNameN);
            this.panel2.Controls.Add(this.btnSetting);
            this.panel2.Controls.Add(this.btnCancel);
            this.panel2.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.panel2.Location = new System.Drawing.Point(15, 477);
            this.panel2.Margin = new System.Windows.Forms.Padding(3, 5, 3, 3);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(482, 233);
            this.panel2.TabIndex = 1;
            // 
            // lblTsSyubetuNo
            // 
            this.lblTsSyubetuNo.AutoSize = true;
            this.lblTsSyubetuNo.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblTsSyubetuNo.Location = new System.Drawing.Point(14, 79);
            this.lblTsSyubetuNo.Name = "lblTsSyubetuNo";
            this.lblTsSyubetuNo.Size = new System.Drawing.Size(138, 24);
            this.lblTsSyubetuNo.TabIndex = 14;
            this.lblTsSyubetuNo.Text = "特定施設種別番号";
            // 
            // txtTsSyubetuNo
            // 
            this.txtTsSyubetuNo.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtTsSyubetuNo.ImeMode = System.Windows.Forms.ImeMode.Hiragana;
            this.txtTsSyubetuNo.Location = new System.Drawing.Point(202, 76);
            this.txtTsSyubetuNo.MaxLength = 5;
            this.txtTsSyubetuNo.Name = "txtTsSyubetuNo";
            this.txtTsSyubetuNo.Size = new System.Drawing.Size(100, 31);
            this.txtTsSyubetuNo.TabIndex = 7;
            // 
            // txtTsSyubetu
            // 
            this.txtTsSyubetu.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtTsSyubetu.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.txtTsSyubetu.Location = new System.Drawing.Point(202, 12);
            this.txtTsSyubetu.MaxLength = 3;
            this.txtTsSyubetu.Name = "txtTsSyubetu";
            this.txtTsSyubetu.Size = new System.Drawing.Size(50, 31);
            this.txtTsSyubetu.TabIndex = 5;
            // 
            // lblTsSyubetu
            // 
            this.lblTsSyubetu.AutoSize = true;
            this.lblTsSyubetu.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblTsSyubetu.Location = new System.Drawing.Point(15, 15);
            this.lblTsSyubetu.Name = "lblTsSyubetu";
            this.lblTsSyubetu.Size = new System.Drawing.Size(106, 24);
            this.lblTsSyubetu.TabIndex = 12;
            this.lblTsSyubetu.Text = "特定施設種別";
            // 
            // chkDelete
            // 
            this.chkDelete.AutoSize = true;
            this.chkDelete.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.chkDelete.Location = new System.Drawing.Point(366, 154);
            this.chkDelete.Name = "chkDelete";
            this.chkDelete.Size = new System.Drawing.Size(61, 28);
            this.chkDelete.TabIndex = 8;
            this.chkDelete.Text = "削除";
            this.chkDelete.UseVisualStyleBackColor = true;
            // 
            // lblTsSyubetuNameN
            // 
            this.lblTsSyubetuNameN.AutoSize = true;
            this.lblTsSyubetuNameN.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblTsSyubetuNameN.Location = new System.Drawing.Point(15, 47);
            this.lblTsSyubetuNameN.Name = "lblTsSyubetuNameN";
            this.lblTsSyubetuNameN.Size = new System.Drawing.Size(138, 24);
            this.lblTsSyubetuNameN.TabIndex = 10;
            this.lblTsSyubetuNameN.Text = "特定施設種別名称";
            // 
            // txtTsSyubetuNameN
            // 
            this.txtTsSyubetuNameN.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtTsSyubetuNameN.ImeMode = System.Windows.Forms.ImeMode.Hiragana;
            this.txtTsSyubetuNameN.Location = new System.Drawing.Point(202, 44);
            this.txtTsSyubetuNameN.MaxLength = 40;
            this.txtTsSyubetuNameN.Name = "txtTsSyubetuNameN";
            this.txtTsSyubetuNameN.Size = new System.Drawing.Size(265, 31);
            this.txtTsSyubetuNameN.TabIndex = 6;
            // 
            // btnSetting
            // 
            this.btnSetting.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnSetting.Location = new System.Drawing.Point(261, 188);
            this.btnSetting.Name = "btnSetting";
            this.btnSetting.Size = new System.Drawing.Size(100, 30);
            this.btnSetting.TabIndex = 9;
            this.btnSetting.Text = "設定";
            this.btnSetting.UseVisualStyleBackColor = true;
            this.btnSetting.Click += new System.EventHandler(this.btnSetting_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnCancel.Location = new System.Drawing.Point(367, 188);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(100, 30);
            this.btnCancel.TabIndex = 10;
            this.btnCancel.Text = "キャンセル";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // panel3
            // 
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.lblTsSyubetuSaiListLine);
            this.panel3.Controls.Add(this.lblTsSyubetuSaiList);
            this.panel3.Controls.Add(this.btnAddSai);
            this.panel3.Controls.Add(this.btnSelectSai);
            this.panel3.Controls.Add(this.dgvTsSyubetuSai);
            this.panel3.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel3.Location = new System.Drawing.Point(503, 51);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(482, 420);
            this.panel3.TabIndex = 4;
            // 
            // lblTsSyubetuSaiListLine
            // 
            this.lblTsSyubetuSaiListLine.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblTsSyubetuSaiListLine.Font = new System.Drawing.Font("ＭＳ ゴシック", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblTsSyubetuSaiListLine.Location = new System.Drawing.Point(167, 25);
            this.lblTsSyubetuSaiListLine.Name = "lblTsSyubetuSaiListLine";
            this.lblTsSyubetuSaiListLine.Size = new System.Drawing.Size(300, 1);
            this.lblTsSyubetuSaiListLine.TabIndex = 81;
            // 
            // lblTsSyubetuSaiList
            // 
            this.lblTsSyubetuSaiList.AutoSize = true;
            this.lblTsSyubetuSaiList.Font = new System.Drawing.Font("メイリオ", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblTsSyubetuSaiList.Location = new System.Drawing.Point(15, 15);
            this.lblTsSyubetuSaiList.Name = "lblTsSyubetuSaiList";
            this.lblTsSyubetuSaiList.Size = new System.Drawing.Size(152, 20);
            this.lblTsSyubetuSaiList.TabIndex = 80;
            this.lblTsSyubetuSaiList.Text = "特定施設種別（細区分）";
            // 
            // btnAddSai
            // 
            this.btnAddSai.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddSai.Location = new System.Drawing.Point(367, 375);
            this.btnAddSai.Name = "btnAddSai";
            this.btnAddSai.Size = new System.Drawing.Size(100, 30);
            this.btnAddSai.TabIndex = 13;
            this.btnAddSai.Text = "追加";
            this.btnAddSai.UseVisualStyleBackColor = true;
            this.btnAddSai.Click += new System.EventHandler(this.btnAddSai_Click);
            // 
            // btnSelectSai
            // 
            this.btnSelectSai.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSelectSai.Location = new System.Drawing.Point(261, 375);
            this.btnSelectSai.Name = "btnSelectSai";
            this.btnSelectSai.Size = new System.Drawing.Size(100, 30);
            this.btnSelectSai.TabIndex = 12;
            this.btnSelectSai.Text = "選択";
            this.btnSelectSai.UseVisualStyleBackColor = true;
            this.btnSelectSai.Click += new System.EventHandler(this.btnSelectSai_Click);
            // 
            // dgvTsSyubetuSai
            // 
            this.dgvTsSyubetuSai.AllowUserToAddRows = false;
            this.dgvTsSyubetuSai.AllowUserToDeleteRows = false;
            this.dgvTsSyubetuSai.AllowUserToResizeColumns = false;
            this.dgvTsSyubetuSai.AllowUserToResizeRows = false;
            this.dgvTsSyubetuSai.AutoGenerateColumns = false;
            this.dgvTsSyubetuSai.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvTsSyubetuSai.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.tsSyubetuSaiDataGridViewTextBoxColumn,
            this.tsSyubetuSaiNameNDataGridViewTextBoxColumn,
            this.tsSyubetuSaiNoDataGridViewTextBoxColumn});
            this.dgvTsSyubetuSai.DataSource = this.bsTsSyubetuSai;
            this.dgvTsSyubetuSai.Location = new System.Drawing.Point(15, 41);
            this.dgvTsSyubetuSai.MultiSelect = false;
            this.dgvTsSyubetuSai.Name = "dgvTsSyubetuSai";
            this.dgvTsSyubetuSai.ReadOnly = true;
            this.dgvTsSyubetuSai.RowHeadersVisible = false;
            this.dgvTsSyubetuSai.RowHeadersWidth = 40;
            this.dgvTsSyubetuSai.RowTemplate.Height = 21;
            this.dgvTsSyubetuSai.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvTsSyubetuSai.Size = new System.Drawing.Size(452, 328);
            this.dgvTsSyubetuSai.TabIndex = 11;
            this.dgvTsSyubetuSai.CellMouseDoubleClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgvTsSyubetuSai_CellMouseDoubleClick);
            // 
            // panel4
            // 
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel4.Controls.Add(this.txtTsSyubetuSaiNo);
            this.panel4.Controls.Add(this.lblTsSyubetuSaiNo);
            this.panel4.Controls.Add(this.txtTsSyubetuSai);
            this.panel4.Controls.Add(this.lblTsSyubetuSai);
            this.panel4.Controls.Add(this.txtParent);
            this.panel4.Controls.Add(this.lblParent);
            this.panel4.Controls.Add(this.chkDeleteSai);
            this.panel4.Controls.Add(this.lblTsSyubetuSaiNameN);
            this.panel4.Controls.Add(this.txtTsSyubetuSaiNameN);
            this.panel4.Controls.Add(this.btnSettingSai);
            this.panel4.Controls.Add(this.btnCancelSai);
            this.panel4.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.panel4.Location = new System.Drawing.Point(503, 477);
            this.panel4.Margin = new System.Windows.Forms.Padding(3, 5, 3, 3);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(482, 233);
            this.panel4.TabIndex = 5;
            // 
            // txtTsSyubetuSaiNo
            // 
            this.txtTsSyubetuSaiNo.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtTsSyubetuSaiNo.ImeMode = System.Windows.Forms.ImeMode.Katakana;
            this.txtTsSyubetuSaiNo.Location = new System.Drawing.Point(220, 108);
            this.txtTsSyubetuSaiNo.MaxLength = 1;
            this.txtTsSyubetuSaiNo.Name = "txtTsSyubetuSaiNo";
            this.txtTsSyubetuSaiNo.Size = new System.Drawing.Size(31, 31);
            this.txtTsSyubetuSaiNo.TabIndex = 17;
            // 
            // lblTsSyubetuSaiNo
            // 
            this.lblTsSyubetuSaiNo.AutoSize = true;
            this.lblTsSyubetuSaiNo.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblTsSyubetuSaiNo.Location = new System.Drawing.Point(15, 111);
            this.lblTsSyubetuSaiNo.Name = "lblTsSyubetuSaiNo";
            this.lblTsSyubetuSaiNo.Size = new System.Drawing.Size(200, 24);
            this.lblTsSyubetuSaiNo.TabIndex = 19;
            this.lblTsSyubetuSaiNo.Text = "特定施設種別(細区分)番号";
            // 
            // txtTsSyubetuSai
            // 
            this.txtTsSyubetuSai.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtTsSyubetuSai.ImeMode = System.Windows.Forms.ImeMode.KatakanaHalf;
            this.txtTsSyubetuSai.Location = new System.Drawing.Point(220, 44);
            this.txtTsSyubetuSai.MaxLength = 1;
            this.txtTsSyubetuSai.Name = "txtTsSyubetuSai";
            this.txtTsSyubetuSai.Size = new System.Drawing.Size(31, 31);
            this.txtTsSyubetuSai.TabIndex = 15;
            // 
            // lblTsSyubetuSai
            // 
            this.lblTsSyubetuSai.AutoSize = true;
            this.lblTsSyubetuSai.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblTsSyubetuSai.Location = new System.Drawing.Point(15, 47);
            this.lblTsSyubetuSai.Name = "lblTsSyubetuSai";
            this.lblTsSyubetuSai.Size = new System.Drawing.Size(168, 24);
            this.lblTsSyubetuSai.TabIndex = 13;
            this.lblTsSyubetuSai.Text = "特定施設種別(細区分)";
            // 
            // txtParent
            // 
            this.txtParent.Enabled = false;
            this.txtParent.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtParent.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.txtParent.Location = new System.Drawing.Point(220, 12);
            this.txtParent.MaxLength = 3;
            this.txtParent.Name = "txtParent";
            this.txtParent.Size = new System.Drawing.Size(50, 31);
            this.txtParent.TabIndex = 14;
            // 
            // lblParent
            // 
            this.lblParent.AutoSize = true;
            this.lblParent.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblParent.Location = new System.Drawing.Point(15, 15);
            this.lblParent.Name = "lblParent";
            this.lblParent.Size = new System.Drawing.Size(106, 24);
            this.lblParent.TabIndex = 12;
            this.lblParent.Text = "特定施設種別";
            // 
            // chkDeleteSai
            // 
            this.chkDeleteSai.AutoSize = true;
            this.chkDeleteSai.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.chkDeleteSai.Location = new System.Drawing.Point(366, 154);
            this.chkDeleteSai.Name = "chkDeleteSai";
            this.chkDeleteSai.Size = new System.Drawing.Size(61, 28);
            this.chkDeleteSai.TabIndex = 18;
            this.chkDeleteSai.Text = "削除";
            this.chkDeleteSai.UseVisualStyleBackColor = true;
            // 
            // lblTsSyubetuSaiNameN
            // 
            this.lblTsSyubetuSaiNameN.AutoSize = true;
            this.lblTsSyubetuSaiNameN.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblTsSyubetuSaiNameN.Location = new System.Drawing.Point(15, 79);
            this.lblTsSyubetuSaiNameN.Name = "lblTsSyubetuSaiNameN";
            this.lblTsSyubetuSaiNameN.Size = new System.Drawing.Size(200, 24);
            this.lblTsSyubetuSaiNameN.TabIndex = 10;
            this.lblTsSyubetuSaiNameN.Text = "特定施設種別(細区分)名称";
            // 
            // txtTsSyubetuSaiNameN
            // 
            this.txtTsSyubetuSaiNameN.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtTsSyubetuSaiNameN.ImeMode = System.Windows.Forms.ImeMode.Hiragana;
            this.txtTsSyubetuSaiNameN.Location = new System.Drawing.Point(220, 76);
            this.txtTsSyubetuSaiNameN.MaxLength = 40;
            this.txtTsSyubetuSaiNameN.Name = "txtTsSyubetuSaiNameN";
            this.txtTsSyubetuSaiNameN.Size = new System.Drawing.Size(247, 31);
            this.txtTsSyubetuSaiNameN.TabIndex = 16;
            // 
            // btnSettingSai
            // 
            this.btnSettingSai.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnSettingSai.Location = new System.Drawing.Point(261, 188);
            this.btnSettingSai.Name = "btnSettingSai";
            this.btnSettingSai.Size = new System.Drawing.Size(100, 30);
            this.btnSettingSai.TabIndex = 19;
            this.btnSettingSai.Text = "設定";
            this.btnSettingSai.UseVisualStyleBackColor = true;
            this.btnSettingSai.Click += new System.EventHandler(this.btnSettingSai_Click);
            // 
            // btnCancelSai
            // 
            this.btnCancelSai.Font = new System.Drawing.Font("メイリオ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnCancelSai.Location = new System.Drawing.Point(367, 188);
            this.btnCancelSai.Name = "btnCancelSai";
            this.btnCancelSai.Size = new System.Drawing.Size(100, 30);
            this.btnCancelSai.TabIndex = 20;
            this.btnCancelSai.Text = "キャンセル";
            this.btnCancelSai.UseVisualStyleBackColor = true;
            this.btnCancelSai.Click += new System.EventHandler(this.btnCancelSai_Click);
            // 
            // backColorChangeOnFocusProvider1
            // 
            this.backColorChangeOnFocusProvider1.Target = this;
            // 
            // tsSyubetuSaiDataGridViewTextBoxColumn
            // 
            this.tsSyubetuSaiDataGridViewTextBoxColumn.DataPropertyName = "TsSyubetuSai";
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.tsSyubetuSaiDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle2;
            this.tsSyubetuSaiDataGridViewTextBoxColumn.HeaderText = "細区分";
            this.tsSyubetuSaiDataGridViewTextBoxColumn.Name = "tsSyubetuSaiDataGridViewTextBoxColumn";
            this.tsSyubetuSaiDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // tsSyubetuSaiNameNDataGridViewTextBoxColumn
            // 
            this.tsSyubetuSaiNameNDataGridViewTextBoxColumn.DataPropertyName = "TsSyubetuSaiNameN";
            this.tsSyubetuSaiNameNDataGridViewTextBoxColumn.HeaderText = "名称(細区分)";
            this.tsSyubetuSaiNameNDataGridViewTextBoxColumn.Name = "tsSyubetuSaiNameNDataGridViewTextBoxColumn";
            this.tsSyubetuSaiNameNDataGridViewTextBoxColumn.ReadOnly = true;
            this.tsSyubetuSaiNameNDataGridViewTextBoxColumn.Width = 201;
            // 
            // tsSyubetuSaiNoDataGridViewTextBoxColumn
            // 
            this.tsSyubetuSaiNoDataGridViewTextBoxColumn.DataPropertyName = "TsSyubetuSaiNo";
            this.tsSyubetuSaiNoDataGridViewTextBoxColumn.HeaderText = "番号(細区分)";
            this.tsSyubetuSaiNoDataGridViewTextBoxColumn.Name = "tsSyubetuSaiNoDataGridViewTextBoxColumn";
            this.tsSyubetuSaiNoDataGridViewTextBoxColumn.ReadOnly = true;
            this.tsSyubetuSaiNoDataGridViewTextBoxColumn.Width = 130;
            // 
            // bsTsSyubetuSai
            // 
            this.bsTsSyubetuSai.DataSource = typeof(Suisitu.Entity.TsSyubetuSaiEntity);
            // 
            // tsSyubetuDataGridViewTextBoxColumn
            // 
            this.tsSyubetuDataGridViewTextBoxColumn.DataPropertyName = "TsSyubetu";
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.tsSyubetuDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle1;
            this.tsSyubetuDataGridViewTextBoxColumn.HeaderText = "施設種別";
            this.tsSyubetuDataGridViewTextBoxColumn.Name = "tsSyubetuDataGridViewTextBoxColumn";
            this.tsSyubetuDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // tsSyubetuNameNDataGridViewTextBoxColumn
            // 
            this.tsSyubetuNameNDataGridViewTextBoxColumn.DataPropertyName = "TsSyubetuNameN";
            this.tsSyubetuNameNDataGridViewTextBoxColumn.HeaderText = "施設種別名称";
            this.tsSyubetuNameNDataGridViewTextBoxColumn.Name = "tsSyubetuNameNDataGridViewTextBoxColumn";
            this.tsSyubetuNameNDataGridViewTextBoxColumn.ReadOnly = true;
            this.tsSyubetuNameNDataGridViewTextBoxColumn.Width = 201;
            // 
            // tsSyubetuNoDataGridViewTextBoxColumn
            // 
            this.tsSyubetuNoDataGridViewTextBoxColumn.DataPropertyName = "TsSyubetuNo";
            this.tsSyubetuNoDataGridViewTextBoxColumn.HeaderText = "施設種別番号";
            this.tsSyubetuNoDataGridViewTextBoxColumn.Name = "tsSyubetuNoDataGridViewTextBoxColumn";
            this.tsSyubetuNoDataGridViewTextBoxColumn.ReadOnly = true;
            this.tsSyubetuNoDataGridViewTextBoxColumn.Width = 130;
            // 
            // bsTsSyubetu
            // 
            this.bsTsSyubetu.DataSource = typeof(Suisitu.Entity.TsSyubetuEntity);
            // 
            // TsSyubetu
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.ClientSize = new System.Drawing.Size(997, 722);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.btnReturn);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "TsSyubetu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "特定施設種別　保守画面";
            this.Load += new System.EventHandler(this.TsSyubetu_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTsSyubetu)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTsSyubetuSai)).EndInit();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bsTsSyubetuSai)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsTsSyubetu)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DataGridView dgvTsSyubetu;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btnSelect;
        private System.Windows.Forms.Button btnReturn;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.TextBox txtTsSyubetuNameN;
        private System.Windows.Forms.Button btnSetting;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Label lblTsSyubetuNameN;
        private System.Windows.Forms.CheckBox chkDelete;
        private Component.BackColorChangeOnFocusProvider backColorChangeOnFocusProvider1;
        private System.Windows.Forms.Label lblTsSyubetu;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button btnAddSai;
        private System.Windows.Forms.Button btnSelectSai;
        private System.Windows.Forms.DataGridView dgvTsSyubetuSai;
        private System.Windows.Forms.TextBox txtTsSyubetu;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.TextBox txtParent;
        private System.Windows.Forms.Label lblParent;
        private System.Windows.Forms.CheckBox chkDeleteSai;
        private System.Windows.Forms.Label lblTsSyubetuSaiNameN;
        private System.Windows.Forms.TextBox txtTsSyubetuSaiNameN;
        private System.Windows.Forms.Button btnSettingSai;
        private System.Windows.Forms.Button btnCancelSai;
        private System.Windows.Forms.TextBox txtTsSyubetuSai;
        private System.Windows.Forms.Label lblTsSyubetuSai;
        private System.Windows.Forms.Label lblTsSyubetuList;
        private System.Windows.Forms.Label lblTsSyubetuListLine;
        private System.Windows.Forms.Label lblTsSyubetuSaiListLine;
        private System.Windows.Forms.Label lblTsSyubetuSaiList;
        private System.Windows.Forms.BindingSource bsTsSyubetu;
        private System.Windows.Forms.BindingSource bsTsSyubetuSai;
        private System.Windows.Forms.Label lblTsSyubetuNo;
        private System.Windows.Forms.TextBox txtTsSyubetuNo;
        private System.Windows.Forms.TextBox txtTsSyubetuSaiNo;
        private System.Windows.Forms.Label lblTsSyubetuSaiNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn tsSyubetuDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn tsSyubetuNameNDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn tsSyubetuNoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn tsSyubetuSaiDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn tsSyubetuSaiNameNDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn tsSyubetuSaiNoDataGridViewTextBoxColumn;
    }
}