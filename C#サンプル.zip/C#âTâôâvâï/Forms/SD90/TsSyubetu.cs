﻿using Suisitu.Common;
using Suisitu.Dao;
using Suisitu.Entity;
using System;
using System.Windows.Forms;

namespace Suisitu.Forms.SD90
{
    using CommonEvents = Suisitu.Common.Events;

    /// <summary>
    /// 特定施設種別保守画面クラス
    /// </summary>
    public partial class TsSyubetu : Form
    {
        // 特定施設種別が追加モードかどうか
        private bool isInsert_ = false;
        // 特定施設種別（細区分）が追加モードかどうか
        private bool isInsertSai_ = false;

        #region コンストラクタ

        /// <summary>
        /// コンストラクタ
        /// </summary>
        public TsSyubetu()
        {
            InitializeComponent();

            // 左側の特定施設種別 半角英数字のみ入力可
            this.txtTsSyubetu.KeyPress += new KeyPressEventHandler(CommonEvents.txtHalfAll_KeyPress);
            // 左側の特定施設種別名称 全角のみ入力可
            this.txtTsSyubetuNameN.KeyPress += new KeyPressEventHandler(CommonEvents.txtFullAll_KeyPress);
            // 左側の特定施設種別番号 全角のみ入力可
            this.txtTsSyubetuNo.KeyPress += new KeyPressEventHandler(CommonEvents.txtFullAll_KeyPress);
            // 右側の特定施設種別 半角数字のみ入力可
            this.txtParent.KeyPress += new KeyPressEventHandler(CommonEvents.txtHalfNumber_KeyPress);
            // 右側の特定施設種別（細区分） 半角カタカナのみ入力可
            this.txtTsSyubetuSai.KeyPress += new KeyPressEventHandler(CommonEvents.txtHalfKatakana_KeyPress);
            // 右側の特定施設種別（細区分）名称 全角のみ入力可
            this.txtTsSyubetuSaiNameN.KeyPress += new KeyPressEventHandler(CommonEvents.txtFullAll_KeyPress);
            // 右側の特定施設種別番号 全角カタカナのみ入力可
            this.txtTsSyubetuSaiNo.KeyPress += new KeyPressEventHandler(CommonEvents.txtFullKatakana_KeyPress);
        }

        #endregion

        #region イベント

        /// <summary>
        /// 画面が表示されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void TsSyubetu_Load(object sender, EventArgs e)
        {
            // 特定施設種別のデータを取得
            bsTsSyubetu.DataSource = TsSyubetuDao.SelectAll();

            Clear();
            ClearSai();
        }

        /// <summary>
        /// 戻るボタンが押下されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnReturn_Click(object sender, EventArgs e)
        {
            Close();
        }

        /// <summary>
        /// 左側の選択ボタンが押下されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnSelect_Click(object sender, EventArgs e)
        {
            SelectedItem();
        }

        /// <summary>
        /// 左側のデータグリッドビューのセルがダブルクリックされたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void dgvTsSyubetu_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (bsTsSyubetu.Current != null)
                SelectedItem();
        }

        /// <summary>
        /// 左側の設定ボタンが押下されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnSetting_Click(object sender, EventArgs e)
        {
            TsSyubetuEntity entity = null;

            if (chkDelete.Checked)
            {
                TsSyubetuDao.Delete((TsSyubetuEntity)bsTsSyubetu.Current);
            }
            else
            {
                entity = new TsSyubetuEntity
                {
                    TsSyubetu = txtTsSyubetu.Text,
                    TsSyubetuNameN = txtTsSyubetuNameN.Text,
                    TsSyubetuNo = txtTsSyubetuNo.Text,
                    UpdDate = DateTime.Now.ToString(),
                    Rev = 1,
                };

                if (!Validation(entity))
                    return;

                // 追加モードの場合はInsert、それ以外はUpdateする
                if (this.isInsert_)
                {
                    TsSyubetuDao.Insert(entity);
                }
                else
                {
                    TsSyubetuDao.Update(entity);
                }
            }

            // 一覧をリフレッシュする
            bsTsSyubetu.DataSource = TsSyubetuDao.SelectAll();

            // 追加モードの場合は、追加行を選択行に設定する
            if (this.isInsert_)
            {
                int rowIndex = 0;

                foreach (DataGridViewRow row in dgvTsSyubetu.Rows)
                {
                    if (row.Cells[0].Value.ToString().Trim() == entity.TsSyubetu)
                    {
                        break;
                    }
                    rowIndex++;
                }
                dgvTsSyubetu.CurrentCell = dgvTsSyubetu[0, rowIndex];
            }

            // コントロールを初期化する
            Clear();
        }

        /// <summary>
        /// 左側の追加ボタンが押下されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnAdd_Click(object sender, EventArgs e)
        {
            // 特定施設種別を追加モードに設定する
            this.isInsert_ = true;

            // 左側下部のパネルのみ使用可とする
            panel1.Enabled = false;
            panel2.Enabled = true;
            panel3.Enabled = false;
            panel4.Enabled = false;

            // 戻るボタン：使用不可
            btnReturn.Enabled = false;
            // 左側の特定施設種別：入力可
            txtTsSyubetu.Enabled = true;
            // 左側の削除チェックボックス：使用不可
            chkDelete.Enabled = false;

            // 特定施設種別にフォーカスをセット
            txtTsSyubetu.Focus();
        }

        /// <summary>
        /// 左側のキャンセルボタンが押下されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnCancel_Click(object sender, EventArgs e)
        {
            Clear();
        }

        /// <summary>
        /// 左側のカレントセル変更時の処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void dgvTsSyubetu_CurrentCellChanged(object sender, EventArgs e)
        {
            // 選択行を取得する
            TsSyubetuEntity currentEntity = (TsSyubetuEntity)bsTsSyubetu.Current;

            // データがない場合は処理を抜ける（データがない場合のアボート対策）
            if (currentEntity == null)
            {
                currentEntity = new TsSyubetuEntity();
            }

            // 選択行の特定施設種別に該当する特定施設種別（細区分）を取得する
            bsTsSyubetuSai.DataSource = TsSyubetuSaiDao.SelectByParent(currentEntity);
            // 特定施設種別（細区分）を取得できた場合
            if (bsTsSyubetuSai.Count > 0)
            {
                // 特定施設種別（細区分）のカレントセルを先頭行とする
                dgvTsSyubetuSai.CurrentCell = dgvTsSyubetuSai[0, 0];
            }

            // 右側の選択ボタンの使用可/不可を設定する
            if (dgvTsSyubetuSai.Rows.Count == 0)
            {
                btnSelectSai.Enabled = false;
            }
            else
            {
                btnSelectSai.Enabled = true;
            }
        }

        /// <summary>
        /// 右側の選択ボタンが押下されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnSelectSai_Click(object sender, EventArgs e)
        {
            SelectedSaiItem();
        }

        /// <summary>
        /// 右側のデータグリッドビューのセルがダブルクリックされたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void dgvTsSyubetuSai_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (bsTsSyubetuSai.Current != null)
                SelectedSaiItem();
        }

        /// <summary>
        /// 右側の設定ボタンが押下されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnSettingSai_Click(object sender, EventArgs e)
        {
            TsSyubetuSaiEntity entity = null;

            if (chkDeleteSai.Checked)
            {
                TsSyubetuSaiDao.Delete((TsSyubetuSaiEntity)bsTsSyubetuSai.Current);
            }
            else
            {
                entity = new TsSyubetuSaiEntity
                {
                    TsSyubetuSai = txtParent.Text + txtTsSyubetuSai.Text,
                    TsSyubetuSaiNameN = txtTsSyubetuSaiNameN.Text,
                    TsSyubetuSaiNo = txtTsSyubetuSaiNo.Text,
                    Parent = txtParent.Text,
                    UpdDate = DateTime.Now.ToString(),
                    Rev = 1,
                };

                if (!ValidationSai(entity))
                    return;

                // 追加モードの場合はInsert、それ以外はUpdateする
                if (this.isInsertSai_)
                {
                    TsSyubetuSaiDao.Insert(entity);
                }
                else
                {
                    TsSyubetuSaiDao.Update(entity);
                }
            }

            // 一覧をリフレッシュする
            bsTsSyubetuSai.DataSource = TsSyubetuSaiDao.SelectByParent((TsSyubetuEntity)bsTsSyubetu.Current);

            // 追加モードの場合は、追加行を選択行に設定する
            if (this.isInsertSai_)
            {
                int rowIndex = 0;

                foreach (DataGridViewRow row in dgvTsSyubetuSai.Rows)
                {
                    if (row.Cells[0].Value.ToString().Trim() == entity.TsSyubetuSai)
                    {
                        break;
                    }
                    rowIndex++;
                }
                dgvTsSyubetuSai.CurrentCell = dgvTsSyubetuSai[0, rowIndex];
            }

            // コントロールを初期化する
            ClearSai();
        }

        /// <summary>
        /// 右側の追加ボタンが押下されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnAddSai_Click(object sender, EventArgs e)
        {
            // 左側の選択行を取得
            TsSyubetuEntity currentEntity = (TsSyubetuEntity)bsTsSyubetu.Current;

            // 選択行を取得できない場合は処理を抜ける（データがない場合のアボート対策）
            if (currentEntity == null)
            {
                return;
            }

            // 特定施設種別（細区分）を追加モードに設定する
            this.isInsertSai_ = true;

            // 右側下部のパネルのみ使用可とする
            panel1.Enabled = false;
            panel2.Enabled = false;
            panel3.Enabled = false;
            panel4.Enabled = true;

            // 戻るボタン：使用不可
            btnReturn.Enabled = false;
            // 右側の特定施設種別（細区分）：入力可
            txtTsSyubetuSai.Enabled = true;
            // 右側の削除チェックボックス：使用不可
            chkDeleteSai.Enabled = false;

            // 特定施設種別に左側で選択されているものと同じ値を設定する
            txtParent.Text = currentEntity.TsSyubetu;

            // 特定施設種別（細区分）にフォーカスをセット
            txtTsSyubetuSai.Focus();
        }

        /// <summary>
        /// 右側のキャンセルボタンが押下されたときの処理
        /// </summary>
        /// <param name="sender">メッセージの送信元</param>
        /// <param name="e">メッセージ</param>
        private void btnCancelSai_Click(object sender, EventArgs e)
        {
            ClearSai();
        }

        #endregion

        #region プライベートメソッド

        /// <summary>
        /// 特定施設種別のバリデーションをチェックします。
        /// </summary>
        /// <returns>True:チェックOK / False:チェックNG</returns>
        private bool Validation(TsSyubetuEntity entity)
        {
            // 特定施設種別
            // 必須入力チェック
            if (string.IsNullOrEmpty(entity.TsSyubetu.Trim()))
            {
                MessageUtils.NoInputDataMessage(CommonUtils.Trim(lblTsSyubetu.Text), Text);
                txtTsSyubetu.Focus();
                return false;
            }

            // 半角英数字チェック行う
            if (!ValidationUtils.ValidatetxtHalfAll(txtTsSyubetu.Text))
            {
                MessageUtils.ZenkakuHankakuMessage(CommonUtils.Trim(lblTsSyubetu.Text), 0, Text);
                txtTsSyubetu.Focus();
                return false;
            }

            // 全角文字チェック  特定施設種別名称
            if (!ValidationUtils.ValidateZenkaku(txtTsSyubetuNameN.Text) & !string.IsNullOrEmpty(txtTsSyubetuNameN.Text))
            {
                MessageUtils.ZenkakuHankakuMessage(CommonUtils.Trim(lblTsSyubetuNameN.Text), 1, Text);
                txtTsSyubetuNameN.Focus();
                return false;
            }

            // 全角文字チェック  特定施設種別番号
            if (!ValidationUtils.ValidateZenkaku(txtTsSyubetuNo.Text) & !string.IsNullOrEmpty(txtTsSyubetuNo.Text))
            {
                MessageUtils.ZenkakuHankakuMessage(CommonUtils.Trim(lblTsSyubetuNo.Text), 1, Text);
                txtTsSyubetuNo.Focus();
                return false;
            }

            // 存在チェック
            if (this.isInsert_)
            {
                if (TsSyubetuDao.Select(entity) != null)
                {
                    MessageUtils.Duplication(CommonUtils.Trim(lblTsSyubetu.Text), Text);
                    txtTsSyubetu.Focus();
                    return false;
                }
            }

            return true;
        }

        /// <summary>
        /// 特定施設種別（細区分）のバリデーションをチェックします。
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        private bool ValidationSai(TsSyubetuSaiEntity entity)
        {
            // 特定種別(細区分)
            // 必須チェック
            if (string.IsNullOrEmpty(txtTsSyubetuSai.Text.Trim()))
            {
                MessageUtils.NoInputDataMessage(CommonUtils.Trim(lblTsSyubetuSai.Text), Text);
                txtTsSyubetuSai.Focus();
                return false;
            }

            // 半角カタカナチェック行う
            if (!ValidationUtils.ValidatetxtHalfKatakana(txtTsSyubetuSai.Text))
            {
                MessageUtils.KatakanaMessage(CommonUtils.Trim(lblTsSyubetuSai.Text), 0, Text);
                txtTsSyubetuSai.Focus();
                return false;
            }

            // 全角文字チェック  特定施設種別(細区分)名称
            if (!ValidationUtils.ValidateZenkaku(txtTsSyubetuSaiNameN.Text) & !string.IsNullOrEmpty(txtTsSyubetuSaiNameN.Text))
            {
                MessageUtils.ZenkakuHankakuMessage(CommonUtils.Trim(lblTsSyubetuSaiNameN.Text), 1, Text);
                txtTsSyubetuSaiNameN.Focus();
                return false;
            }

            // 全角カタカナチェック  特定施設種別(細区分)番号
            if (!ValidationUtils.ValidatetxtFullKatakana(txtTsSyubetuSaiNo.Text) & !string.IsNullOrEmpty(txtTsSyubetuSaiNo.Text))
            {
                MessageUtils.KatakanaMessage(CommonUtils.Trim(lblTsSyubetuSaiNo.Text), 1, Text);
                txtTsSyubetuSaiNo.Focus();
                return false;
            }


            // 存在チェック
            if (this.isInsertSai_)
            {
                if (TsSyubetuSaiDao.SelectByTsSyubetuSai(entity) != null)
                {
                    MessageUtils.Duplication(CommonUtils.Trim(lblTsSyubetuSai.Text), Text);
                    txtTsSyubetuSai.Focus();
                    return false;
                }
            }

            return true;
        }

        /// <summary>
        /// 特定施設種別のクリア処理
        /// </summary>
        private void Clear()
        {
            // コントロールを初期値に戻す
            txtTsSyubetu.Text = "";
            txtTsSyubetuNameN.Text = "";
            txtTsSyubetuNo.Text = "";
            chkDelete.Checked = false;
            btnReturn.Enabled = true;

            // 左側の選択ボタンの使用可/不可を設定する
            if (dgvTsSyubetu.Rows.Count == 0)
            {
                btnSelect.Enabled = false;
            }
            else
            {
                btnSelect.Enabled = true;
            }

            // 右側の選択ボタンの使用可/不可を設定する
            if (dgvTsSyubetuSai.Rows.Count == 0)
            {
                btnSelectSai.Enabled = false;
            }
            else
            {
                btnSelectSai.Enabled = true;
            }

            // 一覧部分を操作可、編集部分を操作不可に設定する
            panel1.Enabled = true;
            panel2.Enabled = false;
            panel3.Enabled = true;
            panel4.Enabled = false;

            this.isInsert_ = false;
        }

        /// <summary>
        /// 特定施設種別の一覧からアイテムが選択されたときの処理
        /// </summary>
        private void SelectedItem()
        {
            // 選択行を取得する
            TsSyubetuEntity currentEntity = (TsSyubetuEntity)bsTsSyubetu.Current;

            // 選択行を取得できない場合は処理を抜ける（データがない場合のアボート対策）
            if (currentEntity == null)
            {
                return;
            }

            // 左側下部のパネルのみ使用可とする
            panel1.Enabled = false;
            panel2.Enabled = true;
            panel3.Enabled = false;
            panel4.Enabled = false;

            // 戻るボタン：使用不可
            btnReturn.Enabled = false;
            // 左側の削除チェックボックス：使用可
            chkDelete.Enabled = true;
            // 左側の特定施設種別：使用不可
            txtTsSyubetu.Enabled = false;

            // 特定施設種別
            txtTsSyubetu.Text = currentEntity.TsSyubetu;
            // 特定施設種別名称
            txtTsSyubetuNameN.Text = currentEntity.TsSyubetuNameN;
            // 特定施設種別番号
            txtTsSyubetuNo.Text = currentEntity.TsSyubetuNo;
            // 特定施設種別名称にフォーカスをセット
            txtTsSyubetuNameN.Focus();
        }

        /// <summary>
        /// 特定施設種別（細区分）のクリア処理
        /// </summary>
        private void ClearSai()
        {
            // コントロールを初期値に戻す
            txtParent.Text = "";
            txtTsSyubetuSai.Text = "";
            txtTsSyubetuSaiNameN.Text = "";
            txtTsSyubetuSaiNo.Text = "";
            chkDeleteSai.Checked = false;
            btnReturn.Enabled = true;

            // 左側の選択ボタンの使用可/不可を設定する
            if (dgvTsSyubetu.Rows.Count == 0)
            {
                btnSelect.Enabled = false;
            }
            else
            {
                btnSelect.Enabled = true;
            }

            // 右側の選択ボタンの使用可/不可を設定する
            if (dgvTsSyubetuSai.Rows.Count == 0)
            {
                btnSelectSai.Enabled = false;
            }
            else
            {
                btnSelectSai.Enabled = true;
            }

            // 一覧部分を操作可、編集部分を操作不可に設定する
            panel1.Enabled = true;
            panel2.Enabled = false;
            panel3.Enabled = true;
            panel4.Enabled = false;
            
            this.isInsertSai_ = false;
        }

        /// <summary>
        /// 特定施設種別（細区分）の一覧からアイテムが選択されたときの処理
        /// </summary>
        private void SelectedSaiItem()
        {
            // 選択行を取得する
            TsSyubetuSaiEntity currentEntity = (TsSyubetuSaiEntity)bsTsSyubetuSai.Current;

            // 選択行を取得できない場合は処理を抜ける（データがない場合のアボート対策）
            if (currentEntity == null)
            {
                return;
            }

            // 右側下部のパネルのみ使用可とする
            panel1.Enabled = false;
            panel2.Enabled = false;
            panel3.Enabled = false;
            panel4.Enabled = true;

            // 戻るボタン：使用不可
            btnReturn.Enabled = false;
            // 右側の削除チェックボックス：使用可
            chkDeleteSai.Enabled = true;
            // 右側の特定施設種別（細区分）名称：使用不可
            txtTsSyubetuSai.Enabled = false;

            // 特定施設種別
            txtParent.Text = currentEntity.Parent;
            // 特定施設種別（細区分）
            txtTsSyubetuSai.Text = currentEntity.TsSyubetuSai.Substring(currentEntity.TsSyubetuSai.Length - 1, 1);
            // 特定施設種別（細区分）名称
            txtTsSyubetuSaiNameN.Text = currentEntity.TsSyubetuSaiNameN;
            // 特定施設種別（細区分）番号
            txtTsSyubetuSaiNo.Text = currentEntity.TsSyubetuSaiNo;
            // 特定施設種別（細区分）名称にフォーカスをセット
            txtTsSyubetuSaiNameN.Focus();
        }

        #endregion
    }
}
